# LAWDS - added parameter "field" or "field_on_switch_in" to many functions so that AI can run checks according to whatever field they set it to on switching in via trainer effect
class AI_MonData
	attr_accessor	:index		#To help ensure we keep the right data with the right battler
	attr_accessor	:roles		#This is for roles that belong to the current battler
	attr_accessor	:trainer
	attr_accessor	:partyroles  #This is for roles that belong to the entire party
	attr_accessor	:skill
	attr_accessor	:party
	attr_accessor	:scorearray
	attr_accessor	:roughdamagearray
	attr_accessor	:itemscore
	attr_accessor	:shouldswitchscore
	attr_accessor	:switchscore
	attr_accessor	:shouldMegaOrUltraBurst
	attr_accessor	:zmove
	attr_accessor	:attitemworks
	attr_accessor	:oppitemworks
	attr_accessor	:sameopps # lawds tracks if the playerside is the same as when the partner was scoring switch-ins
	

	def initialize(trainer, index,battle)
		@trainer	= trainer
		@index 		= index
		@skill 		= trainer.nil? ? 0 : trainer.skill
		@party 		= trainer.nil? ? [] : battle.pbPartySingleOwner(index)
		@roles 		= []
		#fuckin double battles
		#there are four move arrays, but one of them doesn't get used depending on the index of the aimon
		@scorearray = [[-1,-1,-1,-1],[-1,-1,-1,-1],[-1,-1,-1,-1],[-1,-1,-1,-1]]
		@roughdamagearray = [[-1,-1,-1,-1],[-1,-1,-1,-1],[-1,-1,-1,-1],[-1,-1,-1,-1]]	#again, for doubles...
		@itemscore = {}
		@switchscore = []
		@shouldswitchscore = -10000
		@shouldMegaOrUltraBurst = false
		@zmove = nil
		@attitemworks = true
		@oppitemworks = true
		@sameopps = [nil,nil]
	end
end

class PokeBattle_AI
	attr_accessor		:battle					#Current battle the AI is pulling from 			(PokeBattle_Battle)
	attr_accessor		:move					#Current move being scored						(PokeBattle_Move)
	attr_accessor		:attacker				#User of the current move being scored			(PokeBattle_Battler)
	attr_accessor		:opponent				#Opposing pokemon that the move will be used on	(PokeBattle_Battler)
	attr_accessor		:aimondata				#Array of all trainers in the battle			(AI_PokemonData)
	attr_accessor		:mondata				#Current trainer being processed				(AI_PokemonData)
	attr_accessor		:miniscore				#holder for the miniscore						#Number
	attr_accessor		:score					#holder for the score-score						#Number
	attr_accessor		:index					#index of the battler being evaluated			#Number
	attr_accessor		:aiMoveMemory			#Moves the AI knows about						#Array of move numbers
	attr_accessor		:initial_scores			#scores of all moves for a target				#Array of scores
	attr_accessor		:score_index			#index of current move being evaluated
	attr_accessor		:player_damage_array    #lawds tracks player kill data
	attr_accessor		:AI_Matchup_Spread		#lawds an array set up at start-of-battle to get a general idea of how valuable a mon is, used when weighing switching
	attr_accessor		:Player_Matchup_Array   #lawds an array that, for each player mon, finds the sum of matchup scores for each AI mon, used for weighted matchups
	attr_accessor		:gonnaTerrains		    #lawds array of terrains that will be set by abilities/trainer effects on switch-in
	attr_accessor		:gonnaWeather			#lawds weather that will be set by abilities on switch-in

	#We can adjust the thresholds as we work on things
	# LAWDS everything is best skill now
	MINIMUMSKILL = 1
	LOWSKILL = 10
	MEDIUMSKILL = 30
	HIGHSKILL = 60
	BESTSKILL = -1000

	#Function codes you might want to use on your partner.
	PARTNERFUNCTIONS = [0x40,0x41,0x55,0x63,0x66,0x67,0xA0,0xC1,
		0xDF,0x142,0x162,0x164,0x167,0x169,0x170,0x11d,0x185,0x317]
	#Swagger, Flatter, Psych Up, Simple Beam, Entrainment, Skill Swap, Frost Breath, Beat Up,
	#Heal Pulse, Topsy-Turvy, Floral Healing, Instruct, Pollen Puff, Purify, Spotlight, After You

	######################################################
	# Core functions
	######################################################
	#Do what we can to setup at the start of the battle

	def initialize(battle)
		@battle 			= battle
		@aimondata 		= [nil,nil,nil,nil]
		@aiMoveMemory = {}
		@gonnaTerrains = []
		@gonnaWeather = 0
		player = @battle.player
		opponent = @battle.opponent
		if @battle.doublebattle
			if player.is_a?(Array)
				@aimondata[0] = AI_MonData.new(player[0],0,@battle)
				@aimondata[2] = AI_MonData.new(player[1],2,@battle)
				@aiMoveMemory[player[0]] = {}
				@aiMoveMemory[player[1]] = {}
			else
				@aimondata[0] = AI_MonData.new(player,0,@battle)
				@aimondata[2] = AI_MonData.new(player,2,@battle)
				@aiMoveMemory[player] = {}
			end
			if opponent && opponent.is_a?(Array)
				@aimondata[1] = AI_MonData.new(opponent[0],1,@battle)
				@aimondata[3] = AI_MonData.new(opponent[1],3,@battle)
				@aiMoveMemory[opponent[0]] = {}
				@aiMoveMemory[opponent[1]] = {}
			elsif opponent 
				@aimondata[1] = AI_MonData.new(opponent,1,@battle)
				@aimondata[3] = AI_MonData.new(opponent,3,@battle)
				@aiMoveMemory[opponent] = {}
			else
				@aimondata[1] = AI_MonData.new(nil,1,@battle)
				@aimondata[3] = AI_MonData.new(nil,3,@battle)
			end
		else
			@aimondata[0] = AI_MonData.new(player,0,@battle)
			@aiMoveMemory[player] = {}
			if @battle.opponent
				@aimondata[1] = AI_MonData.new(opponent,1,@battle)
				@aiMoveMemory[opponent] = {}
			else
				@aimondata[1] = AI_MonData.new(nil,1,@battle)
			end
		end
		#Having set up the data objects, get their roles (if applicable)
		for data in @aimondata
			next if data.nil?
			@mondata = data
			@mondata.partyroles = (@mondata.skill >= HIGHSKILL) ? pbGetMonRoles : Array.new(@mondata.party.length) {Array.new()}
		end
	end

	def pbGetFieldOnSwitchIn(trainer, pkmn, checkDelayed = false) # LAWDS gets the field on switch-in due to trainer effects, mainly for saki. WIP
		field_on_switch_in = @battle.field.effect
		return field_on_switch_in if @battle.opponent==nil || @battle.opponent.is_a?(Array) # just dont worry about multibattles.
		return field_on_switch_in if trainer.trainereffect==nil
		if trainer.trainereffect[:effectmode]!=nil
			if trainer.trainereffect[:effectmode] == :Party
				trainereffect = trainer.trainereffect[pkmn.pokemonIndex]
			elsif trainer.trainereffect[:effectmode] == :Fainted
				trainereffect = trainer.trainereffect[pkmn.pbFaintedPokemonCount]
			end
			if trainereffect && (trainer.trainereffect[:buffactivation] == :Always)
				if trainereffect[:fieldChange]
					field_on_switch_in = trainereffect[:fieldChange][0]
					return field_on_switch_in if !checkDelayed
					if trainereffect[:delayedaction] && trainereffect[:delayedaction][:delay]==1
						if trainereffect[:delayedaction][:fieldChange]
							if trainereffect[:delayedaction][:fieldChange][0]!=field_on_switch_in
								field_on_switch_in = trainereffect[:delayedaction][:fieldChange][0]
							end
						end
					end
				end
			end
		end
		return field_on_switch_in
	end

	def pbGetMatchupArray(opponent=@battle.opponent) # LAWDS gets the matchup array for the current party.
		#cprint "Recalculating team matchups.\n"
		@gonnaTerrains = []
		@gonnaWeather = 0
		if opponent!=nil
			num_ai_mons = 0
			num_player_mons = 0
			if !opponent.is_a?(Array)
				ai_temp_Party = @battle.pbParty(1)
				ai_temp_Party_2 = []
			else
				ai_temp_Party = @battle.pbPartySingleOwner(1)
				ai_temp_Party_2 = @battle.pbPartySingleOwner(3)
			end
			player_temp_Party = @battle.pbParty(0)
			for partyindex in 0...player_temp_Party.length
				playermon = player_temp_Party[partyindex]
				num_player_mons+=1 if playermon!=nil && playermon.hp > 0 && !playermon.isEgg?
			end
			aiParty = []
			for partyindex in 0...ai_temp_Party.length
				aimon = ai_temp_Party[partyindex]
				aiParty.push(aimon)
				num_ai_mons+=1 if aimon!=nil && aimon.hp > 0 && !aimon.isEgg?
			end
			for partyindex in 0...ai_temp_Party_2.length
				aimon = ai_temp_Party[partyindex]
				aiParty.push(aimon)
				num_ai_mons+=1 if aimon!=nil && aimon.hp > 0 && !aimon.isEgg?
			end
			score_multiplier = 6.0/(num_player_mons.to_f) * 6.0/(num_ai_mons.to_f)
			@AI_Matchup_Spread = Array.new(aiParty.length)
			@Player_Matchup_Array = Array.new(player_temp_Party.length,0)
			for partyindex in 0...aiParty.length
				aimon = aiParty[partyindex]
				#cprint "Generating matchup array for #{getMonName(aimon.species)} in party position #{partyindex}\n"
				if aimon==nil || aimon.hp <= 0 || aimon.isEgg?
					mon_matchup = Array.new(player_temp_Party.length,0)
					@AI_Matchup_Spread[partyindex]=mon_matchup
					#cprint "\n"
					next
				end

				aiBattler = pbMakeFakeBattler(aimon,partyindex,false,1)
				if ai_temp_Party_2.length > 0 && partyindex > 5
					aiOwner = @battle.pbGetOwner(3)
					effect_index = partyindex - 6
				else
					aiOwner = @battle.pbGetOwner(1)
					effect_index = partyindex
				end
				field_on_switch_in = pbGetFieldOnSwitchIn(aiOwner, aiBattler) # initial field change
				#cprint "Getting switch-in boosts for #{getMonName(aimon.species)} after field change\n" if field_on_switch_in != @battle.field.effect
				aiBattler = pbStatChangingSwitch(aiBattler,field_on_switch_in)
				delayed_field = pbGetFieldOnSwitchIn(aiOwner, aiBattler, true) # delayed field change
				#cprint "Getting switch-in boosts for #{getMonName(aimon.species)} after delayed change\n" if field_on_switch_in != delayed_field
				field_on_switch_in = delayed_field
				hazpercent = (totalHazardDamage(aiBattler,field_on_switch_in).to_f)/100
				aiBattler.hp -= (hazpercent*(aiBattler.totalhp))
				if aiBattler.hp<=0
					mon_matchup = Array.new(player_temp_Party.length,0)
					@AI_Matchup_Spread[partyindex]=mon_matchup
					next
				end
				if aiBattler.hasMega?
					aiBattler.pokemon.makeMega
					aiBattler.form=aiBattler.pokemon.form
					aiBattler.backupability= aiBattler.pokemon.ability 
					aiBattler.pbUpdate(true)
				end
				aiBattler.stages[PBStats::SPEED]+=1 if aiBattler.stages[PBStats::SPEED]<6 && (aiBattler.ability==:SPEEDBOOST || (@battle.FE==:ELECTERRAIN && aiBattler.ability==:MOTORDRIVE)) && (aiBattler.pbHasMove?(:PROTECT) || aiBattler.pbHasMove?(:DETECT)) # see speed boosts
				monRoles = pbGetMonRoles(aiBattler)
				mon_matchup = Array.new(player_temp_Party.length)
				for playerPartyIndex in 0...player_temp_Party.length
					thisMatchup=0
					playermon = player_temp_Party[playerPartyIndex]
					if playermon==nil || playermon.hp <= 0 || playermon.isEgg?
						mon_matchup[playerPartyIndex]=0
						next 
					end
					playerBattler = pbMakeFakeBattler(playermon,playerPartyIndex,false,0)
					pbStatChangingSwitch(playerBattler,field_on_switch_in)
					hazpercent = (totalHazardDamage(playerBattler,field_on_switch_in).to_f)/100
					playerBattler.hp -= (hazpercent*(playerBattler.totalhp))
					playerBattler.stages[PBStats::SPEED]+=1 if playerBattler.stages[PBStats::SPEED]<6 && (playerBattler.ability==:SPEEDBOOST || (@battle.FE==:ELECTERRAIN && playerBattler.ability==:MOTORDRIVE)) && (playerBattler.pbHasMove?(:PROTECT) || playerBattler.pbHasMove?(:DETECT)) # see speed boosts
					if playerBattler.hp<=0
						mon_matchup[playerPartyIndex]=0
						next 
					end
					if monRoles.include?(:SWEEPER)
						faster = pbAIfaster?(nil,nil,aiBattler,playerBattler,field_on_switch_in)
						bestmove,maxdamage = checkAIMovePlusDamage(aiBattler,playerBattler,nil,field_on_switch_in)
						if faster && maxdamage>=playerBattler.hp # outspeeds and KOs
							thisMatchup+=0.75
						elsif faster && maxdamage >= playerBattler.hp/2 # outspeeds and does heavy damage
							thisMatchup+=0.25
							thisMatchup+=0.25 if checkAIdamage(aiBattler,playerBattler,nil,field_on_switch_in) < (aiBattler.hp*0.7).floor
						elsif maxdamage >= playerBattler.hp # lives a hit and KOs
							playerdamage = checkAIdamage(aiBattler,playerBattler,nil,field_on_switch_in)
							thisMatchup += 0.25 if playerdamage < aiBattler.hp
							thisMatchup += 0.25 if playerdamage < aiBattler.hp/2
						end
						if faster && thisMatchup > 0 && !prioBlocked?(aiBattler,playerBattler) # check priority
							maxpriodamage = 0
							for playermove in playerBattler.moves
								next if playermove==nil || playermove.basedamage==0
								next if !playermove.pbIsPriorityMoveAI(playerBattler)
								next if pbAIfaster?(bestmove,playermove,aiBattler,playerBattler,field_on_switch_in)
								if playermove.move==:FIRSTIMPRESSION || playermove.move==:FAKEOUT
									maxpriodamage = ((aiBattler.pbHasMove?(:PROTECT) || aiBattler.pbHasMove?(:DETECT)) && (field_on_switch_in!=:COLOSSEUM || playermove.move==:FAKEOUT)) ? 0 : pbRoughDamage(playermove,playerBattler,aiBattler,false,nil,field_on_switch_in)
								else
									maxpriodamage = pbRoughDamage(playermove,playerBattler,aiBattler,true,nil,field_on_switch_in)
								end
							end
							thisMatchup +=0.25 if maxpriodamage < aiBattler.hp/2
							thisMatchup +=0.25 if maxpriodamage==0
							thisMatchup=0 if maxpriodamage >= aiBattler.hp
						end
						# check for first impression
						if thisMatchup < 1.25 && maxdamage >= playerBattler.hp && aiBattler.pbHasMove?(:FIRSTIMPRESSION) && 
						   bestmove.move!=:FIRSTIMPRESSION && !prioBlocked?(playerBattler,aiBattler) && 
						   (field_on_switch_in==:COLOSSEUM || !(playerBattler.pbHasMove?(:PROTECT) || 
						   playerBattler.pbHasMove?(:DETECT) || playerBattler.pbHasMove?(:SPIKYSHIELD) || playerBattler.pbHasMove?(:BANEFULBUNKER)))
							impressionmove = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(:FIRSTIMPRESSION),aiBattler)
							if pbAIfaster?(impressionmove, nil, aiBattler,playerBattler,field_on_switch_in) && pbRoughDamage(impressionmove,aiBattler,playerBattler,true,nil,field_on_switch_in) > playerBattler.hp
								thisMatchup=1.25
							end
						end
						thisMatchup = thisMatchup * score_multiplier
						thisMatchup = thisMatchup.round(3) # round to 3 decimal places
						mon_matchup[playerPartyIndex]=thisMatchup
						@Player_Matchup_Array[playerPartyIndex]+=thisMatchup
						#cprint "Matchup for #{getMonName(aimon.species)} against mon in party position #{playerPartyIndex}: #{thisMatchup}\n"
					else
						bestmove,maxdamage = checkAIMovePlusDamage(aiBattler,playerBattler,nil,field_on_switch_in)
						bestplayermove,playerdamage = checkAIMovePlusDamage(playerBattler,aiBattler,nil,field_on_switch_in)
						maxdamage = maxdamage.to_f
						playerdamage = playerdamage.to_f
						matchupmult = maxdamage/((playerBattler.hp).to_f)
						matchupmult = 1.0 if matchupmult > 1.0
						matchupdivider = playerdamage/((aiBattler.hp).to_f)
						matchupdivider = 0.1 if matchupdivider < 0.1
						matchupdivider = 1.0 if matchupdivider > 1.0
						thisMatchup = 0.25 * matchupmult/matchupdivider
						thisMatchup = 1.0 if thisMatchup > 1.0
						faster = pbAIfaster?(bestmove,bestplayermove,aiBattler,playerBattler,field_on_switch_in)
						
						thisMatchup = 1.0 if maxdamage >= playerBattler.hp && faster
						thisMatchup = 0 if playerdamage >= aiBattler.hp && !faster
						# check for first impression
						if thisMatchup < 1.0 && aiBattler.pbHasMove?(:FIRSTIMPRESSION) && bestmove.move!=:FIRSTIMPRESSION && !prioBlocked?(playerBattler,aiBattler) && (field_on_switch_in==:COLOSSEUM || !(playerBattler.pbHasMove?(:PROTECT) || playerBattler.pbHasMove?(:DETECT) || playerBattler.pbHasMove?(:SPIKYSHIELD) || playerBattler.pbHasMove?(:SPIKYSHIELD)))
							impressionmove = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(:FIRSTIMPRESSION),aiBattler)
							if pbAIfaster?(impressionmove, bestplayermove, aiBattler,playerBattler,field_on_switch_in) && pbRoughDamage(impressionmove,aiBattler,playerBattler,true,nil,field_on_switch_in) > playerBattler.hp
								thisMatchup=1.0
							end
						end
						thisMatchup = thisMatchup * score_multiplier
						thisMatchup = thisMatchup.round(3) # round to 3 decimal places
						mon_matchup[playerPartyIndex]=thisMatchup
						@Player_Matchup_Array[playerPartyIndex]+=thisMatchup
					end
				end
				@AI_Matchup_Spread[partyindex]=mon_matchup
			end
		end
		@gonnaTerrains = []
		@gonnaWeather = 0
	end

	def getPokemonMatchupTotal(pkmn) # LAWDS gets the sum of matchup scores of the specified battler into all playerside pokemon left alive
		return 1 if !@AI_Matchup_Spread
		return 1 if !@Player_Matchup_Array
		return 1 if !@battle.opponent
		return 1 if !(pkmn.index==1 || pkmn.index==3)
		party = @battle.party2
		partyindex=pkmn.pokemonIndex
		#cprint "Weighing matchup spread for party index: #{partyindex}\n"
		playerparty = @battle.pbParty(0)
		matchuparray = @AI_Matchup_Spread[partyindex]
		return 1 if matchuparray == nil # quick band-aid for a weird error that cropped up, not a huge deal, only affects some pokemon in multibattles, will fix later
		weightedtotal = 0
		for i in 0...playerparty.length
			playermon = playerparty[i]
			next if playermon==nil || playermon.hp <= 0 || playermon.isEgg? || @Player_Matchup_Array[i]==0
			matchup = matchuparray[i].round(3)
			
			matchup_weight = (matchup/(@Player_Matchup_Array[i])).round(3) # weigh each matchup according to how many other mons in the AI party also have a good matchup into that player mon
			matchup = (matchup*matchup_weight*2.0).round(3)
			weightedtotal += matchup
		end
		return (weightedtotal).round(3)
	end

	def getPokemonMatchupArray(pkmn) # LAWDS get the matchup array for a mon
		return 1 if !@AI_Matchup_Spread
		return 1 if !@Player_Matchup_Array
		return 1 if !@battle.opponent
		return 1 if !(pkmn.index==1 || pkmn.index==3)
		party = @battle.party2
		partyindex=pkmn.pokemonIndex
		#cprint "Weighing matchup spread for party index: #{partyindex}\n"
		playerparty = @battle.pbParty(0)
		matchuparray = @AI_Matchup_Spread[partyindex]
		return matchuparray
	end

	def processAIturn # lawds significantly changed the order of operations here in order to make it work more efficiently with my new code
		#Get the scores for each mon in battle
		# LAWDS - if player has an AI partner, build its scores last
		@sameopps = [nil,nil]
		if @battle.doublebattle
			if @battle.pbOwnedByPlayer?(2)
				monarray = [0, 1, 2, 3]
				aiPartner = false
			else
				monarray = [0, 1, 3, 2]
				aiPartner = true
			end
		else
			monarray = [0, 1, 2, 3]
			aiPartner = false
		end
		# LAWDS clear AI mon data before any scoring is done, so that initial damage matrixes are always accurate or empty
		for index in monarray
			next if @aimondata[index].nil?
			clearMonDataTurn(@aimondata[index])
			#cprint "Clearing mon data for index #{index}\n"
		end
		@gonnaTerrains = []
		@gonnaWeather = 0
		pbGetMatchupArray() if $game_variables[:DifficultyModes]!=1 && (@battle.party2.length < 12)
		for index in monarray
			next if @aimondata[index].nil?
			next if !@battle.pbCanShowCommands?(index) || @battle.battlers[index].hp == 0
			next if @battle.pbOwnedByPlayer?(index) && !@battle.controlPlayer
			@mondata = @aimondata[index]
			#load up the class variables
			@index = index
			@attacker = pbCloneBattler(@index)
			$ai_log_data[index].reset(@attacker) #AI data collection
			@opponent = @attacker.pbOppositeOpposing
			@mondata.roles = pbGetMonRoles(@attacker)
			#Check for conditions where the attacker object is not the one we want to score
			checkMega()
			checkUltraBurst()
			#Actually get the scores
			checkZMoves()

			buildMoveScores(true) # lawds get ONLY damage of moves, no scoring. this is so we know the damage arrays of all battlers before any other processing is done, so we only have to calculate them once
			buildPlayerDamageArray if aiPartner==true && index==2 # LAWDS - player's AI partner should be scored last
			# set @opponent for switchingscore
			@opponent = pbCloneBattler(firstOpponent().index, illusionCheck(firstOpponent(), @battle.battlers[firstOpponent().index]))
			getSwitchingScore() # do switching score before move scores so prio scores can be done easier
			# set @opponent for move scoring
			@opponent = @attacker.pbOppositeOpposing
			buildMoveScores() # lawds here we get move scores, without recollecting damage

			# lawds - in doubles, we only grab the switching score array after seeing that the switching score is higher than the max move score, to minimize the number of redundant party scans.
			# logic here mimics chooseAction cause im lazy
			if @battle.doublebattle
				score_array = @mondata.scorearray
				score_array.map! {|scorelist| scorelist.map! {|score| score < 0 ? -1 : score}}
				moves = findChoosableMoves(@attacker,@mondata)
				moves = moves.find_all {|arrays| arrays[:score] >= 0}

				if moves.length !=0
					maxmovescore = moves.max {|a1,a2| a1[:score]<=>a2[:score]}[:score] rescue 0
				else
					maxmovescore = 0
				end
				if @mondata.shouldswitchscore > maxmovescore && @mondata.shouldswitchscore > 50
					@opponent = pbCloneBattler(firstOpponent().index, illusionCheck(firstOpponent(), @battle.battlers[firstOpponent().index]))
					@mondata.switchscore = getSwitchInScoresParty(true)
				end
			end
			#we set @opponent for Itemscore and Switchingscore
			@opponent = pbCloneBattler(firstOpponent().index, illusionCheck(firstOpponent(), @battle.battlers[firstOpponent().index]))
			getItemScore()
		end
		#Coordination if there are two mons on the same side
		coordinateActions() if @battle.doublebattle
		#At this point, the processing is done and the AI should register its decisions
		#but i don't know how to do that, and i think we can do it from the battle side anyway
		#so as far as the ai code is concerned, we're done now.
		#We have the scores, now we decide what we want to do with them
		chooseAction()
		# lawds make sure we are ALWAYS setting this shit back
		@gonnaTerrains = []
		@gonnaWeather = 0
	end

	def pbCloneBattler(index, illusion = false)
		return nil if @battle.battlers[index]==nil # LAWDS just return nil if no battler
		original = illusion ? @battle.battlers[index].effects[:Illusion] : @battle.battlers[index]
		battler = original.clone
		battler.pokemon = original.pokemon.clone
		battler.form = original.form.clone
		battler.pokemon.hp = original.pokemon.hp.clone if original.pokemon!=nil # lawds
		battler.moves = original.moves.clone
		for i in 0...original.moves.length
		  battler.moves[i] = original.moves[i].clone
		end
		battler.stages = original.stages.clone
		for i in 0...original.stages.length
		  battler.stages[i] = original.stages[i].clone
		end
		battler.effects = original.effects.clone
		battler.effects[:Illusion] = nil # need to make absolutely sure there isn't anything pointing at the "real" illusion copy
		return battler
	end

	def clearMonDataTurn(mondata)
		mondata.shouldMegaOrUltraBurst = false
		mondata.scorearray = [[-1,-1,-1,-1],[-1,-1,-1,-1],[-1,-1,-1,-1],[-1,-1,-1,-1]]
		mondata.roughdamagearray = [[-1,-1,-1,-1],[-1,-1,-1,-1],[-1,-1,-1,-1],[-1,-1,-1,-1]]
		mondata.itemscore = {}
		mondata.switchscore = []
		mondata.shouldswitchscore = -10000
		mondata.zmove = nil
	end

	def checkMega(battler=@attacker,field=@battle.FE)
		is_attacker = battler==@attacker
		return false if battler==nil
		return false if !battler.is_a?(PokeBattle_Battler)
		return false if !@battle.pbCanMegaEvolve?(battler.index)
		want_to_mega=true
		# LAWDS get a dummy of the mega evolved battler to make decisions with.
		# make sure all attributes are cloned so nothing points at the base form battler object
		megaform = battler.clone
		megaform.pokemon = battler.pokemon.clone
		megaform.pokemon.ability = battler.pokemon.ability.clone
		megaform.pokemon.ability.ability = battler.pokemon.ability.ability.clone
		megaform.pokemon.hp = battler.pokemon.hp.clone
		megaform.moves = battler.moves.clone
		for i in 0...battler.moves.length
			megaform.moves[i] = battler.moves[i].clone
		end
		megaform.stages = battler.stages.clone
		for i in 0...battler.stages.length
		    megaform.stages[i] = battler.stages[i].clone
		end
		megaform.effects = battler.effects.clone
		megaform.pokemon.makeMega
		megaform.form = megaform.pokemon.form
		megaform.pbUpdate(true)
		megaform = pbStatChangingSwitch(megaform,field,mega: true)
		#Run through conditions to see if you don't want to mega

		# LAWDS delayed mega AI. written on a case-by-case basis.
		case battler.species
		when :ALCREMIE # dont mega if your partner wont benefit from the speed boost
			if @battle.doublebattle && battler.pbPartner.hp > 0
				faster1 = pbAIfaster?(nil,nil,battler.pbPartner,battler.pbOpposing1)
				faster2 = pbAIfaster?(nil,nil,battler.pbPartner,battler.pbOpposing2)
				partner = pbCloneBattler(battler.pbPartner.index)
				partner.stages[PBStats::SPEED]+=1 if battler.pbPartner.stages[PBStats::SPEED] < 6
				want_to_mega = false unless (!faster1 && pbAIfaster?(nil,nil,partner,battler.pbOpposing1)) || (!faster2 && pbAIfaster?(nil,nil,partner,battler.pbOpposing2))
				want_to_mega = false if want_to_mega && checkAIdamage(battler.pbOpposing1,partner)<battler.pbOpposing1.hp*0.5 && checkAIdamage(battler.pbOpposing2,partner)<battler.pbOpposing2.hp*0.5
			end
			want_to_mega = true if (checkAIdamage(battler,battler.pbOpposing1) + checkAIdamage(battler,battler.pbOpposing2)) >= battler.hp

		when :CORVIKNIGHT
			if field==:STARLIGHT && @battle.doublebattle && battler.effects[:FollowMe]==true && $game_variables[:DifficultyModes]==2 && battler.pbPartner.hp > 0
				# if we can survive a turn, dont mega until the next turn.
				dam1 = checkAIdamage(battler,battler.pbOpposing1)
				firstdies = pbAIfaster?(nil,nil,battler.pbPartner,battler.pbOpposing1) && checkAIdamage(battler.pbOpposing1,battler.pbPartner) > battler.pbOpposing2.hp
				dam2 = checkAIdamage(battler,battler.pbOpposing2)
				seconddies = pbAIfaster?(nil,nil,battler.pbPartner,battler.pbOpposing2) && checkAIdamage(battler.pbOpposing2,battler.pbPartner) > battler.pbOpposing2.hp
				if dam1 + dam2 < battler.hp || (dam2 < battler.hp && dam1 < battler.hp && (firstdies || seconddies))
					want_to_mega = false 
				end
			end
		when :LOPUNNY
			if field==:DRAGONSDEN && battler.pbHasMove?(:FAKEOUT) && battler.turncount==0 && battler.ability==:KLUTZ && !@battle.doublebattle && !battler.pokemon.klutzUsed
				opp = @battle.battlers[0]
				ffout = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(:FAKEOUT),battler)
				if !secondaryEffectNegated?(ffout,battler,opp) && opp.ability!=:INNERFOCUS && !prioBlocked?(opp,battler) && opp.pbCanBurn?(false) && ![:GUTS,:FLAREBOOST,:QUICKFEET].include?(opp.ability) && !(pbAIfaster?(nil,nil,megaform,opp) && checkAIdamage(opp,megaform) >= opp.hp && !checkAIpriority(nil,opp))
					want_to_mega = false
				end
			end
		end
		# lawds dont mega evolve into a worse matchup
		if want_to_mega && !@battle.doublebattle && $game_variables[:DifficultyModes]!=1 && !@battle.pbOwnedByPlayer?(battler.index)
			opp = battler.pbOppositeOpposing
			if opp.hp > 0 && pbAIfaster?(nil,nil,battler,megaform,field)
				baseform_outspeeds_ohkos = canKillBeforeOpponentKills?(battler,opp,true,field)
				mega_outspeeds_ohkos = canKillBeforeOpponentKills?(megaform,opp,true,field)
				want_to_mega = false if baseform_outspeeds_ohkos && !mega_outspeeds_ohkos
			end
		end
		# LAWDS juuust in case
		want_to_mega = true if @battle.pbOwnedByPlayer?(battler.index)

		return false if !want_to_mega && $game_variables[:DifficultyModes]!=1 # lawds dont do fancy AI shit on story
		#and if you want to mega, change the attacker
		battler.pokemon.makeMega
		battler.form=battler.pokemon.form
		battler.pbUpdate(true)
		battler = pbStatChangingSwitch(battler,field,mega: true)
		@mondata.shouldMegaOrUltraBurst = true if is_attacker
		return true
	end

	def checkUltraBurst
		return if !@battle.pbCanUltraBurst?(@index)
		#change the attacker to be itself but ultra bursted
		@attacker.pokemon.makeUltra
		@attacker.form=@attacker.pokemon.form
		@attacker.pbUpdate(true)
		@mondata.shouldMegaOrUltraBurst = true
	end

	def checkZMoves
		return if @attacker.zmoves.nil?
		return if !@battle.pbCanZMove?(@index)
		#Special case processing- there are specific moves that should intentionally be made z-moves
		#if both the move and the z-crystal are present
		bestbase = 0
		for i in 0...@attacker.zmoves.length
			move = @attacker.zmoves[i]
			next if move.nil?
			next if @attacker.moves[i].nil?
			next if @attacker.moves[i].pp == 0
			if (move.move == :CONVERSION || move.move == :SPLASH || move.move == :CELEBRATE) && @attacker.item == :NORMALIUMZ
				zmove = move
				break 
			end
			if (move.move == :NATUREPOWER && @attacker.item == :NORMALIUMZ)
				newmove = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(@battle.field.naturePower),@attacker)
				if newmove.basedamage > 0
					zmove = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(PBStuff::CRYSTALTOZMOVE[PBStuff::TYPETOZCRYSTAL[newmove.type]]),@attacker,newmove)
					break 
				end
			end
			if (move.move == :EXTREMEEVOBOOST && @attacker.item == :EEVIUMZ)
				zmove = move
				break 
			end
			next if $cache.moves[move.move].category == :status	#Skip all other status moves
			thisbase = move.basedamage
			if bestbase < thisbase
				bestbase = thisbase
				zmove = move
			end
		end
		#if there's a zmove, put it on the moves list and run it with the rest
		if zmove
			@attacker.moves.push(zmove)
			@mondata.zmove = zmove
			@mondata.scorearray.each {|array| array.push(-1)}
			@mondata.roughdamagearray.each {|array| array.push(-1)}
		end
	end

	def buildPlayerDamageArray # LAWDS building array for player partner AI
		# essentially tracks what mons the player can kill for the purposes of choosing a better action for player AI partner
		@player_damage_array = [0,0]
		playermon = @battle.battlers[0]
		playerpartner = @battle.battlers[2]
		aimon1 = @battle.battlers[1]
		aimon2 = @battle.battlers[3]

		player_kills_target = false
		player_kills_target_first = false
		player_kills_partner = false
		player_kills_partner_first = false

		aimon1_killmoves = []
		aimon2_killmoves = []

		for i in 0...aimon1.moves.length
			move = aimon1.moves[i]
			dmg = @aimondata[1].roughdamagearray[0][i]
			aimon1_killmoves.push(move) if dmg >= 110
		end

		for i in 0...aimon2.moves.length
			move = aimon2.moves[i]
			dmg = @aimondata[3].roughdamagearray[0][i]
			aimon2_killmoves.push(move) if dmg >= 110
		end
		
		player_damage1 = @aimondata[1].roughdamagearray[0].max
		player_damage2 = @aimondata[3].roughdamagearray[0].max

		targetkillsplayer = player_damage1 >= 110
		partnerkillsplayer = player_damage2 >= 110
		player_can_die = player_damage1 + player_damage2 >= 110

		for i in 0...playermon.moves.length # lawds note to self improve the speed tier checks later
			move = playermon.moves[i]
			next if move==nil || move.basedamage==0 || !(@battle.pbCanChooseMove?(playermon.index,i,false))

			playerdamage1 = @aimondata[0].roughdamagearray[1][i]
			playerdamage2 = @aimondata[0].roughdamagearray[3][i]

			playerkills1 = playerdamage1 >= 110
			playerkills2 = playerdamage2 >= 110
			if playerkills1 #&& !player_kills_target_first
				player_kills_target = true
				player_kills_target_first = true if pbAIfaster?(move,nil,playermon,aimon1)
			end
			if playerkills2 #&& !player_kills_partner_first
				player_kills_partner = true
				player_kills_partner_first = true if pbAIfaster?(move,nil,playermon,aimon2)
			end
		end
		if player_kills_target
			@player_damage_array[0]+=1
			@player_damage_array[0]+=1 if player_kills_target_first # array entry > 0 means the player can definitely kill that enemy; array entry > 1 means it will also do so before the enemy can move
		end
		if player_kills_partner
			@player_damage_array[1]+=1
			@player_damage_array[1]+=1 if player_kills_partner_first
		end
	end

	def buildMoveScores(justdamage=false) # lawds added parameter to get just rough damage, then full damage
		# this is the framework for getting the move scores. minimal calculation should be done here
		if !@battle.opponent && @battle.pbIsOpposing?(@index) && !(Rejuv && (@battle.battlers[@index].isbossmon || @battle.battlers[@index].issossmon)) # First check if this is a wild battle
		  preference = @attacker.personalID % 4
		  for j in [0, 2]
			next if j == 2 && !@battle.doublebattle
	
			for i in 0...4
			  if @battle.pbCanChooseMove?(index, i, false)
				@mondata.scorearray[j][i] = 100
				@mondata.scorearray[j][i] += 5 if preference == i # for personality
			  end
			end
		  end
		  return
		end
		# real code time.
		if @battle.doublebattle # this JUST gets the numbers. other things can be computed later.
		  if @attacker.pbPartner.species==:ALCREMIE # lawds make attacker see its own incoming sugar rush speed boost before scoring moves
			partnerdummy = pbCloneBattler(@attacker.pbPartner.index)
			willMega = checkMega(partnerdummy)
			if willMega && @attacker.pbCanIncreaseStatStage?(PBStats::SPEED,false)
			   @attacker.stages[PBStats::SPEED]+=1
			end
		  end
		  for monindex in 0...@battle.battlers.length
			next if monindex == @index # This is you! We don't want to hit ourselves.
			next if @battle.battlers[monindex].isFainted? # Can't hit 'em if they're dead
	
			@opponent = pbCloneBattler(monindex, illusionCheck(@attacker, @battle.battlers[monindex]))
			mega_opp = pbCloneBattler(monindex, illusionCheck(@attacker, @battle.battlers[monindex])) # lawds get mega evolution
			checkMega(mega_opp)
			if @opponent.pbPartner.species==:ALCREMIE # lawds make attacker see an enemy sugar rush speed boost before scoring moves
				partnerdummy = pbCloneBattler(@opponent.pbPartner.index)
				willMega = checkMega(partnerdummy)
				if willMega && @opponent.pbCanIncreaseStatStage?(PBStats::SPEED,false)
				   @opponent.stages[PBStats::SPEED]+=1
				end
			end
			
			# Save the amount of damage the AI think opp can do
			# LAWDS rewrote this to store how much damage a player mon can do with each move
			if monindex != @attacker.pbPartner.index && justdamage
				maxdamage = 0
				for oppmoveindex in 0...@opponent.moves.length
					move = @opponent.moves[oppmoveindex]
					next if move==nil || move.basedamage==0 || !@battle.pbCanChooseMove?(monindex, oppmoveindex, false)
					damage = pbRoughDamage(move, @opponent, @attacker)
					maxdamage = damage if damage > maxdamage
					if @battle.pbOwnedByPlayer?(monindex)
						# now the AI will know player mon move damage
						initialdmg = [(damage * 100/(@attacker.hp)),110].min
						@aimondata[monindex].roughdamagearray[@attacker.index][oppmoveindex] = initialdmg
					end
				end
			end


			$ai_log_data[@index].expected_damage.push((maxdamage * 100.0 / @attacker.totalhp).round(1)) unless monindex == @attacker.pbPartner.index || !$INTERNAL || !justdamage
			$ai_log_data[@index].expected_damage_name.push(getMonName(@opponent.species, @opponent.form)) unless monindex == @attacker.pbPartner.index || !$INTERNAL || !justdamage
			# get the moves the pokemon can choose, in case of choice item/encore/taunt/torment
			for moveindex in 0...@attacker.moves.length
			  next if !@battle.pbCanChooseMove?(@index, moveindex, false) || !justdamage
	
			  @move = pbChangeMove(@attacker.moves[moveindex], @attacker)
			  # if you can't/shouldn't hit your partner with the move, skip it
			  next if @attacker.pbPartner.index == monindex && (@attacker.pbTarget(@move) != :AllNonUsers && !PARTNERFUNCTIONS.include?(@move.function))
	
			  if @move.basedamage != 0
				@mondata.roughdamagearray[monindex][moveindex] = [(pbRoughDamage(@attacker.moves[moveindex]) * 100) / (@opponent.hp), 110].min
				if mega_opp.isMega? && !@opponent.isMega? # lawds also grab the score for the mega and take the minimum
					megadamage = [(pbRoughDamage(@attacker.moves[moveindex],@attacker,mega_opp) * 100) / (mega_opp.hp), 110].min
					@mondata.roughdamagearray[monindex][moveindex] = megadamage if megadamage < @mondata.roughdamagearray[monindex][moveindex]
				end
			  # The old function makes some adjustments for two-turn moves here. I'm leaving that for later.
			  else
				@mondata.roughdamagearray[monindex][moveindex] = getStatusDamage
			  end
			end
	
			for moveindex in 0...@attacker.moves.length
			  next if !@battle.pbCanChooseMove?(@index, moveindex, false) || justdamage
	
			  @move = pbChangeMove(@attacker.moves[moveindex], @attacker)
			  next if @attacker.pbPartner.index == monindex && (@attacker.pbTarget(@move) != :AllNonUsers && !PARTNERFUNCTIONS.include?(@move.function))
	
			  @mondata.scorearray[monindex][moveindex] = getMoveScore(@mondata.roughdamagearray[monindex], moveindex)
			  if mega_opp.isMega? && !@opponent.isMega? # lawds also grab the score for the mega and take the minimum
				oppbuffer = @opponent
				@opponent = mega_opp
				megascore = getMoveScore(@mondata.roughdamagearray[monindex], moveindex)
				@opponent = oppbuffer
				@mondata.scorearray[monindex][moveindex] = megascore if megascore < @mondata.scorearray[monindex][moveindex]
			  end
			  # at this point we have legally acquired the move scores and thus should be done.
			end
			# add z-move if relevant
			if @mondata.zmove && @attacker.pbPartner.index != monindex
			  @move = pbChangeMove(@mondata.zmove, @attacker)
			  if @move.basedamage != 0 && @opponent.hp > 0 && justdamage
				@mondata.roughdamagearray[monindex][-1] = [(pbRoughDamage(@mondata.zmove) * 100) / (@opponent.hp), 110].min
			  elsif justdamage
				@mondata.roughdamagearray[monindex][-1] = getStatusDamage
			  end
			  @mondata.scorearray[monindex][-1] = getMoveScore(@mondata.roughdamagearray[monindex], @mondata.roughdamagearray[monindex].length - 1) if !justdamage
			end
	
			# Add struggle
			has_to_struggle = true
			@attacker.moves.each_with_index { |move, moveindex| has_to_struggle = false if @battle.pbCanChooseMove?(@index, moveindex, false) }
			if has_to_struggle
			  next if @attacker.pbPartner.index == monindex
	
			  @move = @battle.struggle
			  @mondata.roughdamagearray[monindex][0] = [(pbRoughDamage * 100) / (@opponent.hp), 110].min
			  @mondata.scorearray[monindex][0] = getMoveScore(@mondata.roughdamagearray[monindex], 0)
			end
		  end
		else
		  	oppindex = @index ^ 1
		  	@opponent = pbCloneBattler(oppindex, illusionCheck(@attacker, @battle.battlers[oppindex]))
		  	mega_opp = pbCloneBattler(oppindex, illusionCheck(@attacker, @battle.battlers[oppindex])) # lawds get mega evolution
		  	checkMega(mega_opp)

			# LAWDS rewrote this to store how much damage a player mon can do with each move
			maxdamage = 0
			if justdamage
			for oppmoveindex in 0...@opponent.moves.length
				move = @opponent.moves[oppmoveindex]
				next if move==nil || move.basedamage==0 || !@battle.pbCanChooseMove?(oppindex, oppmoveindex, false)
				damage = pbRoughDamage(move, @opponent, @attacker)
				maxdamage = damage if damage > maxdamage
				if @battle.pbOwnedByPlayer?(oppindex)
					# now the AI will know player mon move damage
					initialdmg = [(damage * 100/(@attacker.hp)),110].min
					@aimondata[oppindex].roughdamagearray[@attacker.index][oppmoveindex] = initialdmg
				end
			end
			end


		  $ai_log_data[@index].expected_damage.push((maxdamage * 100.0 / @attacker.totalhp).round(1)) if justdamage && $INTERNAL
		  $ai_log_data[@index].expected_damage_name.push(getMonName(@opponent.species, @opponent.form)) if justdamage && $INTERNAL
		  # get the moves the pokemon can choose, in case of choice item/encore/taunt/torment
		  for moveindex in 0...@attacker.moves.length
			next if !@battle.pbCanChooseMove?(@index, moveindex, false) || !justdamage
	
			@move = pbChangeMove(@attacker.moves[moveindex], @attacker)
			if @move.basedamage != 0 && @opponent.hp > 0 # lawds - added this to catch 0 hp opponents i guess
			  @mondata.roughdamagearray[oppindex][moveindex] = [(pbRoughDamage(@attacker.moves[moveindex])*100 / @opponent.hp), 110].min
			  if mega_opp.isMega? && !@opponent.isMega? # lawds also grab the score for the mega and take the minimum
				megadamage = [(pbRoughDamage(@attacker.moves[moveindex],@attacker,mega_opp) * 100) / (mega_opp.hp), 110].min
				@mondata.roughdamagearray[oppindex][moveindex] = megadamage if megadamage < @mondata.roughdamagearray[oppindex][moveindex]
			  end
			# The old function makes some adjustments for two-turn moves here. I'm leaving that for later.
			else
			  @mondata.roughdamagearray[oppindex][moveindex] = getStatusDamage
			end
		  end
		  for moveindex in 0...@attacker.moves.length
			next if !@battle.pbCanChooseMove?(@index, moveindex, false) || justdamage
	
			@move = @attacker.moves[moveindex]
			@mondata.scorearray[oppindex][moveindex] = getMoveScore(@mondata.roughdamagearray[oppindex], moveindex)
			if mega_opp.isMega? && !@opponent.isMega? # lawds also grab the score for the mega and take the minimum
				oppbuffer = @opponent
				@opponent = mega_opp
				megascore = getMoveScore(@mondata.roughdamagearray[oppindex], moveindex)
				@opponent = oppbuffer
				@mondata.scorearray[oppindex][moveindex] = megascore if megascore < @mondata.scorearray[oppindex][moveindex]
			end
			# at this point we have legally acquired the move scores and thus should be done.
		  end
		  # add z-move if relevant
		  if @mondata.zmove
			@move = pbChangeMove(@mondata.zmove, @attacker)
			if @move.basedamage != 0 && justdamage
			  @mondata.roughdamagearray[oppindex][-1] = [(pbRoughDamage(@mondata.zmove) * 100) / (@opponent.hp), 110].min
			elsif justdamage
			  @mondata.roughdamagearray[oppindex][-1] = getStatusDamage
			end
			@mondata.scorearray[oppindex][-1] = getMoveScore(@mondata.roughdamagearray[oppindex], @mondata.scorearray[oppindex].length - 1) if !justdamage
		  end
	
		  # Add struggle
		  has_to_struggle = true
		  @attacker.moves.each_with_index { |move, moveindex| has_to_struggle = false if @battle.pbCanChooseMove?(@index, moveindex, false) }
		  if has_to_struggle
			@move = @battle.struggle
			@mondata.roughdamagearray[oppindex][0] = [(pbRoughDamage * 100) / (@opponent.hp), 110].min
			@mondata.scorearray[oppindex][0] = getMoveScore(@mondata.roughdamagearray[oppindex], 0)
		  end
		end
	  end

	def chooseAction
		for index in 0...@aimondata.length #for every battler
			next if @aimondata[index].nil?
			next if @battle.pbOwnedByPlayer?(index) && !@battle.controlPlayer
			battler = @battle.battlers[index]
			next if battler.hp == 0 || !@battle.pbCanShowCommands?(index)
			next if @battle.choices[battler.index][0] != 0
			@mondata = @aimondata[index]
			#make move-targets coupled list bc that works way easier ?
			@mondata.scorearray.map! {|scorelist| scorelist.map! {|score| score < 0 ? -1 : score}}
			#make list of moves, targets, and scores, # structured [moveindex, [target(s)], score, isZmove?]
			chooseablemoves = findChoosableMoves(battler,@mondata)


			chooseablemoves = chooseablemoves.find_all {|arrays| arrays[:score] >= 0}
			#dealing with mon that can't even choose fight menu
			if !@battle.pbCanShowCommands?(battler.index)
				@battle.pbAutoChooseMove(battler.index)
				next
			end

			if chooseablemoves.length !=0
				maxmovescore = chooseablemoves.max {|a1,a2| a1[:score]<=>a2[:score]}[:score] rescue 0
			else
				maxmovescore = 0
			end
			#chooses the action that the AI pokemon will perform
			#SWITCH											# LAWDS - made the AI totally willing to switch out an untransformed palafin
			# lawds switch threshold is higher on story mode and in doubles
			switchscore_threshold = ($game_variables[:DifficultyModes]==1 || @battle.doublebattle) ? 150 : 100
			if @mondata.shouldswitchscore > maxmovescore && ((battler.ability== :ZEROTOHERO && battler.form == 0) || (@mondata.switchscore.length > 0 && @mondata.switchscore.max >= switchscore_threshold)) #arbitrary
				if battler.index==3 && @battle.choices[1][0]==2 && @battle.choices[1][1] == @mondata.switchscore.index(@mondata.switchscore.max)
					if (@mondata.switchscore.max(2)[1] > switchscore_threshold) && shouldHardSwitch?(battler,@mondata.switchscore.index(@mondata.switchscore.max(2)[1]))
						indexhighestscore = @mondata.switchscore.index(@mondata.switchscore.max(2)[1])
						PBDebug.log(sprintf("Switching to %s",getMonName(@battle.pbParty(battler.index)[indexhighestscore].species))) if $INTERNAL
						$ai_log_data[battler.index].chosen_action = sprintf("Switching to %s",getMonName(@battle.pbParty(battler.index)[indexhighestscore].species))
						@battle.pbRegisterSwitch(battler.index,indexhighestscore)
						next
					end
				elsif shouldHardSwitch?(battler,@mondata.switchscore.index(@mondata.switchscore.max))
					indexhighestscore = @mondata.switchscore.index(@mondata.switchscore.max)
					PBDebug.log(sprintf("Switching to %s",getMonName(@battle.pbParty(battler.index)[indexhighestscore].species))) if $INTERNAL
					$ai_log_data[battler.index].chosen_action = sprintf("Switching to %s",getMonName(@battle.pbParty(battler.index)[indexhighestscore].species))
					@battle.pbRegisterSwitch(battler.index,indexhighestscore)
					next
				end
			end

			#USE ITEM
			if !@mondata.itemscore.empty? && @mondata.itemscore.values.max > maxmovescore
				item = @mondata.itemscore.key(@mondata.itemscore.values.max)
				#check if quantity of item the battler has is 1 and if previous battler hasn't also tried to use this item
				if battler.index==3 && @battle.choices[1][0]==3 && @battle.choices[1][1]==item
					items=@battle.pbGetOwnerItems(battler.index)
					if items.count {|element| element==item} > 1
						@battle.pbRegisterItem(battler.index,item)
						$ai_log_data[battler.index].chosen_action = sprintf("Using Item %s", getItemName(item))
						next
					end
				else
					@battle.pbRegisterItem(battler.index,item)
					$ai_log_data[battler.index].chosen_action = sprintf("Using Item %s", getItemName(item))
					next
				end
			end

			if !@battle.pbCanShowCommands?(battler.index) || (0..3).none? {|number| @battle.pbCanChooseMove?(battler.index,number,false)}
				@battle.pbAutoChooseMove(battler.index)
				next
			end
			#MEGA+BURST
			if @aimondata[index].shouldMegaOrUltraBurst
				@battle.pbRegisterMegaEvolution(index) if @battle.pbCanMegaEvolve?(index)
				@battle.pbRegisterUltraBurst(index) if @battle.pbCanUltraBurst?(index)
			end

			#MOVE
			canusemovelist = []
			for moveindex in 0...battler.moves.length
				canusemovelist.push(moveindex) if @battle.pbCanChooseMove?(battler.index,moveindex,false)
			end
			if chooseablemoves.length==0 && canusemovelist.length > 0
				@battle.pbRegisterMove(battler.index,canusemovelist[rand(canusemovelist.length)],false)
				@battle.pbRegisterTarget(battler.index,battler.pbOppositeOpposing.index) if @battle.doublebattle
				$ai_log_data[battler.index].chosen_action = "Random Move bc only bad decisions"
				next
			elsif chooseablemoves.length==0
				@battle.pbAutoChooseMove(battler.index)
			end
			# Minmax choices depending on AI
			if  @mondata.skill>=MEDIUMSKILL
				threshold=(@mondata.skill>=BESTSKILL) ? 1.5 : (@mondata.skill>=HIGHSKILL) ? 2 : 3
				newscore=(@mondata.skill>=BESTSKILL) ? 5 : (@mondata.skill>=HIGHSKILL) ? 10 : 15
				for scoreindex in 0...chooseablemoves.length
					chooseablemoves[scoreindex][:score] = chooseablemoves[scoreindex][:score] > newscore && chooseablemoves[scoreindex][:score]*threshold<maxmovescore ? newscore : chooseablemoves[scoreindex][:score]
				end
			end

			#Log the move scores in debuglog
			if $INTERNAL
				x="[#{battler.pbThis}: "
				j=0
				for i in 0...4
					next if battler.moves[i].nil?
					x+=", " if j>0
					movelistscore = [@mondata.scorearray[0][i], @mondata.scorearray[1][i], @mondata.scorearray[2][i], @mondata.scorearray[3][i]]
					x+=battler.moves[i].name+"="+movelistscore.to_s
					j+=1
				end
				x+="]"
				PBDebug.log(x)
				#$stdout.print(x); $stdout.print("\n")
			end

			preferredMoves = []
			for i in chooseablemoves
				if  (i[:score] >= (maxmovescore* 0.95))
					#preferredMoves.push(i)
					preferredMoves.push(i) if i[:score]==maxmovescore # Doubly prefer the best move
				end
			end
			
			chosen=preferredMoves[0]
			if chosen[:zmove]
				PBDebug.log("[Prefer "+battler.zmoves[chosen[:moveindex]].name+"]") if $INTERNAL
				$ai_log_data[battler.index].chosen_action = "[Prefer "+battler.zmoves[chosen[:moveindex]].name+"]"
			else
				PBDebug.log("[Prefer "+battler.moves[chosen[:moveindex]].name+"]") if $INTERNAL
				$ai_log_data[battler.index].chosen_action = "[Prefer "+battler.moves[chosen[:moveindex]].name+"]"
			end
			@battle.pbRegisterZMove(battler.index) if chosen[:zmove]==true #if chosen move is a z-move
			@battle.pbRegisterMove(battler.index,chosen[:moveindex],false)
			@battle.pbRegisterTarget(battler.index,chosen[:target][0]) if @battle.doublebattle
		end
	end

	def findChoosableMoves(battler,mondata)
		chooseablemoves = []
		for moveindex in 0...4
			next if !@battle.pbCanChooseMove?(battler.index,moveindex,false)
			if !@battle.opponent && @battle.pbIsOpposing?(battler.index) && !(battler.isbossmon || battler.issossmon)
				chooseablemoves.push({moveindex: moveindex,target: [0,2].sample,score: mondata.scorearray[0][moveindex],zmove: false})
				next
			end

			move = pbChangeMove(battler.moves[moveindex],battler)
			if @battle.doublebattle
				pi = battler.pbPartner.index # partner
				oi = battler.pbOppositeOpposing.index #opposite opponent
				ci = battler.pbCrossOpposing.index
				case battler.pbTarget(move)
				when :SingleNonUser, :SingleOpposing
					[oi,pi,ci].each {|targetindex| chooseablemoves.push({moveindex: moveindex,target: [targetindex],score: mondata.scorearray[targetindex][moveindex],zmove: false}) }
				when :RandomOpposing, :User, :NoTarget, :UserSide
					if @battle.battlers[oi].hp > 0 && @battle.battlers[ci].hp > 0
						chooseablemoves.push({moveindex: moveindex,target: [oi],score: (mondata.scorearray[ci][moveindex]+mondata.scorearray[oi][moveindex])/2,zmove: false})
					elsif @battle.battlers[oi].hp > 0
						chooseablemoves.push({moveindex: moveindex,target: [oi],score: mondata.scorearray[oi][moveindex],zmove: false})
					else
						chooseablemoves.push({moveindex: moveindex,target: [ci],score: mondata.scorearray[ci][moveindex],zmove: false})
					end
				when :AllOpposing, :OpposingSide
					chooseablemoves.push({moveindex: moveindex,target: [oi,ci],score: (mondata.scorearray[ci][moveindex]+mondata.scorearray[oi][moveindex]),zmove: false})
				when :AllNonUsers
					scoremult=1.0
					if (move.pbType(battler) == :FIRE && (battler.pbPartner.ability== :FLASHFIRE || battler.pbPartner.crested == :DRUDDIGON || battler.pbPartner.ability== :WELLBAKEDBODY)) ||
							(move.pbType(battler) == :WATER && (battler.pbPartner.ability== :WATERABSORB || battler.pbPartner.ability== :STORMDRAIN || battler.pbPartner.ability== :DRYSKIN)) ||
							(move.pbType(battler) == :GRASS && (battler.pbPartner.ability== :SAPSIPPER || battler.pbPartner.crested == :WHISCASH)) ||
							(move.pbType(battler) == :ELECTRIC && (battler.pbPartner.ability== :VOLTABSORB || battler.pbPartner.ability== :LIGHTNINGROD || battler.pbPartner.ability== :MOTORDRIVE)) ||
							(move.pbType(battler) == :GROUND && ((battler.pbPartner.crested == :SKUNTANK) || battler.pbPartner.ability== :EARTHEATER)) || # Gen 9 Mod - Added Earth Eater
							(move.pbType(battler) == :BUG && battler.pbPartner.ability==:ENTOMOPHAGY) || # lawds entomophagous
							(move.pbType(battler) == :GHOST && battler.pbPartner.ability== :SPIRITSENVOY && @battle.FE != :HAUNTED) # LAWDS - spirit's envoy 
							scoremult*=2
					elsif battler.pbPartner.hp > 0 && (battler.pbPartner.hp.to_f > 0.1* battler.pbPartner.totalhp || pbAIfaster?(move,nil,battler,battler.pbPartner)) && !(!@battle.pbOwnedByPlayer?(battler.index) && battler.name=="Spacea")
						if (@battle.opponent.is_a?(Array) || @battle.pbIsWild? || @battle.opponent.trainertype != :LEADER_VALARIE || (battler.turncount > 1 || battler.pbPartner.turncount>1)) # multiplier to control how much to arbitrarily care about hitting partner; lower cares more
							scoremult = [(1-2*mondata.scorearray[pi][moveindex]/110.0), 0].max 
							scoremult*= 0.5 if pbAIfaster?(move,nil,battler,battler.pbPartner) && mondata.scorearray[pi][moveindex] > 50 && battler.turncount > 1# care more if we're faster and would knock it out before it attacks
						end
					end
					chooseablemoves.push({moveindex: moveindex,target: [oi,ci,pi],score: scoremult*(mondata.scorearray[ci][moveindex]+mondata.scorearray[oi][moveindex]),zmove: false})
				when :BothSides #actually targets only user side
					chooseablemoves.push({moveindex: moveindex,target: [oi,ci],score: Math.sqrt(mondata.scorearray[ci][moveindex]**2+mondata.scorearray[oi][moveindex]**2).round,zmove: false})
				when :Partner
					chooseablemoves.push({moveindex: moveindex,target: [pi],score: [mondata.scorearray[ci][moveindex], mondata.scorearray[oi][moveindex] ].max,zmove: false})
					[oi,ci].each {|targetindex| chooseablemoves.push({moveindex: moveindex,target:[targetindex],score: mondata.scorearray[targetindex][moveindex],zmove: false}) }
				when :OppositeOpposing
					if @battle.battlers[oi].hp > 0
						chooseablemoves.push({moveindex: moveindex,target: [oi],score: mondata.scorearray[oi][moveindex],zmove: false})
					else
						chooseablemoves.push({moveindex: moveindex,target: [ci],score: mondata.scorearray[ci][moveindex],zmove: false})
					end
				when :UserOrPartner
					if @battle.battlers[oi].hp > 0 && @battle.battlers[ci].hp > 0
						chooseablemoves.push({moveindex: moveindex,target: [battler.index],score: (mondata.scorearray[ci][moveindex]+mondata.scorearray[oi][moveindex])/2,zmove: false})
					elsif @battle.battlers[oi].hp > 0
						chooseablemoves.push({moveindex: moveindex,target: [battler.index],score: mondata.scorearray[oi][moveindex],zmove: false})
					else
						chooseablemoves.push({moveindex: moveindex,target: [battler.index],score: mondata.scorearray[ci][moveindex],zmove: false})
					end
				when :DragonDarts #curse whoever made this thing
					if move.pbDragonDartTargetting(battler).length > 1
						chooseablemoves.push({moveindex: moveindex,target: [pi],score: [mondata.scorearray[ci][moveindex], mondata.scorearray[oi][moveindex] ].max,zmove: false})
						chooseablemoves.push({moveindex: moveindex,target: [oi,ci],score: (mondata.scorearray[ci][moveindex]+mondata.scorearray[oi][moveindex]),zmove: false})
					else
						[oi,pi,ci].each {|targetindex| chooseablemoves.push({moveindex: moveindex,target: [targetindex],score: mondata.scorearray[targetindex][moveindex],zmove: false}) }
					end
				end
			else
				unless battler.pbTarget(move) == :UserOrPartner
					chooseablemoves.push({moveindex: moveindex,target: [0],score: mondata.scorearray[0][moveindex],zmove: false})
				else
					chooseablemoves.push({moveindex: moveindex,target: [battler.index],score: mondata.scorearray[0][moveindex],zmove: false})
				end
			end
		end
		#Add a possible z-move to the choosable moves. Only if the scores for non-z move are all lower than 100
		if mondata.zmove && (chooseablemoves.all? {|array| array[:score] < 100} || [:CONVERSION,:CELEBRATE,:SPLASH,:CLANGOROUSSOULBLAZE].include?(mondata.zmove.move))
			#find which move has been turned into z-move
			originalmove = battler.zmoves.include?(mondata.zmove) ? mondata.zmove : :NATUREPOWER
			if originalmove.is_a?(Symbol)
				originalmoveindex = battler.zmoves.find_index {|moveloop| moveloop!=nil && moveloop.move==originalmove}
			elsif originalmove.is_a?(PokeBattle_Move)
				originalmoveindex = battler.zmoves.find_index(mondata.zmove)
			else
				puts "How did you fuck up this badly?"
			end
			if @battle.doublebattle
				oi = battler.pbOppositeOpposing.index #opposite opponent
				ci = battler.pbCrossOpposing.index
				if  [:CONVERSION,:CELEBRATE,:SPLASH,:CLANGOROUSSOULBLAZE].include?(mondata.zmove.move)
					chooseablemoves.push({moveindex: originalmoveindex,target: [oi,ci],score: mondata.scorearray[oi][-1] + mondata.scorearray[ci][-1],zmove: true})
				else
					[oi,ci].each {|targetindex| chooseablemoves.push({moveindex: originalmoveindex,target: [targetindex],score: mondata.scorearray[targetindex][-1],zmove: true}) }
				end
			else
				chooseablemoves.push({moveindex: originalmoveindex,target: [0],score: mondata.scorearray[0][4],zmove: true})
			end
		end
		return chooseablemoves
	end

	def coordinateActions # changes some scores doesn't choose
		return if @battle.battlers[1].hp == 0 || @battle.battlers[3].hp == 0 || (@battle.pbIsWild? && !(@battle.battlers.any? { |battler| battler.isbossmon || battler.issossmon }))
		# Threat Assesment
		threatscore = threatAssesment()
		biggest_threat = threatscore.index(threatscore.max)
		aimon1 = @battle.battlers[1]
		aimon2 = @battle.battlers[3]
	
		# indexing
		op_l = 0
		op_r = 2
		ai_l = 1
		ai_r = 3
	
		# find targets of all killing moves
		killing_moves = [[], [], [], []]
		for i in [ai_l, ai_r]
		  @aimondata[i].roughdamagearray.each_with_index { |array, monindex|
			next if monindex == ai_l || monindex == ai_r
	
			array.each_with_index { |obj, moveindex|
			  if obj >= 100 && @aimondata[i].scorearray[monindex][moveindex] > 80 # killing move + not awful score
				killing_moves[i].push(monindex)
			  end
			}
		  }
		end
		# shape the array in something more usable
		killing_moves.map! { |arr| arr.uniq }
		killing_moves.map!.with_index { |arr, index|
		  if arr.length == 2
			:both
		  elsif arr[0] == 0
			:left
		  elsif arr[0] == 2
			:right
		  elsif index == 0 || index == 2
			:_
		  else
			:none
		  end
		}
		# if only one of them has a killing move, make it so the other one doesn't target the same mon
		if (killing_moves[ai_l] != :none && killing_moves[ai_r] == :none) || (killing_moves[ai_r] != :none && killing_moves[ai_l] == :none)
		  # battlerindexes
		  ai_leader = killing_moves[ai_l] != :none ? ai_l : ai_r
		  ai_follow = ai_leader ^ 2
	
		  leader_mon = @battle.battlers[ai_leader]
		  follow_mon = @battle.battlers[ai_follow]
		  opp_left_mon = @battle.battlers[op_l]
		  opp_righ_mon = @battle.battlers[op_r]
	
		  # get the move it will choose
		  leader_moves = findChoosableMoves(leader_mon, @aimondata[ai_leader])
		  leader_moves.sort! { |a, b| b[:score] <=> a[:score] }
		  bestmove = leader_moves[0][:zmove] ? @aimondata[ai_leader].zmove : leader_mon.moves[leader_moves[0][:moveindex]]
		  bestmove1 = ai_leader==1 ? bestmove : nil # lawds
		  bestmove2 = ai_leader==3 ? bestmove : nil # lawds
		  if bestmove.betterCategory != :status && bestmove.priority == 0
			decrease_by = 1.0
			speedorder = pbMoveOrderAI(bestmove1,bestmove2) # lawds include best move for turn order
			case speedorder
			  # leader fastest and no specific way to save follower before follower attacks
			  when [ai_leader, ai_follow, op_l, op_r] then decrease_by = 0.4
			  when [ai_leader, op_l, op_r, ai_follow] then decrease_by = 0.4
			  when [ai_leader, op_r, op_l, ai_follow] then decrease_by = 0.4
			  when [ai_follow, ai_leader, op_l, op_r] then decrease_by = 0.4
			  when [ai_follow, ai_leader, op_r, op_l] then decrease_by = 0.4
			  when [ai_leader, ai_follow, op_r, op_l] then decrease_by = 0.4
	
			  # leader slowest, but survives both hits of the opponent
			  when [op_l, op_r, ai_follow, ai_leader] then decrease_by = 0.7 if checkAIdamage(leader_mon, opp_left_mon) + checkAIdamage(leader_mon, opp_righ_mon) < leader_mon.hp
			  when [op_r, op_l, ai_follow, ai_leader] then decrease_by = 0.7 if checkAIdamage(leader_mon, opp_left_mon) + checkAIdamage(leader_mon, opp_righ_mon) < leader_mon.hp
			  when [op_l, ai_follow, op_r, ai_leader] then decrease_by = 0.7 if checkAIdamage(leader_mon, opp_left_mon) + checkAIdamage(leader_mon, opp_righ_mon) < leader_mon.hp
			  when [op_r, ai_follow, op_l, ai_leader] then decrease_by = 0.7 if checkAIdamage(leader_mon, opp_left_mon) + checkAIdamage(leader_mon, opp_righ_mon) < leader_mon.hp
			  when [ai_follow, op_l, op_r, ai_leader] then decrease_by = 0.7 if checkAIdamage(leader_mon, opp_left_mon) + checkAIdamage(leader_mon, opp_righ_mon) < leader_mon.hp
			  when [ai_follow, op_r, op_l, ai_leader] then decrease_by = 0.7 if checkAIdamage(leader_mon, opp_left_mon) + checkAIdamage(leader_mon, opp_righ_mon) < leader_mon.hp
			  when [op_r, op_l, ai_leader, ai_follow] then decrease_by = 0.7 if checkAIdamage(leader_mon, opp_left_mon) + checkAIdamage(leader_mon, opp_righ_mon) < leader_mon.hp
			  when [op_l, op_r, ai_leader, ai_follow] then decrease_by = 0.7 if checkAIdamage(leader_mon, opp_left_mon) + checkAIdamage(leader_mon, opp_righ_mon) < leader_mon.hp
	
			  # leader survives a hit from the left opp before targetting their mon, and can't save follower
			  when [op_l, ai_leader, ai_follow, op_r] then decrease_by = 0.7 if checkAIdamage(leader_mon, opp_left_mon) < leader_mon.hp
			  when [ai_follow, op_l, ai_leader, op_r] then decrease_by = 0.7 if checkAIdamage(leader_mon, opp_left_mon) < leader_mon.hp
			  when [op_l, ai_follow, ai_leader, op_r] then decrease_by = 0.7 if checkAIdamage(leader_mon, opp_left_mon) < leader_mon.hp
	
	
			  # leader survives a hit from the left opp before targetting their mon, and can't save follower
			  when [op_r, ai_leader, ai_follow, op_l] then decrease_by = 0.7 if checkAIdamage(leader_mon, opp_righ_mon) < leader_mon.hp
			  when [ai_follow, op_r, ai_leader, op_l] then decrease_by = 0.7 if checkAIdamage(leader_mon, opp_righ_mon) < leader_mon.hp
			  when [op_r, ai_follow, ai_leader, op_l] then decrease_by = 0.7 if checkAIdamage(leader_mon, opp_righ_mon) < leader_mon.hp
	
			  # leader can save follower from taking a hit before moving follower moves, so target that slot unless that slot is unimportant
			  when [ai_leader, op_l, ai_follow, op_r] then decrease_by = 0.7
			  when [ai_leader, op_r, ai_follow, op_l] then decrease_by = 0.7
			  when [op_l, ai_leader, op_r, ai_follow] then decrease_by = 0.7
			  when [op_r, ai_leader, op_l, ai_follow] then decrease_by = 0.7
	
			end
	
			# change the targetting of the biggest target if it stops the follower from getting hit
			case speedorder
			  # leader moves first, then the mon that can be killed then the follower, then the last
			  when [ai_leader, op_l, ai_follow, op_r], [ai_leader, op_r, ai_follow, op_l]
				if killing_moves[ai_leader] == :both && checkAIdamage(follow_mon, @battle.battlers[speedorder[1]]) >= follow_mon.hp
				  biggest_threat = speedorder[1] if threatscore[speedorder[3]] <= 2 * threatscore[speedorder[1]]
				end
			  # if the leader is gonna survive a hit from the mon moving before it, but the follower isn't from the mon after it, kill the mon that moves aftere the follower
			  when [op_l, ai_leader, op_r, ai_follow]
				if killing_moves[ai_leader] == :both && checkAIdamage(leader_mon, @battle.battlers[speedorder[0]]) < leader_mon.hp && checkAIdamage(follow_mon, @battle.battlers[speedorder[2]]) >= follow_mon.hp
				  biggest_threat = threatscore[speedorder[0]] >= 2 * threatscore[speedorder[2]] ? speedorder[0] : speedorder[2]
				end
			end
	
	
			scoreDecrease(biggest_threat, killing_moves, decrease_by, ai_leader)
		  elsif bestmove.priority > 0
			# priority moves fuck up jsut about everything
			biggest_threat_index = biggest_threat
			scoreDecrease(biggest_threat, killing_moves, 0.4, ai_leader)
		  elsif bestmove.target == :AllOpposing || bestmove.target == :AllNonUsers
			# fuck it if i know
		  end
		end
	
		# if both of them have killing move determine who should target who, mostly just don't target both the same
		if killing_moves[1] != :none && killing_moves[3] != :none
	
		  bestchoice1 = getMaxScoreIndex(@aimondata[1].scorearray)
		  bestchoice2 = getMaxScoreIndex(@aimondata[3].scorearray)
		  bestmove1 = bestchoice1[1] == 4 ? @aimondata[1].zmove : aimon1.moves[bestchoice1[1]]
		  bestmove2 = bestchoice2[1] == 4 ? @aimondata[3].zmove : aimon2.moves[bestchoice2[1]]
		  # make sure the best move isn't a status move or switching/item
	
		  if bestmove2.betterCategory != :status && bestmove1.betterCategory != :status
			speedorder = pbMoveOrderAI(bestmove1, bestmove2) # lawds see priorities of best moves in finding move order
			targetting_done = false
			case speedorder
			  when [1, 3, 2, 0], [3, 1, 2, 0], [1, 3, 0, 2], [3, 1, 0, 2] # ai,ai,player,player
				  # lawds added coordination here. if both mons want to target the same enemy, the second mon will (almost always) end up targeting the partner of its intended target, so it should care about attacking the partner instead.
				  aiMon1BestTarget = -1
				  aiMon2BestTarget = -1
				  if @aimondata[1].scorearray[0][bestchoice1[1]] > @aimondata[1].scorearray[2][bestchoice1[1]] # which player mon is aimon1 targeting with its best move
					aiMon1BestTarget = 0
				  elsif @aimondata[1].scorearray[0][bestchoice1[1]] < @aimondata[1].scorearray[2][bestchoice1[1]]
					aiMon1BestTarget = 2
				  end
				  if @aimondata[3].scorearray[0][bestchoice2[1]] > @aimondata[3].scorearray[2][bestchoice2[1]] # which player mon is aimon2 targeting with its best move
					aiMon2BestTarget = 0
				  elsif @aimondata[3].scorearray[0][bestchoice2[1]] < @aimondata[3].scorearray[2][bestchoice2[1]]
					aiMon2BestTarget = 2
				  end
				  if aiMon1BestTarget==-1 && aiMon2BestTarget!=-1 #-1 means they are equal
					aiMon1BestTarget=aiMon2BestTarget
				  elsif aiMon1BestTarget!=-1 && aiMon2BestTarget==-1 #-1 means they are equal
					aiMon2BestTarget=aiMon1BestTarget
				  end
				  same_target = aiMon1BestTarget==aiMon2BestTarget && aiMon1BestTarget != -1 # bool that determines if we need to change scores
				  if pbAIfaster?(bestmove1, bestmove2, aimon1, aimon2) && same_target # aimon1 will go first, so aimon2 shouldnt care about targeting that same mon
					@aimondata[3].scorearray[aiMon2BestTarget].map! {|score| score * 0.5}
				  elsif same_target # aimon2 will go first, so aimon1 shouldnt care about targeting that same mon
					@aimondata[1].scorearray[aiMon1BestTarget].map! {|score| score * 0.5}
				  end
				  # end new lawds coordination
			  when [1, 0, 3, 2], [1, 2, 3, 0], [3, 0, 1, 2], [3, 2, 1, 0] # ai,player,ai,player
				if killing_moves == [:_, :both, :_, :both]
				  @aimondata[speedorder[0]].scorearray[speedorder[3]].map! { |score| score * 0.4 }
				  @aimondata[speedorder[2]].scorearray[speedorder[1]].map! { |score| score * 0.4 }
				  # speedorder[0] targets speedorder[1]
				  # speedorder[2] targets speedorder[3]
				  targetting_done = true
				elsif speedorder == [1, 0, 3, 2] && killing_moves == [:_, :both, :_, :left] ||
					  speedorder == [1, 2, 3, 0] && killing_moves == [:_, :both, :_, :right] ||
					  speedorder == [3, 0, 1, 2] && killing_moves == [:_, :left, :_, :both] ||
					  speedorder == [3, 2, 1, 0] && killing_moves == [:_, :right, :_, :both]
				  if checkAIdamage(@battle.battlers[speedorder[2]], @battle.battlers[speedorder[1]]) >= @battle.battlers[speedorder[2]].hp
					@aimondata[speedorder[0]].scorearray[speedorder[3]].map! { |score| score * 0.4 }
					@aimondata[speedorder[2]].scorearray[speedorder[1]].map! { |score| score * 0.7 }
					# speedorder[0] targets speedorder[1]
					# speedorder[2] gets score decreased for speedorder[1]
					targetting_done = true
				  end
				end
			  when [1, 0, 2, 3], [1, 2, 0, 3], [3, 0, 2, 1], [3, 2, 0, 1] # ai,player,player,ai
				case killing_moves
				  when [:_, :both, :_, :both]
					@aimondata[speedorder[0]].scorearray[biggest_threat].map! { |score| score * 0.7 }
					@aimondata[speedorder[3]].scorearray[biggest_threat].map! { |score| score * 0.7 }
					# speedorder[0] targets biggest threat
					# speedorder[3] targets other
					targetting_done = true
				  when [:_, :left, :_, :left]
					@aimondata[speedorder[0]].scorearray[2].map! { |score| score * 0.7 }
					@aimondata[speedorder[3]].scorearray[0].map! { |score| score * 0.7 }
					# speedorder[0] targets the one they can kill
					# speedorder[3] targets other
					targetting_done = true
				  when [:_, :right, :_, :right]
					@aimondata[speedorder[0]].scorearray[2].map! { |score| score * 0.7 }
					@aimondata[speedorder[3]].scorearray[0].map! { |score| score * 0.7 }
					# speedorder[0] targets the one they can kill
					# speedorder[3] targets other
					targetting_done = true
				end
			  when [0, 1, 3, 2], [0, 3, 1, 2], [2, 1, 3, 0], [2, 3, 1, 0] # player,ai,ai,player
				# LAWDS improved this.
				leaderkills1 = checkAIdamage(@battle.battlers[speedorder[1]], @battle.battlers[speedorder[0]]) >= @battle.battlers[speedorder[1]].hp
				leaderkills2 = checkAIdamage(@battle.battlers[speedorder[2]], @battle.battlers[speedorder[0]]) >= @battle.battlers[speedorder[2]].hp
				aiLeaderKillsPlayerLeader = checkAIdamage(@battle.battlers[speedorder[0]], @battle.battlers[speedorder[1]]) >= @battle.battlers[speedorder[0]].hp
				aiFollowerKillsPlayerLeader = checkAIdamage(@battle.battlers[speedorder[0]], @battle.battlers[speedorder[2]]) >= @battle.battlers[speedorder[0]].hp
				if !leaderkills1 && aiLeaderKillsPlayerLeader # speedorder[0] cant kill speedorder[1], but speedorder[1] can kill speedorder[0]. then speedorder[2] should target other.
					@aimondata[speedorder[2]].scorearray[0].map! { |score| score * 0.7 }
				elsif !leaderkills2 && aiFollowerKillsPlayerLeader # speedorder[0] cant kill speedorder[2], but speedorder[2] can kill speedorder[1]. then speedorder[1] should target other.
					@aimondata[speedorder[1]].scorearray[0].map! { |score| score * 0.7 }
				end
				targetting_done = true
				# end lawds improvement
			  when [0, 1, 2, 3], [0, 3, 2, 1], [2, 1, 0, 3], [2, 3, 0, 1] # player,ai,player,ai
				case killing_moves
				  when [:_, :both, :_, :both]
					@aimondata[speedorder[1]].scorearray[speedorder[0]].map! { |score| score * 0.7 }
					@aimondata[speedorder[3]].scorearray[speedorder[2]].map! { |score| score * 0.7 }
					# speedorder[1] targets speedorder[2]
					# speedorder[3] targets speedorder[0]
					targetting_done = true
				  when [:_, :left, :_, :left], [:_, :right, :_, :right]
					if checkAIdamage(@battle.battlers[speedorder[1]], @battle.battlers[speedorder[0]]) >= @battle.battlers[speedorder[1]].hp
					  chosen_index = killing_moves == [:_, :left, :_, :left] ? 0 : 2
					  @aimondata[speedorder[3]].scorearray[chosen_index].map! { |score| score * 0.7 }
					  targetting_done = true
					else
					  # don't edit the scores, who knows which mon will live
					  targetting_done = true
					end
				end
			  when [0, 2, 1, 3], [2, 0, 1, 3], [0, 2, 3, 1], [2, 0, 3, 1] # player,player,ai,ai
				case killing_moves
				  when [:_, :both, :_, :both]
					# don't edit the scores, who knows which mon will live
					targetting_done = true
				  when [:_, :left, :_, :left], [:_, :right, :_, :right]
					# don't edit the scores, who knows which mon will live
					targetting_done = true
				end
			end
			if !targetting_done
			  case killing_moves
				when [:_, :both, :_, :both]
				  # just target differently
				  if rand(2) == 0
					@aimondata[1].scorearray[0].map! { |score| score * 0.7 }
					@aimondata[3].scorearray[2].map! { |score| score * 0.7 }
				  else
					@aimondata[1].scorearray[0].map! { |score| score * 0.7 }
					@aimondata[3].scorearray[2].map! { |score| score * 0.7 }
				  end
				when [:_, :left, :_, :both]
				  # only need to change 3 to target 2
				  @aimondata[3].scorearray[0].map! { |score| score * 0.7 }
				when [:_, :right, :_, :both]
				  # only need to change 3 to target 0
				  @aimondata[3].scorearray[2].map! { |score| score * 0.7 }
				when [:_, :both, :_, :left]
				  # only need to change 1 to target 2
				  @aimondata[1].scorearray[0].map! { |score| score * 0.7 }
				when [:_, :both, :_, :right]
				  # only need to change 1 to target 0
				  @aimondata[3].scorearray[2].map! { |score| score * 0.7 }
				when [:_, :left, :_, :left]
				  # check which has highest score move not targetting 0
				  if @aimondata[1].scorearray[0].max > @aimondata[3].scorearray[0].max
					@aimondata[1].scorearray[2].map! { |score| score * 0.7 }
					@aimondata[3].scorearray[0].map! { |score| score * 0.7 }
				  else
					@aimondata[1].scorearray[0].map! { |score| score * 0.7 }
					@aimondata[3].scorearray[2].map! { |score| score * 0.7 }
				  end
	
				when [:_, :left, :_, :right]
				# nothing to do here
				when [:_, :right, :_, :left]
				# nothing to do here
				when [:_, :right, :_, :right]
				  # check which has highest score move not targetting 2
				  if @aimondata[1].scorearray[2].max > @aimondata[3].scorearray[2].max
					@aimondata[1].scorearray[0].map! { |score| score * 0.7 }
					@aimondata[3].scorearray[2].map! { |score| score * 0.7 }
				  else
					@aimondata[1].scorearray[2].map! { |score| score * 0.7 }
					@aimondata[3].scorearray[0].map! { |score| score * 0.7 }
				  end
			  end
			end
		  end
		end
	
		# Finding the best moves for both AI
		moves_1 = findChoosableMoves(aimon1, @aimondata[1])
		moves_2 = findChoosableMoves(aimon2, @aimondata[3])
		return if moves_1.length == 0 || moves_2.length == 0
	
		moves_1.sort! { |a, b| b[:score] <=> a[:score] }
		moves_2.sort! { |a, b| b[:score] <=> a[:score] }
		bestindex1 = moves_1[0][:moveindex]
		bestindex2 = moves_2[0][:moveindex]

		bestmove1 = aimon1.moves[bestindex1]
		bestmove2 = aimon2.moves[bestindex2]
		nextbest1 = moves_1.find { |scores| scores[:moveindex] != moves_1[0][:moveindex] }
		nextbest2 = moves_2.find { |scores| scores[:moveindex] != moves_2[0][:moveindex] }
		bestmoves_id = [bestmove1.move, bestmove2.move]
	
		# both want to use a attention-grabbing move
		if bestmoves_id.all? { |bestmove| [:FOLLOWME, :RAGEPOWDER].include?(bestmove) }
		  if !nextbest1.nil? || !nextbest2.nil?
			if nextbest1.nil? || !nextbest2.nil? && nextbest1[:score] > nextbest2[:score]
			  @aimondata[1].scorearray.map! { |a| a.map!.with_index { |b, i| i == bestindex1 ? 0 : b } }
			else
			  @aimondata[3].scorearray.map! { |a| a.map!.with_index { |b, i| i == bestindex2 ? 0 : b } }
			end
		  end
		end
	
		# one wants to use helping hand	# LAWDS also extended this to if the partner wants to use fake out
		if :HELPINGHAND == bestmove1.move || :HELPINGHAND == bestmove2.move
		  if :HELPINGHAND == bestmove1.move && (bestmove2.basedamage == 0 || bestmove2.move==:FAKEOUT)
			@aimondata[1].scorearray.map! { |a| a.map!.with_index { |b, i| i == bestindex1 ? 0 : b } }
		  elsif :HELPINGHAND == bestmove2.move && (bestmove1.basedamage == 0 || bestmove1.move==:FAKEOUT)
			@aimondata[3].scorearray.map! { |a| a.map!.with_index { |b, i| i == bestindex2 ? 0 : b } }
		  end
		end
	
		# both want to use the same move that affects the battlefield
		if bestmove1.move == bestmove2.move &&
		   [:STEALTHROCK, :STICKYWEB, :TAILWIND, :GRAVITY, :LIGHTSCREEN, :REFLECT, :AURORAVEIL, :TRICKROOM, :WONDERROOM, :MAGICROOM, :SUNNYDAY, :RAINDANCE, :HAIL, :SANDSTORM, :SAFEGUARD, :SHADOWSKY].include?(bestmove1.move)
		  if !nextbest1.nil? && !nextbest2.nil?
			mon1usemove=false
			mon2usemove=false
			# LAWDS if tailwind with wind rider partner, have the faster non-wind rider mon use the move to apply the partner's boost before the partner attacks
			if bestmove1.move == :TAILWIND
				if pbAIfaster?(bestmove1,bestmove2,aimon1,aimon2) && aimon2.ability== :WINDRIDER
					mon1usemove = true
				elsif pbAIfaster?(bestmove2,bestmove1,aimon2,aimon1) && aimon1.ability== :WINDRIDER
					mon2usemove = true
				end
			end
			if bestmove1.canSnatch?
				# LAWDS if its gonna get snatched, try to kill the snatching mon before the partner uses the move
				if (aimon1.pbOppositeOpposing && aimon1.pbOppositeOpposing.pbHasMove?(:SNATCH) && aimon1.turncount == 0) || (aimon2.pbOppositeOpposing && aimon2.pbOppositeOpposing.pbHasMove?(:SNATCH) && aimon2.turncount == 0)
					if pbAIfaster?(bestmove1,bestmove2,aimon1,aimon2)
						mon2usemove=true
						mon1usemove=false
					elsif pbAIfaster?(bestmove2,bestmove1,aimon2,aimon1)
						mon1usemove=true
						mon2usemove=false
					end
				end
			end
			if nextbest1[:score] > nextbest2[:score] && !(mon1usemove && !mon2usemove)
			  @aimondata[1].scorearray.map! { |a| a.map!.with_index { |b, i| i == bestindex1 ? 0 : b } }
			else
			  @aimondata[3].scorearray.map! { |a| a.map!.with_index { |b, i| i == bestindex2 ? 0 : b } }
			end
		  end
		end
	
		# both want to use a status move against an opponent
		if PBStuff::STATUSCONDITIONMOVE.include?(bestmove1.move) && PBStuff::STATUSCONDITIONMOVE.include?(bestmove2.move) && moves_1[0][:target].intersection(moves_2[0][:target]) != []
		  nextbest1 = moves_1.find { |scores|
			scores[:moveindex] != moves_1[0][:moveindex] || scores[:target].intersection(moves_2[0][:target]) == []
		  }
		  nextbest2 = moves_2.find { |scores|
			scores[:moveindex] != moves_2[0][:moveindex] || scores[:target].intersection(moves_1[0][:target]) == []
		  }
		  if !nextbest1.nil? && !nextbest2.nil?
			if nextbest1[:score] > nextbest2[:score]
			  @aimondata[1].scorearray.map!.with_index do |a, moveindex|
				a.map!.with_index { |b, i|
				  i == bestindex1 && nextbest1[:target].include?(moveindex) ? 0 : b
				}
			  end
			else
			  @aimondata[3].scorearray.map!.with_index do |a, moveindex|
				a.map!.with_index { |b, i|
				  i == bestindex2 && nextbest2[:target].include?(moveindex) ? 0 : b
				}
			  end
			end
		  end
		end
	
		# both want to use a confusion causing move agains an opponent
		if bestmoves_id.all? { |bestmove| PBStuff::CONFUMOVE.include?(bestmove) && ![:CHATTER, :DYNAMICPUNCH].include?(bestmove) } && moves_1[0][:target].intersection(moves_2[0][:target]) != []
		  nextbest1 = moves_1.find { |scores|
			scores[:moveindex] != moves_1[0][:moveindex] || scores[:target].intersection(moves_2[0][:target]) == []
		  }
		  nextbest2 = moves_2.find { |scores|
			scores[:moveindex] != moves_2[0][:moveindex] || scores[:target].intersection(moves_1[0][:target]) == []
		  }
		  if !nextbest1.nil? && !nextbest2.nil?
			if nextbest1[:score] > nextbest2[:score]
			  @aimondata[1].scorearray.map!.with_index { |a, moveindex|
				a.map!.with_index { |b, i|
				  i == bestindex1 && nextbest1[:target].include?(moveindex) ? 0 : b
				}
			  }
			else
			  @aimondata[3].scorearray.map!.with_index { |a, moveindex|
				a.map!.with_index { |b, i|
				  i == bestindex2 && nextbest2[:target].include?(moveindex) ? 0 : b
				}
			  }
			end
		  end
		end
	
		# both want to use other move that interferes with eachother on same mon
		if bestmoves_id.all? { |bestmove| [:ENCORE].include?(bestmove) } && moves_1[0][:target].intersection(moves_2[0][:target]) != []
		  nextbest1 = moves_1.find { |scores|
			scores[:moveindex] != moves_1[0][:moveindex] || scores[:target].intersection(moves_2[0][:target]) == []
		  }
		  nextbest2 = moves_2.find { |scores|
			scores[:moveindex] != moves_2[0][:moveindex] || scores[:target].intersection(moves_1[0][:target]) == []
		  }
		  if !nextbest1.nil? && !nextbest2.nil?
			if nextbest1[:score] > nextbest2[:score]
			  @aimondata[1].scorearray.map!.with_index { |a, moveindex|
				a.map!.with_index { |b, i|
				  i == bestindex1 && nextbest1[:target].include?(moveindex) ? 0 : b
				}
			  }
			else
			  @aimondata[3].scorearray.map!.with_index { |a, moveindex|
				a.map!.with_index { |b, i|
				  i == bestindex2 && nextbest2[:target].include?(moveindex) ? 0 : b
				}
			  }
			end
		  end
		end
	
		# one is using eq and other wants to roost
		if bestmoves_id.include?(:EARTHQUAKE) && bestmoves_id.include?(:ROOST)
		  if :EARTHQUAKE == bestmove1.move
			if !pbAIfaster?(bestmove1, bestmove2, aimon1, aimon2)
			  @aimondata[3].scorearray.map! { |a| a.map!.with_index { |b, i| i == bestindex2 ? 0 : b } }
			end
		  elsif :EARTHQUAKE == bestmove2.move
			if !pbAIfaster?(bestmove2, bestmove1, aimon2, aimon1)
			  @aimondata[1].scorearray.map! { |a| a.map!.with_index { |b, i| i == bestindex1 ? 0 : b } }
			end
		  end
		end
	end

	def threatAssesment
		# Dont care about it if one of the player mons is dead
		return [1, -1, 1, -1] if @battle.battlers[0].hp <= 0 && @battle.battlers[2].hp <= 0
		return [0, -1, 1, -1] if @battle.battlers[0].hp <= 0
		return [1, -1, 0, -1] if @battle.battlers[2].hp <= 0
		threatscore = [-1, 1.0, -1, 1.0]

		# find out which of the AI mons are still Alive
		aimons = [@battle.battlers[1], @battle.battlers[3]].find_all {|mon| mon && mon.hp>0}

		@battle.battlers.each_with_index {|opp,i|
			next if i == 1 || i == 3 # only player needs assesed
			# Base stat total
			threatscore[i]*= pbBaseStatTotal(opp.species)/200.0
			# Level
			threatscore[i]*= (opp.level / ((aimons.sum {|mon| mon.level}) / aimons.length))**2
			# Mega
			threatscore[i]*= 1.1 if opp.isMega?
			# Boosts
			threatscore[i]*= 1+0.2*opp.stages[PBStats::ATTACK] 		if opp.attack > opp.spatk
			threatscore[i]*= 1+0.2*opp.stages[PBStats::SPATK] 		if opp.spatk > opp.attack
			threatscore[i]*= 1+0.05*opp.stages[PBStats::DEFENSE] 	if aimons.any? {|mon| mon.attack > mon.spatk}
			threatscore[i]*= 1+0.05*opp.stages[PBStats::SPDEF] 		if aimons.any? {|mon| mon.spatk > mon.attack}
			threatscore[i]*= 1+0.10*opp.stages[PBStats::SPEED] 		if (opp.stages[PBStats::SPEED] > 0) ^ @battle.trickroom!=0
			threatscore[i]*= [1+0.20*opp.stages[PBStats::ACCURACY],0.3].max	if opp.stages[PBStats::ACCURACY] < 0
			threatscore[i]*= 1+0.20*opp.stages[PBStats::EVASION]	if opp.stages[PBStats::EVASION] >0
			# Opp has revealed spread move
			threatscore[i]*= 1.2 if getAIMemory(opp).any? {|moveloop| moveloop!=nil && [:AllOpposing,:AllNonUsers].include?(moveloop.target)}
			# LAWDS target tailwind users
			threatscore[i]*=1.2 if opp.pbHasMove?(:TAILWIND) && opp.pbOwnSide.effects[:Tailwind]==0
			# lawds - threat score based on mon damage
			dmgthreatscore = 1.0
			for mon in aimons
				oppdmg = checkAIdamage(opp,mon)
				if oppdmg > mon.hp
					dmgthreatscore*=1.5
					next
				end
				# scale down threat scoring the lower the target mon's HP is, assuming there's no kill
				mon_hpfactor = Math.sqrt(mon.hp/mon.totalhp)
				mon_hpfactor = 0.5 if mon_hpfactor < 0.5
				dmgscore_buffer = 1 + ((oppdmg/mon.hp)/2)*mon_hpfactor
				dmgthreatscore *= dmgscore_buffer
			end
			threatscore[i]*=dmgthreatscore
			# Abilities				# lawds - added the threatscoring field to the disruptscore function for ability shield
			threatscore[i]*= aimons.sum {|mon| getAbilityDisruptScore(mon,opp,true) / aimons.length }
			# Speed
			threatscore[i]*=1.5 if aimons.any? {|aimon| pbAIfaster?(nil,nil,opp,aimon) }
			threatscore[i]*=1.1 if aimons.all? {|aimon| pbAIfaster?(nil,nil,opp,aimon) }
			# Status
			threatscore[i]*=0.6 if opp.status== :SLEEP || opp.status== :FROZEN
			threatscore[i]*=0.8 if opp.status== :PARALYSIS && ![:GUTS,:MARVELSCALE,:QUICKFEET].include?(opp.ability)
			# lawds - check for setup moves
			setupthreatscore = opp.moves.any? {|moveloop| moveloop!=nil && (PBStuff::SETUPMOVE).include?(moveloop.move)} ? 1.2 : 1
			# lawds - sleep moves increase threat score if AI mons can be slept
			sleepthreatscore = opp.moves.any? {|moveloop| moveloop!=nil && (PBStuff::SLEEPMOVE).include?(moveloop.move)} ? 1.2 : 1
			threatscore[i]*=sleepthreatscore if aimons.any? {|aimon| aimon.pbCanSleep?(false) }
			# lawds - setup moves only increase threat score on their own if the mon is already at least a mild threat
			threatscore[i]*=setupthreatscore if threatscore[i] > 1.1
			# lawds - if you have setup AND can sleep stuff, you must die
			if setupthreatscore > 1 && sleepthreatscore > 1
				threatscore[i]*=1.3
			end
		}
		PBDebug.log(sprintf("Opposing threat scores : %s",threatscore.join(", "))) if $INTERNAL
		return threatscore
	end

	def getMoveScore(initialscores=[],scoreindex=-1)
		#################### Setup ####################
		score=initialscores[scoreindex]
		# lawds again make sure
		@gonnaTerrains = []
		@gonnaWeather = 0
		#/lawds
		@initial_scores=initialscores
		@score_index=scoreindex
		if $ai_log_data[@attacker.index].move_names.length - $ai_log_data[@attacker.index].final_score_moves.length > 0
			$ai_log_data[@attacker.index].move_names.pop()
			$ai_log_data[@attacker.index].init_score_moves.pop()
			$ai_log_data[@attacker.index].opponent_name.pop()
		end
		$ai_log_data[@attacker.index].move_names.push(sprintf("%s - %d", @move.name, @opponent.index))
		$ai_log_data[@attacker.index].init_score_moves.push(score)
		$ai_log_data[@attacker.index].opponent_name.push(@opponent.name)
		@mondata.oppitemworks = @opponent.itemWorks?
		@mondata.attitemworks = @attacker.itemWorks?
		#################### Misc. Scoring ####################
		# lawds encourage breaking of sash even if it doesnt kill. this way damage checks will see a non-kill but the AI wont unreasonably prefer not breaking sash
		if @move.basedamage > 0 && @initial_scores[@score_index]==99 && notOHKO?(@opponent,@attacker,false,@move) && checkAIdamage(@opponent,@attacker) < @opponent.hp
			score = 104
			if @opponent.item==:FOCUSSASH && @battle.pbOwnedByPlayer?(@opponent.index)
				score = 110
				initialscores[scoreindex]=110
				@initial_scores[@score_index]=110
			end
		end
		if @move.function == 0x116 && @attacker.effects[:SuckerPunch] # LAWDS sucker punch
			$ai_log_data[@attacker.index].final_score_moves.push(0)
			return 0
		end
		if @move.move==:CLANGOROUSSOULBLAZE && @opponent.ability==:SOUNDPROOF && !(moldBreakerCheck(@attacker))
			$ai_log_data[@attacker.index].final_score_moves.push(0)
			return 0
		end
		# Type-nulling abilities
		if @move.basedamage>0
			typemod=pbTypeModNoMessages(@move.pbType(@attacker))
			$ai_log_data[@attacker.index].final_score_moves.push(typemod) if typemod<=0
			return typemod if typemod<=0
			wondercheck = typemod<=4 && @opponent.ability== :WONDERGUARD
			# LAWDS playing against disguise. break that shite
			score+=40 if (@opponent.effects[:Disguise] || @opponent.effects[:IceFace]) && !moldBreakerCheck(@attacker,@move)
			if [:MULTISCALE,:SHADOWSHIELD].include?(@opponent.ability) && 
				!moldBreakerCheck(@attacker,@move) && 
				@opponent.hp==@opponent.totalhp
				hpgain = hpGainPerTurn(@opponent,true)
				score+=20 if hpgain >=0 && hpgain*100 < @initial_scores[@score_index]
			end
			
		end
		# LAWDS - knowing your move is going to get redirected by Dachsbun Crest or Ring Target on Big Top
		if @battle.doublebattle
		  redirected = false
		  redirected = true if @opponent.pbPartner.effects[:FollowMe] && !@opponent.effects[:FollowMe]

		  if redirected && (@attacker.pbTarget(@move)==:SingleNonUser || @attacker.pbTarget(@move)==:RandomOpposing) && ![:STALWART,:PROPELLERTAIL].include?(@attacker.ability) && @move.function != 0x179 && @move.move != :THUNDERRAID # Snipe Shot, Thunder Raid
			$ai_log_data[@attacker.index].final_score_moves.push(0)
			return 0 # we return 0 for the score against the opponent since we can't target them
		  end
		end
		# LAWDS playing with new red card and sand spit on desert. not perfect but should mostly suffice.
		if @move.basedamage > 0 && (@attacker.hasWorkingItem(:REDCARD) || @attacker.effects[:DesertSpit]==true) && !illusionCheck() && ![:GUARDDOG,:SUCTIONCUPS].include?(@opponent.ability) && !@opponent.effects[:Ingrain] && !(pbAIfaster?() || checkAIpriority(nil,@opponent,true))
			validparty = @battle.pbPartySingleOwner(@opponent.index)
			lastindex=0
			for i in 0...validparty.length
				mon = validparty[i]
				next if mon==nil || mon.hp<=0 || mon==@opponent.pokemon || mon==@opponent.pbPartner.pokemon || mon.isEgg? || !@battle.pbCanSwitchLax?(@opponent.index,i,false) || mon.isbossmon
				lastindex = i
			end
			if lastindex > 0
				dragged_mon = validparty[lastindex]
				dragged_battler = pbMakeFakeBattler(dragged_mon, lastindex, false, @opponent.index)
				dragged_battler = pbStatChangingSwitch(dragged_battler)
				pbStatChangingSwitchOpponent(dragged_battler,@attacker)
				dmg = pbRoughDamage(@move,@attacker,dragged_battler,false)
				if dmg <= 0
					score*=0.9
				end
			end
		end
		# LAWDS improved playing around crabominable crest
		if !@battle.doublebattle && @opponent.crested == :CRABOMINABLE && pbAIfaster?(@move) && @move.basedamage==0 && !hasgreatmoves()
			oppdamage = checkAIdamage()
			oppdamageNoAttack = (oppdamage*2/3).round
			if oppdamage >= @attacker.hp && oppdamageNoAttack < @attacker.hp
				score*=1.5
			end
		end
		# LAWDS playing with water retention
		if @move.basedamage > 0 && @attacker.ability==:WATERRETENTION && !([:DESERT,:VOLCANICTOP,:VOLCANIC].include?(@battle.FE)) && @opponent.ability!=:LONGREACH && !(@opponent.hasWorkingItem(:PROTECTIVEPADS)) && !(@opponent.type1==:WATER && @opponent.type2==nil)
			bestmove = checkAIbestMove()
			if bestmove.contactMove? && !pbAIfaster?(@move,bestmove) && @opponent.ability!=:LONGREACH && @opponent.item!=:PROTECTIVEPADS
				oppdummy = pbCloneBattler(@opponent.index)
				oppdummy.type1=:WATER
				oppdummy.type2=nil
				dummyinitscore = pbRoughDamage(@move,@attacker,oppdummy)
				scoremult = dummyinitscore/@initial_scores[@score_index]
				score*=scoremult if scoremult < 1
			end
		end
		#Hell check: Can you hit this pokemon that has an ability that nullifies your move?
		if @mondata.skill>=MEDIUMSKILL && !moldBreakerCheck(@attacker,@move) && !@opponent.hasWorkingItem(:ABILITYSHIELD) && !(@move.isSoundBased? && @attacker.ability==:LIQUIDVOICE) && # lawds just put this here manually ig
				((@attacker.pbTarget(@move)==:SingleNonUser || [:RandomOpposing, :AllOpposing, :OpposingSide, :SingleOpposing].include?(@attacker.pbTarget(@move)) || (@attacker.pbTarget(@move)==:OppositeOpposing && @attacker.hasType?(:GHOST))) && @move.basedamage == 0) 
			if wondercheck
				$ai_log_data[@attacker.index].final_score_moves.push(0)
				return 0
			end
			if 	(@move.pbType(@attacker) == :FIRE && @opponent.nullsFire?) || (@move.pbType(@attacker) == :GRASS && @opponent.nullsGrass?) ||
				(@move.pbType(@attacker) == :WATER && @opponent.nullsWater?) || (@move.pbType(@attacker) == :ELECTRIC && @opponent.nullsElec?) ||
				(@move.pbType(@attacker)==:GROUND && @opponent.ability==:EARTHEATER) || # LAWDS soil slurper
				(@move.pbType(@attacker) == :POISON && [:IMMUNITY,:POISONHEAL].include?(@opponent.ability)) # lawds
				$ai_log_data[@attacker.index].final_score_moves.push(-1)
				return -1
			end			# LAWDS - reflector also acts like MBounce. also magic bounce buffer
			$ai_log_data[@attacker.index].final_score_moves.push(0) if (@opponent.ability== :MAGICBOUNCE || @opponent.pbPartner.ability== :MAGICBOUNCE || @opponent.ability== :REFLECTOR || @opponent.pbPartner.ability== :REFLECTOR) && !(@opponent.effects[:mbouncebuffer] || @opponent.pbPartner.effects[:mbouncebuffer]) && @move.basedamage == 0 #there is not a good way to do this section
			$ai_log_data[@attacker.index].final_score_moves.push(0) if (@opponent.effects[:MagicCoat]==true || @opponent.pbPartner.effects[:MagicCoat]==true) && @move.basedamage == 0 #there is not a good way to do this section
			return -1 if (@opponent.ability== :MAGICBOUNCE || @opponent.pbPartner.ability== :MAGICBOUNCE || @opponent.ability== :REFLECTOR || @opponent.pbPartner.ability== :REFLECTOR) && !(@opponent.effects[:mbouncebuffer] || @opponent.pbPartner.effects[:mbouncebuffer]) && @move.basedamage == 0 #there is not a good way to do this section
			return -1 if (@opponent.effects[:MagicCoat]==true || @opponent.pbPartner.effects[:MagicCoat]==true) && @move.basedamage == 0 #there is not a good way to do this section
		end				# LAWDS - added thousand arrows and the new scorchingsands-desert-sandstorm interaction as exceptions to this block
		if @move.pbType(@attacker) == :GROUND && !canGroundMoveHit?(@opponent) && @battle.FE !=:CAVE && @move.basedamage != 0 && @move.move != :THOUSANDARROWS && !(@move.move == :SCORCHINGSANDS && @battle.FE == :DESERT && @battle.pbWeather == :SANDSTORM && !@opponent.hasWorkingItem(:UTILITYUMBRELLA))
			$ai_log_data[@attacker.index].final_score_moves.push(0)
			return 0
		end
		# field based move failures (should this be a high skill check?)
		if @move.moveFieldBoost==0
			$ai_log_data[@attacker.index].final_score_moves.push(0)
			return 0
		end
		if @move.typeFieldBoost(@move.pbType(@attacker),@attacker,@opponent)==0
			$ai_log_data[@attacker.index].final_score_moves.push(0)
			return 0
		end
		# LAWDS - status move as Crested Klinklang
		if @attacker.crested == :KLINKLANG && @move.basedamage == 0 && @move != :PROTECT
			lockonscore = lockoncode()
			score *= lockonscore if lockonscore > 1
			score *= 5 if @move == :SHIFTGEAR && (@attacker.stages[PBStats::ATTACK] < 1 && @attacker.stages[PBStats::SPEED] < 1) 
			# LAWDS - a very contrived implementation of the intended playstyle of the crest but be fr. klinklang exists for one purpose. just do it already.
		end
		#fuck
		#Priority checks
		if @move.pbIsPriorityMoveAI(@attacker) && @attacker != @opponent.pbPartner
			aifaster=pbAIfaster?
			aifaster_partner = pbAIfaster?(nil,nil,@attacker,@opponent.pbPartner) if @battle.doublebattle && @opponent.pbPartner.hp > 0
			PBDebug.log(sprintf("Priority Check Begin")) if $INTERNAL
			aifaster ? PBDebug.log(sprintf("AI Pokemon is faster.")) : PBDebug.log(sprintf("Player Pokemon is faster.")) if $INTERNAL
			if (@battle.doublebattle || (@opponent.status!=:SLEEP && @opponent.status!=:FROZEN && !@opponent.effects[:Truant] && @opponent.effects[:HyperBeam] == 0)) && !seedProtection?(@attacker) # This line might be in the wrong place, but we're trying our best here-- skip priority if opponent is incapacitated
				if @initial_scores[@score_index]>=110
					# lawds if you're naturally faster, check other conditions before boosting prio in singles
					scoremult = @battle.doublebattle ? 1.3 : 1.0
					if scoremult == 1.0
						opp_best_move,opp_damage = checkAIMovePlusDamage
						# if we need to use prio to outspeed their best move, boost score
						scoremult = 1.2 if pbAIfaster?(@move,opp_best_move,@attacker,@opponent) && !pbAIfaster?(nil,opp_best_move,@attacker,@opponent)
						naturally_outspeeds_all = true
						move_outspeeds_all = true
						for move in @opponent.moves
							enemyMoveDmg = @aimondata[@opponent.index].roughdamagearray[@attacker.index][@opponent.moves.index(move)]
							next if move.basedamage > 0 && enemyMoveDmg && enemyMoveDmg <= 0
							naturally_outspeeds_all = false if !pbAIfaster?(nil,move,@attacker,@opponent)
							move_outspeeds_all = false if pbAIfaster?(@move,move,@attacker,@opponent)
						end
						# if we can use prio to kill before they can use any move, when they'd be able to get a move in if we dont use priority, boost score
						scoremult *= 1.1 if move_outspeeds_all && !naturally_outspeeds_all
						# in that case, favor it even more if we could preserve our sash this way
						scoremult *= 1.2 if move_outspeeds_all && !naturally_outspeeds_all && @attacker.hp==@attacker.totalhp && hpGainPerTurn(@attacker)>=1 && 
										 (@attacker.ability==:STURDY || (@attacker.ability==:STALWART && @battle.FE==:COLOSSEUM) || (@attacker.item==:FOCUSSASH) || (@battle.FE==:CHESS && @attacker.pokemon.piece==:PAWN)) &&
										!(@move.contactMove? && @attacker.ability!=:LONGREACH && @attacker.ability!=:MAGICGUARD && @attacker.item!=:PROTECTIVEPADS && ([:ROUGHSKIN,:IRONBARBS,:AFTERMATH].include?(@opponent.ability)))
					end
					score*=scoremult
					# /lawds
				elsif @attacker.ability== :STANCECHANGE && !aifaster && @attacker.form == 0 && @attacker.pokemon.species == :AEGISLASH && @initial_scores[@score_index] < 100
					score*=0.5
				elsif @attacker.crested == :VESPIQUEN && !aifaster && @attacker.effects[:VespiCrest] == false
					score*=0.7
				end
				movedamage = -1
				opppri = false
				pridam = -1
				movedamage2 = -1
				opppri2 = false
				pridam2 = -1
				abusemove = false # LAWDS checks if the opponent has any moves that they can use to exploit you clicking prio
				if !aifaster || aifaster_partner==false || getAIMemory().any? {|moveloop| moveloop!=nil && moveloop.basedamage > 0 && moveloop.pbIsPriorityMoveAI(@opponent)} || (getAIMemory(@opponent.pbPartner).any? {|moveloop| moveloop!=nil && moveloop.basedamage > 0 && moveloop.pbIsPriorityMoveAI(@opponent.pbPartner)} && @battle.doublebattle)
					testmemory= getAIMemory() + [PokeBattle_Move_FFF.new(@battle,@opponent, @opponent.type1)]
					testmemory= testmemory + [PokeBattle_Move_FFF.new(@battle,@opponent, @opponent.type2)] if !@opponent.type2.nil?
					for i in @opponent.moves
						next if i==nil
						next if i.function==0x116 && @opponent.effects[:SuckerPunch]
						next if i.function==0xe0 && !@battle.doublebattle # lawds dont worry about dying to explosion in singles cause theyll boom too
						tempdam = pbRoughDamage(i,@opponent,@attacker)
						movedamage = tempdam if tempdam>movedamage
						if i.pbIsPriorityMoveAI(@opponent) && i.basedamage > 0
							opppri=true
							pridam = tempdam if tempdam>pridam
						end
						# LAWDS check for any moves the opponent has that they can abuse your priority with (assuming your priority move doesn't KO)
						next if @attacker.pbPartner.index==2
						if abusemove==false && initialscores[scoreindex] < 100 && @move.basedamage > 0 &&
							((i.move==:REFLECT && @opponent.pbOwnSide.effects[:Reflect]==0) ||
							(i.move==:LIGHTSCREEN && @opponent.pbOwnSide.effects[:LightScreen]==0) ||
							([:SPIKES,:CEASELESSEDGE].include?(i.move) && @attacker.pbOwnSide.effects[:Spikes] < 3) ||
							([:STEALTHROCK,:STONEAXE].include?(i.move) && @attacker.pbOwnSide.effects[:StealthRock]==false) ||
							(i.move==:STICKYWEB && @attacker.pbOwnSide.effects[:StickyWeb]==false) ||
							(i.move==:TOXICSPIKES && @attacker.pbOwnSide.effects[:ToxicSpikes]==0) ||
							((i.move==:TAILWIND || (i.move==:NATUREPOWER && @battle.FE==:SKY)) && @opponent.pbOwnSide.effects[:Tailwind]==0) ||
							(i.move == :AURORAVEIL && (@battle.pbWeather==:HAIL || [:DARKCRYSTALCAVERN,:RAINBOW,:ICY,:CRYSTALCAVERN,:SNOWYMOUNTAIN,:MIRROR,:STARLIGHT,:FROZENDIMENSION].include?(@battle.FE) && @opponent.pbOwnSide.effects[:AuroraVeil]==0)) ||
							(i.move == :ARENITEWALL && (@battle.pbWeather==:SANDSTORM || [:ROCKY,:DESERT,:BEACH,:DARKCRYSTALCAVERN].include?(@battle.FE)) && @opponent.pbOwnSide.effects[:AreniteWall]==0) || 
							(PBStuff::SETUPMOVE.include?(i.move) && @opponent.ability!=:INDUSTRYSTANDARD) ||
							(i.function==0x116 && pbAIfaster?()) ||
							i.isHealingMove? || 
							(hpGainPerTurn(@opponent,true))*100 > @initial_scores[@score_index] || 
							(i.function==0x0DD && @attacker.ability!=:LIQUIDOOZE)) # drain moves
							abusemove = true
						end
					end
					testmemory= getAIMemory(@opponent.pbPartner) + [PokeBattle_Move_FFF.new(@battle,@opponent.pbPartner, @opponent.pbPartner.type1)]
					testmemory= testmemory + [PokeBattle_Move_FFF.new(@battle,@opponent.pbPartner, @opponent.pbPartner.type2)] if !@opponent.pbPartner.type2.nil?
					for i in @opponent.pbPartner.moves
						next if i==nil
						next if i.function==0x116 && @opponent.pbPartner.effects[:SuckerPunch]
						tempdam = pbRoughDamage(i,@opponent.pbPartner,@attacker)
						next if tempdam <= 0
						movedamage2 = tempdam if tempdam>movedamage2
						if i.pbIsPriorityMoveAI(@opponent.pbPartner) && i.basedamage > 0
							opppri2=true
							pridam2 = tempdam if tempdam>pridam2
						end
					end
					# lawds if you outspeed, only favor priority killing moves if they can smack you with prio on the way down
					if score > 100 && aifaster && (pridam > 0 || pridam2 > 0)
						score *= @battle.doublebattle ? 1.1 : 1.3
					end
				end
				movedamage = @attacker.hp - 1 if notOHKO?(@attacker, @opponent, true)
				movedamage2 = @attacker.hp - 1 if notOHKO?(@attacker, @opponent.pbPartner, true)
				PBDebug.log(sprintf("pre-check: %d",score)) if $INTERNAL
				PBDebug.log(sprintf("Expected damage taken: %d",[movedamage,movedamage2].max)) if $INTERNAL
				# LAWDS change to doubles prio AI
				if @battle.doublebattle
					switchableparty = @battle.pbParty(@opponent.index).find_all.with_index {|mon,monindex| @battle.pbCanSwitch?(@opponent.index,monindex,false,true)}
					canswitchout = switchableparty.length > 0
					scoreboost = @attacker.index==2 ? 150 : (initialscores[scoreindex]>50 || !canswitchout || 
					([:LIGHTSCREEN,:REFLECT,:AURORAVEIL,:SPIKES,:STEALTHROCK,:STICKYWEB,:TAILWIND,:FIRSTIMPRESSION].include?(@move.move) && score > 20) || 
					@move.move==:EXTREMESPEED && @attacker.ability==:PIXILATE && score > 20) ? 60 : 0
					score+=30 if @move.move==:FIRSTIMPRESSION && initialscores[scoreindex] >= 100
				else
					scoreboost = 150
				end
				scoreboost = 30 if PBStuff::PROTECTMOVE.include?(@move.move)
				scoreboost = 0 if @attacker.species==:SYLVEON && $game_switches[342] && @initial_scores[@score_index]<100
				if (@attacker.pbPartner.pbHasMove?(:FOLLOWME) || @attacker.pbPartner.pbHasMove?(:RAGEPOWDER))
					scoreboost = 0 
				end
				if @opponent.species == :MEWTWO && @opponent.isbossmon
					scoreboost = 0
				end
				# lawds dont be exploitable and give free turns with this shit okie
				hpgain = hpGainPerTurn(@opponent)
				scoreboost = 0 if initialscores[scoreindex] < 100 && (@opponent.ability== :STAMINA || [:NOCTOWL,:PERRSERKER,:DECIDUEYE].include?(@opponent.crested)) 
				scoreboost = 0 if initialscores[scoreindex] < 100 && scoreboost > 0 && abusemove && @battle.pbOwnedByPlayer?(@opponent.index) &&
						!(([:MULTISCALE,:SHADOWSHIELD,:STURDY].include?(@opponent.ability) || (@mondata.oppitemworks && @opponent.item==:FOCUSSASH) || 
						(@battle.FE==:COLOSSEUM && @opponent.ability==:STALWART) ||
						(@battle.FE==:CHESS && @opponent.pokemon.piece==:PAWN && !@opponent.damagestate.pawnsturdyused)) && 
						@opponent.hp==@opponent.totalhp && hpgain>=1 && (hpgain - 1.0)*100 < initialscores[scoreindex]*(@opponent.hp.to_f)/@opponent.totalhp)

				if scoreboost > 0 && !aifaster && ((movedamage > @attacker.hp  && !(@attacker.ability== :RESUSCITATION && @attacker.form==1)) || (!aifaster_partner && movedamage2 > @attacker.hp && !(@attacker.ability== :RESUSCITATION && @attacker.form==1))) && score > 1
					score+= scoreboost
					# LAWDS - limit the priority score by the switching score so that the AI wont just click priority brainlessly instead of switching, while still making it use prio when it doesn't want to switch
					if !@battle.doublebattle && @mondata.shouldswitchscore > 0 && @initial_scores[@score_index] < 100
						this_switchscore = @mondata.shouldswitchscore
						if this_switchscore > 0 && @mondata.switchscore.length > 0
							switch_in_score = @mondata.switchscore.max
							if shouldHardSwitch?(@attacker,@mondata.switchscore.index(@mondata.switchscore.max(2)[1]))
								score=this_switchscore*0.8 if score > this_switchscore && switch_in_score >= 100 && this_switchscore >= 100 && initialscores[scoreindex] < 100
							end
						end
					end
				end
				PBDebug.log(sprintf("post-check: %d",score)) if $INTERNAL
				if opppri
					score*=1.1
					score*= aifaster ? 3 : 0.5 if pridam>attacker.hp
				elsif opppri2
					score*=1.1
					score*= aifaster_partner ? 3 : 0.5 if pridam2>attacker.hp
				end
			end
			score*=0 if !aifaster && @opponent.effects[:TwoTurnAttack]!=0
			# Lawds Mod - AI should note priority attacks are not blocked by the terrain or by abilities under these conditions. also, king moves ignore dazzling and the like
			not_prio_block_exception = !([:User,:Partner,:UserSide,:OpposingSide,:UserOrPartner,:AllNonUsers,:BothSides].include?(@move.target)) && !([:PERISHSONG, :ROTOTILLER, :FLOWERSHIELD].include?(@move.target)) && !(@move.priorityCheck(@attacker) == 1 && @battle.FE == :CHESS && @attacker.pokemon && @attacker.pokemon.piece == :KING) 
			is_prio_blocked = not_prio_block_exception && prioBlocked?(@opponent,@attacker) # final judgement of whether the prio move is blocked or not
			score*=0 if is_prio_blocked
			# lawds - only worry about quick guard in double battles unless you're taking chip in singles or the enemy's partner has fainted so its just a 1v1. yes you can do some singles stuff to dodge FImp but like i dont care
			if (checkAImoves([:QUICKGUARD]) || checkAImoves([:QUICKGUARD],getAIMemory(@opponent.pbPartner))) && [:AllOpposing,:AllNonUsers,:SingleNonUser].include?(@move.target) && ((@battle.doublebattle && !@opponent.pbPartner.isFainted?) || hpGainPerTurn(@attacker) < 1) && !(@attacker.ability==:UNSEENFIST && @move.contactMove? && @attacker.item!=:PROTECTIVEPADS)
				score*=0.9 # improve this sometime
			end
			score*=1.2 if @attacker.ability== :EMERGENCYEXIT && @battle.FE != :COLOSSEUM && !aifaster # lawds - just a flat preference for priority moves with emergency exit if you're slower.
			PBDebug.log(sprintf("Priority Check End")) if $INTERNAL
		elsif @move.priority<0 && pbAIfaster?()
			score*=0.9
			score*=0.6 if initialscores[scoreindex] >=100 && initialscores.count {|iniscore| iniscore >= 100} > 1
			score*=2 if @move.basedamage>0 && @opponent.effects[:TwoTurnAttack]!=0
		end
		#Sound move checks
		if !@move.zmove && @move.isSoundBased?
			$ai_log_data[@attacker.index].final_score_moves.push(0) if (@opponent.ability== :SOUNDPROOF && !moldBreakerCheck(@attacker,@move)) || @attacker.effects[:ThroatChop]!=0
			return 0 if (@opponent.ability== :SOUNDPROOF && !moldBreakerCheck(@attacker,@move)) || @attacker.effects[:ThroatChop]!=0
			# LAWDS - playing around follow me with immunities
			if @move.target == :SingleNonUser && (@opponent.pbPartner.pbHasMove?(:FOLLOWME) || (@opponent.pbPartner.pbHasMove?(:RAGEPOWDER) && !(@attacker.hasType?(:GRASS) || @attacker.ability== :OVERCOAT || @attacker.hasWorkingItem(:SAFETYGOGGLES)))) && ![:PROPELLERTAIL,:STALWART].include?(@attacker.ability) && (@opponent.pbPartner.ability== :SOUNDPROOF && !moldBreakerCheck(@attacker,@move))
				score*=0.2
			end
			score *= 0.6 if checkAImoves([:THROATCHOP]) && !pbAIfaster?(@move) # LAWDS - only care about getting throat chopped if you're slower
			if @attacker.hasWorkingItem(:THROATSPRAY) && @move.move != :TORCHSONG # Lawds Mod - AI now sees a special attack boost when consuming throat spray. torch song is excepted so the net +2 can be taken into account in a single selfstatboost check
				score *= selfstatboost([0,0,0,1,0,0,0])
				score *= 1.5 if @mondata.roughdamagearray[@opponent.index][@score_index] > 100 # LAWDS - AI fix for Jenner Dudun
			end
		end
		# LAWDS - playing around follow me with immunities. takes thunder raid and snipe shot into account
		if @move.target == :SingleNonUser && (@opponent.pbPartner.pbHasMove?(:FOLLOWME) || (@opponent.pbPartner.pbHasMove?(:RAGEPOWDER) && !(@attacker.hasType?(:GRASS) || @attacker.ability== :OVERCOAT || @attacker.hasWorkingItem(:SAFETYGOGGLES)))) && ![:PROPELLERTAIL,:STALWART].include?(@attacker.ability) && (pbTypeModNoMessages(@move.pbType(@attacker),@attacker,@opponent) == 0) && ![:SNIPESHOT,:THUNDERRAID].include?(@move.move)
			score*=0.2
		end
		# Wind Move Checks
    	# Gen 9 Mod - Added Wind Rider # Gen 9 Mod - Added myceliumMightCheck
		if !@move.zmove && @move.windMove? # LAWDS - wind rider does not block wind moves on sky field
			sky_rider = (@opponent.ability== :WINDRIDER && @battle.FE == :SKY)
			wind_rider_block = (@opponent.ability== :WINDRIDER && !(moldBreakerCheck(@attacker,@move)) && !sky_rider)
      		$ai_log_data[@attacker.index].final_score_moves.push(0) if wind_rider_block
			return 0 if wind_rider_block && !sky_rider
			score*=0.3 if sky_rider && @mondata.roughdamagearray[@opponent.index][@score_index] < 100 # dont boost them if you cant kill
			# LAWDS - playing around follow me with immunities
			if @move.target == :SingleNonUser && (@opponent.pbPartner.pbHasMove?(:FOLLOWME) || (@opponent.pbPartner.pbHasMove?(:RAGEPOWDER) && !(@attacker.hasType?(:GRASS) || @attacker.ability== :OVERCOAT || @attacker.hasWorkingItem(:SAFETYGOGGLES)))) && ![:PROPELLERTAIL,:STALWART].include?(@attacker.ability) && (@opponent.pbPartner.ability== :WINDRIDER && !moldBreakerCheck(@attacker,@move) && @battle.FE != :SKY)
				score*=0.2
			end
    	end
		if @opponent.ability== :DANCER
			if (PBStuff::DANCEMOVE).include?(@move.move)
				score*=0.5
				score*=0.1 if @battle.FE == :BIGTOP || @battle.FE == :DANCEFLOOR
			end
		end
		# LAWDS - reorganized this
		if @mondata.skill>=HIGHSKILL && @opponent.index!=@attacker.index
			for j in getAIMemory(@opponent)
				ioncheck = true if j.move==:PLASMAFISTS
				if @opponent.effects[:Taunt]<=0 # LAWDS - dont worry about these moves if the opponent is taunted. improve taunt code?
					ioncheck = true if j.move==:IONDELUGE
					if j.move==:DESTINYBOND && !@opponent.effects[:DestinyRate] # lawds grab a few other things for playing against dbond
						destinycheck = true
						faster_dbond = !pbAIfaster?(@move,j,@attacker,@opponent)
					end
					widecheck = true if j.move==:WIDEGUARD && j.pp > 0 # lawds also check the PP on the move 
					powdercheck = true if j.move==:POWDER
					shieldcheck = true if j.move==:SPIKYSHIELD || j.move==:KINGSSHIELD ||  j.move==:BANEFULBUNKER || j.move==:SILKTRAP || j.move==:BURNINGBULWARK # Gen 9 Mod - Added Silk Trap, Burning Bulwark
				end
			end
			if @battle.doublebattle
				for j in getAIMemory(@opponent.pbPartner)
					ioncheck = true if j.move==:PLASMAFISTS
					if @opponent.pbPartner.effects[:Taunt]<=0
						widecheck = true if j.move==:WIDEGUARD && j.pp > 0 # LAWDS - dont worry about these moves if the opponent is taunted. improve taunt code?
						powdercheck = true if j.move==:POWDER
						ioncheck = true if j.move==:IONDELUGE
					end
				end
			end
			if @move.basedamage > 0
				couldkill = (@battle.doublebattle || @mondata.roughdamagearray[@opponent.index][@score_index] > 100) # LAWDS only cut score if there is any reasonable chance of killing with the move. allows AI to stall with a weak attack if they have no good status moves to click
				if @opponent.effects[:DestinyBond] && couldkill
					score*=0.1
				elsif couldkill && destinycheck	
					# LAWDS - DIE MEGA BANETTE DIE
					if faster_dbond
						if @move.pbTargetsAll?(@attacker)
							score*=0.5 if pbRoughDamage(@move,@attacker,@opponent.pbPartner) < @opponent.pbPartner.totalhp/2 # unless you have a big fuckoff spread move to click
						else
							score*=0.3
							score*=0.3 if @opponent.hp<@opponent.totalhp/2
						end
					end
				end
			end
			if ioncheck && @move.type == :NORMAL
				score*=0.3 if [:LIGHTNINGROD,:VOLTABSORB,:MOTORDRIVE].include?(@opponent.ability) || (@opponent.pbPartner.ability== :LIGHTNINGROD && ![:STALWART,:PROPELLERTAIL].include?(@attacker.ability))
			end
			# Lawds Mod - ion deluge global effect, might be a weird placement in the file but its fine
			if @battle.state.effects[:IonDeluge] && @move.type == :NORMAL
				return -1 if [:LIGHTNINGROD,:VOLTABSORB,:MOTORDRIVE].include?(@opponent.ability) || (@opponent.pbPartner.ability== :LIGHTNINGROD && ![:STALWART,:PROPELLERTAIL].include?(@attacker.ability))
			end
			if widecheck && [:AllOpposing, :AllNonUsers].include?(@move.target) && ((@battle.doublebattle && !@opponent.pbPartner.isFainted?) || hpGainPerTurn(@attacker) < 1) # LAWDS - only worry about wide guard in doubles OR if the attacker is taking HP damage per turn and would get stalled out with wide guard. improvement to scoring method
				score*=0.9 # lawds change the score cut to 0.9 since wide guard only has 1pp now, shouldnt be too exploitable
			end
			score*=0.2 if powdercheck && @move.pbType(@attacker)==:FIRE
		end
		# If opponent about to use a recover move before being killed, check damage vs them again
		if checkAIhealing && !pbAIfaster?(@move) && @mondata.skill >= BESTSKILL && @move.basedamage > 0
			newhp = [((@opponent.totalhp+1)/2) + @opponent.hp, @opponent.totalhp].min
			score*= [pbRoughDamage/newhp.to_f, 1.1].min
		end

		# LAWDS - type berries
		type = @move.pbType(@attacker)
		typemod = pbTypeModNoMessages(type)
		berrycheck = false
		if @mondata.oppitemworks && typemod>4 && !([:UNNERVE,:ASONE].include?(@attacker.ability) || [:UNNERVE,:ASONE].include?(@attacker.pbPartner.ability)) && !hasgreatmoves()
			case @opponent.item
				when :CHOPLEBERRY	then berrycheck=true if type == :FIGHTING
				when :COBABERRY		then berrycheck=true if type == :FLYING
				when :KEBIABERRY	then berrycheck=true if type == :POISON
				when :SHUCABERRY	then berrycheck=true if type == :GROUND
				when :CHARTIBERRY   then berrycheck=true if type == :ROCK
				when :TANGABERRY	then berrycheck=true if type == :BUG
				when :KASIBBERRY	then berrycheck=true if type == :GHOST
				when :BABIRIBERRY 	then berrycheck=true if type == :STEEL
				when :OCCABERRY 	then berrycheck=true if type == :FIRE
				when :PASSHOBERRY 	then berrycheck=true if type == :WATER
				when :RINDOBERRY 	then berrycheck=true if type == :GRASS
				when :WACANBERRY 	then berrycheck=true if type == :ELECTRIC
				when :PAYAPABERRY 	then berrycheck=true if type == :PSYCHIC
				when :YACHEBERRY 	then berrycheck=true if type == :ICE
				when :HABANBERRY 	then berrycheck=true if type == :DRAGON
				when :COLBURBERRY 	then berrycheck=true if type == :DARK
				when :ROSELIBERRY 	then berrycheck=true if type == :FAIRY
			end
		end
		# encourage expending berries unless they have harvest or you can kill them otherwise
		if berrycheck && (@opponent.ability!=:HARVEST) && checkAIdamage(@opponent,@attacker) < @opponent.hp && (@opponent.pbPartner.hp <= 0 || (checkAIdamage(@opponent.pbPartner,@attacker)<@opponent.pbPartner.hp))
			# increase score even further to see 2hkos
			score*=1.5 if ((@initial_scores[@score_index] >= 34) || (@opponent.ability==:RIPEN && @initial_scores[@score_index] >= 20)) && @initial_scores[@score_index] < 50
		end

		# Check for moves that can be nullified by any mon in doubles		# LAWDS - thunder raid ignores redirection. also added snipe shot to the consideration
		if @battle.doublebattle && [:SingleNonUser, :RandomOpposing, :SingleOpposing, :OppositeOpposing].include?(@move.target) && !(@attacker.ability== :PROPELLERTAIL || @attacker.ability== :STALWART) && (@move.move != :THUNDERRAID) && @move.function != 0x179
			if (@move.pbType(@attacker)==:ELECTRIC) || (ioncheck && @move.type == :NORMAL)
				$ai_log_data[@attacker.index].final_score_moves.push(0) if @opponent.pbPartner.ability== :LIGHTNINGROD
				return -1 if @opponent.pbPartner.ability== :LIGHTNINGROD
				if @attacker.pbPartner.ability== :LIGHTNINGROD
					return -1 if @opponent!=@attacker.pbPartner
					score*=0.3
				end
			elsif @move.pbType(@attacker)==:WATER
				$ai_log_data[@attacker.index].final_score_moves.push(0) if @opponent.pbPartner.ability== :STORMDRAIN
				return -1 if @opponent.pbPartner.ability== :STORMDRAIN
				if @attacker.pbPartner.ability== :STORMDRAIN
					return -1 if @opponent!=@attacker.pbPartner
					score*=0.3
				end
			elsif @move.pbType(@attacker)==:GHOST # LAWDS - spirit's envoy. doesnt affect partner moves so we dont put the 0.3 multiplier for it
				$ai_log_data[@attacker.index].final_score_moves.push(0) if @opponent.pbPartner.ability== :SPIRITSENVOY && @battle.FE!=:HAUNTED
				return -1 if @opponent.pbPartner.ability== :SPIRITSENVOY && @battle.FE!=:HAUNTED
			end
		end
		if !@move.nil? && !@move.zmove && @move.highCritRate?
			if !(@opponent.ability== :SHELLARMOR || @opponent.ability== :BATTLEARMOR || @attacker.effects[:LaserFocus]>0)
				boostercount = 0
				if @move.pbIsPhysical?()
					boostercount += @opponent.stages[PBStats::DEFENSE] if @opponent.stages[PBStats::DEFENSE]>0
					boostercount -= @attacker.stages[PBStats::ATTACK] if @attacker.stages[PBStats::ATTACK]<0
				elsif @move.pbIsSpecial?()
					boostercount += @opponent.stages[PBStats::SPDEF] if @opponent.stages[PBStats::SPDEF]>0
					boostercount -= @attacker.stages[PBStats::SPATK] if @attacker.stages[PBStats::SPATK]<0
				end
				score*=(1.05**boostercount) if hasgreatmoves()
			end
		end
		# If you have two moves that kill, use one that doesn't consume your item (gems only rn)
		if hasgreatmoves() && @attacker.item
			score*=0.85 if @attacker.item == :POWERHERB && (PBStuff::TWOTURNMOVE + PBStuff::CHARGEMOVE).include?(@move.move)
			score*=0.9 if $cache.items[@attacker.item].checkFlag?(:typeboost) == @move.type && $cache.items[@attacker.item].checkFlag?(:gem) && @battle.FE != :CRYSTALCAVERN # LAWDS - gems arent consumed on ccavern so dont worry
			score*=0.9 if @move.function==0xf7 && (@attacker.item==:BIGNUGGET || (@battle.FE==:DEEPEARTH && @attacker.item==:IRONBALL)) # lawds dont waste "useless" items to preserve fling
		end
		if Rejuv && @battle.FE == :SWAMP
			if ([:ATTACKORDER, :STRINGSHOT].include?(@move.move) || PBStuff::HEALFUNCTIONS.include?(@move.function))
				statarray = [1,1,1,1,1,1,1]
				statarray.unshift(0) #this is required to make the next line work correctly
				#Start by eliminating pointless stats
				minidrop = 1.05
				for i in 1...statarray.length
					if @opponent.pbCanReduceStatStage?(i)
						minidrop += (@opponent.ability== :COMPETITIVE || @opponent.ability== :DEFIANT || @opponent.ability== :CONTRARY) ? -0.1 : 0.05
					end
				end
				score *= minidrop
			end
		end
		#Contact move checks
		if !@move.zmove && @move.contactMove? && !(@attacker.item == :PROTECTIVEPADS) && @attacker.ability != :LONGREACH
			contactscore=1.0
			contactscore*= @attacker.hp < 0.2*@attacker.totalhp ? 0.5 : 0.85 if (@mondata.oppitemworks && @opponent.item == :ROCKYHELMET) || shieldcheck
			abil=[]
			if @opponent.ability.is_a?(PokeAbility)
				if @opponent.ability.ability.is_a?(Array)
					for i in @opponent.ability.ability
						abil.push(i)
					end
				else
					abil= [@opponent.ability.ability]
				end
			end
			for i in abil
			case i
			when :EFFECTSPORE 	then contactscore*=0.75
			when :PERISHBODY 	then contactscore*= [:DIMENSIONAL,:HAUNTED,:INFERNAL].include?(@battle.FE) ? 0.5 : 0.75 unless @battle.FE == :HOLY
			when :FLAMEBODY 	then contactscore*=0.5 if @attacker.pbCanBurn?(false) && ![:GUTS,:QUICKFEET].include?(@attacker.ability)
			when :STATIC 		then contactscore*=0.75 if @attacker.pbCanParalyze?(false) && ![:QUICKFEET].include?(@attacker.ability)
			when :POISONPOINT	then contactscore*=0.75 if @attacker.pbCanPoison?(false) && ![:GUTS,:QUICKFEET].include?(@attacker.ability)
			when :CUTECHARM 	then contactscore*=0.8 if  @attacker.effects[:Attract]<0 && initialscores.length>0 && initialscores[scoreindex] < 110
			when :ROUGHSKIN, :IRONBARBS then contactscore*= @attacker.hp < 0.2*@attacker.totalhp ? 0.5 : 0.85
			when :TOXICDEBRIS
				# LAWDS toxic debris
				if @attacker.pbOwnSide.effects[:ToxicSpikes] == 0 && !(@battle.FE == :WATERSURFACE || @battle.FE == :MURKWATERSURFACE || @battle.FE == :SKY)
					if @battle.FE == :WASTELAND
						contactscore*=0.8 if !@attacker.isAirborne? && !@attacker.hasType?(:POISON) && !@attacker.hasType?(:STEEL) && !@attacker.pbCanPoison?(false) && @attacker.ability!=:POISONHEAL
					else
						vulnerablecount=0.0
						ownparty = @battle.pbParty(@attacker.index)
						for i in 0...ownparty.length
							mon = ownparty[i]
							next if mon==nil || @attacker.pokemon==mon || @attacker.pbPartner.pokemon==mon || mon.hp<=0 || mon.isEgg?
							dummybattler = pbMakeFakeBattler(mon,i,false,@attacker.index)
							if dummybattler.hasType?(:POISON) && !!dummybattler.isAirborne?
								vulnerablecount=0
								break
							end
							dummyroles = pbGetMonRoles(dummybattler)
							if dummyroles.include?(:SPINNER)
								vulnerablecount=0
								break
							end
							next if dummybattler.hasType?(:STEEL) || dummybattler.isAirborne? || !(dummybattler.pbCanPoison?(false)) || dummyroles.include?(:STATUSABSORBER) || dummybattler.ability==:MAGICGUARD || dummybattler.item==:HEAVYDUTYBOOTS
							vulnerablecount+=1.0
						end
						scorecut = 10.0/(10.0+vulnerablecount)
						scorecut = Math.sqrt(scorecut) if checkAIdamage() >= @attacker.hp
						contactscore*=scorecut
					end
				end
			when :GOOEY, :TANGLINGHAIR, :COTTONDOWN
				if @attacker.pbCanReduceStatStage?(PBStats::SPEED)
					gooeyfaster = pbAIfaster?()
					contactscore*=0.9 if !(@move.pbIsPriorityMoveAI(@attacker) && !gooeyfaster)
					contactscore*=0.8 if gooeyfaster
				end
			when :MUMMY, :WANDERINGSPIRIT, :LINGERINGAROMA # Gen 9 Mod - Added Lingering Aroma
				if !((PBStuff::FIXEDABILITIES).include?(@attacker.ability)) && !([:MUMMY,:LINGERINGAROMA].include?(@attacker.ability) || @attacker.ability== :SHIELDDUST)
					mummyscore = getAbilityDisruptScore(@opponent,@attacker)
					# Gen 9 Mod - Added Ability Shield
          			mummyscore = 1 if (@mondata.oppitemworks && @opponent.item == :ABILITYSHIELD)
					mummyscore = mummyscore < 2 ? 2 - mummyscore : 0
					contactscore*=mummyscore
				end
			# LAWDS - Water Retention
			when :WATERRETENTION then contactscore*=typechangecode(:WATER) if !([:DESERT,:VOLCANIC,:VOLCANICTOP].include?(@battle.FE)) && ![:PROTEAN,:LIBERO].include?(@attacker.ability) && ![:REUNICLUS,:GOTHITELLE].include?(@attacker.crested) && !(@attacker.type1==:WATER && @attacker.type2==nil) && !(@initial_scores[@score_index]>=100 && !hasgreatmoves())
			end
			end
			contactscore*=0.8 if @opponent.species == :AEGISLASH && !checkAImoves([:KINGSSHIELD]) && (@move.pbIsPhysical?() || @battle.FE == :FAIRYTALE)
			contactscore*=0.5 if checkAImoves([:OBSTRUCT]) && !PBStuff::RATESHARERS.include?(@opponent.lastMoveUsed) && (@move.priority < 1 || (@move.priority==1 && !pbAIfaster?)) # LAWDS - reduce contact score vs. obstruct pokemon if the move would get blocked.
			contactscore*=0.5 if checkAImoves([:KINGSSHIELD]) && !PBStuff::RATESHARERS.include?(@opponent.lastMoveUsed) && (@move.pbIsPhysical?() || @battle.FE == :FAIRYTALE)
			contactscore*=0.7 if checkAImoves([:BANEFULBUNKER]) && !PBStuff::RATESHARERS.include?(@opponent.lastMoveUsed) && @attacker.pbCanPoison?(false)
			contactscore*=0.6 if checkAImoves([:SPIKYSHIELD]) && !PBStuff::RATESHARERS.include?(@opponent.lastMoveUsed) && @attacker.hp < 0.3 * @attacker.totalhp
			# Gen 9 Mod - Added Silk Trap and Burning Bulwark
			contactscore*=0.7 if checkAImoves([:SILKTRAP]) && !PBStuff::RATESHARERS.include?(@opponent.lastMoveUsed) && @attacker.pbCanReduceStatStage?(PBStats::SPEED)
			if checkAImoves([:BURNINGBULWARK]) && !PBStuff::RATESHARERS.include?(@opponent.lastMoveUsed) && @attacker.pbCanBurn?(false)
				if @attacker.attack > @attacker.spatk
				contactscore*=0.6
				else
				contactscore*=0.8
				end
			end
			contactscore*=1.1 if @attacker.ability== :POISONTOUCH && @opponent.pbCanPoison?(false) && !(@opponent.ability== :SHIELDDUST || @opponent.item == :COVERTCLOAK) # Gen 9 Mod - Added Shield Dust & Covert Cloak

			# LAWDS klutz
			if @attacker.ability== :KLUTZ && !(@attacker.pokemon.klutzUsed) && @initial_scores[@score_index] < 100 && !(opponent.item==:PROTECTIVEPADS)
				klutzscore = secretcode()
				klutzscore = oppstatdrop([0,0,0,0,1,0,0]) if [:SKY,:INVERSE].include?(@battle.FE)
				klutzscore = oppstatdrop([0,0,0,1,0,0,0]) if @battle.FE==:PSYTERRAIN
				klutzscore = oppstatdrop([1,0,0,0,0,0,0]) if @battle.FE==:FAIRYTALE
				klutzscore = tormentcode() if @battle.FE == :DIMENSIONAL
				if [:FOREST,:GRASSY,:BEWITCHED].include?(@battle.FE)
					klutzscore = leechcode()
					klutzscore = 1.2 if klutzscore > 0
					klutzscore = 1.0 if klutzscore == 0
				end
				klutzscore = 1 if [:CONCERT1,:CONCERT2,:CONCERT3,:CONCERT4].include?(@battle.FE)
				# deep earth handled in damage
				# fuck cave bro
				klutzscore = 0.1 if @battle.FE==:CAVE && ([:STURDY,:STALWART,:BULLETPROOF,:ROCKHEAD,:SOLIDROCK,:PRISMARMOR].include?(@opponent.ability) || @opponent.effects[:ARENITEWALL]) &&
										(!([:STURDY,:STALWART,:BULLETPROOF,:ROCKHEAD,:SOLIDROCK,:PRISMARMOR].include?(@attacker.ability) || @attacker.effects[:ARENITEWALL]) || 
										 (!([:STURDY,:STALWART,:BULLETPROOF,:ROCKHEAD,:SOLIDROCK,:PRISMARMOR].include?(@attacker.pbPartner.ability) || 
										 @attacker.pbPartner.effects[:ARENITEWALL])))
				
				contactscore*=klutzscore
			end
			if @opponent.ability== :KLUTZ && !(@opponent.pokemon.klutzUsed) && !(opponent.item==:PROTECTIVEPADS)
				attackerbuffer = @attacker
				opponentbuffer = @opponent
				@attacker = opponentbuffer
				@opponent = attackerbuffer
				klutzscore = secretcode()
				klutzscore = oppstatdrop([0,0,0,0,1,0,0]) if [:SKY,:INVERSE].include?(@battle.FE)
				klutzscore = oppstatdrop([0,0,0,1,0,0,0]) if @battle.FE==:PSYTERRAIN
				klutzscore = oppstatdrop([1,0,0,0,0,0,0]) if @battle.FE==:FAIRYTALE
				klutzscore = tormentcode() if @battle.FE == :DIMENSIONAL
				if [:FOREST,:GRASSY,:BEWITCHED].include?(@battle.FE)
					klutzscore = leechcode()
					klutzscore = 1.2 if klutzscore > 0
					klutzscore = 1.0 if klutzscore == 0
				end
				klutzscore = 1 if [:CONCERT1,:CONCERT2,:CONCERT3,:CONCERT4].include?(@battle.FE)
				if @battle.FE == :DEEPEARTH
					weightratio = (@opponent.weight/2000)
					weightratio = 0.3 if weightratio > 0.3
					weightratio = 0.1 if weightratio < 0.1
					klutzscore*=(1.0 + 0.2*(weightratio))
				end
				# fuck cave bro
				klutzscore = 0.1 if @battle.FE==:CAVE && ([:STURDY,:STALWART,:BULLETPROOF,:ROCKHEAD,:SOLIDROCK,:PRISMARMOR].include?(@opponent.ability) || @opponent.effects[:ARENITEWALL]) &&
										(!([:STURDY,:STALWART,:BULLETPROOF,:ROCKHEAD,:SOLIDROCK,:PRISMARMOR].include?(@attacker.ability) || @attacker.effects[:ARENITEWALL]) || 
										 (!([:STURDY,:STALWART,:BULLETPROOF,:ROCKHEAD,:SOLIDROCK,:PRISMARMOR].include?(@attacker.pbPartner.ability) || 
										 @attacker.pbPartner.effects[:ARENITEWALL])))
				contactscore/=klutzscore if klutzscore > 0
				@attacker = attackerbuffer
				@opponent = opponentbuffer
			end
			# end lawds klutz
			
			contactscore*=1.1 if @attacker.ability== :PICKPOCKET && @opponent.item && !@battle.pbIsUnlosableItem(@opponent,@opponent.item) && @attacker.item.nil?
			contactscore*=0.1 if seedProtection?(@opponent) && !PBStuff::PROTECTIGNORINGMOVE.include?(@move.move)
			score*=contactscore
		end
		#This is for seeds that activated at the start of the turn
		if @move.basedamage > 0 && seedProtection?(@opponent) && !PBStuff::PROTECTIGNORINGMOVE.include?(@move.move)
			score*=0.1
		end
		
		# LAWDS bad seeds fdim. not in the contact section bc im lazy but fuck it right
		if @battle.FE==:FROZENDIMENSION && @move.contactMove? && @opponent.ability==:BADSEEDS && @attacker.ability!=:BADSEEDS && !@attacker.hasType?(:ICE) && @attacker.ability !=:SHIELDDUST && !((PBStuff::FIXEDABILITIES).include?(@attacker.ability)) && @initial_scores[@score_index] < 100
			mummyscore = getAbilityDisruptScore(@opponent,@attacker)
			mummyscore*=2 if !@attacker.hasType?(:ICE)
			# Gen 9 Mod - Added Ability Shield
			mummyscore = 1 if (@mondata.oppitemworks && @opponent.item == :ABILITYSHIELD)
			mummyscore = mummyscore < 2 ? 2 - mummyscore : 0
			score*=mummyscore
		end
		#If you have a move that kills, use it.		# LAWDS - ignore the score cuts when a kill is found if the attacker is able to set tailwind/aurora veil/trick room with less than half of the team gone
		if @move.basedamage==0 && hasgreatmoves() && !(([:TAILWIND, :AURORAVEIL, :TRICKROOM].include?(@move.move) && @attacker.pbFaintedPokemonCount < 3) || [:FOLLOWME, :RAGEPOWDER].include?(@move.move))
			maxdam=checkAIdamage()
			if maxdam>0 && maxdam<(@attacker.hp*0.3)
				score*=0.6
			else
				score*=0.2 ### highly controversial, revert to 0.1 if shit sucks
			end
		end
		#Don't use powder moves if they don't do anything
		if PBStuff::POWDERMOVES.include?(@move.move) && (@opponent.hasType?(:GRASS) || @opponent.ability== :OVERCOAT || (@mondata.oppitemworks && @opponent.item == :SAFETYGOGGLES))
			$ai_log_data[@attacker.index].final_score_moves.push(0)
			return 0
		end
		# Prefer damaging moves if AI has no more Pokémon
		if @attacker.pbNonActivePokemonCount==0
			if @mondata.skill>=MEDIUMSKILL && !(@mondata.skill>=HIGHSKILL && @opponent.pbNonActivePokemonCount>0)
				if @move.basedamage==0
					PBDebug.log("[Not preferring status move]") if $INTERNAL
					score*=0.9
				elsif @opponent.hp<=@opponent.totalhp/2.0
					PBDebug.log("[Preferring damaging move]") if $INTERNAL
					score*=1.1
				end
			end
		end
		# Don't prefer attacking the opponent if they'd be semi-invulnerable
		if @opponent.effects[:TwoTurnAttack]!=0 && @mondata.skill>=HIGHSKILL
			invulmove=@opponent.effects[:TwoTurnAttack]
			if (@move.accuracy>0 || @move.function==0xA5 || @move.zmove && @move.basedamage > 0 || @move.move == :WHIRLWIND) && (PBStuff::TWOTURNMOVE.include?(invulmove) || @opponent.effects[:SkyDrop]) &&
					pbAIfaster?(@move,nil,@attacker,@opponent) && @attacker.ability != :NOGUARD && @opponent.ability != :NOGUARD && !(@attacker.ability==:FAIRYAURA && @battle.FE == :FAIRYTALE)
				miss = true
				if @mondata.skill>=BESTSKILL
					case invulmove
						when :FLY, :BOUNCE then miss = false if PBStuff::AIRHITMOVES.include?(@move.move) || @move.move == :WHIRLWIND
						when :DIG then miss = false if @move.move == :EARTHQUAKE || @move.move == :MAGNITUDE || @move.move == :FISSURE
						when :DIVE then miss = false if @move.move == :SURF || @move.move == :WHIRLPOOL
						when :SKYDROP then miss = false if PBStuff::AIRHITMOVES.include?(@move.move)
						end
					if @opponent.effects[:SkyDrop]
						miss = false if PBStuff::AIRHITMOVES.include?(@move.move)
					end
					$ai_log_data[@attacker.index].final_score_moves.push(0) if miss
					return 0 if miss
				else
					$ai_log_data[@attacker.index].final_score_moves.push(0)
					return 0
				end
			end
		end
		# Gen 9 Mod - Don't prefer attacking a Tatsugiri inside Dondozo's mouth
    	if @opponent.effects[:Commander]
      		$ai_log_data[@attacker.index].final_score_moves.push(0)
      		return 0
		end
		
		# lawds if the opponent can heal with a drain move before you can kill them, and you have other kill moves, check damage against them again
		drainDisruptsKO = false
		if initialscores[scoreindex] >= 110 && hasgreatmoves() && @opponent.effects[:HealBlock]==0 && @attacker.ability!=:LIQUIDOOZE
			maxhealing = 0
			for move in @opponent.moves
				next if move==nil || move==-1 || pbAIfaster?(@move,move)
				next if ![0x0DD,0x139,0x208,0x912].include?(move.function) && !(@opponent.ability==:SPIRITEATER && move.pbIsPhysical?) # most drain moves, draining kiss, hexing slash, matcha gotcha
				leechmovedmg = pbRoughDamage(move,@opponent,@attacker)
				next if leechmovedmg<=0
				mult = (move.function==0x139) ? 0.75 : 0.5
				if mult==0.5
					mult = 0.75 if (move.move==:BITTERBLADE && @battle.FE==:INFERNAL) || 
								   (move.move==:PARABOLICCHARGE && @battle.FE==:ELECTERRAIN) || 
								   ([:ABSORB,:GIGADRAIN,:MEGADRAIN,:HORNLEECH].include?(move.move) && @battle.FE==:GRASSY)
				end
				healing = leechmovedmg*mult
				maxhealing = healing if healing > maxhealing
			end
			if maxhealing > 0
				hpafterhealing = [(@opponent.hp + maxhealing), @opponent.totalhp].min
				dummyop = pbCloneBattler(@opponent.index)
				dummyop.hp= hpafterhealing
				dmgAfterHeal = pbRoughDamage(@move,@attacker,dummyop)
				newInitScore = (dmgAfterHeal*100/dummyop.hp).floor
				newInitScore = [newInitScore,110].min
				score *= ((newInitScore).to_f)/(initialscores[scoreindex].to_f)
				drainDisruptsKO = true if dmgAfterHeal < dummyop.hp
			end
		end

		
		# Don't prefer an attack if the opponent has revealed a mon that would be immune to it
		switchableparty = @battle.pbParty(@opponent.index).find_all.with_index {|mon,monindex| @battle.pbCanSwitch?(@opponent.index,monindex,false,true)}
		oppparty = switchableparty # LAWDS 7/17/2024 AI sees your entire party.
		oppparty = [] if !@battle.pbOwnedByPlayer?(@opponent.index) # LAWDS don't care about this if its not a player controlled pokemon.
		oppparty = [] if @move.move==:PURSUIT # LAWDS pursuit will always hit targets that switch out, so dont worry about switch-ins.
		# LAWDS decrease score even more if they can redirect on switch-in
		can_redirect = @battle.doublebattle && @attacker.pbTarget(@move)==:SingleNonUser && ![:STALWART,:PROPELLERTAIL].include?(@attacker.ability) && ![:THUNDERRAID,:SNIPESHOT].include?(@move.move)
		# LAWDS experimental - check the type modifier of the move into every enemy mon, give a bonus if nothing resists
		immune=false
		safeswitch=false
		for opppartyindex in 0...oppparty.length
			oppmon = oppparty[opppartyindex]
			oppbattler = pbMakeFakeBattler(oppmon, opppartyindex, false)
			#next if !pbAIfaster?(nil,nil,@attacker,oppbattler) && !can_redirect
			oppbattler = pbStatChangingSwitch(oppbattler) if @battle.FE == :ROCKY # only do this for rocky as rocky field is the only field that creates immunities via stat boosts
			mod = pbTypeModNoMessages(@move.pbType(@attacker),@attacker,oppbattler,@move)

			if mod > 0 && !moldBreakerCheck(@attacker,@move) # LAWDS doing these checks manually cause calling pbRoughDamage has way too much overhead.
				mod=0 if oppbattler.ability==:SOUNDPROOF && (@move.isSoundBased?)
				mod=0 if (@move.windMove? && oppbattler.ability==:WINDRIDER && @battle.FE!=:SKY)
				mod=0 if (@move.function==0x116) && oppbattler.ability==:FOREWARN
				mod=0 if @move.pbIsPriorityMoveAI(@attacker) && ([:DAZZLING,:ARMORTAIL,:QUEENLYMAJESTY].include?(oppbattler.ability) || (@battle.FE==:BEWITCHED && oppbattler.item==:BRIGHTPOWDER))
			end

			mod=0 if ((PBStuff::BULLETMOVE).include?(@move.move) && (@battle.FE==:ROCKY && oppbattler.stages[PBStats::DEFENSE] > 0)) # bullet moves (bulletproof is accounted for in pbtypemodnomessages)
			nullsmove = mod <= 0
			if nullsmove
				immune = true
				score *= 0.9
				score *= 0.9 if @attacker.effects[:HelpingHand] # lawds dont waste helping hand
				score*= 0.8 if can_redirect && ((@move.pbType(@attacker)==:ELECTRIC && oppmon.ability==:LIGHTNINGROD) || 
						  				   (@move.pbType(@attacker)==:WATER && oppmon.ability==:STORMDRAIN) || 
						   				   (@move.pbType(@attacker)==:GHOST && oppmon.ability==:SPIRITSENVOY && @battle.FE != :HAUNTED) ||
										   #(oppmon.species==:DACHSBUN && oppmon.item==:DACHSCREST && (@move.pbType(@attacker)==:DRAGON || (@move.pbType(@attacker)==:FIRE && oppmon.ability==:WELLBAKEBODY && !moldBreakerCheck(@attacker,@move)))) || 
										   #(oppmon.item==:RINGTARGET && @battle.FE == :BIGTOP) || 
										   (oppmon.ability==:MIRRORARMOR && @battle.FE==:STARLIGHT))
				break # only reduce score once
			elsif $game_variables[:DifficultyModes]!=1 # not a perfect check but itll do for now
				mod*=2 if mod<4 && @attacker.ability==:TINTEDLENS
				if !moldBreakerCheck(@attacker,@move) # LAWDS doing these checks manually cause calling pbRoughDamage has way too much overhead.
					mod/=2 if @move.contactMove? && oppbattler.ability==:FLUFFY
					mod/=2 if oppbattler.ability==:HEATPROOF && @move.pbType(@attacker)==:FIRE
					mod/=2 if oppbattler.ability==:THICKFAT && [:ICE,:FIRE].include?(@move.pbType(@attacker))
					mod/=2 if oppbattler.ability==:PUNKROCK && (@move.isSoundBased?)
					mod/=2 if oppbattler.ability==:FURCOAT && @move.pbIsPhysical?(@move.pbType(@attacker))
				end
				mod/=2 if @move.pbType(@attacker)==:GROUND && @battle.FE==:DEEPEARTH && oppbattler.hasType?(:GROUND)
				mod*=2 if oppbattler.ability==:FLUFFY && @move.pbType(@attacker)==:FIRE
				mod*=2 if @attacker.ability==:STAKEOUT
				safeswitch = true if mod < 4
			end
		end
		if !immune && !(@battle.doublebattle) && $game_variables[:DifficultyModes]==2 && @initial_scores[@score_index] >= 110 && hasgreatmoves() && !drainDisruptsKO # LAWDS if we have a killing move and nothing can switch in, favor it over other killing moves.
			# lawds these moves should tolerate allowing safe switches as the pre-damage boost makes them more oppressive if spammed than trying to predict switches
			safeswitch=false if [:ELECTROSHOT,:METEORBEAM].include?(@move.move)
			score*=0.95 if safeswitch
			if !safeswitch && !@battle.doublebattle # if nothing resists it, value a killing move more if something is guaranteed to die. we skip this block in doubles due to the enormous overhead it would cause for much littler preferred behavior
				reallysafeswitch=false
				for opppartyindex in 0...oppparty.length
					oppmon = oppparty[opppartyindex]
					oppbattler = pbMakeFakeBattler(oppmon, opppartyindex, false)
					oppbattler = pbStatChangingSwitch(oppbattler)
					damage = pbRoughDamage(@move,@attacker,oppbattler,false)
					# a move is not considered safe to switch in if it does more than 2/3 (conservative)
					next if damage >= (oppbattler.hp*2/3) && pbAIfaster?(nil,nil,@attacker,oppbattler) && !(oppbattler.pbHasMove?(:FIRSTIMPRESSION) && ((!@attacker.pbHasMove?(:PROTECT) && !@attacker.pbHasMove?(:DETECT) && !@attacker.pbHasMove?(:SPIKYSHIELD)) || @battle.FE==:COLOSSEUM))
					damage*=2 if @attacker.ability==:STAKEOUT
					safeswitch = true if damage < oppbattler.hp
					reallysafeswitch=true if damage < oppbattler.hp/2
					break if reallysafeswitch
				end
				score*=1.15 if !safeswitch
				score*=0.95 if reallysafeswitch
			end
		end
		# LAWDS in doubles, give a bonus to a kill move that isnt resisted by the target's partner
		if @battle.doublebattle && @initial_scores[@score_index] >= 110 && @opponent.pbPartner.hp>0 && !@opponent.pbPartner.isFainted? && !drainDisruptsKO
			oppbattler = @opponent.pbPartner
			partnerdamage = @mondata.roughdamagearray[oppbattler.index][scoreindex]
			partnerdamage = checkAIdamage(oppbattler,@attacker) if partnerdamage==nil
			partnerbestmove,partnermaxdamage = checkAIMovePlusDamage(@attacker.pbPartner,@opponent)
			slower = pbAIfaster?(partnerbestmove,@move,@attacker.pbPartner,@attacker)
			if (partnerdamage > @mondata.roughdamagearray[oppbattler.index].min)
				score*=1.05
				score*=1.1 if partnerdamage >= oppbattler.hp 
				score*=1.2 if slower && partnermaxdamage >= @opponent.hp
			end
		end



			# LAWDS for AI player partner, favor targeting mons the player can't kill
			# player kills are tracked in buildPlayerDamageArray
			# dont run this code for last-ditch priority moves or non-attack moves
			if @attacker.index==2 && @battle.player.is_a?(Array) && @player_damage_array != nil && @move.basedamage>0 && !(@move.pbIsPriorityMoveAI(@attacker,true) && checkAIdamage() >= @attacker.hp)
				#cprint "coordinating partner actions with player: "
				i = (@opponent.index==1) ? 0 : 1 # array index for target
				j = (i==0) ? 1 : 0 # array index for target's partner
				saveplayer=false
				saveself=false
				hippobypass = @opponent.species==:HIPPOWDON && @opponent.form==1 && @opponent.isbossmon && @opponent.shieldCount < 1
				saveself = true if hippobypass
				player_owns = @player_damage_array[i] > 1
				if !player_owns
					for moveindex in 0...@opponent.moves.length
						oppmove = @opponent.moves[moveindex]
						next if oppmove==nil || oppmove.basedamage==0 || !@battle.pbCanChooseMove?(@opponent.index, moveindex, false)
						self_goes_before_target = pbAIfaster?(@move,oppmove,@attacker,@opponent)
						if !saveplayer
							playerdamage = @aimondata[@opponent.index].roughdamagearray[0][moveindex]
							playerdamage = 0 if playerdamage == nil
							saveplayer = true if playerdamage >= @attacker.pbPartner.hp && pbAIfaster?(oppmove,nil,@opponent,@attacker.pbPartner) && self_goes_before_target
						end
						if !saveself
							selfdamage = @aimondata[@opponent.index].roughdamagearray[2][moveindex]
							selfdamage = 0 if selfdamage == nil
							saveself = true if selfdamage >= @attacker.hp && self_goes_before_target
						end
					end
					score*=0.7 if @player_damage_array[j] > @player_damage_array[i] && !saveplayer && !saveself # cut score to prioritize moves that are good against partner if the player cant do anything to them
					#cprint "Player will be killed by #{getMonName(@opponent.species)} unless KO'd\n" if saveplayer
					#cprint "AI partner Pokemon will be killed by #{getMonName(@opponent.species)} unless KO'd\n" if saveself
				elsif !hippobypass
					#cprint "Player outspeeds and OHKOs #{getMonName(@opponent.species)}\n"
					score*=0.5 if @player_damage_array[j] < 2
					score*=0.5 if @player_damage_array[j] == 0 # cut score if the player can kill the target before they can move, but can't do the same to the partner
				end

				# increase score to encourage eliminating enemies before they can kill
				score*=1.2 if saveplayer
				score*=1.2 if saveself
			end



		
		# Pick a good move for the Choice items
		if (@mondata.attitemworks && (@attacker.item == :CHOICEBAND || @attacker.item == :CHOICESPECS || @attacker.item == :CHOICESCARF)) || @attacker.ability== :GORILLATACTICS
			if @move.basedamage==0 && @move.function!=0xF2 && @move.function!=0x13d && @move.function!=0xb4 # Trick, parting shot and sleep talk 
				score*=0.1
			else
				score *= 0.8 if oppparty.any? { |oppmon,moves| @move.pbTypeModifierNonBattler(@move.pbType(@attacker),@attacker,oppmon) == 0 }
			end
			score *= (@move.accuracy/100.0) if @move.accuracy > 0
			score *= 0.9 if @move.pp <= 5
			score *= 0.1 if [:FIRSTIMPRESSION, :FAKEOUT].include?(@move.move) && (@opponent.pbNonActivePokemonCount > 0 || @initial_scores[@score_index] < 100)
		end
		# If user is frozen, prefer a move that can thaw the user
    	if @attacker.status== :FROZEN && @mondata.skill>=MEDIUMSKILL
			if PBStuff::UNFREEZEMOVE.include?(@move.move)
				score+=30
			else
				$ai_log_data[@attacker.index].final_score_moves.push(0) if @attacker.moves.any? {|moveloop| moveloop!=nil && (PBStuff::UNFREEZEMOVE).include?(moveloop.move)}
				return 0 if @attacker.moves.any? {|moveloop| moveloop!=nil && (PBStuff::UNFREEZEMOVE).include?(moveloop.move)}
			end
		end
		# If target is frozen, don't prefer moves that could thaw them
		if @opponent.status== :FROZEN
			score *= 0.1 if @move.pbType(@attacker) == :FIRE
		end
		# If opponent is dark type and attacker has prankster, or (Lawds Mod) the opponent has Good as Gold and we don't have Mold Breaker, don't use status moves on them
		if @mondata.skill>=MEDIUMSKILL && ((@attacker.ability== :PRANKSTER && (@opponent.hasType?(:DARK) && @battle.FE != :BEWITCHED)) || (@opponent.ability== :GOODASGOLD && !moldBreakerCheck(@attacker,@move)))
			if @move.basedamage==0 && @move.priority>-1 && (@attacker.pbTarget(@move)!=nil) && (@attacker.pbTarget(@move)==:SingleNonUser) # lawds- weird ass conditional here that bypassed the targeting check, i've removed it
				$ai_log_data[@attacker.index].final_score_moves.push(0)
				return 0
			end
		end
		# Lawds Mod - Crested Pachirisu favors using moves that would knock healthy targets to 1/2 HP or lower
		if @attacker.crested == :PACHIRISU && (@opponent.hp > (@opponent.totalhp/2))
			maxdam = checkAIdamage(@opponent,@attacker)
			hpAfterAttack = @opponent.hp - maxdam
			if hpAfterAttack <= (@opponent.totalhp/2)
				score *= 1.5
			end
		end
		# If move changes field consider value of changing it
		# lawds ignore field changes if field is locked
		if !@battle.state.effects[:FIELDLOCK] && !($game_variables[:DifficultyModes]==2 && !(@battle.ProgressiveFieldCheck(PBFields::CONCERT)) && !(@battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN)) && ![:FACTORY,:SHORTCIRCUIT].include?(@battle.FE)) 
			fieldmove = @battle.field.moveData(@move.move)
			if fieldmove && fieldmove[:fieldchange]
				attacker = @attacker
				change_conditions = @battle.field.fieldChangeData
				if change_conditions[fieldmove[:fieldchange]]
					handled = eval(change_conditions[fieldmove[:fieldchange]])
				else
					handled = true
				end
				if handled  #don't continue if conditions to change are not met
					currentfieldscore = getFieldDisruptScore(@attacker,@opponent,@battle.FE) # the higher the better for opp
					newfieldscore = getFieldDisruptScore(@attacker,@opponent,fieldmove[:fieldchange])
					score*= Math.sqrt(currentfieldscore/newfieldscore)
				end
			end
		end
		#Weigh scores against accuracy
		accuracy=pbRoughAccuracy(@move,@attacker,@opponent)
		moddedacc = (accuracy + 100)/2.0
    	score*=moddedacc/100.0
		# Avoid shiny wild pokemon if you're an AI partner
		if @battle.pbIsWild?
			score *= 0.1 if @attacker.index == 2 && @opponent.pokemon.isShiny?
		end
		if @opponent.pbPartner.species == :MEWTWO && opponent.pbPartner.isbossmon
			score *= 0.1
		end



		# LAWDS Mod 7/10/2024 --  if the target knows Rage Fist, weigh an attack depending on how much damage you deal and how much healing they have, 
								# as well as how dangerous Rage Fist could become.
								# the more healing the opposing Pokemon has and the less damage you deal, the more the score is slashed
								# EXPERIMENTAL as of 7/10/2024, make sure this actually causes the AI to make good decisions.

								# The block is skipped if the AI thinks it can kill the target with an attack; if Rage Fist is cut by the field; 
								# if the target is burned (and doesn't have Guts or Quick Feet) or has had its attack lowered; 
								# or if Rage Fist's base power is already so high that you might as well just hit them
		if @opponent.pbHasMove?(:RAGEFIST) && @move.basedamage > 0 && ![:RAINBOW, :HOLY, :ASHENBEACH].include?(@battle.FE) && !hasgreatmoves() && (@opponent.stages[PBStats::ATTACK] > -1 || (@opponent.status != :BURN && ![:GUTS,:QUICKFEET].include?(@opponent.ability))) && @battle.getBattlerHit(@opponent) < 5
		  maxdam = checkAIdamage()
		  hp_per_turn = hpGainPerTurn(@opponent,true)
		  if maxdam < @opponent.hp/4 && hp_per_turn > 1 # 1/3 is arbitrary. 
														#The code checks current HP rather than max HP because as the target's HP decreases,
														#it becomes increasingly unlikely for the AI to even be in this block, 
														#and we don't want the AI to just never attack a Rage Fist user if it cant do 1/3 max HP.
														#Having the threshold shift as the target's hp lowers makes the AI less rigid and predictable.
														#If they're taking passive damage per turn, then doing slightly less to them is considered safer.
			score*=0.8 # also arbitrary
			if hp_per_turn >= 0.125
				score*=0.9
			end
		  end
		  if checkAIhealing || (@opponent.pbHasMove?(:DRAINPUNCH) && (@mondata.roles.include?(:STALLBREAKER) || @opponent.stages[PBStats::ATTACK] > 0))
			# If the target is able to heal a lot and you can't stop them, and your attack can't significantly outdamage the healing, then don't hit them
			score*=0.8 if maxdam < 5*(@opponent.totalhp)/8
		  end
		end
		# End Rage Fist stuff.



		# LAWDS - make the AI not want to click water moves on Water Compaction
		if @opponent.ability== :WATERCOMPACTION && @move.pbType(@attacker) == :WATER && checkAIdamage(@opponent,@attacker) < @opponent.hp && @opponent.pbCanIncreaseStatStage?(PBStats::DEFENSE,false,nil,:WATERCOMPACTION)
			score*=0.5 if (@attacker.attack > @attacker.spatk) || (@attacker.pbPartner.attack > @attacker.pbPartner.spatk)
		end

		# lawds - discourage boosting enemy justified pokemon
		if @opponent.ability== :JUSTIFIED && @move.pbType(@attacker) == :DARK && @opponent.pbCanIncreaseStatStage?(PBStats::ATTACK,false,nil,:JUSTIFIED)
			score*=0.5 if (@attacker.attack > @attacker.spatk*1.1) && @mondata.roughdamagearray[@opponent.index][@score_index] < @opponent.hp && checkAIdamage() > @attacker.hp/3
			return -1000 if score < 30 # just dont click it no matter what if its REALLY bad
		end


		#################### Function Code Scoring ####################
		miniscore=1.0
		case @move.function
			when 0x00 # No effect
				if @mondata.skill >= BESTSKILL && @battle.FE != :INDOOR
					case @battle.FE
					when :ICY
						if @move.move == :TECTONICRAGE
							if @battle.field.backup== :WATERSURFACE # Water Surface
								currentfieldscore = getFieldDisruptScore(@attacker,@opponent,@battle.FE) # the higher the better for opp
								newfieldscore = getFieldDisruptScore(@attacker,@opponent,:WATERSURFACE)
								miniscore = currentfieldscore/newfieldscore
							else
								miniscore*=1.2 if @opponent.pbNonActivePokemonCount>2
								miniscore*=0.8 if @attacker.pbNonActivePokemonCount>2
							end
						end
					when :MIRROR
						miniscore*=2 if @move.move == :DAZZLINGGLEAM && mirrorNeverMiss
						miniscore*=0.3 if @move.move == :BOOMBURST || @move.move == :HYPERVOICE
					when :FLOWERGARDEN2,:FLOWERGARDEN3,:FLOWERGARDEN4,:FLOWERGARDEN5
						if (@move.move == :CUT || @move.move == :XSCISSOR) && @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,2,5)
							miniscore*= pbPartyHasType?(:GRASS) || pbPartyHasType?(:BUG) ? 0.3 : 2.0
						end
						if @move.move==:PETALBLIZZARD && @battle.FE == :FLOWERGARDEN5
							miniscore*=1.5 if @battle.doublebattle
						end
					when :VOLCANICTOP
						miniscore*=volcanoeruptioncode() if @move.move == :PRECIPICEBLADES
					end
				end
			when 0x01 # Splash
				if @mondata.skill >= BESTSKILL && @battle.FE == :WATERSURFACE
					miniscore = antistatcode([0,0,0,0,0,1,0],initialscores[scoreindex])
				end
				if @move.zmove
					miniscore*= selfstatboost([1,1,1,1,1,0,0]) if @move.move == :CELEBRATE
					miniscore*= selfstatboost([3,0,0,0,0,0,0]) if @move.move == :SPLASH
				end
			when 0x02 # Struggle
				miniscore*=0.2
			when 0x03 # Sleep, Dark Void, Grass Whistle, Sleep Powder, Spore, Relic Song, Lovely Kiss, Sing, Hypnosis
				miniscore = sleepcode()
				miniscore *= 1.3 if pbAIfaster?(@move)
				if @mondata.skill >= BESTSKILL
					miniscore*= 2 if (@move.move==:SLEEPPOWDER && @battle.FE == :FLOWERGARDEN5 && @battle.doublebattle)
				end
			when 0x04 # Yawn
				miniscore = sleepcode()
			when 0x05 # Poison, Gunk Shot, Sludge Wave, Sludge Bomb, Poison Jab, Sludge, Poison Tail, Smog, Poison Sting, Poison Gas, Poison Powder
				miniscore = poisoncode()
				if @mondata.skill >= BESTSKILL
					if @battle.FE == :WATERSURFACE || @battle.FE == :UNDERWATER # Water Surface/Underwater
						if @move.move==:SLUDGEWAVE
					   		miniscore*=1.75 if pbPartyHasType?(:POISON) && !pbPartyHasType?(:WATER)
							miniscore*=0 if !@attacker.hasType?(:POISON) && !@attacker.hasType?(:STEEL) && @battle.pbPokemonCount(@battle.pbParty(@opponent.index))==1 && @battle.field.counter==1
					  	end
					end
					if @battle.FE == :MISTY # Misty Terrain
						if @move.move==:SMOG || @move.move==:POISONGAS
							miniscore*=1.75 if pbPartyHasType?(:POISON) && !pbPartyHasType?(:FAIRY)
						end
						if @move.move==:POISONGAS
							if pbPartyHasType?(:POISON) && !pbPartyHasType?(:FAIRY)
								score = 15
								miniscore = 1.0
							end
						end
				  	end
				end
			when 0x06 # Toxic, Poison Fang
				miniscore = poisoncode()
				if @move.move==:TOXIC
					miniscore*=1.1 if @attacker.hasType?(:POISON)
				end
			when 0x07 # Paralysis, Dragon breath, Bolt Strike, Zap Cannon, Thunderbolt, Discharge, Thunder Punch, Spark, Thunder Shock, Thunder Wave, Force Palm, Lick, Stun Spore, Body Slam, Glare, Nuzzle
				miniscore = paracode()
			when 0x08 # Thunder
				miniscore = paracode()
				miniscore *= thunderboostcode()
				miniscore *= nevermisscode(initialscores[scoreindex]) if @battle.pbWeather== :RAINDANCE
			when 0x09 # Paralysis + Flinch, Thunder Fang
				miniscore = paracode()
				miniscore *= flinchcode()
			when 0x0A # Burn Blue Flare, Fire Blast, Heat Wave, Inferno, Sacred Fire, Searing Shot, Flamethrower, Blaze kick, Lava Plume, Fire Punch, Flame Wheel, Ember, Will-O-Wisp, Scald, Steam Eruption
				miniscore = burncode()
				if @mondata.skill >= BESTSKILL
					if @move.move==:SCALD || @move.move==:STEAMERUPTION
						if @battle.FE == :ICY # Icy Field
							currentfieldscore = getFieldDisruptScore(@attacker,@opponent,@battle.FE) # the higher the better for opp
							newfieldscore = getFieldDisruptScore(@attacker,@opponent,:WATERSURFACE)
							miniscore*= Math.sqrt(currentfieldscore/newfieldscore)
						end
					end
					if @move.move == :LAVAPLUME
						if @battle.FE == :VOLCANICTOP
							miniscore*=volcanoeruptioncode()
						end
					end
				end
				# LAWDS rocky blocks will-o-wisp with the same logic as bulletproof
				miniscore = 0 if @move.move==:WILLOWISP && @battle.FE==:ROCKY && @opponent.stages[PBStats::DEFENSE]>0
			when 0x0B # Burn + Flinch, Fire Fang
				miniscore = burncode()
				miniscore *= flinchcode()
			when 0x0C # Freeze, Ice Beam, Ice Punch, Powder Snow, Freeze-Dry
				miniscore = freezecode()
			when 0x0D # Blizzard Freeze
				miniscore = freezecode()
				miniscore *= nevermisscode(initialscores[scoreindex]) if @battle.pbWeather== :HAIL
			when 0x0E # Freeze + Flinch, Ice Fang
				miniscore = freezecode()
				miniscore *= flinchcode()
				if @mondata.skill >= BESTSKILL
					if @battle.FE == :GLITCH # Glitch
						miniscore*=1.2
					end
				end
			when 0x0F # Flinch, Dark Pulse, Bite, Rolling Kick, Air Slash, Astonish, Needle Arm, Hyper Fang, Headbutt, Extrasensory, Zen Headbutt, Heart Stamp, Rock Slide, Iron Head, Waterfall, Zing Zap
				miniscore = flinchcode()
				# LAWDS - make neved's kilowattrel take the competitive boost into account on beach with rain up
				miniscore *= selfstatboost([0,0,2,0,0,0,0]) if (@move.move== :AIRSLASH && @battle.FE == :ASHENBEACH && @battle.pbWeather == :RAINDANCE && @attacker.ability== :COMPETITIVE && !@attacker.hasWorkingItem(:CLEARAMULET))
			when 0x10 # Stomp, Steamroller, Dragon Rush
				miniscore = flinchcode()
			when 0x11 # Snore
				miniscore = flinchcode() if @attacker.status== :SLEEP
				score = 0 if @attacker.status!=:SLEEP
			when 0x12 # Fake Out		
			# LAWDS - don't fake out something that can also use fake out and is faster + less of a threat than the partner. yes this can be exploited but it just means the AI is more likely to fake out the partner instead.
				if @attacker.turncount==0 && !(@opponent.effects[:Substitute] > 0 || @opponent.ability== :INNERFOCUS || secondaryEffectNegated?() || @opponent.effects[:FlinchCooldown]>0) && 
					!(@opponent.turncount == 0 && @opponent.pbHasMove?(:FAKEOUT) && !pbAIfaster?() && @battle.doublebattle && (checkAIdamage(@opponent,@attacker) >= @opponent.hp || checkAIdamage(@opponent,@attacker.pbPartner) >= @opponent.pbPartner.hp)) &&
					!((opponent.pbHasMove?(:DETECT) || opponent.pbHasMove?(:PROTECT) || opponent.pbHasMove?(:SPIKYSHIELD) || opponent.pbHasMove?(:SILKTRAP) || opponent.pbHasMove?(:BANEFULBUNKER)) && opponent.effects[:ProtectRate] == 0)
					#usually this would be saved as miniscore, but we directly add to the score
					score *= flinchcode()
					score+=10 if score>1 # lawds massively lower the initial score here, basically making it a specific use case tool for the AI
					score+=50 if !@battle.doublebattle && notOHKO?(@opponent,@attacker) && score > 1
					if @attacker.ability==:KLUTZ && @battle.FE==:DRAGONSDEN && score > 1
						checkBurn = burncode
						score+=50 if burncode > 1 && !hasgreatmoves && !(pbAIfaster? && !checkAIpriority)
					end
					score*=0.7 if @battle.doublebattle
					score*=4.5 if (@attacker.pbPartner.pbHasMove?(:TRICKROOM) && @battle.trickroom == 0) || (@attacker.pbPartner.pbHasMove?(:TAILWIND) || @attacker.pbOwnSide.effects[:Tailwind] == 0) && score > 1 # raise it here
					score*=1.1 if (@attacker.itemWorks? && @attacker.item == :NORMALGEM) && @attacker.ability== :UNBURDEN && score > 1
					if (@opponent.pbHasMove?(:FIRSTIMPRESSION) || @opponent.crested == :FERALIGATR) && @opponent.turncount==0 && score > 1
					# LAWDS Mod - shut down First Impression and Gatr crest
						score*=2
						score*=10 if (pbTypeModNoMessages(:BUG,@opponent,@attacker)>4) || @opponent.crested == :FERALIGATR
					end
					if (@opponent.pbHasMove?(:FAKEOUT) && @opponent.turncount==0) && score > 1
						score*=2
						score*=10 if (@attacker.pbPartner.pbHasMove?(:LIGHTSCREEN) && @attacker.pbOwnSide.effects[:LightScreen]==0) || (@attacker.pbPartner.pbHasMove?(:REFLECT) && @attacker.pbOwnSide.effects[:Reflect]==0) 
					end
					score*=0.3 if checkAImoves([:ENCORE])
					score *= 2 if (@attacker.ability==:STALL || @attacker.pbPartner==:STALL) && score > 1
				elsif @attacker.turncount!=0
					score=0
				end
			when 0x13 # Confusion, Signal Beam, Dynamic Punch, Chatter, Confuse Ray, Rock Climb, Dizzy Punch, Supersonic, Sweet Kiss, Teeter Dance, Psybeam, Water Pulse, Strange Steam
				miniscore = confucode()
				if @mondata.skill >= BESTSKILL
					if @move.move==:SIGNALBEAM
						miniscore*=2 if @battle.FE == :MIRROR && mirrorNeverMiss  # Mirror Arena
					end
					if @move.move==:SWEETKISS
						miniscore*=0.2 if @battle.FE == :FAIRYTALE && @opponent.status== :SLEEP # Fairy Tale
					end
				end
				if @battle.FE == :DANCEFLOOR
					statarray = [0,1,0,0,0,0,0] if @mondata.skill >= BESTSKILL && @move.move == :TEETERDANCE
					miniscore = oppstatdrop(statarray)
				end
			when 0x14 # Chatter
			when 0x15 # Hurricane
				miniscore = confucode()
				miniscore *= thunderboostcode()
				miniscore *= nevermisscode(initialscores[scoreindex]) if @battle.pbWeather== :RAINDANCE
				# LAWDS - make neved's kilowattrel take the competitive boost into account on beach with rain up. not really necessary for other moves since they dont benefit in this way
				miniscore *= selfstatboost([0,0,2,0,0,0,0]) if (@battle.FE == :ASHENBEACH && @battle.pbWeather == :RAINDANCE && @attacker.ability== :COMPETITIVE && !@attacker.hasWorkingItem(:CLEARAMULET) && @attacker.pbCanIncreaseStatStage?(PBStats::SPATK, false, nil, :COMPETITIVE))
			when 0x16 # Attract
				miniscore = attractcode()
			when 0x17 # Tri Attack
				miniscore = (burncode() + paracode() + freezecode()) / 3
			when 0x18 # Refresh
				miniscore = refreshcode()
			when 0x19 # Aromatherapy, Heal Bell
				miniscore = partyrefreshcode()
			when 0x1a # Safeguard
				#dont use safeguard.
				if @attacker.pbOwnSide.effects[:Safeguard]<=0 
					if pbAIfaster?(@move) && @attacker.nil? && !@mondata.roles.include?(:STATUSABSORBER)
						score+=50 if checkAImoves([:SPORE])
					end
					#uggggh fine, i guess you are my little guardchamp
					if !@battle.opponent.is_a?(Array)
						if (@battle.opponent.trainertype==:CAMERUPT)
							score+=150
						end
					end
				end
			when 0x1b # Psycho Shift
				miniscore = psychocode()
			when 0x1c # Howl, Sharpen, Meditate, Meteor Mash, Metal Claw, Power-Up Punch
				statarray = [1,0,0,0,0,0,0]
				statarray = [3,0,0,0,0,0,0] if @mondata.skill >= BESTSKILL && @move.move==:MEDITATE && (@battle.FE == :RAINBOW || @battle.FE == :ASHENBEACH)
				statarray = [2,0,2,0,0,0,0] if @mondata.skill >= BESTSKILL && ((@move.move==:MEDITATE && @battle.FE == :PSYTERRAIN) || @move.move == :HOWL && @battle.FE == :COLOSSEUM)
				statarray = [2,0,0,0,0,0,0] if @mondata.skill >= BESTSKILL && @move.move == :HOWL && (@battle.FE == :COLOSSEUM || @battle.ProgressiveFieldCheck(PBFields::CONCERT))
				miniscore = selfstatboost(statarray)
			when 0x1d # Harden, Steel Wing, Withdraw, Psyshield Bash
				statarray = [0,1,0,0,0,0,0]
				statarray = [0,1,0,1,0,0,0] if @move.move==:PSYSHIELDBASH && @battle.FE == :PSYTERRAIN
				miniscore = selfstatboost(statarray)
			when 0x1e # Defense Curl
				miniscore = selfstatboost([0,1,0,0,0,0,0])
				score*=1.3 if @attacker.pbHasMove?(:ROLLOUT) && @attacker.effects[:DefenseCurl]==false
			when 0x1f # Flame Charge	# LAWDS - Esper Wing, Trailblaze
				statarray = [0,0,0,0,1,0,0]
				statarray = [0,0,0,0,2,0,0] if (@move.move==:ESPERWING && @battle.FE == :PSYTERRAIN) || (@move.move == :TRAILBLAZE && @battle.FE == :GRASSY)
				miniscore = selfstatboost(statarray)
			when 0x20 # Charge Beam, Fiery Dance, Torch Song
				increment = 1
				# lawds - fiery dance sky field interaction, torch song with throat spray
				torchspray = (@move.move == :TORCHSONG && @attacker.hasWorkingItem(:THROATSPRAY))
				increment = 2 if torchspray
				# torch song on these fields
				increment += 1 if @move.move == :TORCHSONG && ([:VOLCANICTOP, :VOLCANIC, :INFERNAL, :HAUNTED].include?(@battle.FE) || @battle.ProgressiveFieldCheck(PBFields::CONCERT))
				miniscore = selfstatboost([0,0,increment,0,0,0,0])
				miniscore*=1.5 if (@move.move == :FIERYDANCE && (@battle.FE == :SKY && @attacker.pbOwnSide.effects[:Tailwind] != 0 && @attacker.ability== :DANCER))
				miniscore*=1.5 if increment > 1 && @move.move == :TORCHSONG && @attacker.stages[PBStats::SPATK] < 1
			when 0x21 # Charge
				miniscore = selfstatboost([0,0,0,1,0,0,0])
				miniscore*=1.5 if @attacker.moves.any?{|moveloop| moveloop!=nil && moveloop.pbType(@attacker)==:ELECTRIC} && !(@attacker.effects[:Charge])
			when 0x22 # Double Team
				statarray = [0,0,0,0,0,0,1]
				statarray = [0,0,0,0,0,0,2] if @mondata.skill >= BESTSKILL && @move.move==:DOUBLETEAM && @battle.FE == :MIRROR
				miniscore = selfstatboost(statarray)
			when 0x23 # Focus Energy
				miniscore = focusenergycode()
				miniscore*= 1.5 if @mondata.skill >= BESTSKILL && @battle.FE == :ASHENBEACH # Ashen Beach
			when 0x24 # Bulk Up
				miniscore = selfstatboost([1,1,0,0,0,0,0])
				miniscore = selfstatboost([2,2,0,0,0,0,0]) if @mondata.skill >= BESTSKILL && @battle.FE == :CROWD
			when 0x25 # Coil
				statarray = [1,1,0,0,0,1,0]
				statarray = [2,2,0,0,0,2,0] if @mondata.skill >= BESTSKILL && (@battle.FE == :GRASSY || (Rejuv && @battle.FE == :DRAGONSDEN))
				miniscore = selfstatboost(statarray)
			when 0x26 # Dragon Dance
				statarray = [1,0,0,0,1,0,0]
				# lawds - dancer sky interaction
				statarray = [2,0,0,0,2,0,0] if @mondata.skill >= BESTSKILL && (@battle.FE == :BIGTOP || @battle.FE == :DRAGONSDEN || @battle.FE == :DANCEFLOOR || (@battle.FE == :SKY && @attacker.pbOwnSide.effects[:Tailwind] != 0 && @attacker.ability== :DANCER))
				miniscore = selfstatboost(statarray)
			when 0x27 # Work Up
				statarray = [1,0,1,0,0,0,0]
				statarray = [2,0,2,0,0,0,0] if @battle.ProgressiveFieldCheck(PBFields::CONCERT) || @battle.FE == :CROWD
				miniscore = selfstatboost(statarray)
			when 0x28 # Growth
				statarray = [1,0,1,0,0,0,0]
				if @mondata.skill >= BESTSKILL
					statarray = [2,0,2,0,0,0,0] if @battle.FE == :GRASSY || @battle.FE == :FOREST || @battle.pbWeather== :SUNNYDAY || @battle.FE == :FLOWERGARDEN3 || @attacker.crested == :CHERRIM || @attacker.pbPartner.crested == :CHERRIM
					statarray = [3,0,3,0,0,0,0] if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,4,5) # Flower Garden
				end
				miniscore = selfstatboost(statarray)
			when 0x29 # Hone Claws
				miniscore = selfstatboost([1,0,0,0,0,1,0])
			when 0x2a # Cosmic Power, Defend Order
				statarray = [0,1,0,1,0,0,0]
				statarray = [0,2,0,2,0,0,0] if @mondata.skill >= BESTSKILL && @move.move==:COSMICPOWER && [:MISTY,:RAINBOW,:HOLY,:STARLIGHT,:NEWWORLD,:PSYTERRAIN].include?(@battle.FE)
				statarray = [0,2,0,2,0,0,0] if @mondata.skill >= BESTSKILL && @move.move==:DEFENDORDER && @battle.FE == :FOREST
				miniscore = selfstatboost(statarray)
			when 0x2b # Quiver Dance
				statarray = [0,0,1,1,1,0,0] # lawds - dancer sky boost
				statarray = [0,0,2,2,2,0,0] if @mondata.skill >= BESTSKILL && (@battle.FE == :BIGTOP || @battle.FE == :DANCEFLOOR || (@battle.FE == :SKY && @attacker.pbOwnSide.effects[:Tailwind] != 0 && @attacker.ability== :DANCER))
				miniscore = selfstatboost(statarray)
			when 0x2c # Calm Mind
				statarray = [0,0,1,1,0,0,0]
				statarray = [0,0,2,2,0,0,0] if @mondata.skill >= BESTSKILL && (@battle.FE == :CHESS || @battle.FE == :ASHENBEACH)
				miniscore = selfstatboost(statarray)
			when 0x2d # Ancient Power, Silver Wind, Ominous Wind
				#miniscore = selfstatboost([1,1,1,1,1,0,0]) # lawds just forget this, it keeps clicking the move when it shouldnt
			when 0x2e # Swords Dance
				statarray = [2,0,0,0,0,0,0] # lawds dancer sky boost
				statarray = [3,0,0,0,0,0,0] if @mondata.skill >= BESTSKILL && @move.move==:SWORDSDANCE && [:BIGTOP,:FAIRYTALE,:DANCEFLOOR,:COLOSSEUM].include?(@battle.FE)
				statarray = [4,0,0,0,0,0,0] if (@battle.FE == :SKY && @attacker.pbOwnSide.effects[:Tailwind] != 0 && @attacker.ability== :DANCER)
				miniscore = selfstatboost(statarray)
			when 0x2f # Iron Defense, Acid Armor, Barrier, Diamond Storm
				statarray = [0,2,0,0,0,0,0]
				statarray = [0,1,0,0,0,0,0] if @move.move==:SHELTER # lawds shelter
				statarray = [0,3,0,0,0,0,0] if @mondata.skill >= BESTSKILL && (@move.move==:IRONDEFENSE && @battle.FE == :FACTORY) || (@move.move==:ACIDARMOR && [:CORROSIVE,:CORROSIVEMIST,:MURKWATERSURFACE,:FAIRYTALE,:CONCERT1,:CONCERT2,:CONCERT3,:CONCERT4].include?(@battle.FE))
				miniscore = selfstatboost(statarray)
			when 0x30 # Agility, Rock Polish
				statarray = [0,0,0,0,2,0,0]
				#statarray = [0,0,0,0,3,0,0] if @mondata.skill >= BESTSKILL && @move.move==:ROCKPOLISH && @battle.FE == :ROCKY
				statarray = [1,0,1,0,2,0,0] if @mondata.skill >= BESTSKILL && @move.move==:ROCKPOLISH && @battle.FE == :CRYSTALCAVERN
				miniscore = selfstatboost(statarray)
			when 0x31 # Autotomize
				statarray = [0,0,0,0,2,0,0]
				statarray = [0,0,0,0,3,0,0]  if @mondata.skill >= BESTSKILL && [:FACTORY,:CITY,:DEEPEARTH].include?(@battle.FE)
				miniscore = selfstatboost(statarray)
				miniscore*=1.5 if checkAImoves([:LOWKICK,:GRASSKNOT])
				miniscore*=0.5 if checkAImoves([:HEATCRASH,:HEAVYSLAM])
				miniscore*=0.7 if @attacker.pbHasMove?(:HEATCRASH) || @attacker.pbHasMove?(:HEAVYSLAM)
			when 0x32 # Nasty Plot
				statarray = [0,0,2,0,0,0,0]
				statarray = [0,0,3,0,0,0,0] if @mondata.skill >= BESTSKILL && [:CHESS,:PSYTERRAIN,:INFERNAL,:BACKALLEY].include?(@battle.FE)
				miniscore = selfstatboost(statarray)
			when 0x33 # Amnesia
				statarray = [0,0,0,2,0,0,0]
				miniscore = selfstatboost(statarray)
				miniscore *= 2 if @mondata.skill >= BESTSKILL && @battle.FE == :GLITCH
			when 0x34 # Minimize
				miniscore = selfstatboost([0,0,0,0,0,0,2])
			when 0x35 # Shell Smash
				miniscore = selfstatboost([2,0,2,0,2,0,0])
				#miniscore*=5.0 if (@battle.FE == :ASHENBEACH && @attacker.ability== :SNIPER && @attacker.stages[PBStats::SPEED] < 1 && @attacker.effects[:FocusEnergy] > 0 && checkAIdamage() < @attacker.totalhp/3) # Lawds Mod - neved just click the fucking move
				no_def_drop = ((@mondata.attitemworks && @attacker.item == :WHITEHERB) || @battle.FE == :ASHENBEACH)
				if no_def_drop
					miniscore*=1.3
				else
					miniscore*= selfstatdrop([0,1,0,1,0,0,0],score)
				end
			when 0x36 # Shift Gear
				statarray = [1,0,0,0,2,0,0]
				miniscore = selfstatboost(statarray)
			when 0x37 # Acupressure		LAWDS - Acupressure no longer boosts Evasion
				miniscore = selfstatboost([2,0,0,0,0,0,0]) +selfstatboost([0,2,0,0,0,0,0]) + selfstatboost([0,0,2,0,0,0,0]) +selfstatboost([0,0,0,2,0,0,0]) +selfstatboost([0,0,0,0,2,0,0]) +selfstatboost([0,0,0,0,0,2,0])
				miniscore/=6
			when 0x38 # Cotton Guard
				miniscore = selfstatboost([0,3,0,0,0,0,0])
			when 0x39 # Tail Glow
				miniscore = selfstatboost([0,0,3,0,0,0,0])
			when 0x3a # Belly Drum
				statarray = [6,0,0,0,0,0,0]
				statarray = [6,1,0,1,0,0,0] if @mondata.skill >= BESTSKILL && @battle.FE == :BIGTOP
				miniscore = selfstatboost(statarray) ** 1.4 #More extreme scoring
				if !@attacker.moves.any?{|moveloop| moveloop!=nil && moveloop.basedamage > 0 && moveloop.pbIsPriorityMoveAI(@attacker)} && !pbAIfaster?()
					# melia lax
					if !(@attacker.pbPartner.effects[:FollowMe] && @attacker.ability==:GLUTTONY && @attacker.item==:IAPAPABERRY && @opponent.ability!=:UNNERVE && @opponent.pbPartner.ability!=:UNNERVE)
						miniscore *= 0.3
					else
						miniscore *= 2.0
						miniscore *= 6.0 if hasgreatmoves
						miniscore *= 0 if (@opponent.pbHasMove?(:HAZE) || @opponent.pbHasMove?(:CLEARSMOG) || @opponent.pbPartner.pbHasMove?(:HAZE) || @opponent.pbPartner.pbHasMove?(:CLEARSMOG))
					end
				end
				miniscore *= 1.2 if @attacker.turncount<1
				miniscore = 1 if (@attacker.hp.to_f)/@attacker.totalhp <= 0.5
			when 0x3b # Superpower
				statarray = [1,1,0,0,0,0,0]
				if @attacker.ability== :CONTRARY
					miniscore = selfstatboost(statarray)
				else
					miniscore = selfstatdrop(statarray,score)
					miniscore*=1.5 if @attacker.ability== :MOXIE || @attacker.ability== :CHILLINGNEIGH || (@attacker.ability== :ASONE && @attacker.form == 1)
				end
			when 0x3c # Close Combat, Dragon Ascent, Headlong Rush
				statarray = [0,1,0,1,0,0,0]
				if @attacker.ability== :CONTRARY
					miniscore = selfstatboost(statarray)
				else
					miniscore = selfstatdrop(statarray,score)
					# LAWDS tangled feet, make it not care so much about the stat drops if it can maximize damage
					miniscore = Math.sqrt(miniscore) if (@attacker.ability==:TANGLEDFEET && @battle.FE==:SKY && @move.contactMove? && @initial_scores[@score_index] == @initial_scores.max)
				end
			when 0x3d # V-Create
				statarray = [0,1,0,1,1,0,0]
				if @attacker.ability== :CONTRARY
					miniscore = selfstatboost(statarray)
				else
					miniscore = selfstatdrop(statarray,score)
				end
			when 0x3e # Hammer Arm, Ice Hammer
				statarray = [0,0,0,0,1,0,0]
				if @attacker.ability== :CONTRARY || @battle.trickroom > 2
					miniscore = selfstatboost(statarray)
				else
					miniscore = selfstatdrop(statarray,score)
				end
			when 0x3f # Overheat, Draco Meteor, Leaf Storm, Psycho Boost, Flear Cannon
				statarray = [0,0,2,0,0,0,0]
				if @battle.FE == :GLITCH && @attacker.spdef > @attacker.spatk
					# LAWDS - AI now sees that it wont weaken its special attacks if its on glitch field and is attacking using its special defense. this is a messy fix and a more universal one should be handled in selfstatdrop
				else
					if @attacker.ability== :CONTRARY
						miniscore = selfstatboost(statarray)
					elsif @move.pbCritRate?(@attacker,@opponent) < 3 || # lawds
						((pbPartyHasAbility?(:SHELLARMOR,@opponent.index,false) || 
						pbPartyHasAbility?(:BATTLEARMOR,@opponent.index,false)) && !moldBreakerCheck(@attacker))
					# lawds 
						miniscore = selfstatdrop(statarray,score)
						miniscore *=1.3 if @attacker.ability== :SOULHEART
					end
				end
			when 0x40 # Flatter
				increment = 1
				increment = 2 if @battle.FE == :COLOSSEUM
				statarray = [0,0,increment,0,0]
				miniscore = oppstatboost(statarray)
				miniscore *= selfstatboost([0,0,2,0,0,0,0]) if (@attacker.item==:MIRRORHERB || @attacker.ability==:OPPORTUNIST) # lawds
			when 0x41 # Swagger
				increment = 2
				increment = 3 if @battle.FE == :COLOSSEUM
				statarray = [increment,0,0,0,0]
				miniscore = oppstatboost(statarray)
				miniscore *= selfstatboost([increment,0,0,0,0,0,0]) if (@attacker.item==:MIRRORHERB || @attacker.ability==:OPPORTUNIST) # lawds
			when 0x42 # Growl, Aurora Beam, Baby-Doll Eyes, Play Nice, Play Rough, Lunge, Trop Kick				 # LAWDS - Chilling Water
				statarray = [1,0,0,0,0,0,0]
				statarray = [1,0,1,0,0,0,0] if @mondata.skill >= BESTSKILL && @battle.FE == :HAUNTED && @move.move == :BITTERMALICE 
				statarray = [2,0,0,0,0,0,0] if @mondata.skill >= BESTSKILL && @battle.ProgressiveFieldCheck(PBFields::CONCERT) && @move.move == :GROWL # LAWDS - think i found a bug, this line never checked for Growl before. added it.
				statarray = [2,0,0,0,0,0,0] if @mondata.skill >= BESTSKILL && [:FROZENDIMENSION, :ICY].include?(@battle.FE) && @move.move == :CHILLINGWATER # LAWDS - Chilling Water drops Attack by 2 on Frozen Dimension
				miniscore=oppstatdrop(statarray)
				if @mondata.skill >= BESTSKILL
					miniscore*=selfstatboost([0,0,0,0,1,0,0]) if @move.move==:LUNGE && @battle.FE == :ICY
					miniscore*=2 if @move.move==:AURORABEAM && mirrorNeverMiss && @battle.FE == :MIRROR
					miniscore*=freezecode() if Rejuv && (@battle.FE == :ICY || @battle.FE == :SNOWYMOUNTAIN) && @move.move == :BITTERMALICE
				end
			when 0x43 # Tail Whip, Crunch, Rock Smash, Crush Claw, Leer, Iron Tail, Razor Shell, Fire Lash, Liquidation, Shadow Bone
				miniscore=oppstatdrop([0,1,0,0,0,0,0])
			when 0x44 # Rock Tomb, Electroweb, Low Sweep, Bulldoze, Mud Shot, Glaciate, Icy Wind, Constrict, Bubble Beam, Bubble
				statarray = [0,0,0,0,1,0,0]
				statarray = [0,0,0,0,2,0,0] if Rejuv && ((@move.move == :STRUGGLEBUG && @battle.FE == :SWAMP) || (@battle.FE == :ELECTERRAIN && @move.move == :ELECTROWEB))
				miniscore=oppstatdrop(statarray)
				if @move.move == :BULLDOZE
					if @mondata.skill >= BESTSKILL
						if @battle.FE == :ICY # Icy Field
							if @battle.field.backup== :WATERSURFACE # Water Surface
								currentfieldscore = getFieldDisruptScore(@attacker,@opponent,@battle.FE) # the higher the better for opp
								newfieldscore = getFieldDisruptScore(@attacker,@opponent,:WATERSURFACE)
								miniscore = currentfieldscore/newfieldscore
							else
								miniscore*=1.2 if @opponent.pbNonActivePokemonCount>2
								miniscore*=0.8 if @attacker.pbNonActivePokemonCount>2
							end
						end
						if @battle.FE == :CAVE
							if @attacker.ability != :ROCKHEAD && @attacker.ability != :BULLETPROOF && @attacker.ability != :STALWART
								miniscore*=0.7
								miniscore *= 0.3 if @battle.field.counter >=1
							end
						end
						if @battle.FE == :VOLCANICTOP
							miniscore*=volcanoeruptioncode()
						end
					end
				end
			when 0x45 # Snarl, Struggle Bug, Mist Ball, Confide, Moonblast, Mystical Fire
				statarray = [0,0,1,0,0,0,0]
				statarray = [0,0,2,0,0,0,0] if @mondata.skill >= BESTSKILL && ((@move.move == :SNARL && [:FROZENDIMENSION,:BACKALLEY].include?(@battle.FE)) || (Rejuv && @move.move == :STRUGGLEBUG && @battle.FE == :SWAMP))
				miniscore=oppstatdrop(statarray)
			when 0x46 # Psychic, Bug Buzz, Focus Blast, Shadow Ball, Energy Ball, Earth Power, Acid, Luster Purge, Flash Cannon
				miniscore=oppstatdrop([0,0,0,1,0,0,0])
				if @mondata.skill >= BESTSKILL
					miniscore*=2 if (@move.move==:FLASHCANNON || @move.move==:LUSTERPURGE) && mirrorNeverMiss && @battle.FE == :MIRROR
					miniscore*=volcanoeruptioncode() if @battle.FE == :VOLCANICTOP && @move.move == :EARTHPOWER
				end
			when 0x47 # Sand Attack, Night Daze, Leaf Tornado, Mod Bomb, Mud-Slap, Flash, Smokescreen, Kinesis, Mirror Shot, Muddy Water, Octazooka
				statarray = [0,0,0,0,0,1,0]
				if @mondata.skill >= BESTSKILL
					statarray = [0,0,0,0,0,2,0] if (@move.move==:SANDATTACK && (@battle.FE == :ASHENBEACH || @battle.FE == :DESERT))
					statarray = [0,0,0,0,0,2,0] if @move.move==:FLASH && ([:DARKCRYSTALCAVERN,:SHORTCIRCUIT,:MIRROR,:STARLIGHT,:NEWWORLD,:DARKNESS1].include?(@battle.FE))
					statarray = [0,0,0,0,0,2,0] if @move.move==:SMOKESCREEN && [:BURNING,:CORROSIVEMIST,:VOLCANIC,:VOLCANICTOP,:BACKALLEY,:CITY].include?(@battle.FE)
					statarray = [0,0,0,0,0,2,0] if (@move.move==:KINESIS && (@battle.FE == :PSYTERRAIN || @battle.FE == :ASHENBEACH))
				end
				miniscore=oppstatdrop(statarray)
				if @mondata.skill >= BESTSKILL
					miniscore*=selfstatboost([2,0,2,0,0,0,0]) if @move.move==:KINESIS && @battle.FE == :PSYTERRAIN
					miniscore*=2 if @move.move==:MIRRORSHOT && mirrorNeverMiss && @battle.FE == :MIRROR
					miniscore*=0.7 if @move.move==:LEAFTORNADO && @battle.FE == :ASHENBEACH
				end
				if @move.move==:MUDDYWATER
					miniscore*=0.7 if @battle.FE == :SUPERHEATED # Superheated
					if @battle.FE == :DRAGONSDEN # Dragon's Den
						miniscore*= pbPartyHasType?(:FIRE) || pbPartyHasType?(:DRAGON) ? 0 : 1.5
					end
				end
			when 0x48 # Sweet Scent
				statarray = [0,0,0,0,0,0,1]
				if @mondata.skill >= BESTSKILL
					statarray = [0,1,0,1,0,0,1] if @battle.FE == :MISTY || @battle.FE == :FLOWERGARDEN3 
					statarray = [0,2,0,2,0,0,2] if @battle.FE == :FLOWERGARDEN4
					statarray = [0,3,0,3,0,0,3] if @battle.FE == :FLOWERGARDEN5
				end
				miniscore*=oppstatdrop(statarray)
			when 0x49 # Defog
				miniscore = defogcode()
			when 0x4a # Tickle
				miniscore = oppstatdrop([1,1,0,0,0,0,0])
			when 0x4b # Feather Dance, Charm
				statarray = [2,0,0,0,0,0,0]
				statarray = [3,0,0,0,0,0,0] if @mondata.skill >= BESTSKILL && @move.move == :FEATHERDANCE && @battle.FE == :BIGTOP
				statarray = [2,0,2,0,0,0,0] if @mondata.skill >= BESTSKILL && @move.move == :FEATHERDANCE && @battle.FE == :DANCEFLOOR
				# lawds - dancer sky
				statarray = [4,0,0,0,0,0,0] if @move.move == :FEATHERDANCE && (@battle.FE == :SKY && @attacker.pbOwnSide.effects[:Tailwind] != 0 && @attacker.ability== :DANCER) && ![:COMPETITIVE, :DEFIANT].include?(@opponent.ability)
				miniscore = oppstatdrop(statarray)
			when 0x4c # Screech
				statarray = [0,2,0,0,0,0,0]
				statarray = [0,3,0,0,0,0,0] if @mondata.skill >= BESTSKILL && @battle.ProgressiveFieldCheck(PBFields::CONCERT)
				miniscore = oppstatdrop(statarray)
			when 0x4d # Scary Face, String Shot, Cotton Spore
				statarray = [0,0,0,0,2,0,0]
				statarray = [0,0,0,0,4,0,0] if @mondata.skill >= BESTSKILL && @move.move == :SCARYFACE && [:HAUNTED,:DARKCRYSTALCAVERN].include?(@battle.FE)
				statarray = [0,0,0,0,4,0,0] if @mondata.skill >= BESTSKILL && @move.move == :MEANLOOK && [:DARKCRYSTALCAVERN].include?(@battle.FE)
				miniscore = oppstatdrop(statarray)
			when 0x4e # Captivate
				agender=@attacker.gender
				ogender=@opponent.gender
				if (agender==2 || ogender==2 || agender==ogender || @opponent.effects[:Attract]>=0 || ((@opponent.ability== :OBLIVIOUS || (@opponent.ability== :MINDSEYE && @battle.FE==:PSYTERRAIN) || @opponent.ability== :AROMAVEIL || @opponent.pbPartner.ability== :AROMAVEIL) && !moldBreakerCheck(@attacker,@move)))
					miniscore = 0
				else
					miniscore = oppstatdrop([0,0,0,2,0,0,0])
				end
			when 0x4f # Acid Spray, Seed Flare, Metal Sound, Fake Tears
				statarray = [0,0,0,2,0,0,0]
				statarray = [0,0,0,3,0,0,0] if @mondata.skill >= BESTSKILL && @move.move==:METALSOUND && (@battle.FE == :FACTORY || @battle.FE == :SHORTCIRCUIT || @battle.ProgressiveFieldCheck(PBFields::CONCERT))
				statarray = [0,0,0,3,0,0,0] if @mondata.skill >= BESTSKILL && @move.move==:FAKETEARS && @battle.FE == :BACKALLEY
				miniscore = oppstatdrop(statarray)
			when 0x50 # Clear Smog
				miniscore = oppstatrestorecode()
				miniscore *= nevermisscode(initialscores[scoreindex])
			when 0x51 # Haze
				miniscore = hazecode()
			when 0x52 # Power Swap
				miniscore = statswapcode(PBStats::ATTACK,PBStats::SPATK)
			when 0x53 # Guard Swap
				miniscore = statswapcode(PBStats::DEFENSE,PBStats::SPDEF)
			when 0x54 # Heart Swap
				boostarray,droparray = psychupcode()
				buffscore = selfstatboost(boostarray.clone) - selfstatdrop(droparray.clone,score)
				dropscore = oppstatdrop(boostarray.clone) - selfstatboost(droparray.clone)
				miniscore = buffscore + dropscore
				miniscore = 25 if miniscore == 0 && @battle.FE == :NEWWORLD
				miniscore *= splitcode(PBStats::HP) if @battle.FE == :NEWWORLD
			when 0x55 # Psych Up
				boostarray,droparray = psychupcode()
				boostarray[3] += 2 if @mondata.skill >= BESTSKILL && @battle.FE == :PSYTERRAIN
				actualopp = @opponent
				@opponent = firstOpponent() if @opponent.index == @attacker.pbPartner.index
				miniscore = selfstatboost(boostarray) - selfstatdrop(droparray.clone,score)
				stagecounter=boostarray.sum - droparray.sum
				miniscore*= 1.3 if stagecounter>=3
				miniscore*= [1,refreshcode()].max if @mondata.skill >= BESTSKILL && @battle.FE == :ASHENBEACH
				@opponent = actualopp
			when 0x56 # Mist
				miniscore = mistcode()
				fieldscore = 1
				if @attacker.item!=:EVERSTONE && @battle.canChangeFE?(:MISTY)
					fieldscore=getFieldDisruptScore(@attacker,@opponent)
					fieldscore*=1.3 if pbPartyHasType?(:FAIRY)
					fieldscore*=1.3 if @opponent.hasType?(:DRAGON) && !@attacker.hasType?(:FAIRY)
					fieldscore*=0.5 if @attacker.hasType?(:DRAGON)
					fieldscore*=0.5 if @opponent.hasType?(:FAIRY)
					fieldscore*=1.5 if @attacker.hasType?(:FAIRY) && @opponent.spatk>@opponent.attack
					fieldscore*=2   if @mondata.attitemworks && @attacker.item == :AMPLIFIELDROCK
				end
				score*=0 if miniscore<=1 && fieldscore<=1
				miniscore*= fieldscore
			when 0x57 # Power Trick
				miniscore = powertrickcode()
			when 0x58 # Power Split
				miniscore = splitcode(PBStats::ATTACK)
			when 0x59 # Guard Split
				miniscore = splitcode(PBStats::DEFENSE)
			when 0x5a # Pain Split
				miniscore = splitcode(PBStats::HP)
			when 0x5b # Tailwind
				miniscore = tailwindcode()
				if (@battle.FE == :MOUNTAIN || @battle.FE == :SNOWYMOUNTAIN || @battle.FE == :SKY || @battle.FE == :VOLCANICTOP) && !(@battle.state.effects[:WEATHERLOCK] && @battle.FE!=:SKY)
					miniscore*=2.0
					miniscore*=2.0**@battle.pbParty(@attacker.index).count {|mon| mon && mon.hp>0 && mon.hasType?(:FLYING)}
					miniscore*=2.0 if @attacker.pbPartner.ability== :WINDRIDER
					miniscore*=5 if @battle.pbWeather != :STRONGWINDS
				end
				# Lawds Mod - Wind Rider boost + field interactions
				if @attacker.ability== :WINDRIDER && @attacker.pbOwnSide.effects[:Tailwind] == 0
					statarray = [1,0,0,0,0,0,0]
					statarray = [2,0,2,0,0,0,0] if @battle.FE == :SKY
					miniscore *= selfstatboost(statarray)
				end
			when 0x5c # Mimic
				miniscore = mimicsketchcode([0x02, 0x14, 0x5C, 0x5D, 0xB6],false) # Struggle, Chatter, Mimic, Sketch, Metronome
			when 0x5d # Sketch
				miniscore = mimicsketchcode([0x02, 0x14, 0x5D],true) #Struggle, Chatter, Sketch
			when 0x5e # Conversion
				miniscore = typechangecode(@attacker.moves[0].type)
				miniscore*=0.3 if @battle.field.conversion==1
				if @attacker.item!=:EVERSTONE && @battle.canChangeFE?(:GLITCH)
					minimini = getFieldDisruptScore(@attacker,@opponent)
					minimini = 1 + (minimini - 1) / 2 if @battle.field.conversion!=2
					miniscore*=minimini
				end
				if @move.zmove
					miniscore*= selfstatboost([1,1,1,1,1,0,0]) if @move.move == :CONVERSION
				end
			when 0x5f # Conversion2
				for i in @opponent.moves
					next if i.nil?
					atype=i.pbType(@attacker) if i.move==@opponent.lastMoveUsed
				end
				miniscore = 0
				if atype
					resistedtypes = PBTypes.typeResists(atype)
					for type in resistedtypes
						miniscore += (typechangecode(type) / resistedtypes.length)
					end
				end
				miniscore*=0.3 if @battle.field.conversion==2
				if @battle.canChangeFE?(:GLITCH)
					minimini = getFieldDisruptScore(@attacker,@opponent)
					minimini = 1 + (minimini - 1) / 2 if @battle.field.conversion!=1
					miniscore*=minimini
				end
			when 0x60 # Camouflage
				type = :NORMAL
				type = @battle.field.mimicry
				miniscore = typechangecode(type)
			when 0x61 # Soak
				miniscore = opptypechangecode(:WATER)
			when 0x62 # Reflect Type
				miniscore1 = typechangecode(@opponent.type1)
				miniscore2 = typechangecode(@opponent.type2)
				miniscore = [miniscore1,miniscore2].max
			when 0x63 # Simple Beam
				miniscore = abilitychangecode(:SIMPLE)
			when 0x64 # Worry Seed
				miniscore = abilitychangecode(:INSOMNIA)
				miniscore *= oppstatdrop([1,0,0,0,0,0,0]) if Rejuv && @battle.FE == :GRASSY
			when 0x65 # Role Play
				minisore = roleplaycode()
			when 0x66 # Entrainment
				score = entraincode(score)
			when 0x67 # Skill Swap
				minisore = skillswapcode()
			when 0x68 #Gastro Acid
				miniscore = gastrocode()
			when 0x69 # Transform
				minisore = transformcode()
			#when 0x6A # Sonicboom
			#when 0x6B # Dragon Rage
			#when 0x6C # Super Fang, Nature Madness
			#when 0x6D # Seismic Toss, Night Shade
			when 0x6e # Endeavor
				miniscore = endeavorcode()
			when 0x70 # Fissure, Sheer Cold, Guillotine, Horn Drill
				miniscore = ohkode()
				if @mondata.skill >= BESTSKILL
					if @move.move == :FISSURE
						if @battle.FE == :ICY # Icy Field
							if @battle.field.backup== :WATERSURFACE # Water Surface
								currentfieldscore = getFieldDisruptScore(@attacker,@opponent,@battle.FE) # the higher the better for opp
								newfieldscore = getFieldDisruptScore(@attacker,@opponent,:WATERSURFACE)
								miniscore = currentfieldscore/newfieldscore
							else
								miniscore*=1.2 if @opponent.pbNonActivePokemonCount>2
								miniscore*=0.8 if @attacker.pbNonActivePokemonCount>2
							end
						end
					end
				end
			when 0x71..0x73 # Counter, Mirror Coat, Metal Burst
				miniscore = counterattackcode()
				miniscore*= Math.sqrt(selfstatboost([0,1,0,1,0,0,1])) if @mondata.skill >= BESTSKILL && @battle.FE == :MIRROR && @move.move==:MIRRORCOAT
			when 0x74 # Flame Burst
				miniscore *= 1.1 if @battle.doublebattle
			when 0x75 # Surf
				if @mondata.skill >= BESTSKILL
					miniscore*=0.7 if @battle.FE == :SUPERHEATED && @move.move == :SURF
					miniscore*= (pbPartyHasType?(:DRAGON) || pbPartyHasType?(:FIRE)) ? 0 : 1.5  if @battle.FE == :DRAGONSDEN && @move.move == :SURF
					miniscore*=volcanoeruptioncode() if @battle.FE == :VOLCANICTOP && @move.move == :MAGMADRIFT
				end
			when 0x76 # Earthquake
				if @mondata.skill >= BESTSKILL
					if @battle.FE == :ICY # Icy Field
						if @battle.field.backup== :WATERSURFACE # Water Surface
							currentfieldscore = getFieldDisruptScore(@attacker,@opponent,@battle.FE) # the higher the better for opp
							newfieldscore = getFieldDisruptScore(@attacker,@opponent,:WATERSURFACE)
							miniscore = currentfieldscore/newfieldscore
						else
							miniscore*=1.2 if @opponent.pbNonActivePokemonCount>2
							miniscore*=0.8 if @attacker.pbNonActivePokemonCount>2
						end
					end
					if @battle.FE == :CAVE && @move.move==:EARTHQUAKE
						if @attacker.ability != :ROCKHEAD && @attacker.ability != :BULLETPROOF || @attacker.ability != :STALWART
							miniscore*=0.7
							miniscore *= 0.3 if @battle.field.counter >=1
						end
					end
					if @battle.FE == :VOLCANICTOP
						miniscore=volcanoeruptioncode()
					end
				end
			when 0x77 # Gust
			when 0x78 # Twister
				miniscore = flinchcode()
				miniscore*=0.7 if @mondata.skill >= BESTSKILL && @battle.FE == :ASHENBEACH
			#when 0x79 # Fusion Bolt, Fusion Flare, Venoshock
			when 0x7c # Smelling Salts
				if @opponent.status== :PARALYSIS  && @opponent.effects[:Substitute]<=0
					score*=0.8
					score*=0.5 if @opponent.speed>@attacker.speed && @opponent.speed/2.0<@attacker.speed
				end
			when 0x7d # Wake-up Slap
				if @opponent.status== :SLEEP && @opponent.effects[:Substitute]<=0
					score*=0.8
					score*=0.3 if @attacker.ability== :BADDREAMS || @attacker.pbHasMove?(:DREAMEATER) || @attacker.pbHasMove?(:NIGHTMARE)
					score*=1.3 if checkAImoves([:SLEEPTALK, :SNORE])
				end
			#when 0x7E..0x80 # Facade, Hex, Brine
			when 0x81 # Revenge, Avalanche
				miniscore = revengecode()
			when 0x82 # Assurance
				score*=1.5 if !pbAIfaster?(@move)
			when 0x83 # Round
				score*=1.5 if @battle.doublebattle && @attacker.pbPartner.pbHasMove?(:ROUND)
			when 0x84 # Payback
				score*=2 if !pbAIfaster?(@move)
			#when 0x85..0x87 # Retaliate, Acrobatics, Weather Ball
			when 0x88 # Pursuit
				# LAWDS forget the miniscore, just make it a pure trapping tool. it will go for it if its guaranteed a kill or if it does the most damage with it and traps.
				miniscore = 1
				if @initial_scores[@score_index] >= 110 || (@initial_scores[@score_index]==@initial_scores.max && @initial_scores[@score_index] >= 50)
					miniscore*=1.5 if !checkAIpriority(@attacker.moves,@attacker,true) # if attacker doesnt have a priority move, to avoid screwing things up
					miniscore*=2 if pbAIfaster?(@move)
				end
			#when 0x89..0x8a # Return, Frustration
			when 0x8B # Water Spout, Eruption
				# LAWDS more rigorous checks to see possible damage taken before moving
				alwaysfirst = true
				opparray = @battle.doublebattle ? [@opponent,@opponent.pbPartner] : [@opponent]
				totaldmgpremove = 0
				for opp in opparray
				    next if !opp || opp.isFainted?
				    maxoppdmg = 0
				    for i in 0...opp.moves.length
					oppmove = opp.moves[i]
					next if oppmove==nil || oppmove.basedamage==0 || !@battle.pbCanChooseMove?(opp.index,i,false)
					next if pbAIfaster?(@move,oppmove,@attacker,opp)
					movedamage = pbRoughDamage(oppmove,opp,@attacker)
					next if movedamage <= 0
					maxoppdmg = movedamage if movedamage > maxoppdmg
				    end
				    totaldmgpremove+=maxoppdmg
				end
				if totaldmgpremove > 0
					original_power = [(150*(@attacker.hp.to_f)/@attacker.totalhp),1.0].max
					actual_power = [(150*(@attacker.hp.to_f - totaldmgpremove)/@attacker.totalhp),1.0].max
					score*= actual_power / original_power
				end
				if @mondata.skill >= BESTSKILL
					if @move.move==:WATERSPOUT
						score*=0.7 if @battle.FE == :SUPERHEATED # Superheated
					end
				end
			#when 0x8C..0x90 # Crush Grip, Wring Out, Gyro Ball, Stored Power, Pwer Trip, Punishment, Hidden Power
			when 0x8F # LAWDS - punishment
				miniscore = oppstatrestorecode() if @battle.FE == :HOLY
			when 0x91 # Fury Cutter
				miniscore = echocode()
				miniscore *= (1 + 0.15 * @attacker.stages[PBStats::ACCURACY])
				miniscore *= (1 - 0.08 * @opponent.stages[PBStats::EVASION])
				miniscore*=0.8 if checkAImoves(PBStuff::PROTECTMOVE)
			when 0x92 # Echoed Voice
				miniscore = echocode()
			when 0x93 # Rage
				if @battle.FE != :DIMENSIONAL && @battle.FE != :FROZENDIMENSION
					score*=1.2 if @attacker.attack>@attacker.spatk
					score*=1.3 if @attacker.hp==@attacker.totalhp
					score*=1.3 if checkAIdamage()<(@attacker.hp/4.0)
				else
					statarray = [1,0,0,0,0,0,0]
					miniscore = selfstatboost(statarray)
				end
			when 0x94 # Present
				score*=1.2 if @opponent.hp==@opponent.totalhp
			when 0x95 # Magnitude
				if @mondata.skill >= BESTSKILL
					if @battle.FE == :ICY # Icy Field
						if @battle.field.backup== :WATERSURFACE # Water Surface
							currentfieldscore = getFieldDisruptScore(@attacker,@opponent,@battle.FE) # the higher the better for opp
							newfieldscore = getFieldDisruptScore(@attacker,@opponent,:WATERSURFACE)
							miniscore = currentfieldscore/newfieldscore
						else
							miniscore*=1.2 if @opponent.pbNonActivePokemonCount>2
							miniscore*=0.8 if @attacker.pbNonActivePokemonCount>2
						end
					end
					if @battle.FE == :CAVE
						if @attacker.ability != :ROCKHEAD && @attacker.ability != :BULLETPROOF || @attacker.ability != :STALWART
							miniscore*=0.7
							miniscore *= 0.3 if @battle.field.counter >=1
						end
					end
					if @battle.FE == :VOLCANICTOP
						miniscore=volcanoeruptioncode()
					end
				end
			when 0x96 # Natural Gift
				score*=0 if @attacker.item.nil? || !pbIsBerry?(@attacker.item) || #@attacker.ability== :KLUTZ || # lawds klutz rework
				@battle.state.effects[:MagicRoom]>0 || @attacker.effects[:Embargo]>0 || (@opponent.ability== :UNNERVE || @opponent.ability== :ASONE)
			when 0x97 # Trump Card
				score*=1.2 if @attacker.hp==@attacker.totalhp
				score*=1.3 if checkAIdamage()<(@attacker.hp/3.0)
				score*=0.5 if @move.pp==1 && hasgreatmoves()
			when 0x98 # Reversal, Flail
				if !pbAIfaster?(@move)
					score*=1.1
					score*=1.3 if @attacker.hp<@attacker.totalhp
				end
			#when 0x99..0x9b # Electro Ball, Low Kick, Grass Knot, Heat Crash, Heavy Slam
			when 0x9c # Helping Hand
				miniscore = helpinghandcode()
			when 0x9d # Mud Sport
				miniscore = mudsportcode()
				miniscore*= !pbPartyHasType?(:ELECTRIC) ? 2 : 0.3 if @battle.FE == :ELECTERRAIN
			when 0x9e # Water Sport
				miniscore = watersportcode()
				miniscore*= !pbPartyHasType?(:FIRE) ? 2 : 0 if @battle.FE == :BURNING
				if @battle.FE == :SUPERHEATED
					miniscore*=0.7
					miniscore*= !pbPartyHasType?(:FIRE) ? 1.8 : 0
				elsif @battle.FE == :GRASSY || @battle.FE == :FOREST || @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN)
					miniscore*=3 if !@attacker.hasType?(:FIRE) && @opponent.hasType?(:FIRE)
					miniscore*=0.5 if pbPartyHasType?(:FIRE)
					if pbPartyHasType?(:GRASS) || pbPartyHasType?(:BUG)
						miniscore*=2
						miniscore*=3 if @battle.FE == :FLOWERGARDEN5
					end
				end
			#when 0x9f # Judgement, Techno Blast, Multi-Attack
			when 0xa0 # Frost Breath, Storm Throw, Wicked Blow
				miniscore = permacritcode(initialscores[scoreindex])
			when 0x90B # Flower Trick
				miniscore = nevermisscode(initialscores[scoreindex])
				miniscore *= permacritcode(initialscores[scoreindex])
			when 0x90C # Glaive Rush
				glaivedamage = pbRoughDamage
				glaivefaster = pbAIfaster?()
				miniscore = 1.0
				miniscore*= 0.7 if (!(glaivedamage > @opponent.hp) && !glaivefaster)  # if we're not going to knock out the opponent and aren't faster, next turn their move will hurt a lot so we might have to switch or get knocked out.
				miniscore*= 0.5 if (!(glaivedamage > @opponent.hp) && glaivefaster)   # If we're not going to knock out the opponent and are faster, their move this turn will hurt a lot and we might get knocked out.
				miniscore*=selfstatboost([0,0,0,0,1,0,0]) if @battle.FE==:ICY # lawds glaive rush on icy
			when 0x218 # LAWDS - razor thread crit condition
				miniscore = permacritcode(initialscores[scoreindex]) if @opponent.pbOwnSide.effects[:StealthRock]
			when 0xa1 # Lucky Chant
				score+=20 if @attacker.pbOwnSide.effects[:LuckyChant]==0  && @attacker.ability != :BATTLEARMOR && @attacker.ability != :SHELLARMOR && (@opponent.effects[:FocusEnergy]>1 || @opponent.effects[:LaserFocus]>0)
			when 0xa2 # Reflect
				miniscore = screencode()
				miniscore+= [0,selfstatboost([0,0,0,0,0,0,1])-1].max if  @mondata.skill >=BESTSKILL && @battle.FE == :MIRROR
			when 0xa3 # Light Screen
				miniscore = screencode()
				miniscore+= [0,selfstatboost([0,0,0,0,0,0,1])-1].max if  @mondata.skill >=BESTSKILL && @battle.FE == :MIRROR
			when 0xa4 # Secret Power
				miniscore = secretcode()
			when 0xa5 # Shock Wave, Feint Attack, Aura Sphere, Vital Throw, Aerial Ace, Shadow Punch, Swift, Magnet Bomb, Disarming Voice, Smart Strike, False Surrender
				miniscore = nevermisscode(initialscores[scoreindex])
				miniscore *= tauntcode() if @move.move == :FALSESURRENDER && @mondata.skill >= BESTSKILL && @battle.FE == :CHESS
			when 0xa6 # Lock On, Mind Reader
				miniscore = lockoncode()
				if @battle.FE == :PSYTERRAIN && @move.move == :MINDREADER
					miniscore*=selfstatboost([0,0,2,0,0,0,0])
					score+=10 if @attacker.stages[PBStats::SPATK]<6
				end
			when 0xa7 # Foresight, Odor Sleuth
				miniscore = forecode5me()
			when 0xa8 # Miracle Eye
				miniscore = miracode()
				if @battle.FE == :PSYTERRAIN || @battle.FE == :HOLY || @battle.FE == :FAIRYTALE
					score+=10 if @attacker.stages[PBStats::SPATK]<6
					miniscore*=selfstatboost([0,0,2,0,0,0,0])
				end
			when 0xa9 # Chip Away, Sacred Sword, Darkest Lariat
				miniscore = chipcode()
			when 0xaa # Protect, Detect
				miniscore = protectcode()
			when 0xab # Quick Guard
				if (@opponent.ability== :GALEWINGS && (@opponent.hp == @opponent.totalhp || @battle.FE == :SKY)) || (@opponent.ability== :PRANKSTER && (!@attacker.hasType?(:DARK) || @battle.FE == :BEWITCHED)) || checkAIpriority()
					miniscore = specialprotectcode()
					# LAWDS - Quick Guard vs. FImp
					no_prio_blocked_self = !prioBlocked?(@attacker, @opponent)
					no_prio_blocked_partner = !(@battle.doublebattle && prioBlocked?(@attacker.pbPartner, @opponent))
					if ((@opponent.pbHasMove?(:FIRSTIMPRESSION) && @battle.FE != :COLOSSEUM) || @opponent.crested == :FERALIGATR) && @opponent.turncount == 0 && @move.function != 0x188 # LAWDS - playing around first impression and fera crest
						if (no_prio_blocked_self) || (no_prio_blocked_partner)
							miniscore*= 5.0
							miniscore*=2.0 if @mondata.roles.include?(:SWEEPER) # more likely to click this if you're trying to sweep
							miniscore*=10.0 if !(@opponent.pbHasMove?(:AGILITY) || @opponent.pbHasMove?(:DRAGONDANCE) || @opponent.pbHasMove?(:QUIVERDANCE))
						end
					end
				else
					miniscore = 0
				end
			when 0xac # Wide Guard
				if getAIMemory().any? {|moveloop| moveloop!=nil && (moveloop.target == :AllOpposing || moveloop.target == :AllNonUsers)}
					miniscore = specialprotectcode()
					miniscore*=10 if @attacker.effects[:FollowMe] && getAIMemory().any? {|moveloop| moveloop!=nil && moveloop.move==:ROCKSLIDE} # LAWDS - make maddie dog want to click wide guard on rock slide turn 1
					if @battle.FE == :CAVE
						miniscore*=2 if checkAImoves(PBFields::QUAKEMOVES)
					end
					if @battle.FE == :MIRROR
						miniscore*=2 if (checkAImoves([:MAGNITUDE,:EARTHQUAKE,:BULLDOZE]) || checkAImoves([:HYPERVOICE,:BOOMBURST]))
					end
				else
					miniscore=0
				end
			when 0xad # Feint
				miniscore = feintcode()
			when 0xae # Mirror Move
				score = mirrorcode(false) #changes actual score so no miniscore
				score+= 10*selfstatboost([1,0,1,0,0,0,1]) if @mondata.skill >=BESTSKILL && @battle.FE == :MIRROR && score != 0
				score+= 10*selfstatboost([1,0,1,0,1,0,0]) if @mondata.skill >=BESTSKILL && @battle.FE == :SKY && score != 0
			when 0xaf # Copycat
				if @opponent.effects[:Substitute]<=0
					score = mirrorcode(true) #changes actual score so no miniscore
				else
					score=0
				end
			when 0xb0 # Me First
				miniscore = yousecondcode()
			when 0xb1 # Magic Coat
				miniscore = coatcode()
			when 0xb2 # Snatch
				miniscore = snatchcode()
			when 0xb3 # Nature Power
				#we should never need this- nature power should be changed in advance
			when 0xb4 # Sleep Talk
				miniscore = sleeptalkcode()
			when 0xb5 # Assist
				miniscore = metronomecode(25)
			when 0xb6 # Metronome
				miniscore = metronomecode(20)
				miniscore = metronomecode(40) if @battle.FE == :GLITCH
			when 0xb7 # Torment
				miniscore = tormentcode()
			when 0xb8 # Imprison
				miniscore = imprisoncode()
			when 0xb9 # Disable
				miniscore = disablecode()
			when 0xba # Taunt
				miniscore = tauntcode()
			when 0xbb # Heal Block, Psychic Noise
				miniscore = healblockcode()
			when 0xbc # Encore
				miniscore = encorecode()
			when 0xbd # Double Kick, Dual Chop, Bonemerang, Double Hit, Gear Grind
				miniscore = multihitcode()
			when 0xbe # Twinneedle
				miniscore = poisoncode ** 1.2
				miniscore *= multihitcode()
			when 0xbf # Triple Kick
				miniscore = multihitcode()
			when 0xc0 # Bullet Seed, Pin Missile, Arm Thrust, Bone Rush, Icicle Spear, Tail Slap, Spike Cannon, Comet Punch, Furey Swipes, Barrage, Double Slap, Fury Attack, Rock Blast, Water Shuriken
				miniscore = multihitcode()
			when 0xc1 # Beat Up
				if @opponent.index == @attacker.pbPartner.index
					score = beatupcode(initialscores[scoreindex])
				else
					miniscore = multihitcode() if @battle.pbPokemonCount(@battle.pbPartySingleOwner(@attacker.index))>0
				end
			when 0x20F # Boss's Orders
				miniscore = multihitcode() if @battle.pbPokemonCount(@battle.pbPartySingleOwner(@attacker.index))>0
			when 0xc2 # Hyper Beam, Roar of Time, Blast Burn, Frenzy Plant, Giga Impact, Rock Wrecker, Hydro Cannon, Prismatic Laser, Meteor Assault
				# lawds juggernaut
				miniscore = hypercode() unless ((@move.move == :METEORASSAULT && @battle.FE == :STARLIGHT) || (@attacker.ability==:STALL) || (@attacker.ability==:JUGGERNAUT))
			when 0xc3 # Weasel Slash
				miniscore = weaselslashcode() unless @battle.FE == :CLOUDS || @battle.FE == :SKY || (Rejuv && @battle.FE == :GRASSY) || (@battle.state.effects[:GRASSY] > 0)
			when 0xc4 # Solar Beam, Solar Blade
				#if we first want to use sunny day for instant move later
				if @battle.pbWeather!=:SUNNYDAY && @attacker.pbHasMove?(:SUNNYDAY) && !(@battle.pbCheckGlobalAbility(:AIRLOCK) || @battle.pbCheckGlobalAbility(:CLOUDNINE) || @battle.pbCheckGlobalAbility(:DELTASTREAM) ||
					@battle.pbCheckGlobalAbility(:DESOLATELAND) || @battle.pbCheckGlobalAbility(:PRIMORDIALSEA) || @attacker.ability==:EARLYBIRD || @attacker.item == :POWERHERB || @battle.FE == :UNDERWATER || @battle.FE == :NEWWORLD || @battle.FE == :RAINBOW)
					miniscore = 0.3
				else	# lawds early bird
					miniscore = weaselslashcode() if @battle.pbWeather!=:SUNNYDAY && @battle.FE != :RAINBOW && @attacker.ability!=:EARLYBIRD && @attacker.crested != :CLAYDOL && @attacker.crested != :CHERRIM && @attacker.pbPartner.crested != :CHERRIM
				end
				miniscore = 0 if @battle.FE == :DARKCRYSTALCAVERN
			when 0x213 # Electro Shot - Lawds Mod
				miniscore = selfstatboost([0,0,1,0,0,0,0])
				if (@battle.pbWeather!=:RAINDANCE || @attacker.hasWorkingItem(:UTILITYUMBRELLA)) && @battle.FE != :FACTORY && @battle.FE != :CITY && @battle.FE != :BACKALLEY && @battle.FE != :ELECTERRAIN && @battle.FE != :SHORTCIRCUIT && @battle.FE != :GLITCH
					miniscore *= weaselslashcode()
				end
			when 0x214 # Dream Reaper
				#miniscore=selfstatboost([1,0,0,0,0,0,0]) if (@opponent.status == :SLEEP || (@opponent.ability== :COMATOSE && @battle.FE != :ELECTERRAIN) || @attacker.ability== :WORLDOFNIGHTMARES) && !@opponent.damagestate.substitute
			when 0x210 # Adaptive Assault
				stat = opponent.attack #Attack
				miniscore = selfstatboost([1,0,0,0,0,0,0])
				if(opponent.defense > stat)
				  stat = opponent.defense #Defense
				  miniscore = selfstatboost([0,1,0,0,0,0,0])
				end
				if(opponent.spatk > stat)
				  stat = opponent.spatk #SpA
				  miniscore = selfstatboost([0,0,1,0,0,0,0])
				end
				if(opponent.spdef > stat)
				  stat = opponent.spdef #SpDef
				  miniscore = selfstatboost([0,0,0,1,0,0,0])
				end
				if(opponent.speed > stat)
				  stat = opponent.speed #Speed
				  miniscore = selfstatboost([0,0,0,0,1,0,0])
				end
			when 0xc5 # Freeze Shock
				miniscore = paracode()
				miniscore *= weaselslashcode() unless @battle.FE == :FROZENDIMENSION
			when 0xc6 # Ice Burn
				miniscore = burncode()
				miniscore *= weaselslashcode() unless @battle.FE == :FROZENDIMENSION
			when 0xc7 # Sky Attack
				miniscore = flinchcode()
				miniscore *= weaselslashcode()
			when 0xc8 # Skull Bash
				miniscore = selfstatboost([0,1,0,0,0,0,0])
				miniscore *= weaselslashcode()
			when 0xc9 # Fly
				if @battle.FE == :DIMENSIONAL
					miniscore = 0 #Telling the AI that Suicide is bad hmmm kay
				elsif @attacker.ability== :NOGUARD || @opponent.ability== :NOGUARD || (@opponent.ability==:FAIRYAURA && @battle.FE == :FAIRYTALE) || (@opponent.ability==:DUSTDEVIL && (@battle.pbWeather == :SANDSTORM || [:DESERT, :ASHENBEACH].include?(@battle.FE)))
					miniscore = weaselslashcode() unless @battle.FE == :CLOUDS || @battle.FE == :CAVE || @battle.FE == :SKY || (Rejuv && battle.FE == :DRAGONSDEN)
				elsif !(@battle.FE == :CLOUDS || @battle.FE == :CAVE || @battle.FE == :SKY || (Rejuv && battle.FE == :DRAGONSDEN))
					miniscore = twoturncode() unless @battle.FE == :CLOUDS || @battle.FE == :CAVE || @battle.FE == :SKY || (Rejuv && battle.FE == :DRAGONSDEN)
					miniscore*=0.3 if checkAImoves([:THUNDER,:HURRICANE])
				end
				miniscore=0 if @battle.state.effects[:Gravity]!=0
			when 0xca # Dig
				if @battle.FE == :DIMENSIONAL
					miniscore = 0 #Telling the AI that Suicide is bad hmmm kay
				elsif @attacker.ability== :NOGUARD || @opponent.ability== :NOGUARD || (@opponent.ability==:FAIRYAURA && @battle.FE == :FAIRYTALE) || (@opponent.ability==:DUSTDEVIL && (@battle.pbWeather == :SANDSTORM || [:DESERT, :ASHENBEACH].include?(@battle.FE)))
					miniscore = weaselslashcode() unless (Rejuv && @battle.FE == :DESERT)
				elsif !(Rejuv && @battle.FE == :DESERT)
					miniscore = twoturncode()
					miniscore*=0.3 if checkAImoves([:EARTHQUAKE])
				end
			when 0xcb # Dive
				if @battle.FE == :DIMENSIONAL
					miniscore = 0 #Telling the AI that Suicide is bad hmmm kay
				elsif @attacker.ability== :NOGUARD || @opponent.ability== :NOGUARD || (@opponent.ability==:FAIRYAURA && @battle.FE == :FAIRYTALE) || (@opponent.ability==:DUSTDEVIL && (@battle.pbWeather == :SANDSTORM || [:DESERT, :ASHENBEACH].include?(@battle.FE)))
					miniscore = weaselslashcode() unless (@battle.FE == :WATERSURFACE || @battle.FE == :UNDERWATER)
				elsif !(@battle.FE == :WATERSURFACE || @battle.FE == :UNDERWATER)
					miniscore = twoturncode()
					miniscore*=0.3 if checkAImoves([:SURF])
				end
				if @battle.FE == :MURKWATERSURFACE # Murkwater Surface
					miniscore*=0.3 if !@attacker.hasType?(:POISON) && !@attacker.hasType?(:STEEL)
				end
			when 0xcc # Bounce
				if @battle.FE == :DIMENSIONAL
					miniscore = 0 #Telling the AI that Suicide is bad hmmm kay
				elsif @attacker.ability== :NOGUARD || @opponent.ability== :NOGUARD || (@opponent.ability==:FAIRYAURA && @battle.FE == :FAIRYTALE) || (@opponent.ability==:DUSTDEVIL && (@battle.pbWeather == :SANDSTORM || [:DESERT, :ASHENBEACH].include?(@battle.FE)))
					miniscore = weaselslashcode() unless @battle.FE == :CLOUDS || @battle.FE == :CAVE || @battle.FE == :SKY || (Rejuv && @battle.FE == :DRAGONSDEN)
				elsif !(@battle.FE == :CLOUDS || @battle.FE == :CAVE || @battle.FE == :SKY || (Rejuv && @battle.FE == :DRAGONSDEN))
					miniscore = twoturncode()
					miniscore*= 0.3 if checkAImoves([:THUNDER,:HURRICANE])
				end
				miniscore*= paracode()
				miniscore = 0 if @battle.state.effects[:Gravity]!=0
			when 0xcd # Phantom Force, Shadow Force
				if @attacker.ability== :NOGUARD || @opponent.ability== :NOGUARD || (@opponent.ability==:FAIRYAURA && @battle.FE == :FAIRYTALE)
					miniscore = weaselslashcode() unless @battle.FE == :HAUNTED || @battle.ProgressiveFieldCheck(PBFields::DARKNESS,2,3)
				else
					miniscore = twoturncode() unless @battle.FE == :HAUNTED || @battle.ProgressiveFieldCheck(PBFields::DARKNESS,2,3)
				end
				miniscore*=1.1 if checkAImoves(PBStuff::PROTECTMOVE)
			when 0xce # Sky Drop
				if @attacker.ability== :NOGUARD || @opponent.ability== :NOGUARD || (@opponent.ability==:FAIRYAURA && @battle.FE == :FAIRYTALE)
					miniscore = weaselslashcode()
				else
					miniscore = twoturncode()
				end
				miniscore=0 if @battle.state.effects[:Gravity]!=0 || @battle.FE == :CAVE
			when 0xcf # Fire Spin, Magma Storm, Sand Tomb, Bind, Clamp, Wrap, Infestation, Thunder Cage, Snap Trap
				miniscore = firespincode()
				case @move.move
				when :FIRESPIN
					miniscore*=0.7 if @battle.FE == :ASHENBEACH
					miniscore*=1.3 if @battle.FE == :BURNING
				when :SANDTOMB
					miniscore*=1.3 if @battle.FE == :DESERT
					score+=10*oppstatdrop([0,0,0,0,0,1,0]) unless opponent.stages[PBStats::ACCURACY]<(-2) if @battle.FE == :ASHENBEACH
				when :INFESTATION
					miniscore*=1.3 if @battle.FE == :FOREST
					if @battle.FE == @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN)
						miniscore*=1.3
						miniscore*=1.3 if @battle.FE == :FLOWERGARDEN4
						miniscore*=1.5 if @battle.FE == :FLOWERGARDEN5
					end
				when :THUNDERCAGE
					miniscore*=1.3 if @battle.FE == :ELECTERRAIN
				when :SNAPTRAP
					miniscore*=1.3 if @battle.FE == :GRASSY
				end
			when 0xd0 # Whirlpool
				miniscore = firespincode()
				miniscore*=1.3 if !$cache.moves[opponent.effects[:TwoTurnAttack]].nil? && 
				$cache.moves[@opponent.effects[:TwoTurnAttack]].function==0xCB
				miniscore*=0.7 if @battle.FE == :ASHENBEACH
				if @battle.FE == :WATERSURFACE || @battle.FE == :UNDERWATER
					miniscore*=1.3
				end
				if @battle.FE == :MURKWATERSURFACE
					miniscore+=10 if miniscore==0
					miniscore*=1.5 if !(@attacker.hasType?(:POISON) || @attacker.hasType?(:STEEL))
					miniscore*=2 if !pbPartyHasType?(:POISON)
					miniscore*=2 if pbPartyHasType?(:WATER)
				end

			when 0xd1 # Uproar
				miniscore = uproarcode()
			when 0xd2 # Outrage, Petal Dance, Thrash
				miniscore*=outragecode(score)
				if @mondata.skill>=BESTSKILL
					if [:SUPERHEATED,:VOLCANICTOP].include?(@battle.FE) && @attacker.ability != :OWNTEMPO # Superheated Field
						miniscore*=0.5
					end
					if @move.move==:PETALDANCE
						miniscore*=1.5 if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,3,5)
					end
					if @move.move==:OUTRAGE
						miniscore*=0.8 if @battle.FE != :INVERSE && pbPartyHasType?(:FAIRY,@opponent.index)
						miniscore*=0.7 if Rejuv && @battle.FE == :CHESS && @attacker.ability != :SHELLARMOR && @attacker.ability != :BATTLEARMOR
					end
					if @move.move==:THRASH
						miniscore*=0.8 if @battle.FE != :INVERSE && pbPartyHasType?(:GHOST,@opponent.index)
						miniscore*=0.7 if Rejuv && @battle.FE == :CHESS && @attacker.ability != :SHELLARMOR && @attacker.ability != :BATTLEARMOR
					end
				end
				miniscore=1 if @attacker.ability==:JUGGERNAUT # lawds juggernaut
			when 0xd3 # Rollout, Ice Ball
				miniscore = rolloutcode()
				score+=10*selfstatboost([0,0,0,0,1,0,0]) if @mondata.skill>=BESTSKILL && @battle.FE == :ICY && @move.move==:ROLLOUT
			when 0xd4 # Bide
				miniscore = bidecode()
			when 0xd5 # Recover, Heal Order, Milk Drink, Slack Off, Soft-Boiled
				recoveramount = @attacker.totalhp/2.0
				recoveramount = @attacker.totalhp*0.66 if @mondata.skill>=BESTSKILL && @move.move==:HEALORDER && @battle.FE == :FOREST # Forest
				miniscore = recovercode(recoveramount)
			when 0xd6 # Roost
				recoveramount = @attacker.totalhp/2.0
				miniscore = recovercode(recoveramount)
				bestmove=checkAIbestMove()
				if pbAIfaster?(@move) && @attacker.hasType?(:FLYING)
					if [:ROCK,:ICE,:ELECTRIC].include?(bestmove.pbType(@opponent))
						score*=1.5
					elsif [:GRASS,:BUG,:FIGHTING,:GROUND].include?(bestmove.pbType(@opponent))
						score*=0.5
					end
				end
			when 0xd7 # Wish
				miniscore = wishcode()		
				miniscore*=1.2 if @mondata.skill>=BESTSKILL && (@battle.FE == :MISTY || @battle.FE == :RAINBOW || @battle.FE == :HOLY || @battle.FE == :FAIRYTALE || @battle.FE == :STARLIGHT) # Misty/Rainbow/Holy/Fairytale/Starlight
			when 0xd8 # Synthesis, Moonlight, Morning Sun
				recoveramount = (@attacker.totalhp/2.0).floor
				recoveramount = (@attacker.totalhp*0.25).floor  if @battle.pbWeather != 0 && !@attacker.hasWorkingItem(:UTILITYUMBRELLA) && @battle.pbWeather != :STRONGWINDS
				recoveramount = (@attacker.totalhp*0.66).floor  if (@battle.pbWeather == :SUNNYDAY && !@attacker.hasWorkingItem(:UTILITYUMBRELLA)) || (@attacker.crested == :CHERRIM || @attacker.pbPartner.crested == :CHERRIM)
				recoveramount = (@attacker.totalhp*0.125).floor if @mondata.skill>=BESTSKILL && @battle.FE == :DARKNESS3 && (@move.move==:SYNTHESIS || @move.move==:MORNINGSUN)
				recoveramount = (@attacker.totalhp*0.25).floor  if @mondata.skill>=BESTSKILL && (@battle.FE == :DARKCRYSTALCAVERN ||@battle.FE == :DARKNESS2)&& (@move.move==:SYNTHESIS || @move.move==:MORNINGSUN)
				recoveramount = (@attacker.totalhp*0.4).floor   if @mondata.skill>=BESTSKILL && @battle.FE == :DARKNESS1 && @move.move==:MOONLIGHT
				recoveramount = (@attacker.totalhp*0.75).floor  if @mondata.skill>=BESTSKILL && (([:DARKCRYSTALCAVERN,:STARLIGHT,:NEWWORLD,:BEWITCHED].include?(@battle.FE) && @move.move==:MOONLIGHT) || (Rejuv && @battle.FE == :GRASSY && @move.move == :SYNTHESIS))
				miniscore = recovercode(recoveramount)
			when 0xd9 # Rest
				miniscore = restcode()
				if @mondata.skill>=BESTSKILL
					miniscore*=1.2 if @battle.FE == :CROWD
				end
			when 0xda # Aqua Ring
				miniscore = aquaringcode()
				if @mondata.skill>=BESTSKILL
					miniscore*=1.3 if @battle.FE == :MISTY || @battle.FE == :SWAMP || @battle.FE == :WATERSURFACE || @battle.FE == :UNDERWATER
					miniscore*=1.3 if @battle.FE == :BURNING
				end
			when 0xdb # Ingrain
				miniscore = aquaringcode()
				if @mondata.skill>=BESTSKILL
					if @battle.FE == :FOREST || @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN) || Rejuv && @battle.FE == :GRASSY
						miniscore*=1.3
						miniscore*=1.3 if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,4,5)
					end
					if @battle.FE == :SWAMP
						miniscore*=0.1 unless (@attacker.hasType?(:POISON) || @attacker.hasType?(:STEEL))
					end
					miniscore*=0.1 if @battle.FE == :CORROSIVE
				end
			when 0xdc # Leech Seed
				miniscore = leechcode()
			when 0xdd # Absorb. Leech Life, Drain Punch, Giga Drain, Horn Leech, Mega Drain, Parabolic Charge
				miniscore = absorbcode(initialscores[scoreindex])
			when 0xde # Dream Eater
				miniscore = absorbcode(initialscores[scoreindex]) if @opponent.status== :SLEEP
				miniscore = 0 if @opponent.status!=:SLEEP
			when 0xdf # Heal Pulse
				miniscore = healpulsecode()
				miniscore*=1.5 if @attacker.ability== :MEGALAUNCHER
			when 0xe0 # Explosion, Self-Destruct
				miniscore = deathcode()
				score*=1.5 if @battle.FE == :GLITCH
				score*=0 if @battle.FE == :MISTY || @battle.FE == :SWAMP || @battle.pbCheckGlobalAbility(:DAMP)
			when 0xe1 # Final Gambit
				miniscore = gambitcode()
			when 0xe2 # Memento
				score = mementcode(score)
			when 0xe3 # Healing Wish
				miniscore = healwishcode()
				miniscore*=1.4 if @battle.FE == :FAIRYTALE || @battle.FE == :STARLIGHT
			when 0xe4 # Lunar Dance
				miniscore = healwishcode()
				if @battle.FE == :FAIRYTALE || @battle.FE == :STARLIGHT
					miniscore*=1.4
				elsif @battle.FE == :NEWWORLD ||  @battle.FE == :DANCEFLOOR
					miniscore*=2
				end
			when 0xe5 # Perish Song
				miniscore = perishcode()
			when 0xe6 # Grudge
				miniscore = deathcode()
				miniscore*= grudgecode()
			when 0xe7 # Destiny Bond
				miniscore = destinycode()
			when 0xe8 # Endure
				miniscore*=endurecode()
				miniscore*=0 if @battle.FE == :BURNING || @battle.FE == :MURKWATERSURFACE
			when 0xe9 # False Swipe
				miniscore = 0.1 if score>=100
			when 0xea # Teleport
				score=0
			when 0xeb # Roar, Whirlwind
				if @battle.FE == :COLOSSEUM
					miniscore = selfstatboost([2,0,0,0,0,0,0])
				else
					miniscore = phasecode()
					miniscore *= selfstatboost([2,0,0,0,0,0,0])
				end
			when 0xec # Dragon Tail, Circle Throw
				miniscore = phasecode()
			when 0xed # Baton Pass
				miniscore = pivotcode()
				#miniscore *= 1.5 if [:CONCERT3,:CONCERT4].include?(@battle.FE) && !(@battle.doublebattle) # LAWDS - Jenner baton pass chicanery
			when 0xee # U-turn, Volt Switch
				miniscore = pivotcode()
			when 0xef # Mean Look, Block, Spider Web
				miniscore = meanlookcode()
				miniscore *=1.1 if  @battle.FE == :CROWD && @move.move== :BLOCK
			when 0xf0 # Knock Off
				miniscore = knockcode()
			when 0xf1 # Covet, Thief
				miniscore = covetcode()
			when 0xf2 # Trick, Switcheroo
				miniscore = covetcode()
				miniscore *= bestowcode()
				if @battle.FE == :BACKALLEY
					if @move.move == :TRICK
						miniscore *= selfstatboost([0,0,1,0,0,0,0])
						miniscore *= oppstatdrop([0,0,1,0,0,0,0])
					elsif @move.move == :SWITCHEROO
						miniscore *= selfstatboost([1,0,0,0,0,0,0])
						miniscore *= oppstatdrop([1,0,0,0,0,0,0])
					end
				end
			when 0xf3 # Bestow
				miniscore = bestowcode()
			when 0xf4 # Bug Bite, Pluck
				miniscore = nomcode()
			when 0xf5 # Incinerate
				miniscore = roastcode()
			when 0xf6 # Recycle
				miniscore = recyclecode()
				if @battle.FE == :CITY
					subscore = selfstatboost([1,0,0,0,0,0,0]) +selfstatboost([0,1,0,0,0,0,0]) + selfstatboost([0,0,1,0,0,0,0]) +selfstatboost([0,0,0,1,0,0,0]) +selfstatboost([0,0,0,0,1,0,0])
					subscore/=5
					miniscore *= subscore
				end
			when 0xf7 # Fling
				miniscore = flingcode()
			when 0xf8 # Embargo
				miniscore = embarcode()
				miniscore *= [meanlookcode(),1].max if @battle.FE == :DIMENSIONAL
			when 0xf9 # Magic Room
				attitemscore=[embarcode(@attacker), 1].max
				miniscore = (embarcode() / attitemscore)
				miniscore*=0 if @battle.state.effects[:MagicRoom]>0
			when 0xfa # Take Down, Head Charge, Submission, Wild Charge, Wood Hammer, Brave Bird, Double-Edge, Head Smash
				miniscore = recoilcode()
			when 0xfd # Volt Tackle
				miniscore = recoilcode()
				miniscore *= paracode()
			when 0xfe # Flare Blitz
				miniscore = recoilcode()
				miniscore *= burncode()
			when 0xff # Sunny Day
				miniscore=weathercode()
				miniscore*=suncode()
				if @battle.pbWeather== :RAINDANCE #Making Rainbow Field
					miniscore*= getFieldDisruptScore(@attacker,@opponent)
					miniscore*=1.2 if @attacker.hasType?(:NORMAL)
				end
				if @mondata.skill>=BESTSKILL
					miniscore*=2   if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN) # Flower Garden
				end
			when 0x100 # Rain Dance
				miniscore=weathercode()
				miniscore*=raincode()
				if @battle.pbWeather== :SUNNYDAY #Making Rainbow Field
					miniscore*= getFieldDisruptScore(@attacker,@opponent)
					miniscore*=1.2 if @attacker.hasType?(:NORMAL)
				end
				if !@battle.opponent.is_a?(Array)
					if Reborn && (@battle.opponent.trainertype==:SHELLY) && (@battle.FE == :GRASSY || @battle.FE == :FOREST || @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN)) # Shelly
						miniscore *= 4
						#experimental -- cancels out drop if killing moves
						miniscore*=6 if initialscores.length>0 && hasgreatmoves()
						#end experimental
					end
				end
				if @mondata.skill>=BESTSKILL
					miniscore*=1.5 if @battle.FE == :GRASSY || @battle.FE == :FOREST || @battle.FE == :SUPERHEATED # Grassy/Forest/Superheated
					miniscore*=2   if @battle.FE == :BURNING || @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN) # Burning/Flower Garden
				end
			when 0x101 # Sandstorm
				miniscore = weathercode()
				miniscore*=sandcode()
				if @mondata.skill>=BESTSKILL
					miniscore*=3   if @battle.FE == :BURNING # Burning
				end
			when 0x102 # Hail
				miniscore = weathercode()
				miniscore*=hailcode()
				if @mondata.skill>=BESTSKILL
					miniscore*=1.5 if @battle.FE == :MOUNTAIN # Rainbow/Mountain
				end
			when 0x103 # Spikes
				if @attacker.pbOpposingSide.effects[:Spikes] < 3
					miniscore = hazardcode()
					miniscore*=0.9 if @attacker.pbOpposingSide.effects[:Spikes]>0
					if @mondata.skill>=BESTSKILL
						miniscore*=0 if @battle.FE == :WATERSURFACE || @battle.FE == :MURKWATERSURFACE # (Murk)Water Surface
						miniscore*=1.3 if Rejuv && @battle.FE == :ELECTERRAIN
					end
				else
					if @move.basedamage == 0 # LAWDS - added this so AI knows it can still click ceaseless edge with rocks up
						miniscore = 0
					else
						miniscore = 1
					end
				end
				if @mondata.skill>=BESTSKILL
					if @battle.FE == :WASTELAND # Wasteland
						miniscore = 1
						score = ((@opponent.totalhp/3.0)/@opponent.hp)*100
						score*=1.5 if @battle.doublebattle
					end
				end
			when 0x104 # Toxic Spikes
				if @attacker.pbOpposingSide.effects[:ToxicSpikes] < 2
					miniscore = hazardcode()
					miniscore*=0.9 if @attacker.pbOpposingSide.effects[:ToxicSpikes]>0
					if @mondata.skill>=BESTSKILL
					  miniscore*=0 if @battle.FE == :WATERSURFACE || @battle.FE == :MURKWATERSURFACE # (Murk)Water Surface
					  miniscore*=1.2 if @battle.FE == :CORROSIVE # Corrosive
					end
					miniscore*=2 if @battle.opponent && !@battle.opponent.is_a?(Array) && @battle.opponent.trainertype==:RIFT_HIPPO && miniscore > 1
				else
					miniscore*=0
				end
				if @mondata.skill>=BESTSKILL
					if @battle.FE == :WASTELAND && !@opponent.isAirborne? # Wasteland
						miniscore = 1
						score = [((@opponent.totalhp*0.13)/@opponent.hp)*100, 110].min
						score*= @opponent.pbCanPoison?(false) ? 1.5 : 0
						score*= 0.6 if hasgreatmoves()
						score*=1.5 if @battle.doublebattle
						score*=0 if @opponent.hasType?(:POISON)
					elsif @battle.FE == :WASTELAND && @opponent.isAirborne?
						score=0
					end
				end
			when 0x105 # Stealth Rocks
				if !@attacker.pbOpposingSide.effects[:StealthRock]
					miniscore = hazardcode()
					miniscore*=1.05 if @attacker.moves.any? {|moveloop| moveloop!=nil && (moveloop.move==:SPIKES || moveloop.move==:TOXICSPIKES)}
					if @mondata.skill>=BESTSKILL
					  miniscore*=2 if @battle.FE == :CAVE || @battle.FE == :ROCKY # Cave/Rocky
					  miniscore*=1.5 if (@battle.FE == :INVERSE && (@attacker.effects[:seed_normalize] || @attacker.ability== :SHARPNESS)) # lawds adam check
					  miniscore*=1.3 if @battle.FE == :CRYSTALCAVERN # Crystal Cavern
					  miniscore*=1.3 if Rejuv && (@battle.FE == :CORRUPTED) # Poison rock fields 
					  miniscore*=1.3 if Rejuv && (@battle.FE == :DRAGONSDEN || @battle.FE == :VOLCANICTOP || @battle.FE == :INFERNAL) # fire rock fields
					end
					miniscore*=1.30 if @attacker.pbHasMove?(:RAZORTHREAD) # LAWDS - razor thread
				else
					if @move.basedamage == 0 # LAWDS - added this so AI knows it can still click stone axe with rocks up
						miniscore = 0
					else
						miniscore = 1
					end
				end
				if @mondata.skill>=BESTSKILL
					if @battle.FE == :WASTELAND && !(@opponent.ability== :MAGICBOUNCE || @opponent.pbPartner.ability== :MAGICBOUNCE || @opponent.ability== :REFLECTOR || @opponent.pbPartner.ability== :REFLECTOR) &&
						(@opponent.effects[:MagicCoat]==true || @opponent.pbPartner.effects[:MagicCoat]==true) # Wasteland
						miniscore=1.0
						score = ((@opponent.totalhp/4.0)/@opponent.hp)*100
						score*=2 if pbTypeModNoMessages(:ROCK,@attacker,@opponent,@move,@mondata.skill)>4
						score*=1.5 if @battle.doublebattle
					end
				end
			when 0x106 # Grass Pledge LAWDS - no pledge shit <3
				#miniscore*= 1.5 if @attacker.pbPartner.pbHasMove?(:FIREPLEDGE) || @attacker.pbPartner.pbHasMove?(:WATERPLEDGE)
				#if @battle.field.checkPledge(:GRASSPLEDGE)
					#miniscore = getFieldDisruptScore(@attacker,@opponent)
					#case @battle.field.pledge
						#when :WATERPLEDGE then miniscore/= getFieldDisruptScore(@attacker,@opponent,:SWAMP)
						#when :FIREPLEDGE then miniscore/=getFieldDisruptScore(@attacker,@opponent,:BURNING)
					#end
				#end
			when 0x107 # Fire Pledge LAWDS - no pledge shit <3
				#miniscore*= 1.5 if @attacker.pbPartner.pbHasMove?(:GRASSPLEDGE) || @attacker.pbPartner.pbHasMove?(:WATERPLEDGE)
				#if @battle.field.checkPledge(:FIREPLEDGE)
					#miniscore = getFieldDisruptScore(@attacker,@opponent)
					#case @battle.field.pledge
						#when :WATERPLEDGE then miniscore/= getFieldDisruptScore(@attacker,@opponent,:RAINBOW)
						#when :GRASSPLEDGE then miniscore/=getFieldDisruptScore(@attacker,@opponent,:BURNING)
					#end
				#end
			when 0x108 # Water Pledge LAWDS - no pledge shit <3
				#miniscore*= 1.5 if @attacker.pbPartner.pbHasMove?(:FIREPLEDGE) || @attacker.pbPartner.pbHasMove?(:GRASSPLEDGE)
				#if @battle.field.checkPledge(:WATERPLEDGE)
					#miniscore = getFieldDisruptScore(@attacker,@opponent)
					#case @battle.field.pledge
						#when :GRASSPLEDGE then miniscore/= getFieldDisruptScore(@attacker,@opponent,:SWAMP)
						#when :FIREPLEDGE then miniscore/=getFieldDisruptScore(@attacker,@opponent,:RAINBOW)
					#end
				#end
			when 0x215 # LAWDS - Make it Rain
				miniscore = selfstatdrop([0,0,1,0,0,0,0], score)
			when 0x217 # LAWDS - Scented Geyser incenses that cause it to drop SpA
				miniscore = selfstatdrop([0,0,2,0,0,0,0], score) if [:FULLINCENSE, :WAVEINCENSE].include?(@attacker.item)
			when 0x905 # Doodle
				miniscore = doodlecode()
			when 0x906 # Double Shock
				miniscore = doubleshockcode()
			when 0x907 # Dragon Cheer
				miniscore = dragoncheercode()
				# LAWDS Mod - added these field interactions. the logic here is probably wack but who cares
				if [:CONCERT1,:CONCERT2,:CONCERT3,:CONCERT4, :BIGTOP, :COLOSSEUM, :DRAGONSDEN].include?(@battle.FE)
					boosts = [1,0,1,0,0,0,0]
					boosts = [2,0,2,0,0,0,0] if @battle.FE == :DRAGONSDEN
					miniscore *= selfstatboost([1,0,1,0,0,0,0])
					miniscore *= focusenergycode()
					miniscore *= focusenergycode() if @attacker.hasType?(:DRAGON)
				end
			when 0x910 # Gen 9 Mod - Last Respects
				miniscore = (1.3 ** @attacker.pbFaintedPokemonCount)
			when 0x912 # Gen 9 Mod - Matcha Gotcha
				miniscore = absorbcode(initialscores[scoreindex])
				miniscore *= burncode()
			when 0x913 # Order Up
				statarray = [0,0,0,0,0,0,0]
				if @attacker.effects[:Commandee] && @attacker.pbPartner.effects[:Commander]
				  case @attacker.pbPartner.form
					when 0
					  statarray = [1,0,0,0,0,0,0]
					when 1
					  statarray = [0,1,0,0,0,0,0]
					when 2
					  statarray = [0,0,0,0,1,0,0]
				  end
				  if @attacker.ability== :CONTRARY
					miniscore = selfstatdrop(statarray,score)
				  else
					miniscore = selfstatboost(statarray)
				  end
				elsif [:UNDERWATER, :WATERSURFACE].include?(@battle.FE) # LAWDS - random boost on these fields
					if @attacker.ability== :CONTRARY
						miniscore += (selfstatdrop([1,0,0,0,0,0,0],score) + selfstatdrop([0,1,0,0,0,0,0],score) + selfstatdrop([0,0,0,0,1,0,0],score))/3
					else
						statcount = 0
						miniscore = 0
						if @attacker.pbCanIncreaseStatStage?(PBStats::ATTACK, false, :ORDERUP)
							statcount+=1
							miniscore += selfstatboost([1,0,0,0,0,0,0],score)
						end
						if @attacker.pbCanIncreaseStatStage?(PBStats::DEFENSE, false, :ORDERUP)
							statcount+=1
							miniscore += selfstatboost([0,1,0,0,0,0,0],score)
						end
						if @attacker.pbCanIncreaseStatStage?(PBStats::SPEED, false, :ORDERUP)
							statcount+=1
							miniscore += selfstatboost([0,0,0,0,1,0,0],score)
						end
						miniscore = miniscore/statcount if statcount>0
						miniscore = 1 if miniscore=0
					end
				end
			when 0x914 # Population Bomb
				miniscore = multihitcode() * 1.2 # More extreme scoring
			when 0x916 # Raging Bull
				miniscore = brickbreakcode()
			when 0x917 # Revival Blessing
				if @attacker.pbFaintedPokemonCount > 3
				  miniscore *= 4
				elsif @attacker.pbFaintedPokemonCount > 2
				  miniscore *= 3
				elsif @attacker.pbFaintedPokemonCount > 1
				  miniscore *= 2 
				elsif @attacker.pbFaintedPokemonCount > 0
				  miniscore *= 1
				else
				  miniscore = 0
				end
				miniscore *= 1.75 if @battle.FE == :HOLY # LAWDS - Revival blessing revives at full HP on blessed
			when 0x918 # Salt Cure
				miniscore = saltcurecode()
			when 0x919 # Shed Tail
				miniscore = shedtailcode()
			when 0x91A # Silk Trap
				miniscore = protecteffectcode()
			when 0x91C # Spicy Extract
				if @opponent.ability== :CONTRARY
				  miniscore = oppstatboost([0, 2, 0, 0, 0])
				  miniscore *= oppstatdrop([2, 0, 0, 0, 0, 0, 0])
				else
				  miniscore = oppstatboost([2, 0, 0, 0, 0])
				  miniscore *= oppstatdrop([0, 2, 0, 0, 0, 0, 0])
				end
			when 0x91D # Spin Out
				statarray = [0,0,0,0,2,0,0]
				if @attacker.ability== :CONTRARY
				  miniscore = selfstatboost(statarray)
				else
				  miniscore = selfstatdrop(statarray,score)
				end
			when 0x91E # Syrup Bomb - Simple ai only considering one turn, mirroring Octolock's implementation.
				miniscore = oppstatdrop([0,0,0,0,1,0,0])
			when 0x91F # Tachyon Cutter
				miniscore = nevermisscode(initialscores[scoreindex])
				miniscore+= multihitcode()
			when 0x921 # Tidy Up
				miniscore = tidyupcode()
				statarray = [1,0,0,0,1,0,0]
				miniscore += selfstatboost(statarray)
			when 0x922 # Triple Dive
				miniscore = multihitcode()
			when 0x923 # Upper Hand
				if (@opponent.ability== :GALEWINGS && (@opponent.hp == @opponent.totalhp || @battle.FE == :SKY)) || checkAIpriority()
				  miniscore = suckercode()
				else
				  miniscore = 0
				end
			when 0x901 # Lawds Mod - Gigaton Hammer, Blood Moon. Not currently ported to 19.5 codebase so here we are.
				miniscore = cooldownmovecode()
			when 0x10a # Brick Break, Psychic Fangs
				miniscore = brickbreakcode() if @battle.FE != :DARKCRYSTALCAVERN
			when 0x10b # Hi Jump Kick, Jump Kick
				miniscore = jumpcode(score)
				if @attacker.index != 2 && @mondata.skill>=BESTSKILL
					miniscore*= 0.5 if @battle.FE != :INVERSE && pbPartyHasType?(:GHOST, @opponent.index)
				end
			when 0x10c # Substitute
				miniscore=subcode()
			when 0x10d # Curse
				if @attacker.hasType?(:GHOST)
					miniscore = spoopycode()
					miniscore = 0 if @battle.FE == :HOLY
				else
					miniscore = selfstatboost([1,1,0,0,0,0,0])
					miniscore *= selfstatdrop([0,0,0,0,1,0,0],score)
				end
			when 0x10e # Spite
				score=spitecode(score)
			when 0x10f # Nightmare
				miniscore = nightmarecode()
				miniscore*=0 if @battle.FE == :RAINBOW
			when 0x110 # Rapid Spin
				score+=20 if @attacker.effects[:LeechSeed]>=0
				score+=10 if @attacker.effects[:MultiTurn]>0
				if @attacker.pbNonActivePokemonCount>0
					score+=25 if @attacker.pbOwnSide.effects[:StealthRock]
					score+=25 if @attacker.pbOwnSide.effects[:StickyWeb]
					score+= (10*@attacker.pbOwnSide.effects[:Spikes])
					score+= (15*@attacker.pbOwnSide.effects[:ToxicSpikes])
				end
				if @move.move == :RAPIDSPIN # lawds - added separate codes for rapid spin and mortal spin
					miniscore=selfstatboost([0,0,0,0,1,0,0])
				elsif @move.move == :MORTALSPIN
					miniscore=poisoncode
				end
			when 0x111 # Future Sight, Doom Desire
				miniscore = futurecode()
			when 0x112 # Stockpile
				if @attacker.effects[:Stockpile]<3
					miniscore = selfstatboost([1,1,0,0,0,0,0])
				else
					miniscore = 0
				end
			when 0x113 # Spit Up
				if @attacker.effects[:Stockpile]==0
					miniscore=0
				else
					miniscore=antistatcode([0,@attacker.effects[:Stockpile],0,0,@attacker.effects[:Stockpile],0,0],score)
					if @attacker.pbHasMove?(:SWALLOW) && @attacker.hp/(@attacker.totalhp.to_f) < 0.66
						miniscore*=0.8
						miniscore*=0.5 if @attacker.hp < 0.4*@attacker.totalhp
					end
				end
			when 0x114 # Swallow
				if @attacker.effects[:Stockpile]==0
					miniscore=0
				else
					miniscore = recovercode()
					miniscore*=selfstatdrop([0,@attacker.effects[:Stockpile],0,0,@attacker.effects[:Stockpile],0,0],score)
				end
			when 0x115 # Focus Punch
				miniscore = focuscode()
			when 0x116 # Sucker Punch
				# LAWDS new sucker punch
				return 0 if @attacker.effects[:SuckerPunch] || @opponent.ability==:FOREWARN
				miniscore = suckercode()
			when 0x117 # Follow Me, Rage Powder
				miniscore = followcode()
			when 0x118 # Gravity
				if @battle.FE != :DEEPEARTH
					miniscore = gravicode() 
					if @battle.state.effects[:Gravity]==0 && @mondata.skill>=BESTSKILL
						if @battle.FE == :NEWWORLD
							score*=2 if !@attacker.hasType?(:FLYING) && ![:LEVITATE,:SOLARDIOL,:LUNARIDOL].include?(@attacker.ability)
							score*=2 if @opponent.hasType?(:FLYING) || [:LEVITATE,:SOLARDIOL,:LUNARIDOL].include?(@opponent.ability)
							if pbPartyHasType?(:PSYCHIC) || pbPartyHasType?(:FAIRY) || pbPartyHasType?(:DARK)
								score*=2
								score*=2 if @attacker.hasType?(:PSYCHIC) || @attacker.hasType?(:FAIRY) || @attacker.hasType?(:DARK)
							end
						end
					end
				end
			when 0x119 # Magnet Rise
				miniscore = magnocode()
				miniscore*=1.3 if @mondata.skill>=BESTSKILL && (@battle.FE == :ELECTERRAIN || @battle.FE == :FACTORY || @battle.FE == :SHORTCIRCUIT || @battle.state.effects[:ELECTERRAIN] > 0)
			when 0x11a # Telekineis
				score = telecode()
			#when 0x11b # Sky Uppercut
			when 0x11c # Smack Down, Thousand Arrows
				miniscore = smackcode()
			when 0x11d # After You
				miniscore = afteryoucode()
				if @battle.opponent.is_a?(Array) && @battle.opponent.any? {|opp| opp.trainertype == :UMBNOEL } &&
					@battle.turncount == 1 && @opponent.index == @attacker.pbPartner.index
					score += 150
				end
			when 0x11e # Quash
				#we could technically have _some_ code for this
			when 0x11f # Trick Room
				miniscore = trcode()
				if @mondata.skill>=BESTSKILL
					miniscore*=1.5 if @battle.FE == :CHESS || @battle.FE == :NEWWORLD || @battle.FE == :PSYTERRAIN || (Rejuv && @battle.FE == :STARLIGHT) # Chess/New World/Psychic Terrain
				end
			when 0x120 # Ally Switch
				miniscore = dinglenugget()
			when 0x903 # Chilly Reception
				miniscore = pivotcode()
				weatherscore = weathercode()
				miniscore *= weatherscore if weatherscore > 1
			#when 0x121 # Foul Play
			#when 0x122 # Secret Sword, Psystrike, Psyshock
			when 0x123 # Synchronoise
				score=0 if !@opponent.hasType?(@attacker.type1) && (!@opponent.hasType?(@attacker.type2) || @attacker.type2.nil?)
			when 0x124 # Wonder Room
				miniscore = wondercode()
			when 0x125 # Last Resort
				miniscore = lastcode()
			when 0x126 # Shadow moves (basic)
				score*=1.2
			when 0x127 # Shadow Bolt
				miniscore = 1.2*paracode()
			when 0x128 # Shadow Fire
				miniscore = 1.2*burncode()
			when 0x129 # Shadow Chill
				miniscore = 1.2*freezecode()
			when 0x12a # Shadow Panic
				miniscore = 1.2*confucode()
			when 0x132 # Shadow Shed (like a hut or a tool shed, i presume.)
				miniscore = brickbreakcode() / brickbreakcode(@opponent)
			when 0x133 # King's Shield
				miniscore = protecteffectcode()
				# lawds - making aegislash AI better. this can be better but its fine
				if !pbAIfaster?() && @attacker.species == :AEGISLASH && @attacker.form==1 && !@battle.doublebattle
					# in singles, if we can kill with a priority move, then do so. otherwise just protect if we're slower
					should_protect = true
					if !checkAIpriority(nil,@opponent,true)
						for i in 0...4
							move = @attacker.moves[i]
							next if move==nil || move.basedamage==0
							if pbAIfaster?(move) && @initial_scores[i] >= 110
								should_protect = false
							end
						end
					end
					miniscore*=20 if should_protect && checkAIdamage >= @attacker.hp
				end
				
			when 0x134 # Electric Terrain
				miniscore = electricterraincode()
			when 0x135 # Grassy Terrain
				miniscore = grassyterraincode()
			when 0x136 # Misty Terrain
				miniscore = mistyterraincode()
			when 0x137 # Flying Press
				#score*=2 if opponent.effects[:Minimize] #handled in pbRoughDamage from now on
				miniscore = 0 if @battle.state.effects[:Gravity]!=0
			when 0x138 # Noble Roar, Tearful Look
				statarray = [1,0,1,0,0,0,0]
				statarray = [2,0,2,0,0,0,0] if @move.move==:NOBLEROAR && @mondata.skill >=BESTSKILL && (@battle.FE == :FAIRYTALE || @battle.FE == :DRAGONSDEN)
				miniscore=oppstatdrop(statarray)
			when 0x139 # Draining Kiss, Oblivion Wing
				miniscore=absorbcode(initialscores[scoreindex])
			when 0x13a # Aromatic Mist
				miniscore=arocode(PBStats::SPDEF)
			when 0x13b # Eerie Impulse
				statarray = [0,0,2,0,0,0,0]
				statarray = [0,0,3,0,0,0,0] if @mondata.skill >=BESTSKILL && @battle.FE == :ELECTERRAIN
				miniscore = oppstatdrop(statarray)
			when 0x13c # Belch
				miniscore=0 if !@attacker.pokemon.belch && @attacker.crested != :SWALOT
			when 0x13d # Parting Shot
				miniscore = pivotcode()
				statarray = [1,0,1,0,0,0,0]
				statarray = [1,0,1,0,1,0,0] if @mondata.skill >=BESTSKILL && @battle.FE == :FROZENDIMENSION
				statarray = [2,0,2,0,0,0,0] if @mondata.skill >=BESTSKILL && (@battle.ProgressiveFieldCheck(PBFields::CONCERT) || @battle.FE == :BACKALLEY)
				miniscore*=oppstatdrop(statarray)
				# Lawds Mod - Make Amber Incin spam parting shot if it can
				miniscore*=5 if !(@battle.pbIsWild?) && !(@battle.doublebattle) && (@battle.opponent.trainertype==:LEADER_AMBER) && !(@opponent.ability== :DEFIANT || @opponent.ability== :COMPETITIVE || @opponent.ability== :CLEARBODY)
			when 0x13e # Geomancy
				miniscore = weaselslashcode() if !(@mondata.skill>=BESTSKILL && @battle.FE == :STARLIGHT)
				miniscore *= selfstatboost([0,0,2,2,2,0,0])
				if @battle.FE == :NEWWORLD
					miniscore*=2 if !@attacker.isAirborne?
					miniscore*=2 if @opponent.isAirborne?
					if pbPartyHasType?(:PSYCHIC) || pbPartyHasType?(:FAIRY) || pbPartyHasType?(:DARK)
						miniscore*=2
						miniscore*=2 if @attacker.hasType?(:PSYCHIC) || @attacker.hasType?(:FAIRY) || @attacker.hasType?(:DARK)
					end
				end
			when 0x13f # Venom Drench
				if @opponent.status== :POISON || @battle.FE == :CORROSIVE || @battle.FE == :CORROSIVEMIST || @battle.FE == :WASTELAND || @battle.FE == :MURKWATERSURFACE
					miniscore = oppstatdrop([1,0,1,0,1,0,0]) 
				else
					miniscore = 0
				end
			when 0x140 # Spiky Shield
				miniscore = protecteffectcode()
			when 0x141 # Sticky Web
				if @battle.FE != :WASTELAND # Wasteland
					if !@attacker.pbOpposingSide.effects[:StickyWeb]
						miniscore = hazardcode
						miniscore*= 2 if @battle.FE == :FOREST
						if seedProtection?(@attacker) # LAWDS - encourage crawli to set webs with protection
							miniscore*= 2
							miniscore*= 3 if hasgreatmoves()
							# if you'll be faster than the opponent after setting webs and your protection wears off, then favor it even more since you'll probably be able to attack after
							miniscore*= 5 if pbAIfaster?() && @opponent.ability!=:SPEEDBOOST && !(@opponent.pbHasMove?(:TAILWIND) && @opponent.pbOwnSide.effects[:Tailwind]!=0)
						end
					else
						miniscore = 0
					end
				else
					miniscore=oppstatdrop([0,0,0,0,1,0,0])
				end
			when 0x142 # Topsy Turvy
				miniscore = 1
				# lawds if we killin, dont worry about their stat changes. the inversion of defense stages as is relevant for damage is accounted for in pbRoughDamage
				miniscore = turvycode() if !(Rejuv && @battle.FE==:DEEPEARTH && @initial_scores[@score_index] >= 110 && !(@opponent.pbHasMove?(:ENDURE) && @opponent.effects[:ProtectRate]==0))
				if !Rejuv && @battle.canChangeFE?(:INVERSE)
					for type in [@opponent.type1,@opponent.type2]
					  effcheck = PBTypes.twoTypeEff(type,@attacker.type1,@attacker.type2)
					  score*=2 if effcheck>4
					  score*=0.5 if effcheck!=0 && effcheck<4
					  score*=0.1 if effcheck==0
				  end
				  for type in [@attacker.type1, @attacker.type2]
					  effcheck = PBTypes.twoTypeEff(type,@opponent.type1,@opponent.type2)
					  score*=0.5 if effcheck>4
					  score*=2 if effcheck!=0 && effcheck<4
					  score*=3 if effcheck==0
				  end
			  end
			when 0x143 # Forest's Curse
				miniscore = opptypechangecode(:GRASS)
				miniscore *= spoopycode() if @battle.FE == :FOREST || @battle.FE == :FAIRYTALE || @battle.FE == :BEWITCHED
			when 0x144 # Trick or Treat
				miniscore = opptypechangecode(:GHOST)
			when 0x145 # Fairy Lock
				miniscore = fairylockcode()
			when 0x146 # Magnetic Flux
				if !(@attacker.ability== :PLUS || @attacker.ability== :MINUS || @attacker.pbPartner.ability== :PLUS || @attacker.pbPartner.ability== :MINUS)
					if Rejuv && @battle.FE == :ELECTERRAIN
						miniscore = selfstatboost([0,1,0,1,0,0,0])
					else
						miniscore=0
					end
				elsif @attacker.ability== :PLUS || @attacker.ability== :MINUS
					miniscore = selfstatboost([0,1,0,1,0,0,0])
					miniscore = selfstatboost([0,2,0,2,0,0,0]) if Rejuv && @battle.FE == :ELECTERRAIN
				elsif @attacker.pbPartner.stages[PBStats::SPDEF]!=6 && @attacker.pbPartner.stages[PBStats::DEFENSE]!=6
					miniscore=0.7
					miniscore*=1.3 if initialscores.length>0 && hasbadmoves(20)
					miniscore*=1.1 if @attacker.pbPartner.hp>@attacker.pbPartner.totalhp*0.75
					miniscore*=0.3 if @attacker.pbPartner.effects[:Yawn]>0 || @attacker.pbPartner.effects[:LeechSeed]>=0 || @attacker.pbPartner.effects[:Attract]>=0 || !@attacker.pbPartner.status.nil?
					miniscore*=0.3 if checkAImoves(PBStuff::PHASEMOVE)
					miniscore*=0.5 if @opponent.ability== :UNAWARE
					miniscore*=1.2 if hpGainPerTurn(@attacker.pbPartner)>1
				end 
				# lawds
				miniscore *= 2 if @battle.doublebattle && pbAIfaster?(@move) && @battle.FE==:ELECTERRAIN
			when 0x147 # Fell Stinger
				if @attacker.stages[PBStats::ATTACK]!=6 && score>=100
					miniscore = 2.0
					miniscore*=2 if pbAIfaster?(@move)
				end
			when 0x148 # Ion Deluge
				miniscore = electricterraincode()
				miniscore*= moveturnselectriccode(false,false)

			when 0x149 # Crafty Shield
				score = craftyshieldcode(score)

			when 0x150 # Flower Shield
				miniscore = arocode(PBStats::DEFENSE)
				score = flowershieldcode(score)

			when 0x151 # Rototiller
				miniscore = arocode(PBStats::ATTACK)
				score = rotocode(score)
			when 0x152 # Powder
				miniscore = powdercode()
			when 0x153 # Electrify
				miniscore = moveturnselectriccode(true,false)
				miniscore *= [opptypechangecode(:ELECTRIC),1].max if Rejuv && @battle.FE == :ELECTERRAIN
			when 0x154 # Mat Block
				if @attacker.turncount==0 && (pbAIfaster?() || pbAIfaster?(nil,nil,@attacker,@opponent.pbPartner))
					miniscore = protectcode()
					miniscore *= 1.3 if @battle.doublebattle
				else
					miniscore = 0
				end
			when 0x155 # Thousand Waves, Anchor Shot, Spirit Shackle
				miniscore = meanlookcode()
			when 0x157 # Hyperspace Hole
				miniscore = nevermisscode(initialscores[scoreindex])
				miniscore*=feintcode()
			when 0x159 # Hyperspace Fury
				if @attacker.species==:HOOPA && @attacker.form==1 # Hoopa-U
					miniscore = nevermisscode(initialscores[scoreindex])
					miniscore*=feintcode()
					if @attacker.ability== :CONTRARY
						miniscore *= selfstatboost([0,1,0,0,0,0,0])
					else
						miniscore*=selfstatdrop([0,1,0,0,0],score)
					end
				else
					score = 0
				end
			when 0x15b # Aurora Veil
				miniscore = screencode()
			when 0x15c # Baneful Bunker
				miniscore = protecteffectcode()
				if !@opponent.status.nil?
					miniscore*=0.8
				elsif @opponent.pbCanPoison?(false)
					miniscore*=1.3
					miniscore*=1.3 if @attacker.ability== :MERCILESS
					miniscore*=1.3 if @attacker.crested == :ARIADOS
					miniscore*=0.3 if @opponent.ability== :POISONHEAL
					miniscore*=0.3 if @opponent.crested == :ZANGOOSE
					miniscore*=0.7 if @opponent.ability== :TOXICBOOST
				end
			when 0x15d # Beak Blast
				miniscore = beakcode()
			when 0x15e # Burn Up
				miniscore = burnupcode()
			when 0x15f # Clanging Scales
				if @attacker.ability== :CONTRARY
					miniscore = selfstatboost([0,1,0,0,0,0,0])
				else
					miniscore = antistatcode([0,1,0,0,0],initialscores[scoreindex])
				end
			when 0x160 # Core Enforcer
				if !(PBStuff::FIXEDABILITIES).include?(@opponent.ability) && !@opponent.effects[:GastroAcid] && @opponent.effects[:Substitute]<=0
					miniscore = getAbilityDisruptScore(@attacker,@opponent)
					# Gen 9 Mod - Added Ability Shield
          			miniscore = 1 if (@mondata.oppitemworks && @opponent.item == :ABILITYSHIELD)
					miniscore*=1.3 if !pbAIfaster?(@move)
					miniscore*=1.3 if checkAIpriority()
					score*=miniscore if !pbAIfaster?(@move) || checkAIpriority()
				  end
			when 0x161 # First Impression
				score=0 if @attacker.turncount!=0
				miniscore = (score>=110) ? 1.3 : 1.0
				miniscore*=feintcode() if @battle.FE == :COLOSSEUM && score > 0
			when 0x162 # Floral Healing
				miniscore = healpulsecode()
				miniscore*=1.5 if @battle.FE == :GRASSY || @battle.FE == :FAIRYTALE || @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,3,5)
				miniscore*=0.2 if @attacker.status!=:POISON && (@battle.FE == :CORROSIVE || @battle.FE == :CORROSIVEMIST)
			when 0x163 # Gear Up
				if !(@attacker.ability== :PLUS || @attacker.ability== :MINUS || @attacker.pbPartner.ability== :PLUS || attacker.pbPartner.ability== :MINUS)
					miniscore=0
				elsif @attacker.ability== :PLUS || @attacker.ability== :MINUS
					miniscore = selfstatboost([1,0,0,1,0,0,0])
				else
					miniscore=1.0
					miniscore*=1.3 if initialscores.length>0 && hasbadmoves(20)
					miniscore*=1.1 if @attacker.pbPartner.hp>@attacker.pbPartner.totalhp*0.75
					miniscore*=0.3 if @attacker.pbPartner.effects[:Yawn]>0 || @attacker.pbPartner.effects[:LeechSeed]>=0 || @attacker.pbPartner.effects[:Attract]>=0 || !@attacker.pbPartner.status.nil?
					miniscore*=0.3 if checkAImoves(PBStuff::PHASEMOVE)
					miniscore*=0.5 if @opponent.ability== :UNAWARE
				end
			when 0x164 # Instruct
				if !@battle.doublebattle || @opponent.index!=@attacker.pbPartner.index || !@opponent.lastMoveUsedSketch.is_a?(Symbol)
					score=1
				else
					score*=instructcode()
					score=1 if @attacker.pbPartner.hp==0
				end
			when 0x165 # Laser Focus
				miniscore = permacritcode(initialscores[scoreindex])
			when 0x166 # Moongeist Beam, Sun Steel Strike
				miniscore = moldbreakeronalaser()
			when 0x167 # Pollen Puff
				if @opponent.index==@attacker.pbPartner.index
					score=15*healpulsecode()
					score=0 if @opponent.ability== :BULLETPROOF
				end
			when 0x168 # Psychic Terrain
				miniscore = psychicterraincode()
			when 0x169 # Purify
				miniscore = almostuselessmovecode()
			when 0x16b # Shell Trap
				miniscore = shelltrapcode()
			when 0x16c # Shore Up
				recoveramount = @attacker.totalhp/2.0
				recoveramount = @attacker.totalhp if @mondata.skill >= BESTSKILL && @battle.FE == :ASHENBEACH
				recoveramount = @attacker.totalhp*0.66 if @battle.pbWeather== :SANDSTORM || @mondata.skill >= BESTSKILL && @battle.FE == :DESERT
				miniscore = recovercode(recoveramount)
				miniscore*= selfstatboost([0,2,0,0,0,0,0]) if @attacker.ability==:WATERCOMPACTION && @mondata.skill >= BESTSKILL && (@battle.FE == :WATERSURFACE || @battle.FE == :MURKWATERSURFACE)
			when 0x16d # Sparkling Aria
				miniscore = (@opponent.status== :BURN && @opponent.ability != :SHIELDDUST && @opponent.item != :COVERTCLOAK) ? 0.6 : 1.0
			when 0x16e # Spectral Thief
				miniscore = spectralthiefcode()
			when 0x16f # Speed Swap
				miniscore=stupidmovecode()
			when 0x170 # Spotlight
				miniscore = spotlightcode()
			when 0x171 # Stomping Tantrum
				miniscore = 1.0
				miniscore*=0.8 if Rejuv && @battle.FE == :CHESS && @attacker.ability != :SHELLARMOR && @attacker.ability != :BATTLEARMOR
			when 0x172 # Strength Sap
				miniscore = recovercode()
				statarray = [1,0,0,0,0,0,0]
				statarray = [1,0,1,0,0,0,0] if @battle.FE == :BEWITCHED
				miniscore*=oppstatdrop(statarray)
			when 0x173 # Throat Chop
				miniscore = chopcode()
			when 0x174 # Toxic Thread
				miniscore = poisoncode()
				miniscore*=oppstatdrop([0,0,0,0,1,0,0])
			when 0x175 # Mind Blown/Steel beam
				miniscore = pussydeathcode(initialscores[scoreindex])
				miniscore = deathcode() if @battle.FE == :SHORTCIRCUIT && @move.move == :STEELBEAM
				if (@battle.FE == :MISTY || @battle.FE == :SWAMP) && @move.move == :MINDBLOWN
					miniscore*=0
				end
			when 0x176 # Photon Geyser
				miniscore = moldbreakeronalaser()
			when 0x177 # Plasma Fists
				miniscore = electricterraincode()
				miniscore*= moveturnselectriccode(false,true)
			when 0x179 # Snipe Shot
				if @battle.doublebattle																													# LAWDS - spirit's envoy
					if checkAImoves([:FOLLOWME,:RAGEPOWDER],getAIMemory(@opponent.pbPartner)) || checkAImoves([:SPOTLIGHT]) || [:STORMDRAIN,:LIGHTNINGROD,:SPIRITSENVOY].include?(@opponent.pbPartner.ability)
						miniscore=1.2
					end
				end
			when 0x17A # Stuff Cheeks
				if pbIsBerry?(@attacker.item)
					miniscore = selfstatboost([0,2,0,0,0,0,0])
					case @attacker.item
					when :LUMBERRY then miniscore*=2 if !@attacker.status.nil?
					when :CHERIBERRY then miniscore*=2 if @attacker.status == :PARALYSIS
					when :RAWSTBERRY then miniscore*=2 if @attacker.status == :BURN
					when :PECHABERRY then miniscore*=2 if @attacker.status == :POISON
					when :SITRUSBERRY, :FIGYBERRY, :WIKIBERRY, :MAGOBERRY, :AGUAVBERRY, :IAPAPABERRY then miniscore*=1.6 if @attacker.hp*(1.0/@attacker.totalhp)<0.66
					when :LIECHIBERRY then miniscore*=1.5 if @attacker.attack>@attacker.spatk
					when :PETAYABERRY then miniscore*=1.5 if @attacker.spatk>@attacker.attack
					when :APICOTBERRY,:GANLONBERRY,:STARFBERRY then miniscore*=1.5
					when :CUSTAPBERRY, :SALACBERRY then miniscore*= pbAIfaster? ? 1.1 : 1.5
					end
				else
					score*=0
				end
			when 0x17B # No Retreat # lawds removed no retreat's field interactions
				if !@attacker.effects[:NoRetreat]
					statarray = [1,1,1,1,1,0,0]
					miniscore = selfstatboost(statarray)
				else
					score*=0
				end
			when 0x17C # Tar Shot
				miniscore=oppstatdrop([0,0,0,0,1,0,0])
				if !@opponent.effects[:TarShot] && (PBTypes.twoTypeEff(:FIRE,@opponent.type1,@opponent.type2) != 0) && @opponent.ability != :FLASHFIRE
					if pbPartyHasType?(:FIRE)
						miniscore*=1.2 unless @battle.FE == :WATERSURFACE
					end
					miniscore*=1.2 if @battle.FE == :VOLCANIC || @battle.FE == :VOLCANICTOP
				end
				if @battle.FE == :MURKWATERSURFACE || @battle.FE == :CORRUPTED
					sidescore=poisoncode()
					miniscore*=sidescore if sidescore > 1
				end
			when 0x17D # Magic Powder
				miniscore = opptypechangecode(:PSYCHIC)
				sleepmult = sleepcode()
				miniscore*=[sleepmult,1].max if @battle.FE == :HAUNTED || @battle.FE == :BEWITCHED
			when 0x17E # Dragon Darts 	Lawds Mod - Dragon Darts is a simple two-hit single target attack for now
				#if !@battle.doublebattle || @move.pbDragonDartTargetting(@attacker).length < 2
					#miniscore = multihitcode()
				#else
					#miniscore = 1.2 if checkAImoves(PBStuff::PROTECTMOVE) || opponent.pbPartyHasType?(:FAIRY)
				#end
				miniscore = multihitcode()
			when 0x17F # teatime
				miniscore = teaslurpcode()
			when 0x180 # Octolock
				miniscore = firespincode()
				miniscore*= oppstatdrop([0,1,0,1,0,0,0])
			when 0x182 # Court Change
				miniscore = defogcode()
			when 0x183 # Clangorous Soul
				if @mondata.skill >= BESTSKILL && [:BIGTOP,:CONCERT1,:CONCERT2,:CONCERT3,:CONCERT4].include?(@battle.FE)
					statarray = [2,2,2,2,2,0,0] 
				else
					statarray = [1,1,1,1,1,0,0]
				end
				miniscore = selfstatboost(statarray) ** 1.2 #More extreme scoring
				miniscore *= 0.3 if !@attacker.moves.any?{|moveloop| moveloop!=nil && moveloop.basedamage > 0 && moveloop.pbIsPriorityMoveAI(@attacker)} && !pbAIfaster?()
				miniscore *= 1.2 if @attacker.turncount<1
				miniscore = 0 if (@attacker.hp.to_f)/@attacker.totalhp <= 0.333 || ((@mondata.skill >= BESTSKILL && [:BIGTOP,:CONCERT1,:CONCERT2,:CONCERT3,:CONCERT4].include?(@battle.FE)) && (@attacker.hp.to_f)/@attacker.totalhp <= 0.5) # LAWDS - why is this 1 and not 0
			when 0x185 # Decorate
				miniscore = 0 if @opponent.index!=@attacker.pbPartner.index
				miniscore = oppstatboost([2,0,2,0,0]) if @opponent.index==@attacker.pbPartner.index 
			when 0x186 # Aura Wheel
				miniscore = selfstatboost([0,0,0,0,1,0,0])
			when 0x187 # Life Dew
				recoveramount = @attacker.totalhp/4.0
				recoveramount = @attacker.totalhp/2.0 if @mondata.skill>=BESTSKILL && (@battle.FE == :RAINBOW || @battle.FE == :HOLY)
				miniscore = lifedewcode(recoveramount)
				miniscore *= 0.5 if @battle.FE == :CORROSIVEMIST && !@attacker.hasType?(:POISON) && !@attacker.hasType?(:STEEL) # self poisoning (provisonal, kind of a complex topic would like to invert poisoncode)
				miniscore *= aquaringcode() if @battle.FE == :WATERSURFACE
			when 0x188 # Obstruct
				miniscore = protecteffectcode()
			when 0x189 # Jaw Lock
				miniscore = meanlookcode()
			when 0x306 # Steel Roller	Lawds Mod: Ice Spinner
				# Lawds Mod - changed AI to reflect new functionality of these moves
				# Lawds Mod - don't try to disrupt the field if it's locked or if an overlay can't be removed
				miniscore = 1
				return 0 if @move == :STEELROLLER && (@battle.state.effects[:OVERLAYLOCK])
				overlayPresent = false
				if @battle.state.effects[:GRASSY] > 0 && @battle.state.effects[:GRASSY] < 100 
					terrain = :GRASSY
					overlayPresent = true
					miniscore *= getFieldDisruptScore(@attacker,@opponent,terrain) # Lawds Mod - acts like the overlay is the full field which isn't right but it's generally good for the AI to get rid of unfavorable terrain anyway
				end
				if @battle.state.effects[:PSYTERRAIN] > 0 && @battle.state.effects[:PSYTERRAIN] < 100
					terrain = :PSYTERRAIN
					overlayPresent = true
					miniscore *= getFieldDisruptScore(@attacker,@opponent,terrain)
				end
				if @battle.state.effects[:MISTY] > 0 && @battle.state.effects[:MISTY] < 100 
					terrain = :MISTY
					overlayPresent = true
					miniscore *= getFieldDisruptScore(@attacker,@opponent,terrain)
				end
				if @battle.state.effects[:ELECTERRAIN] > 0 && @battle.state.effects[:ELECTERRAIN] < 100 
					terrain = :ELECTERRAIN
					overlayPresent = true
					miniscore *= getFieldDisruptScore(@attacker,@opponent,terrain)
				end
				if @battle.state.effects[:FROZENDIMENSION] > 0 && @battle.state.effects[:FROZENDIMENSION] < 100 
					terrain = :FROZENDIMENSION
					overlayPresent = true
					miniscore *= getFieldDisruptScore(@attacker,@opponent,terrain)
				end
				return 0 if @move == :STEELROLLER && !overlayPresent
			when 0x307 # Scale Shot
				miniscore = multihitcode()
				miniscore *= selfstatboost([0,0,0,0,1,0,0])
				miniscore *= selfstatdrop([0,1,0,0,0,0,0],score)
			when 0x308 # Meteor Beam
				miniscore = selfstatboost([0,0,1,0,0,0,0])
				miniscore *= weaselslashcode() unless @battle.FE == :STARLIGHT || @battle.FE == :NEWWORLD
			when 0x309 # Shell Side Arm
				miniscore = poisoncode()
			when 0x313 # Burning Jealousy, # Gen 9 Mod - Alluring Voice
				miniscore = burncode() if (@opponent.effects[:Jealousy] || @battle.FE==:INFERNAL) && @move.move == :BURNINGJEALOUSY
				miniscore = confucode() if (@opponent.effects[:Jealousy]) && @move.move == :ALLURINGVOICE
			when 0x314 # Lash Out # lawds forget this
				#miniscore = 1.5 if (checkAImoves(PBStuff::STATNERFMOVE) && !pbAIfaster?()) && !@attacker.effects[:LashOut]
				# score is already higher from damage if lashout condition is fulfilled when turn starts (via intimidate etc)
			when 0x315 # Poltergeist
				miniscore = 0 if @opponent.item.nil?
			when 0x316 # Corrosive Gas
				miniscore = knockcode()
				miniscore *= oppstatdrop([1,1,1,1,1,0,0]) if [:BACKALLEY,:CITY].include?(@battle.FE)
			when 0x317 # Coaching
				miniscore = 0 if @opponent.index != @attacker.pbPartner.index
				miniscore = oppstatboost([1,1,0,0,0]) if @opponent.index == @attacker.pbPartner.index
			when 0x318 # Jungle Healing
				recoveramount = @attacker.totalhp/4.0
				miniscore = lifedewcode(recoveramount)
			when 0x319 # Surging Strikes
				miniscore = permacritcode(initialscores[scoreindex])
				miniscore *= multihitcode()
			when 0x322
				miniscore = multihitcode()
			when 0x320 # Eerie Spell
				miniscore = spitecode(score)
			# PLA moves
			when 0x500 # Dire Claw
				miniscore = (sleepcode() + poisoncode() + paracode()) / 3
			when 0x219 # LAWDS - Barbed Web
				miniscore = poisoncode()
			when 0x501 # Victory Dance
				statarray = [1,1,0,0,1,0,0]
				# lawds - dancer sky interaction
				statarray = [2,2,0,0,2,0,0] if @mondata.skill >= BESTSKILL && (@battle.FE == :BIGTOP || @battle.FE == :DANCEFLOOR || (@battle.FE == :SKY && @attacker.pbOwnSide.effects[:Tailwind] != 0 && @attacker.ability== :DANCER))
				miniscore = selfstatboost(statarray)
			when 0x502 # Barb Barrage
				miniscore = poisoncode()
			when 0x503 # Triple Arrows
				miniscore = oppstatdrop([0,1,0,0,0,0,0])
				miniscore *= flinchcode()
			when 0x504 # Infernal Parade
				miniscore = burncode()
			when 0x505 # Take Heart
				statarray = [0,0,1,1,0,0,0]
				statarray = [0,0,2,2,0,0,0] if @mondata.skill >= BESTSKILL && (@battle.FE == :WATERSURFACE || @battle.FE == :UNDERWATER)
				miniscore = selfstatboost(statarray)
				miniscore *= [refreshcode(),1].max
			# Gen 9 Moves
			when 0x506 # Axe Kick
				miniscore = jumpcode(score)
				if @attacker.index != 2 && @mondata.skill>=BESTSKILL
					miniscore*= 0.5 if @battle.FE != :INVERSE && pbPartyHasType?(:GHOST, @opponent.index)
				end
				miniscore *= confucode()
			# Rejuv Customs
			when 0x200 # Decimation
				miniscore = moldbreakeronalaser()
				miniscore *= petrifycode()
			when 0x201 # Gale Strike
				miniscore = permacritcode(initialscores[scoreindex]) if @attacker.hp<=((@attacker.totalhp)*0.5).floor
			when 0x202 # Fever Pitch
				miniscore = 1.0
				miniscore = 1.5 if @attacker.status == :SLEEP
				if @battle.FE == :VOLCANICTOP
					miniscore*=volcanoeruptioncode()
				end
				if @attacker.pbNonActivePokemonCount>0
					score+=50 if @attacker.pbOwnSide.effects[:StealthRock]
					score+=25 if @attacker.pbOwnSide.effects[:StickyWeb]
					score+= (10*@attacker.pbOwnSide.effects[:Spikes])
					score+= (15*@attacker.pbOwnSide.effects[:ToxicSpikes])
				end
			when 0x203 # Arenite Wall
				miniscore = screencode()
			#when 0x204 # Matrix shot # handled in damage calc
			when 0x205 # Desert's Mark
				miniscore = opptypechangecode(:GROUND)
				miniscore *= 1.3
				miniscore *= firespincode()
				miniscore *= 1.3 if (@battle.pbWeather == :SANDSTORM && @opponent.ability != :MAGICGUARD && (@opponent.hasType?(:ROCK) || @opponent.hasType?(:GROUND) || @opponent.hasType?(:STEEL) || [:SANDRUSH, :SANDVEIL, :SANDFORCE].include?(@opponent.ability))) # LAWDS - bonus score for removing sandstorm chip immunity
				# lawds make sure you're not opting out of kills
				miniscore *= 0.3 if hasgreatmoves() || (checkAIdamage(@opponent,@attacker) - (hpGainPerTurn(@opponent)-1)*@opponent.totalhp >= @opponent.hp && @opponent.moves.none? {|oppmove| [:COUNTER,:MIRRORCOAT,:METALBURST,:COMEUPPANCE].include?(oppmove.move)})
			#when 0x206 # Probopog # does this *need* AI?? i don't think it does
			when 0x207 # Aquabatics
				statarray = [0,0,1,0,1,0,0]
				statarray = [0,0,2,0,2,0,0] if @mondata.skill >= BESTSKILL && (@battle.FE == :BIGTOP)
				miniscore = selfstatboost(statarray)
			when 0x208 # Hexing Slash
				miniscore = absorbcode(initialscores[scoreindex])
				miniscore *= poisoncode()
			when 0x20A # Quicksilver Spear
				miniscore = oppstatdrop([0,0,0,0,1,0,0])
			when 0x20B #Spectral Scream
				# lawds spectral scream is no longer random
				defense = @attacker.defense
				spdef = @attacker.spdef
				stagemul=[2,2,2,2,2,2,2,3,4,5,6,7,8]
				stagediv=[8,7,6,5,4,3,2,2,2,2,2,2,2]
				defstage = @attacker.stages[PBStats::DEFENSE]+6
				spdefstage = @attacker.stages[PBStats::SPDEF]+6
				defense = defense*(stagemul[defstage]/stagediv[defstage])
				spdef = spdef*(stagemul[spdefstage]/stagediv[spdefstage])
				statarray = [0,0,0,1,0,0,0]
				statarray = [0,1,0,0,0,0,0] if spdef >= defense
				miniscore = selfstatboost(statarray)
			#when 0x20C # Gilded Arrow / Gilded Helix
			when 0x20D # Super Ultra Mega Death Move
				if @move.pbIsPhysical?()
					miniscore = oppstatdrop([0,1,0,0,0,0,0])
				else
					miniscore = oppstatdrop([0,0,0,1,0,0,0])
				end
			#Z-moves
			when 0x800 # Acid Downpour
				miniscore = (burncode() + paracode() + freezecode() + poisoncode()) / 4 if @battle.FE == :WASTELAND
			when 0x801 # Bloom Doom
				miniscore = grassyterraincode() unless @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN)
			when 0x802 # Shattered Psyche
				miniscore = confucode() if @battle.FE == :PSYTERRAIN
			when 0x803 # Stoked Sparksurfer
				miniscore = paracode()
				miniscore *= electricterraincode()
			when 0x804 # Extreme Evoboost
				miniscore = selfstatboost([2,2,2,2,2,0,0])
			when 0x805 # Genesis Supernova
				miniscore = psychicterraincode()
			when 0x807 # Splintered Stormshards
				miniscore = getFieldDisruptScore(@attacker,@opponent)
			when 0x808 # Clangorous Soulblaze
				miniscore = selfstatboost([1,1,1,1,1,0,0])
			when 0x80A # Unleashed Power
				miniscore = brickbreakcode()
				miniscore *= feintcode()
			when 0x80B # Blinding Speed
				miniscore = afteryoucode()
			when 0x80C # Elysian Shield
				miniscore = screencode()
				miniscore *= selfstatboost([0,1,0,1,0,0,0])
			when 0x80D # Domain Shift
				#help why is AI using this
			when 0x80E # Chthonic Malady
				miniscore = petrifycode()
				miniscore *= tormentcode()
				miniscore *= oppstatdrop([2,0,2,0,0,0,0])
		end
		score*=miniscore
		# Lawds - Spirit Eater makes phys moves heal
		if @attacker.ability==:SPIRITEATER && @move.pbIsPhysical?(@move.pbType(@attacker))
			score *= absorbcode(initialscores[scoreindex])
		end
		# LAWDS tough claws rocky
		if @battle.FE==:ROCKY && @attacker.ability==:TOUGHCLAWS && @move.contactMove? && @opponent.ability!=:STAMINA
			increment = @move.pbNumHits(@attacker)
			score *= oppstatdrop([0,increment,0,0,0,0,0])
		end
		# LAWDS - snatch fails past the first turn, and the AI disencourages snatchable moves only if snatch is actually possible 
		score*=0.05 if @move.canSnatch? && ((@opponent.pbHasMove?(:SNATCH) && @opponent.turncount == 0) || (@opponent.pbPartner.pbHasMove?(:SNATCH) && @opponent.pbPartner.turncount == 0))
		if @move.canMagicCoat? && @opponent.pbHasMove?(:MAGICCOAT) && @opponent.effects[:Taunt] <= 0 && @opponent.turncount==0 # LAWDS dont click moves into magic coat
			scoremult = @opponent.turncount<=1 ? 0.01 : 0.3
		end

		# LAWDS - playing around protean stuff + type change crests
		if (@opponent.ability==:PROTEAN || @opponent.ability==:LIBERO || [:GOTHITELLE,:REUNICLUS].include?(@opponent.crested)) && @battle.pbOwnedByPlayer?(@opponent.index)
			crestchecks = [:GOTHITELLE,:REUNICLUS].include?(@opponent.crested) ? @opponent.crested : nil
			resist = false
			immune = false
			typearray = []
			currentmod = pbTypeModNoMessages(@move.pbType(@attacker),@attacker,@opponent,@move)
			least_mod = currentmod
			least_dmg = [initial_scores[scoreindex],100].min
			for i in 0...4
				oppmove = @opponent.moves[i]
				next if oppmove==nil
				next if !@battle.pbCanChooseMove?(@opponent.index,i,false) # if they cant select the move, dw
				next if crestchecks==nil && pbAIfaster?(@move,oppmove) # for protean, if we can attack before they can use this move, dont worry about the type change

				if crestchecks==:REUNICLUS
					opptype = oppmove.pbIsPhysical?(oppmove.pbType(@opponent)) ? :FIGHTING : :PSYCHIC
					next if @opponent.hasType?(opptype)
				elsif crestchecks==:GOTHITELLE
					opptype = oppmove.pbType(@attacker)
					next if ![:DARK,:PSYCHIC].include?(opptype) || @opponent.hasType?(opptype)
				else
					opptype = oppmove.pbType(@opponent)
				end
				next if @opponent.type1==opptype && @opponent.type2==nil # skip moves that dont change type
				next if typearray.include?(opptype) # skip if we've already checked moves of this type
				oppdummy = pbCloneBattler(@opponent.index)
				oppdummy.type1 = opptype
				oppdummy.type2 = nil
				mod = pbTypeModNoMessages(@move.pbType(@attacker),@attacker,oppdummy)
				next if mod >= least_mod # if this isn't the worst modifier we've checked, then next
				selfdamage = pbRoughDamage(oppmove, @opponent, @attacker, false)
				next if (selfdamage >= @attacker.hp) # if they kill us, dont worry about it
				badmove = (selfdamage < @attacker.hp/2) # dont worry about your move getting resisted if they cant highly threaten us with theirs.
				badmove = (selfdamage < @attacker.hp/3) if @mondata.roles.include?(:TANK) || @mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL)
				if mod <= 0
					score*= 0.8
					if !badmove
						score*= 0.5
						immune = true
						break 
					end
				elsif !badmove
					if least_dmg >= 110
						dmg_with_resist = ((pbRoughDamage(@move,@attacker,oppdummy,false)/@opponent.hp) * 100).round
					else
						dmg_with_resist = least_dmg * mod/least_mod
					end
					least_dmg = dmg_with_resist if dmg_with_resist < least_dmg
					typearray.push(opptype)
				end
			end
			if !immune && resist
				percentdmg = least_dmg
				fraction = percentdmg/([@initial_scores[@score_index],100].min)
				multiplier = Math.sqrt(fraction)
				score = (score*fraction).round
			end
		end


		# LAWDS - playing around counter/mirror coat/metalburst

		has_counter_move = false
		noncounterdmg = 0
		# if we are a mon that can change our type to our move, get our typing after using our move so that we can see if we'd become a dark type to become immune to mirror coat, etc.
		attclone = pbCloneBattler(@attacker.index)
		attclone.type1 = @attacker.type1.clone
		attclone.type2 = @attacker.type2.clone
		if [:PROTEAN,:LIBERO].include?(@attacker.ability)
			attclone.type1 = @move.pbType(@attacker)
			attclone.type2 = nil
		end
		if @attacker.crested==:GOTHITELLE && [:DARK,:PSYCHIC].include?(@move.pbType(@attacker))
			attclone.type1 = @move.pbType(@attacker)
			attclone.type2 = nil
		end
		if @attacker.crested==:REUNICLUS && @move.basedamage > 0
			attclone.type1 = @move.pbIsPhysical?(@move.pbType(@attacker)) ? :FIGHTING : :PSYCHIC
			attclone.type2 = nil
		end
		for oppmove in @opponent.moves #this initial loop is used to check for a counter move and get the highest non-counter move damage so we can skip the rigamarole if they don't
			next if !@battle.pbCanChooseMove?(@opponent.index,@opponent.moves.index(oppmove),false)
			next if oppmove.category==:status
			if (oppmove.function == 0x071 && @move.pbIsPhysical?(@move.pbType(@attacker))) || 
			   (oppmove.function == 0x072 && @move.pbIsSpecial?(@move.pbType(@attacker))) || 
			   (oppmove.function == 0x073 && @move.basedamage > 0)
				
				next if pbTypeModNoMessages(oppmove.pbType(@opponent),@opponent,attclone,oppmove)<=0
				has_counter_move = true 
				next
			end
			thisdamage = @aimondata[@opponent.index].roughdamagearray[@attacker.index][@opponent.moves.index(oppmove)]
			noncounterdmg = thisdamage if thisdamage > noncounterdmg
		end
		# if our move is a counter move, then assume it can't be countered. but i'd never give the enemy a counter move except on some absurd trapping set
		if has_counter_move && ![0x071, 0x072, 0x073].include?(@move.function) && (initialscores[scoreindex] < 100)  && noncounterdmg < 100 && !@battle.pbOwnedByPlayer?(@attacker.index) # dont score the player's moves using this logic.
			#cprint "Opponent has a counter-attacking move that can counter the move #{@move.name}\n"
			checkdamage = @move.basedamage > 0 ? ((@initial_scores[@score_index]) * @opponent.hp).to_f/100.0 : 0
			highestdamage = checkAIdamage(@opponent,@attacker)
			# take recoil into account. should also take hp recovery (drain moves/shell bell) into account but dont wanna code that rn
			selfrecoil = 0
			if [0xFA,0xFD,0xFE].include?(@move.function)
				recoilamt = @move.hasFlag?(:recoil)
				selfrecoil = checkdamage*recoilamt
				selfrecoil = 0 if [:MAGICGUARD,:ROCKHEAD].include?(@attacker.ability) || @attacker.crested == :RAMPARDOS
			end
			selfrecoil += checkdamage/2 if @opponent.crested == :BASTIODON
			selfrecoil += @attacker.totalhp/10 if @attacker.hasWorkingItem(:LIFEORB) && !(@attacker.ability== :MAGICGUARD || (@attacker.ability== :SHEERFORCE && @move.effect > 0))
			hpAfterAttack = @attacker.hp - selfrecoil
			hpAfterAttack = 0 if hpAfterAttack < 0
			maxoppdamage = 0
			max_opp_noncounter_dmg = 0
			selfdamage = 0
			non_counter_move_kills = false
			counter_move_kills = false

			for thismove in @opponent.moves
				# because we need to consider recoil, we check if the attacker cannot be OHKOd at the top of the loop
				no_OHKO = notOHKO?(@attacker,@opponent,false,thismove) && (selfrecoil == 0 || (@attacker.crested == :RAMPARDOS && !@attacker.damagestate[:rampCrestUsed]) || (@attacker.ability== :RESUSCITATION && @attacker.form == 1))
				
				if checkdamage > 0 && (thismove.function == 0x071 && @move.pbIsPhysical?(@move.pbType(@attacker))) || (thismove.function == 0x072 && @move.pbIsSpecial?(@move.pbType(@attacker))) || (thismove.function == 0x073 && @move.basedamage > 1)
					if thismove.function == 0x073
						thisdamage = checkdamage * 1.5
					else
						thisdamage = checkdamage * 2
					end
					if thisdamage > selfdamage
						# only look at the most damaging counter move if there is more than one (i.e. counter and metal burst on the same pokemon)
						selfdamage = thisdamage
					else
						next 
					end
					# take into account that only the last hit of a multihit move gets countered. could expand to include other multihit mechanics like parental bond
					selfdamage=(selfdamage/@move.pbNumHits(@attacker)).floor if @move.pbNumHits(@attacker) > 1
					selfdamage=(selfdamage*0.2).floor if @attacker.ability==:PARENTALBOND
					selfdamage=(selfdamage*0.2308).floor if @attacker.crested==:TYPHLOSION && @move.contactMove?
					selfdamage=(selfdamage/5) if @attacker.crested==:CINCCINO && @attacker.ability==:SKILLLINK
					selfdamage=(selfdamage/4) if @attacker.crested==:LEDIAN && @move.punchMove?
					selfdamage=(selfdamage*0.1666).floor if @attacker.ability==:DREADNOUGHT && @move.pbIsSpecial?(@move.pbType(@attacker))
					# limit damage according to hp and ohko-preventing effects. this might be redundant but better safe than sorry
					selfdamage = hpAfterAttack if selfdamage >= hpAfterAttack
					selfdamage = (hpAfterAttack - 1) if no_OHKO && selfdamage >= hpAfterAttack
					maxoppdamage = selfdamage if selfdamage > maxoppdamage
					if selfdamage >= hpAfterAttack && !no_OHKO
						counter_move_kills = true
					end
				elsif thismove.basedamage > 0
					oppdamage = pbRoughDamage(thismove,@opponent,@attacker,false)
					# limit damage according to hp and ohko-preventing effects. this might be redundant but better safe than sorry
					oppdamage = hpAfterAttack if oppdamage >= hpAfterAttack
					oppdamage = (hpAfterAttack - 1) if no_OHKO && oppdamage >= hpAfterAttack
					maxoppdamage = oppdamage if oppdamage > maxoppdamage
					max_opp_noncounter_dmg = oppdamage if oppdamage > max_opp_noncounter_dmg
					non_counter_move_kills = true if no_OHKO && oppdamage >= hpAfterAttack
				end
			end
			if selfdamage > (max_opp_noncounter_dmg*1.2)
				# don't use this move if the resulting counter outdamages everything else and they can't kill you otherwise
				if !non_counter_move_kills
					score*=0.6
					# if the counter would kill, then DEFINITELY don't use it
					score*=0.5 if counter_move_kills
				end
			elsif !counter_move_kills && !non_counter_move_kills && (selfdamage*1.2) < max_opp_noncounter_dmg
				# if using this move would let you avoid taking significant counter damage and then KO on the next turn, then use it if you can't KO with any move on this turn
				if highestdamage >= (@opponent.hp - checkdamage) && highestdamage < @opponent.hp
					if miniscore >= 1 # add to score only if the miniscoring isnt shit
						score+=40 
						score+=40 if selfdamage < hpAfterAttack/2
					end
				end
			end
		end
		# LAWDS - end playing around counter/mirror coat/metalburst

		score=score.to_i
		score=0 if score<0
		$ai_log_data[@attacker.index].final_score_moves.push(score)
		return score
	end
######################################################
# Function (code) subfunctions
######################################################
#All functions here return a modifier to the original score, similar to miniscore
	def sleepcode
		return @move.basedamage > 0 ? 1 : 0 if !(@opponent.pbCanSleep?(false) && @opponent.effects[:Yawn]==0)
		return @move.basedamage > 0 ? 1 : 0 if secondaryEffectNegated?()
		return @move.basedamage > 0 ? 1 : 0 if hydrationCheck(@opponent)
		return @move.basedamage > 0 ? 1 : 0 if @move.move == :DARKVOID && !(attacker.species == :DARKRAI || (attacker.species == :HYPNO && attacker.form == 1))
		miniscore = 1.2
		if @attacker.pbHasMove?(:DREAMEATER) || @attacker.pbHasMove?(:NIGHTMARE) || @attacker.ability== :BADDREAMS
			miniscore *= 1.5
		end
		# Lawds Mod - Night Terror stuff
		if @attacker.ability== :NIGHTTERROR
			# we're night terror guys, of course we love spamming sleep
			miniscore *= (3 + selfstatboost([0,0,0,0,1,0,0]))
		end

		# UNTESTED BUT SHOULD WORK FINE????
		if @opponent.pbPartner.ability== :NIGHTTERROR && !(@opponent.pbPartner.isFainted?) #take into account that their partner will get a speed boost if you put them to sleep
			if @opponent.pbPartner.stages[PBStats::SPEED] == 0 && (@opponent.pbPartner.pbSpeed * 1.5 > @attacker.pbSpeed) # if they outspeed you after a boost then dont sleep
				miniscore*=0.5
				miniscore*=0.2 if (checkAIdamage(@attacker, @opponent.pbPartner) > @attacker.totalhp/2) # if they're an offensive threat, then DEFINITELY don't give them a speed boost
			end
		end
		# End of Night Terror Stuff
		
		miniscore*=(1.2*hpGainPerTurn)
		miniscore*=2 if (attacker.species == :HYPNO && attacker.form == 1)
		miniscore*=1.3 if @attacker.moves.any? {|moveloop| moveloop!=nil && (PBStuff::SETUPMOVE).include?(moveloop.move)}
		miniscore*=1.3 if @attacker.pbHasMove?(:LEECHSEED)
		miniscore*=1.3 if @attacker.pbHasMove?(:SUBSTITUTE)
		miniscore*=1.5 if @attacker.pbHasMove?(:DREAMREAPER)
		miniscore*=1.2 if @opponent.hp==@opponent.totalhp
		miniscore*=0.5 if checkAImoves([:SLEEPTALK,:SNORE]) # LAWDS - reduced the score penalties here
		miniscore*=0.3 if @opponent.ability== :NATURALCURE
		miniscore*=0.8 if @opponent.ability== :MARVELSCALE
		miniscore*=0.5 if @opponent.ability== :SYNCHRONIZE && @attacker.pbCanSleep?(false)
		miniscore*=0.4 if @opponent.effects[:Confusion]>0
		miniscore*=0.5 if @opponent.effects[:Attract]>=0
		ministat = statchangecounter(@opponent,1,7)
		miniscore*= 1 + 0.1*ministat if ministat>0
		if @mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL) || @mondata.roles.include?(:CLERIC) || @mondata.roles.include?(:PIVOT)
			miniscore*=1.2
		end
		if @initial_scores.length>0
			miniscore*=1.3 if hasbadmoves(40)
			miniscore*=1.5 if hasbadmoves(20)
		end
		miniscore = pbSereneGraceCheck(miniscore) if @move.basedamage>0
		miniscore = pbReduceWhenKills(miniscore)
		return miniscore
	end

	def poisoncode
		return @move.basedamage > 0 ? 1 : 0 if !@opponent.pbCanPoison?(false,false,@move.move==:TOXIC && @attacker.ability==:CORROSION)
		return @move.basedamage > 0 ? 1 : 0 if hydrationCheck(@opponent)
		return @move.basedamage > 0 ? 1 : 0 if secondaryEffectNegated?()
		miniscore=1.2
		ministat=0
		ministat+=@opponent.stages[PBStats::DEFENSE]
		ministat+=@opponent.stages[PBStats::SPDEF]
		ministat+=@opponent.stages[PBStats::EVASION]
		miniscore*=1+0.05*ministat if ministat>0
		miniscore*=2 if @move.function == 0x06 && checkAIhealing()
		miniscore*=0.3 if @opponent.ability== :NATURALCURE
		miniscore*=0.7 if @opponent.ability== :MARVELSCALE
		miniscore*=0.2 if @opponent.ability== :TOXICBOOST || @opponent.ability== :GUTS || @opponent.ability== :QUICKFEET
		miniscore*=0.1 if @opponent.ability== :POISONHEAL || @opponent.crested == :ZANGOOSE || @opponent.ability== :MAGICGUARD || (@opponent.ability== :WONDERGUARD && @battle.FE == :COLOSSEUM)
		miniscore*=0.7 if @opponent.ability== :SHEDSKIN
		miniscore*=1.1 if (@opponent.ability== :STURDY || (@battle.FE == :CHESS && @opponent.pokemon.piece==:PAWN) || (@battle.FE == :COLOSSEUM && @opponent.ability== :STALWART)) && @move.basedamage>0
		miniscore*=0.5 if @opponent.ability== :SYNCHRONIZE && @attacker.status.nil? && !@attacker.hasType?(:POISON) && !@attacker.hasType?(:STEEL)
		if checkAImoves([:FACADE])
			facade = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(:FACADE),@opponent)
			damage = pbRoughDamage(facade, @opponent, @attacker,false)
			aiDamage = checkAIdamage()
			miniscore*= 0.2 if damage > @attacker.hp/5 && damage > aiDamage && aiDamage < @attacker.hp
		end
		miniscore*=0.1 if checkAImoves([:REST])
		miniscore*=1.5 if @mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL)
		if @initial_scores.length>0
			miniscore*=1.2 if hasbadmoves(30)
		end
		if @attacker.pbHasMove?(:VENOSHOCK) || @attacker.pbHasMove?(:BARBBARRAGE) || @attacker.pbHasMove?(:NERVEPINCH) || @attacker.pbHasMove?(:VENOMDRENCH) || @attacker.ability== :MERCILESS || (@attacker.crested == :ARIADOS && @opponent.stages[PBStats::SPEED] > -1)
			miniscore*=1.6
		end
		miniscore*=0.4 if @opponent.effects[:Yawn]>0
		miniscore = pbSereneGraceCheck(miniscore) if @move.basedamage>0
		miniscore = pbReduceWhenKills(miniscore)
		miniscore*=2 if (@attacker.ability==:STALL || @opponent.ability==:STALL || @attacker.pbPartner.ability==:STALL) && miniscore > 1 # lawds stall
		return miniscore
	end

	def paracode
		return @move.basedamage > 0 ? 1 : 0 if !@opponent.pbCanParalyze?(false)
		return @move.basedamage > 0 ? 1 : 0 if hydrationCheck(@opponent)
		return @move.basedamage > 0 ? 1 : 0 if secondaryEffectNegated?()
		return @move.basedamage > 0 ? 1 : 0 if @move.move==:THUNDERWAVE && @move.pbTypeModifier(@move.pbType(@attacker),@attacker,@opponent,false,true)==0
		miniscore=1.0
		miniscore*=1.1 if @attacker.moves.any? {|moveloop| moveloop!=nil && (PBStuff::SETUPMOVE).include?(moveloop.move)}
		miniscore*=1.2 if @opponent.hp==@opponent.totalhp
		ministat= @opponent.stages[PBStats::ATTACK] + @opponent.stages[PBStats::SPATK] + @opponent.stages[PBStats::SPEED]
		miniscore*=1+0.05*ministat if ministat>0
		miniscore*=0.3 if @opponent.ability== :NATURALCURE
		miniscore*=0.5 if @opponent.ability== :MARVELSCALE
		miniscore*=0.2 if @opponent.ability== :GUTS || @opponent.ability== :QUICKFEET
		miniscore*=0.7 if @opponent.ability== :SHEDSKIN
		miniscore*=0.5 if @opponent.ability== :SYNCHRONIZE && @attacker.pbCanParalyze?(false)
		miniscore*=1.2 if @mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL) || @mondata.roles.include?(:PIVOT)
		miniscore*=1.3 if @mondata.roles.include?(:TANK)
		if !pbAIfaster?() && (pbRoughStat(@opponent,PBStats::SPEED)/2.0)<@attacker.pbSpeed && @battle.trickroom==0
			miniscore*=1.2
		elsif pbAIfaster?() && (pbRoughStat(@opponent,PBStats::SPEED)/2.0)<@attacker.pbSpeed && @battle.trickroom>1
			miniscore*=0.7
		end
		if pbRoughStat(@opponent,PBStats::SPATK)>pbRoughStat(@opponent,PBStats::ATTACK)
			miniscore*=1.1
		end
		miniscore*=1.1 if @mondata.partyroles.any? {|roles| roles.include?(:SWEEPER)}
		miniscore*=1.1 if @opponent.effects[:Confusion]>0
		miniscore*=1.1 if @opponent.effects[:Attract]>=0
		miniscore*=0.4 if @opponent.effects[:Yawn]>0
		miniscore = pbSereneGraceCheck(miniscore) if @move.basedamage>0
		miniscore = pbReduceWhenKills(miniscore)
		if !pbAIfaster?() && (pbRoughStat(@opponent,PBStats::SPEED)/2.0)<@attacker.pbSpeed && @battle.trickroom==0
			if hasbadmoves(40)
				# Gen 9 Mod - Added Covert Cloak
				miniscore+=25 if @move.effect == 100 && !@opponent.item == :COVERTCLOAK # help nuzzle
			end
		end
		return miniscore
	end

	def burncode
		return @move.basedamage > 0 ? 1 : 0 if !@opponent.pbCanBurn?(false)
		return 0 if (@move.pbType(@attacker)==:FIRE || @move.getSecondaryType(@attacker)==:FIRE) && ((@opponent.ability==:WELLBAKEDBODY && !moldBreakerCheck(@attacker,@move)) || @opponent.crested==:DRUDDIGON) # LAWDS - hopeful fix to AI clicking will-o-wisp on well-baked and druddigon
		return @move.basedamage > 0 ? 1 : 0 if hydrationCheck(@opponent)
		return @move.basedamage > 0 ? 1 : 0 if secondaryEffectNegated?()
		miniscore=1.2
		ministat=0
		ministat+=@opponent.stages[PBStats::ATTACK]
		ministat+=@opponent.stages[PBStats::SPATK]
		ministat+=@opponent.stages[PBStats::SPEED]
		miniscore*=1+0.05*ministat if ministat>0
		miniscore*=0.3 if @opponent.ability== :NATURALCURE
		miniscore*=0.7 if @opponent.ability== :MARVELSCALE
		miniscore*=0.1 if @opponent.ability== :GUTS || @opponent.ability== :FLAREBOOST
		miniscore*=0.7 if @opponent.ability== :SHEDSKIN
		miniscore*=0.5 if @opponent.ability== :SYNCHRONIZE && @attacker.pbCanBurn?(false)
		miniscore*=0.5 if @opponent.ability== :MAGICGUARD || (@opponent.ability== :WONDERGUARD && @battle.FE == :COLOSSEUM)
		miniscore*=0.3 if @opponent.ability== :QUICKFEET
		miniscore*=1.1 if (@opponent.ability== :STURDY || (@battle.FE == :CHESS && @opponent.pokemon.piece==:PAWN) || (@battle.FE == :COLOSSEUM && @opponent.ability== :STALWART)) && @move.basedamage>0
		miniscore*=0.1 if checkAImoves([:REST])
		if [:MULTISCALE,:SHADOWSHIELD,:TERASHELL].include?(@opponent.ability) && !hasgreatmoves && @opponent.ability!=:MAGICGUARD
			hpgain = hpGainPerTurn(@opponent,true)
			miniscore*=1.3 if hpgain >= 0 && hpgain < 0.0625
		end
		if checkAImoves([:FACADE])
			facade = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(:FACADE),@opponent)
			damage = pbRoughDamage(facade, @opponent, @attacker,false)
			aiDamage = checkAIdamage()
			miniscore*= 0.3 if damage > @attacker.hp/5 && damage > aiDamage && aiDamage < @attacker.hp
		end
		# LAWDS - playing around sturdy and non-OHKO stuff
		if notOHKO?(@opponent, @attacker) && @move.basedamage > 0 && @move.move != :FAKEOUT && (checkAIdamage() > @attacker.hp) # LAWDS - playing around sturdy/non-ohko stuff
			miniscore*=2
			miniscore*=5 if !(@battle.doublebattle) || @opponent.pbPartner.isFainted?
		end
		if pbRoughStat(@opponent,PBStats::ATTACK)>pbRoughStat(@opponent,PBStats::SPATK)
			miniscore*=1.4
		end
		miniscore*=0.4 if @opponent.effects[:Yawn]>0
		miniscore = pbSereneGraceCheck(miniscore) if @move.basedamage>0
		miniscore = pbReduceWhenKills(miniscore)
		miniscore*=2 if (@attacker.ability==:STALL || @opponent.ability==:STALL || @attacker.pbPartner.ability==:STALL) && miniscore > 1 # lawds
		return miniscore
	end

	def freezecode
		return @move.basedamage > 0 ? 1 : 0 if !@opponent.pbCanFreeze?(false)
		return @move.basedamage > 0 ? 1 : 0 if hydrationCheck(@opponent)
		return @move.basedamage > 0 ? 1 : 0 if secondaryEffectNegated?()
		miniscore=1.2
		miniscore*=0 if checkAImoves(PBStuff::UNFREEZEMOVE)
		miniscore*=1.2 if @attacker.moves.any? {|moveloop| moveloop!=nil && (PBStuff::SETUPMOVE).include?(moveloop.move)}
		miniscore*=1.2 if checkAIhealing()
		ministat = statchangecounter(@opponent,1,7)
		miniscore*=1+0.05*ministat if ministat>0
		miniscore*=0.3 if @opponent.ability== :NATURALCURE
		miniscore*=0.8 if @opponent.ability== :MARVELSCALE
		miniscore*=0.5 if @opponent.ability== :SYNCHRONIZE && @attacker.pbCanFreeze?(false)
		miniscore = pbSereneGraceCheck(miniscore) if @move.basedamage>0
		miniscore = pbReduceWhenKills(miniscore)
		return miniscore
	end

	def petrifycode
		return @move.basedamage > 0 ? 1 : 0 if !@opponent.pbCanPetrify?(false)
		return @move.basedamage > 0 ? 1 : 0 if hydrationCheck(@opponent)
		return @move.basedamage > 0 ? 1 : 0 if secondaryEffectNegated?()
		return @move.basedamage > 0 ? 1 : 0 if @opponent.ability== :LIQUIDOOZE
		miniscore=1.2
		miniscore*=1.2 if (@mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL) || @mondata.roles.include?(:TANK))
		miniscore*=1.3 if @attacker.effects[:Substitute]>0
		miniscore*=1.2 if hpGainPerTurn(@opponent)>1 || (@mondata.attitemworks && @attacker.item == :BIGROOT) || @attacker.crested == :SHIINOTIC
		miniscore*=0 if @opponent.ability== :LIQUIDOOZE
		miniscore*=0.3 if @opponent.ability== :NATURALCURE
		miniscore*=0.7 if @opponent.ability== :MARVELSCALE
		miniscore*=0.1 if @opponent.ability== :GUTS 
		miniscore*=0.7 if @opponent.ability== :SHEDSKIN
		miniscore*=0.5 if @opponent.ability== :SYNCHRONIZE && @attacker.pbCanPetrify?(false)
		miniscore*=0.5 if @opponent.ability== :MAGICGUARD || (@opponent.ability== :WONDERGUARD && @battle.FE == :COLOSSEUM)
		miniscore*=0.3 if @opponent.ability== :QUICKFEET
		miniscore*=1.1 if (@opponent.ability== :STURDY || (@battle.FE == :CHESS && @opponent.pokemon.piece==:PAWN) || (@battle.FE == :COLOSSEUM && @opponent.ability== :STALWART)) && @move.basedamage>0
		miniscore*=0.1 if checkAImoves([:REST])
		if checkAImoves([:FACADE])
			facade = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(:FACADE),@opponent)
			damage = pbRoughDamage(facade, @opponent, @attacker,false)
			aiDamage = checkAIdamage()
			miniscore*= 0.3 if damage > @attacker.hp/5 && damage > aiDamage && aiDamage < @attacker.hp
		end
		return miniscore
	end

	def flinchcode
		return @move.basedamage > 0 ? 1 : 0 if @opponent.effects[:Substitute] > 0 || @opponent.ability== :INNERFOCUS || secondaryEffectNegated?() || @opponent.effects[:FlinchCooldown] > 0
		return @move.basedamage > 0 ? 1 : 0 if !pbAIfaster?(@move)
		miniscore = 1.0
		miniscore*= 1.3 if !hasgreatmoves()
		miniscore*= 1.3 if @battle.trickroom > 0 && @attacker.pbSpeed > pbRoughStat(@opponent,PBStats::SPEED)
		miniscore*= 1.3 if @battle.field.duration > 0 && getFieldDisruptScore(@attacker,@opponent) > 1.0
		miniscore*= 1.3 if @attacker.pbOpposingSide.screenActive?
		miniscore*= 1.2 if @attacker.pbOpposingSide.effects[:Tailwind] > 0
		# Gen 9 Mod - Hail/Snow/Both consider HAIL only when it is damaging
		if @opponent.status== :POISON || @opponent.status== :BURN || (@battle.pbWeather == :HAIL && !@opponent.hasType?(:ICE)) || (@battle.pbWeather == :SANDSTORM && !@opponent.hasType?(:ROCK) && !@opponent.hasType?(:GROUND) && !@opponent.hasType?(:STEEL)) || (@battle.pbWeather == :SHADOWSKY && !@opponent.hasType?(:SHADOW)) || @opponent.effects[:LeechSeed]>-1 || @opponent.effects[:Curse] || @opponent.effects[:SaltCure]
			miniscore*=1.1
			miniscore*=1.2 if @opponent.effects[:Toxic]>0 && (@opponent.ability != :POISONHEAL || @opponent.ability != :MAGICGUARD || @opponent.crested != :ZANGOOSE) # Gen 9 Mod - Checks for abilities, Crest
			# Gen 9 Mod - Additions for Salt Cure since it does even more damage than burn/weather.
			miniscore*=1.1 if @opponent.effects[:SaltCure] && @opponent.ability != :MAGICGUARD
			miniscore*=1.2 if @opponent.effects[:SaltCure] && @opponent.ability != :MAGICGUARD && (@opponent.hasType?(:WATER) || @opponent.hasType?(:STEEL))
		end
		miniscore*=0.3 if @opponent.ability== :STEADFAST
		if @mondata.skill >= BESTSKILL
			miniscore*=1.1 if @battle.FE == :ROCKY # Rocky
		end
		miniscore = pbSereneGraceCheck(miniscore) if @move.basedamage>0
		miniscore = pbReduceWhenKills(miniscore)
		return miniscore
	end

	def thunderboostcode
		miniscore = 1.0
		invulmove=$cache.moves[@opponent.effects[:TwoTurnAttack]].function rescue nil
		if invulmove==0xC9 || invulmove==0xCC || invulmove==0xCE
			miniscore*=2 if pbAIfaster?()
		end
		if !pbAIfaster?()
			miniscore*=1.2 if checkAImoves(PBStuff::TWOTURNAIRMOVE)
		end
		return miniscore
	end

	def confucode
		return @move.basedamage > 0 ? 1 : 0 if !@opponent.pbCanConfuse?(false)
		return @move.basedamage > 0 ? 1 : 0 if secondaryEffectNegated?()
		miniscore=1.0
		miniscore*=1.2 if !hasgreatmoves()
		miniscore*=1+0.1*@opponent.stages[PBStats::ATTACK] if @opponent.stages[PBStats::ATTACK] > 0
		if pbRoughStat(@opponent,PBStats::ATTACK)>pbRoughStat(@opponent,PBStats::SPATK)
			miniscore*=1.2
		end
		miniscore*=1.3 if @mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL)
		miniscore*=1.1 if @opponent.effects[:Attract]>=0
		miniscore*=1.1 if @opponent.status == :PARALYSIS
		miniscore*=0.7 if @opponent.ability== :TANGLEDFEET
		if @attacker.pbHasMove?(:SUBSTITUTE)
			miniscore*=1.2
			miniscore*=1.3 if @attacker.effects[:Substitute]>0
		end
		if @initial_scores.length>0
			miniscore*=1.4 if hasbadmoves(40)
		end
		miniscore = pbSereneGraceCheck(miniscore) if @move.basedamage>0
		miniscore = pbReduceWhenKills(miniscore)
		return miniscore
	end

	def attractcode
		agender=@attacker.gender
		ogender=@opponent.gender
		return 0 if (agender==2 || ogender==2 || agender==ogender || @opponent.effects[:Attract]>=0 || ((@opponent.ability== :OBLIVIOUS || (@opponent.ability== :MINDSEYE && @battle.FE==:PSYTERRAIN) || @opponent.ability== :AROMAVEIL || @opponent.pbPartner.ability== :AROMAVEIL) && !moldBreakerCheck(@attacker,@move)))
		miniscore=1.2
		miniscore*=0.7 if @attacker.ability== :CUTECHARM
		miniscore*=1.3 if @mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL)
		miniscore*=1.1 if @opponent.effects[:Confusion]>0
		miniscore*=1.1 if @opponent.status== :PARALYSIS
		miniscore*=0.5 if @opponent.effects[:Yawn]>0 || @opponent.status== :SLEEP
		miniscore*=0.1 if (@mondata.oppitemworks && @opponent.item == :DESTINYKNOT)
		if @attacker.pbHasMove?(:SUBSTITUTE)
			miniscore*=1.2
			miniscore*=1.3 if @attacker.effects[:Substitute]>0
		end
		return miniscore
	end

	def refreshcode
		miniscore = 1.0
		if @attacker.status== :BURN || @attacker.status== :POISON || @attacker.status== :PARALYSIS
			miniscore*=3
		else
			return 0
		end
		miniscore*=((@attacker.hp.to_f)/@attacker.totalhp > 0.5) ? 1.5 : 0.3
		miniscore*=0.1 if @opponent.effects[:Yawn] > 0
		miniscore*=0.1 if checkAIdamage() > @attacker.hp
		miniscore*=1.3 if @opponent.effects[:Toxic] > 2
		miniscore*=1.3 if checkAImoves([:HEX])
		return miniscore
	end

	def partyrefreshcode
		return 0 if !@battle.pbPartySingleOwner(@attacker.index).any? {|mon| mon && !mon.status.nil?}
		miniscore=1.2
		for mon in @battle.pbPartySingleOwner(@attacker.index)
			next if mon.nil? || mon.hp <= 0 || mon.status.nil?
			miniscore*=0.5 if mon.status== :POISON && mon.ability== :POISONHEAL
			miniscore*=0.8 if mon.ability== :GUTS || mon.ability== :QUICKFEET || mon.knowsMove?(:FACADE)
			miniscore*=1.1 if mon.status== :SLEEP || mon.status== :FROZEN
			monroles=pbGetMonRoles(mon)
			miniscore*=1.2 if (monroles.include?(:PHYSICALWALL) || monroles.include?(:SPECIALWALL)) && mon.status== :POISON
			miniscore*=1.2 if monroles.include?(:SWEEPER) && mon.status== :PARALYSIS
			miniscore*=1.2 if mon.attack>mon.spatk && mon.status== :BURN
		end
		miniscore*=1.3 if !@attacker.status.nil?
		miniscore*=1.3 if @attacker.effects[:Toxic]>2
		miniscore*=1.1 if checkAIhealing()
		return miniscore
	end

	def psychocode
		return 0 if @attacker.status.nil? || !@opponent.status.nil? || @opponent.effects[:Substitute]>0 || @opponent.effects[:Yawn]!=0
		return 0 if @attacker.status== :BURN && !@opponent.pbCanBurn?(false) || @attacker.status== :PARALYSIS && !@opponent.pbCanParalyze?(false) || @attacker.status== :POISON && !@opponent.pbCanPoison?(false)
		miniscore=1.3*1.3
		if @attacker.status== :BURN && @opponent.pbCanBurn?(false)
			miniscore*=1.2 if pbRoughStat(@opponent,PBStats::ATTACK)>pbRoughStat(@opponent,PBStats::SPATK)
			miniscore*=0.7 if @opponent.ability== :FLAREBOOST
		end
		if @attacker.status== :PARALYSIS && @opponent.pbCanParalyze?(false)
			miniscore*=1.1 if pbRoughStat(@opponent,PBStats::ATTACK)<pbRoughStat(@opponent,PBStats::SPATK)
			miniscore*=1.2 if pbAIfaster?(@move)
		end
		if @attacker.status== :POISON && @opponent.pbCanPoison?(false)
			miniscore*=1.1 if checkAIhealing()
			miniscore*=1.4 if @attacker.effects[:Toxic]>0
			miniscore*=0.3 if @opponent.ability== :POISONHEAL
			miniscore*=0.7 if @opponent.ability== :TOXICBOOST
		end
		miniscore*=0.7 if @opponent.ability== :SHEDSKIN || @opponent.ability== :NATURALCURE || @opponent.ability== :GUTS || @opponent.ability== :QUICKFEET || @opponent.ability== :MARVELSCALE
		if checkAImoves([:FACADE])
			facade = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(:FACADE),@opponent)
			damage = pbRoughDamage(facade, @opponent, @attacker,false)
			aiDamage = checkAIdamage()
			miniscore*= 0.7 if damage > @attacker.hp/5 && damage > aiDamage && aiDamage < @attacker.hp
		end
		miniscore*=1.3 if checkAImoves([:HEX])
		miniscore*=1.3 if @attacker.pbHasMove?(:HEX)
		return miniscore
	end

	def selfstatboost(stats,oppcheck = true) # LAWDS - added oppcheck to avoid infinite recursion when two opportunist mons face each other
		#stats should be an array of the stat boosts like so: [ATK,DEF,SPE,SPA,SPD,ACC,EVA] with nils in unaffected stats
		#coil, for example, would be [1,1,0,0,0,1,0]
		stats.unshift(0) #this is required to make the next line work correctly
		return 1 if @attacker.ability== :INDUSTRYSTANDARD		# LAWDS - Industry Standard prevents all stat changes.
		for i in 1...stats.length
			next if stats[i] == 0
			stats[i]*= 2 if (@attacker.ability== :SIMPLE)
			#cap boost to the max it can be increased
			stats[i] = [6-@attacker.stages[i], stats[i]].min
		end

		stats[PBStats::SPATK]=stats[PBStats::DEFENSE] if @attacker.crested==:CLAYDOL # lawds AI sees boosts of claydol crest
		stats[PBStats::SPATK]=stats[PBStats::ATTACK] if (@battle.FE==:PSYTERRAIN || @battle.state.effects[:PSYTERRAIN]>0) && @attacker.ability==:PUREPOWER
		if stats[PBStats::ATTACK] != 0 || stats[PBStats::SPATK] != 0
			for j in @attacker.moves
				next if j.nil?
				specmove=true if j.pbIsSpecial?()
				physmove=true if j.pbIsPhysical?()
			end
			stats[PBStats::ATTACK] = 0 if !physmove && @battle.FE != :PSYTERRAIN
			stats[PBStats::SPATK] = 0 if !specmove
		end
		if stats.all? {|a| a.nil? || a==0 } && move.function != 0x37
			return @move.basedamage > 0 ? 1 : 0
		end
		# lawds see and categorize the opponent's moves
		oppPhysMoves = []
		oppSpecMoves = []
		for j in @opponent.moves
			next if j.nil?
			if j.pbHitsSpecialStat?(j.pbType(@opponent))
				oppSpecMove=true
				oppSpecMoves.push(j)
			end
			if j.pbHitsPhysicalStat?(j.pbType(@opponent))
				oppPhysMove=true
				oppPhysMoves.push(j)
			end
		end
		#Function is split into 3 sections- individual stat sections, group stat sections, and collective stat sections.
		#Individual is self explanatory; group stats splits stats into offensive/defensive (sweep/tank) and processese separately
		#Collective checks run on all of the stats.
		miniscore=1.0
		if @move.basedamage == 0
			statsboosted = 0
			for i in 1...stats.length				
				statsboosted += stats[i] if stats[i] != nil				
			end
			miniscore = statsboosted
			# weight categories based on combinations of boosted stats
			if (stats[PBStats::ATTACK] > 0 || stats[PBStats::SPATK] > 0) && (stats[PBStats::SPEED] > 0) # Speed and offense i.e dragon dance
				miniscore *= 1.8 
			elsif (stats[PBStats::ATTACK] > 1 || stats[PBStats::SPATK] > 1) # Double offense i.e swords dance, nasty plot
				miniscore *= 1.5 
			elsif (stats[PBStats::ATTACK] > 0 || stats[PBStats::SPATK] > 0) && (stats[PBStats::DEFENSE] > 0 || stats[PBStats::SPDEF] > 0) # Defense and offense i.e bulk up
				miniscore *= 1.5 
			elsif (stats[PBStats::DEFENSE] > 0 && stats[PBStats::SPDEF] > 0) # Both defenses i.e cosmic power
				miniscore *= 1.5 
			end	
		end
		# lawds
		bestoppmove, maxoppdam = checkAIMovePlusDamage()
		for i in 1...stats.length
			next if stats[i].nil? || stats[i]==0
			case i
				when PBStats::ATTACK
					next if !physmove
					sweep = true
					miniscore*=1.3 if checkAIhealing()
					miniscore*=1.5 if pbAIfaster?() || @attacker.moves.any? {|moveloop| moveloop.priority > 0 && moveloop.pbIsPhysical?(moveloop.pbType(@attacker))}
					miniscore*=0.5 if @attacker.status== :BURN && @attacker.ability != :GUTS && @attacker.ability != :QUICKFEET
					miniscore*=0.3 if checkAImoves([:FOULPLAY])
					miniscore*=1.4 if notOHKO?(@attacker,@opponent)
					miniscore*=0.6 if checkAIpriority()
					miniscore*=0.6 if (@opponent.ability== :SPEEDBOOST || (@opponent.ability== :MOTORDRIVE && @battle.FE == :ELECTERRAIN) || (@opponent.ability== :STEAMENGINE && [:UNDERWATER,:WATERSURFACE,:VOLCANIC,:VOLCANICTOP,:INFERNAL].include?(@battle.FE)))
				when PBStats::DEFENSE
					tank = true
					if oppPhysMove
						if !(@mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL))
							if pbAIfaster?(@move) && ((@attacker.hp.to_f)/@attacker.totalhp>0.75 || (maxoppdam < (@attacker.hp*0.66).floor && checkAIhealing(@attacker.moves)))
								miniscore*=1.3
							elsif !pbAIfaster?(@move)
								miniscore*=0.7
							end
						end
						miniscore*=1.3
					end
				when PBStats::SPATK
					sweep = true
					miniscore*=1.3 if checkAIhealing()
					miniscore*=1.5 if pbAIfaster?() || @attacker.moves.any? {|moveloop| moveloop.priority > 0 && moveloop.pbIsSpecial?(moveloop.pbType(@attacker))}
					miniscore*=0.5 if @attacker.status== :PARALYSIS
					if notOHKO?(@attacker,@opponent)
						miniscore*=1.4
					end
					miniscore*=1.5 if checkAIdamage() < @attacker.hp/2
					miniscore*=0.6 if checkAIpriority()
				when PBStats::SPDEF
					tank = true
					miniscore*=1.1 if @opponent.status== :BURN
					if oppSpecMove
						if !(@mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL))
							if pbAIfaster?(@move) && ((@attacker.hp.to_f)/@attacker.totalhp>0.75 || (maxoppdam < (@attacker.hp*0.66).floor && checkAIhealing(@attacker.moves)))
								miniscore*=1.3
							elsif !pbAIfaster?(@move)
								miniscore*=0.7
							end
						end
						miniscore*=1.3
					end
				when PBStats::SPEED
					sweep = true
					if pbAIfaster?()
						miniscore*=0.8
						miniscore*=0.2 if statsboosted == stats[PBStats::SPEED]
					end
					#Additional check if you're the last mon alive?
					miniscore*=0.2 if @battle.trickroom > 1 || checkAImoves([:TRICKROOM])
					#Skip speed checks if we only have priority damaging moves anyway
					if @attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.basedamage > 0 && moveloop.priority < 1 && @mondata.roughdamagearray.transpose[@attacker.moves.find_index(moveloop)].max > 10 } # thank u perry 4 saving me									
						#Moxie/Soul Heart	
						miniscore*=1.5 if (physmove && (@attacker.ability== :MOXIE || @attacker.ability== :CHILLINGNEIGH || (@attacker.ability== :ASONE && @attacker.form == 1))) || (specmove && (@attacker.ability== :SOULHEART || @attacker.ability== :GRIMNEIGH || (@attacker.ability== :ASONE && @attacker.form == 2)))
						if @attacker.attack<@attacker.spatk
							miniscore*=(1+0.05*@attacker.stages[PBStats::SPATK]) if @attacker.stages[PBStats::SPATK]<0
						else
							miniscore*=(1+0.05*@attacker.stages[PBStats::SPATK]) if @attacker.stages[PBStats::ATTACK]<0
						end
						ministat=0
						ministat+=@opponent.stages[PBStats::DEFENSE]
						ministat+=@opponent.stages[PBStats::SPDEF]
						miniscore*= 1 - 0.05*ministat if ministat>0
					end
				when PBStats::ACCURACY
					for j in @attacker.moves
						next if j.nil?
						miniscore*=1.1 if j.basedamage<95
					end
					miniscore*=(1+0.05*@opponent.stages[PBStats::EVASION]) if @opponent.stages[PBStats::EVASION]>0
					# LAWDS - no bright powder, no lax incense
				when PBStats::EVASION
					tank = true																																								# Lawds Mod - Dust Devil, Wildfire
					miniscore*=0.2 if @opponent.ability== :NOGUARD || @attacker.ability== :NOGUARD || checkAIaccuracy() || (@opponent.ability==:FAIRYAURA && @battle.FE == :FAIRYTALE) || (@opponent.ability==:DUSTDEVIL && (@battle.pbWeather == :SANDSTORM || [:DESERT, :ASHENBEACH].include?(@battle.FE))) || (attacker.ability== :WILDFIRE && (@battle.pbWeather == :SUNNYDAY || @battle.FE==:INFERNAL))
					# LAWDS - no bright powder, no lax incense
			end
		end
		if seedProtection?(@attacker) || (@attacker.effects[:Substitute]>0 || ((@attacker.effects[:Disguise] || (@attacker.effects[:IceFace] && (@opponent.attack > @opponent.spatk || @battle.FE == :FROZENDIMENSION))) && !moldBreakerCheck(@opponent)) && !@battle.doublebattle)
			miniscore*=1.3
		end
		miniscore*=0.5 if (@opponent.effects[:Substitute]>0 || ((@opponent.effects[:Disguise] || (@opponent.effects[:IceFace] && (@attacker.attack > @attacker.spatk || @battle.FE == :FROZENDIMENSION))) && !moldBreakerCheck(@attacker,@move)))
		miniscore*=1.3 if @opponent.status== :SLEEP || @opponent.status== :FROZEN
		miniscore*=1.3 if hasbadmoves(20)
		attackerHPpercent = (@attacker.hp.to_f)/@attacker.totalhp
		if attackerHPpercent > 0.5 && attackerHPpercent < 0.75 && (@attacker.ability== :EMERGENCYEXIT || @attacker.ability== :WIMPOUT || (@attacker.itemWorks? && @attacker.item == :EJECTBUTTON))
			miniscore*=0.3
		elsif attackerHPpercent < 0.33 && move.basedamage==0
			miniscore*=0.3
		end
		if @mondata.skill>=MEDIUMSKILL && oppcheck # LAWDS - dont need to check this if we're not actually clicking a move
			bestmove, maxdam1 = checkAIMovePlusDamage()
			bestmove2, maxdam2 = checkAIMovePlusDamage(@opponent.pbPartner,@attacker)
			maxdam = maxdam1+maxdam2
			if maxdam < (@attacker.hp/4.0) && sweep
				miniscore*=1.2
			elsif maxdam < (@attacker.hp/3.0) && tank
				miniscore*=1.1
			elsif maxdam < (@attacker.hp/4.0) && (stats[PBStats::DEFENSE] != 0 && stats[PBStats::SPDEF] != 0) #cosmic power
				miniscore*=1.5
			elsif maxdam < (@attacker.hp/2.0) 
				miniscore*=1.1
			elsif move.basedamage == 0
				miniscore*=0.8
				miniscore*=0.3 if !@attacker.moves.any? { |moveloop| moveloop.basedamage > 0 && pbAIfaster?(moveloop,bestmove) }
				#Don't set up if you're gonna die this turn for sure
				# lawds if they can hit us with a move that puts us in range to die to prio, do not set up
				dies_before_sweep = @opponent.moves.any? {|oppmove| oppmove.pbIsPriorityMoveAI(@opponent,true) && ![:FAKEOUT,:FIRSTIMPRESSION].include?(oppmove.move) && (pbRoughDamage(oppmove,@opponent,@attacker) + maxdam) >= @attacker.hp}
				if (maxdam > @attacker.hp || dies_before_sweep) && !(@attacker.effects[:Substitute]>0 || ((@attacker.effects[:Disguise] || (@attacker.effects[:IceFace] && (@opponent.attack > @opponent.spatk || @battle.FE == :FROZENDIMENSION))) && !moldBreakerCheck(@opponent)) || seedProtection?(@attacker))
					miniscore*=0.1
				end
			end

			if maxdam * 2 > @attacker.hp + (hpGainPerTurn(@attacker)-1)*@attacker.totalhp && (stats[PBStats::ATTACK]==1 || stats[PBStats::SPATK]==1) && 
				((bestmove.pbIsPhysical?(bestmove.type) && stats[PBStats::DEFENSE] == 0) || (bestmove.pbIsSpecial?(bestmove.type) && stats[PBStats::SPDEF] == 0)) && move.basedamage == 0
				miniscore*=0.4
			end
		end
		#Don't set up if you're just going to get run over
		if (@opponent.level-10)>@attacker.level && oppcheck # LAWDS - same as above
			miniscore*=0.6
			if (@opponent.level-15)>@attacker.level
				miniscore*=0.2
			end
		end
		#Some stats run similar checks		
		# LAWDS - snatch fails past the first turn, and the AI disencourages snatchable moves only if snatch is actually possible
		miniscore*=0.1 if oppcheck && @move.canSnatch? && ((opponent.pbHasMove?(:SNATCH) && opponent.turncount <= 1) || (opponent.pbPartner.pbHasMove?(:SNATCH) && opponent.pbPartner.turncount <= 1)) # LAWDS - same as above
		if sweep
			ministat=@opponent.stages[PBStats::ATTACK]+@opponent.stages[PBStats::SPATK]+@opponent.stages[PBStats::SPEED]
			miniscore*=(1+0.05*ministat)
			if @attacker.stages[PBStats::SPEED]<0 && stats[PBStats::SPEED]==0
				miniscore*=(1+0.05*@attacker.stages[PBStats::SPEED])
			end
			miniscore*=1.2 if attackerHPpercent > 0.75
			miniscore*=1.2 if @attacker.turncount<2
			miniscore*=1.2 if !@opponent.status.nil?
			if @opponent.effects[:Encore]>0
				miniscore*=1.5 if @opponent.moves[(@opponent.effects[:EncoreIndex])].basedamage==0
			end
			miniscore*=0.6 if @attacker.effects[:LeechSeed]>=0 || @attacker.effects[:Attract]>=0
			miniscore*=0.5 if checkAImoves(PBStuff::PHASEMOVE)
			miniscore*=1.3 if @mondata.roles.include?(:SWEEPER)
			if @attacker.status== :PARALYSIS
				miniscore*=0.5
				miniscore*=0.5 if stats[PBStats::SPEED] != 0 #stacks
			end
			miniscore*=0.5 if @attacker.pbCanParalyze?(false) && checkAImoves(PBStuff::PARAMOVE) && @move.basedamage == 0
			miniscore*=0.7 if @attacker.status== :POISON && @attacker.ability!=:POISONHEAL && @attacker.crested != :ZANGOOSE
			miniscore*=0.6 if @attacker.effects[:Toxic]>0 && @attacker.ability!=:POISONHEAL && @attacker.crested != :ZANGOOSE
			# Gen 9 Mod - Additional Checks for Salt Cure
      		miniscore*=0.6 if @attacker.effects[:SaltCure] && @attacker.ability != :MAGICGUARD
     		miniscore*=0.6 if @attacker.effects[:SaltCure] && @attacker.ability != :MAGICGUARD && (@attacker.hasType?(:WATER) || @attacker.hasType?(:STEEL))
			miniscore*=0.6 if checkAIpriority()
			miniscore*=0.6 if (@opponent.ability== :SPEEDBOOST || (((@opponent.ability== :MOTORDRIVE && @battle.FE == :ELECTERRAIN) || (@opponent.ability== :STEAMENGINE && [:UNDERWATER,:WATERSURFACE,:VOLCANIC,:VOLCANICTOP,:INFERNAL].include?(@battle.FE))) && (stats[PBStats::SPEED] < 2)))
			miniscore*=1.4 if notOHKO?(@attacker,@opponent)
		else
			miniscore*=1.1 if attackerHPpercent > 0.75
			miniscore*=1.1 if @attacker.turncount<2
			miniscore*=1.1 if !@opponent.status.nil?
			if @opponent.effects[:Encore]>0
				if @opponent.moves[(@opponent.effects[:EncoreIndex])].basedamage==0
					miniscore*=1.3
					miniscore*=1.2 if (stats[PBStats::DEFENSE] != 0 && stats[PBStats::SPDEF] != 0)
				end
			end
			miniscore*=0.2 if checkAImoves(PBStuff::PHASEMOVE)
			miniscore*=0.7 if @attacker.status== :POISON && @attacker.ability!=:POISONHEAL && @attacker.crested != :ZANGOOSE
			miniscore*=0.2 if @attacker.effects[:Toxic]>0 && @attacker.ability!=:POISONHEAL && @attacker.crested != :ZANGOOSE
			# Gen 9 Mod - Additional Checks for Salt Cure
			miniscore*=0.4 if @attacker.effects[:SaltCure] && @attacker.ability != :MAGICGUARD
			miniscore*=0.4 if @attacker.effects[:SaltCure] && @attacker.ability != :MAGICGUARD && (@attacker.hasType?(:WATER) || @attacker.hasType?(:STEEL))
			miniscore*=0.3 if @attacker.effects[:LeechSeed]>=0 || @attacker.effects[:Attract]>=0
		end
		if tank
			if @attacker.stages[PBStats::SPDEF]>0 || @attacker.stages[PBStats::DEFENSE]>0
				ministat=0
				ministat+=@attacker.stages[PBStats::SPDEF] if stats[PBStats::SPDEF] != 0
				ministat+=@attacker.stages[PBStats::DEFENSE] if stats[PBStats::DEFENSE] != 0
				miniscore*=(1-0.05*ministat)
			end
			miniscore*=1.3 if @attacker.moves.any?{|moveloop| moveloop.nil? && moveloop.isHealingMove?}
			miniscore*=1.3 if @attacker.pbHasMove?(:LEECHSEED)
			miniscore*=1.2 if @attacker.pbHasMove?(:PAINSPLIT)
			miniscore*=1.2 if @mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL)
			miniscore*=(1.2*hpGainPerTurn)
			if @mondata.skill>=MEDIUMSKILL
				miniscore*=0.3 if checkAIdamage() < 0.12*@attacker.hp && (getAIMemory().length > 0)
			end
		end
		if @attacker.effects[:Confusion]>0
			if stats[PBStats::ATTACK] != 0 #if move boosts attack
				miniscore*=0.2
				miniscore*=0.5 if stats[PBStats::ATTACK] > 1 #using swords dance or shell smash while confused is Extra Bad
				miniscore*=1.5 if stats[PBStats::DEFENSE] != 0#adds a correction for moves that boost attack and defense
			else
				miniscore*=0.5
			end
		end
		if @battle.doublebattle
			if !(@attacker.pbPartner.pbHasMove?(:PSYCHUP))
				miniscore*=0.7 
			else
				miniscore*=1.1 
			end
			miniscore*=0.5 if !sweep  #drop is doubled
			miniscore*=1.8 if (@attacker.pbPartner.pbHasMove?(:FOLLOWME) || @attacker.pbPartner.pbHasMove?(:RAGEPOWDER))
		end
		miniscore*=0.2 if checkAImoves([:CLEARSMOG,:HAZE,:TOPSYTURVY,:HEAVENLYWING])
		miniscore*=1.3 if @opponent.effects[:HyperBeam]>0
		miniscore*=1.7 if @opponent.effects[:Yawn]>0
		miniscore*=2 if @attacker.pbHasMove?(:STOREDPOWER)
		miniscore*=1.2 if @attacker.pbPartner.pbHasMove?(:PSYCHUP) || @attacker.pbHasMove?(:BATONPASS)
		
		if move.basedamage>0 && oppcheck
			if @initial_scores[@score_index]>=100
				miniscore *= 1.2
			elsif @initial_scores.length>0
				miniscore*= 0.5 if hasgreatmoves()
			end
			miniscore=1 if @opponent.ability== :UNAWARE || miniscore < 1
			miniscore=pbSereneGraceCheck(miniscore)
		else
			miniscore*=0 if @attacker.ability== :CONTRARY 
			miniscore*=0.01 if @opponent.ability== :UNAWARE
		end
		# lawds mod - take opportunist/mirror herb into account
		if (@opponent.ability== :OPPORTUNIST || @opponent.item == :MIRRORHERB) && oppcheck
			attacker_buffer = @attacker
			@attacker = @opponent
			@opponent = attacker_buffer
			opp_buff_score = selfstatboost(stats,false)
			@opponent = @attacker
			@attacker = attacker_buffer
			miniscore = miniscore/opp_buff_score if opp_buff_score > 0
		end
    	return miniscore
	end


	def selfstatdrop(stats,score)
		return 1.0 if [:INDUSTRYSTANDARD,:JUGGERNAUT].include?(@attacker.ability)
		stats.map!.with_index {|a,ind| @attacker.pbTooLow?(ind+1) ? 0 : a}
		return 1.0 if stats.all? {|a| a==0}
		#Only uses a 5 stat array
		miniscore=1.0
		stats.unshift(0)
		movekills = @initial_scores[@score_index] >= 110 # LAWDS replace the scoring thing with just checking damage directly
		if stats[PBStats::ATTACK] != 0 #Basically just to catch superpower
			if !movekills
				miniscore*=0.9
				if !pbAIfaster?()
					miniscore*=1.1
				else
					miniscore*=0.5 if checkAIhealing()
				end
			end
		elsif stats[PBStats::DEFENSE] != 0 || stats[PBStats::SPDEF] != 0
			faster = pbAIfaster?()
			if !(movekills && faster)
				miniscore*=0.9
				miniscore*=0.9 if stats[PBStats::SPEED] < 0
				miniscore*=0.6 if @mondata.roles.include?(:TANK)
			end
		elsif stats[PBStats::SPEED] != 0
			scorebuffer = miniscore # lawds dont care about speed drops with hit and run
			miniscore*=0.9 if !movekills
			miniscore*=1.1 if @mondata.roles.include?(:TANK)
			if pbAIfaster?()
				miniscore*=0.8
				if @battle.pbPokemonCount(@battle.pbParty(@opponent.index))>1 && @battle.pbPokemonCount(@battle.pbPartySingleOwner(@attacker.index))==1
					miniscore*=0.8
				end
			else
				#miniscore*=1.1
			end
			miniscore = scorebuffer if movekills && @attacker.ability==:HITANDRUN
		elsif stats[PBStats::SPATK] != 0
			if @mondata.skill>=BESTSKILL && ((@battle.FE == :GLITCH && @attacker.getSpecialStat(which_is_higher: true) == PBStats::SPDEF) || @attacker.effects[:FocusEnergy] >= 3)
				miniscore*=1.4
			elsif !movekills
				miniscore*=0.9
				miniscore*=0.5 if checkAIhealing()
			end
		end
		if @initial_scores.length>0
			miniscore*=0.6 if hasgreatmoves()
		end
		minimini=100
		livecount=@battle.pbPokemonCount(@battle.pbParty(@opponent.index))
		miniscore*=1 - 0.05 * (livecount-3) if livecount>1
		
		party=@battle.pbParty(@attacker.index)
		pivotvar=false
		for i in 0...party.length
			next if party[i].nil?
			temproles = pbGetMonRoles(party[i])
			if temproles.include?(:PIVOT)
				pivotvar=true
			end
		end
		miniscore*=1.2 if pivotvar && !@battle.doublebattle
		livecount2=@battle.pbPokemonCount(@battle.pbPartySingleOwner(@attacker.index))
		if livecount>1 && livecount2==1
			miniscore*=0.8
		end
		for opp in [@attacker.pbOppositeOpposing, @attacker.pbOppositeOpposing.pbPartner]
			next if !opp
			if opp.crested == :SPIDOPS && !(movekills && opp==@opponent) # Lawds Mod - Spidops Crest
				attackerbuffer = @attacker # store the current attacker
				@attacker = opp # consider the crested spidops the 'attacker' for the purposes of scoring the stat boost
				statboostscore = selfstatboost(stats,false)
				miniscore/=statboostscore if statboostscore > 0
				@attacker = attackerbuffer # restore the current attacker
			end
		end
		miniscore = 1 if miniscore < 1 && livecount==1 && score>=100
		if movekills && @attacker.ability==:HITANDRUN # LAWDS dont care about stat drops if we kill with hit and run.
			miniscore = 1 if stats[PBStats::DEFENSE]==0 && stats[PBStats::SPDEF]==0
			miniscore = 1 if !@battle.doublebattle
		end
		return miniscore
	end

	def oppstatboost(stats)
		stats.map!.with_index {|a,ind| @opponent.pbTooHigh?(ind+1) ? 0 : a}
		#This still uses the 5-array of stats in case other games want to expand on it
		stats.unshift(0)
		miniscore=1.0
		# LAWDS move setup cap
	    if $game_variables[:DifficultyModes]==2
			for i in 1...6
				next if stats[i]==0
				if @opponent.effects[:StatBoosts][i-1][1].include?(@move.move) && !@opponent.pbCanIncreaseStatStage?(i,false,@move.move)
					stats[i] = 0
					next
				end
			end
		end
		if @opponent.ability== :INDUSTRYSTANDARD # LAWDS - swagger only considers confusion on industry standard pokemon
			if @opponent.pbIsOpposing?(@attacker)
				return confucode
			else 
				return 0
			end 
		end
		if @opponent.index != @attacker.pbPartner.index
			if @opponent.pbCanConfuse?(false)
				if stats[PBStats::SPATK] != 0 
					miniscore*=1 + 0.1*@opponent.stages[PBStats::ATTACK] if @opponent.stages[PBStats::ATTACK] > 0
					if @opponent.attack>@opponent.spatk
						miniscore*=1.5
					else
						miniscore*=0.3
					end
				elsif stats[PBStats::ATTACK] != 0
					if @opponent.attack<@opponent.spatk
						miniscore*=1.5
					else
						miniscore*=0.7
					end
				end
				miniscore*=confucode
			else
				miniscore=0
			end
		else
			return 0 if @battle.pbOwnedByPlayer?(@attacker.pbPartner.index)
			miniscore *= @opponent.pbCanConfuse?(false) ? 0.5 : 1.5
			miniscore*=1.5 if (@opponent.attack<@opponent.spatk && stats[PBStats::ATTACK] != 0) || (@opponent.attack>@opponent.spatk && stats[PBStats::SPATK] != 0)
			miniscore*=0.3 if (1.0/@opponent.totalhp)*@opponent.hp < 0.6
			if @opponent.effects[:Attract]>=0 || @opponent.status== :PARALYSIS || @opponent.effects[:Yawn]>0 || @opponent.status== :SLEEP
				miniscore*=0.3
			end
			miniscore*=1.2 if @mondata.oppitemworks && (@opponent.item == :PERSIMBERRY || @opponent.item == :LUMBERRY)
			miniscore*=0 if @opponent.ability== :CONTRARY
			miniscore*=0 if @opponent.effects[:Substitute]>0
			opp1 = @attacker.pbOppositeOpposing
			opp2 = opp1.pbPartner
			if @opponent.pbSpeed > opp1.pbSpeed && @opponent.pbSpeed > opp2.pbSpeed
				miniscore*=1.3
			else
				miniscore*=0.7
			end
		end
		return miniscore
	end

	def oppstatdrop(stats)
		return 1 if @move.basedamage > 0 && @initial_scores[@score_index]>=100						# Lawds Mod - Industry Standard		 Gen 9 Mod - Clear Amulet
		return @move.basedamage > 0 ? 1 : 0 if @opponent.ability== :CLEARBODY || @opponent.ability== :WHITESMOKE || @opponent.ability== :INDUSTRYSTANDARD || @opponent.hasWorkingItem(:CLEARAMULET)
		if @opponent.ability==:MIRRORARMOR && !moldBreakerCheck(@attacker,@move) && @battle.FE != :DARKCRYSTALCAVERN
			# lawds
			return @move.basedamage > 0 ? selfstatdrop(stats,@initial_scores[@score_index]) : 0
		end
		if @move.basedamage > 0 && (@attacker.ability==:PARENTALBOND || (@attacker.crested==:CINCCINO && !@move.pbIsMultiHit)) # lawds parental bond, crestcinno
			effectrate = @move.effect
			effectrate*=2 if @attacker.ability==:SERENEGRACE || (@battle.FE==:RAINBOW && @move.move!=:DIRECLAW) || ((@move.move==:ROCKSMASH || @move.move==:NATUREPOWER) && @battle.FE==:ROCKY)
			if effectrate>=100
				for i in 1...stats.length
					stats[i] = stats[i]*2 if !(i==0 && @opponent.ability==:DEFIANT) && !(i==2 && @opponent.ability==:COMPETITIVE && @battle.FE != :CHESS)
				end
			end
		end
		#stats should be an array of the stat boosts like so: [ATK,DEF,SPE,SPA,SPD,ACC,EVA] with nils in unaffected stats
		#coil, for example, would be [1,1,0,0,0,1,0]
		stats.unshift(0) #this is required to make the next line work correctly
		#Start by eliminating pointless stats
		for i in 1...stats.length
			next if stats[i] == 0
			stats[i] = 0 if !@opponent.pbCanReduceStatStage?(i)
			#Don't get into counter-setup wars you can't win - Ame
			#TODO: probably best to refactor conditions for this, maybe check movememory for setup moves - Fal
			stats[i] = 0 if @move.basedamage == 0 && stats[i] && @opponent.stages[i]>stats[i]
		end
		if stats[PBStats::DEFENSE]>0 || stats[PBStats::SPDEF]>0
			for j in @attacker.moves
				next if j.nil?
				specmove=true if j.pbIsSpecial?()
				physmove=true if j.pbIsPhysical?()
			end
			stats[PBStats::DEFENSE] = 0 if !physmove
			stats[PBStats::SPDEF] = 0 if !specmove
		end
		if stats[PBStats::ATTACK]>0 || stats[PBStats::SPATK]>0
			bestmove = checkAIbestMove()
			stats[PBStats::SPATK] = 0 if (pbRoughStat(@opponent,PBStats::ATTACK)*0.9>pbRoughStat(@opponent,PBStats::SPATK)) && bestmove.pbIsPhysical?()
			stats[PBStats::ATTACK] = 0 if (pbRoughStat(@opponent,PBStats::SPATK)*0.9>pbRoughStat(@opponent,PBStats::ATTACK)) && bestmove.pbIsSpecial?()
		end
		if stats[PBStats::SPEED] > 0 
			stats[PBStats::SPEED] = 0 if pbAIfaster?() && @battle.trickroom == 0
			stats[PBStats::SPEED] = 0 if @battle.trickroom > 1
		end
		if stats.all? {|a| a.nil? || a==0 }
			return @move.basedamage > 0 ? 1 : 0
		end
		#This section is split up a little weird to avoid duplicating checks
		miniscore = 1.0	
		if @move.basedamage == 0
			statsboosted = 0
			for i in 1...stats.length
				statsboosted += stats[i]
			end
			miniscore = statsboosted
		# Lawds Mod 6/19/2024 - Dreadnought makes special moves hit three times, so stat-lowering effects will trigger three times
		elsif @attacker.ability== :DREADNOUGHT && @move.pbIsSpecial?
			for i in 1...stats.length
				stats[i]*=3
			end
		end
		if stats[PBStats::DEFENSE]>0 || stats[PBStats::SPDEF]>0    #defense stuff
			miniscore*=1.1
			miniscore*=1.2 if checkAIdamage() < @opponent.hp
			miniscore*=1.5 if @move.function == 0x4C
		else			#non-defense stuff
			if @mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL)
				miniscore*=1.3 if stats[PBStats::ATTACK]>0 || stats[PBStats::SPATK]>0 || stats[PBStats::ACCURACY]>0
				miniscore*=1.1 if stats[PBStats::SPEED]>0
			end
		end
		if stats[PBStats::SPEED]>0  #speed stuff
			if (pbRoughStat(@opponent,PBStats::SPEED)*0.66) > @attacker.pbSpeed
				miniscore*= hasgreatmoves() ? 1 : 1.5
			end
			miniscore*=1+0.05*@opponent.stages[PBStats::SPEED] if @opponent.stages[PBStats::SPEED]<0 && !secondaryEffectNegated?()
			miniscore*=0.1 if @opponent.itemWorks? && (@opponent.item == :LAGGINGTAIL || @opponent.item == :IRONBALL)
			# LAWDS - ignore defiant/competitive if its alr capped
			miniscore*=0.2 if (@opponent.ability== :COMPETITIVE && 
					!(@opponent.effects[:StatBoosts][2][2].include?(:COMPETITIVE) && 
					@opponent.stages[PBStats::SPATK]==@opponent.effects[:StatBoosts][2][0]) && !(Rejuv && @battle.FE == :CHESS)) || 
					(@opponent.ability== :DEFIANT && !(@opponent.effects[:StatBoosts][0][2].include?(:DEFIANT) && 
					@opponent.stages[PBStats::ATTACK]==@opponent.effects[:StatBoosts][0][0])) || (@opponent.ability== :CONTRARY)
		else    #non-speed stuff																								
			miniscore*=1.1 if @mondata.partyroles.any? {|roles| roles.include?(:SWEEPER)}
		end
		#status & moves section
		if stats[PBStats::DEFENSE]>0 || stats[PBStats::SPATK]>0 || stats[PBStats::SPDEF]>0
			miniscore*=1.2 if @opponent.status== :POISON || @opponent.status== :BURN
		end
		if stats[PBStats::ATTACK]>0
			miniscore*=1.2 if @opponent.status== :POISON
			miniscore*=0.5 if @opponent.status== :BURN
			miniscore*=0.5 if @attacker.pbHasMove?(:FOULPLAY)
		end
		if stats[PBStats::SPEED]>0
			miniscore*=0.5 if @attacker.pbHasMove?(:GYROBALL)
			miniscore*=1.5 if @attacker.pbHasMove?(:ELECTROBALL)
			miniscore*=1.3 if checkAImoves([:ELECTROBALL])
			miniscore*=1.5 if @attacker.crested == :ARIADOS && @opponent.stages[PBStats::SPEED] > -1
			miniscore*=0.5 if checkAImoves([:GYROBALL])
			miniscore*=0.1 if  @battle.trickroom!=0 || checkAImoves([:TRICKROOM])
		end
		if @battle.pbPokemonCount(@battle.pbParty(@opponent.index))==1 || PBStuff::TRAPPINGABILITIESAI.include?(@attacker.ability) || (@attacker.ability== :MAGNETPULL && @opponent.hasType?(:STEEL)) || @opponent.effects[:MeanLook]>0
			miniscore*=1.2
		end
		miniscore *= 0.5 if @mondata.roles.include?(:PHAZER)
		miniscore *= 0.8 if hasgreatmoves() #hoping this doesn't self sabotage
		if move.basedamage>0
			miniscore=pbSereneGraceCheck(miniscore)
		else
			miniscore*=0.5 if @battle.pbPokemonCount(@battle.pbParty(@attacker.index))==1
			miniscore*=0.7 if !@attacker.status.nil?
		end
		# Lawds Mod - Spidops Crest. Currently doesn't weigh if your partner is Crested Spidops and would therefore get boosts from the stat drop but too lazy to hash out what that code would be
		miniscore *= selfstatboost(stats) if (@attacker.crested == :SPIDOPS && @opponent != @attacker.pbPartner)
		return miniscore
	end

	def focusenergycode
		return 0 if @attacker.effects[:FocusEnergy]!=2
		miniscore = 1.0
		attackerHPpercent = (@attacker.hp.to_f)/@attacker.totalhp
		if attackerHPpercent>0.75
			miniscore*=1.2
		elsif attackerHPpercent > 0.5 && attackerHPpercent < 0.75 && (@attacker.ability== :EMERGENCYEXIT || @attacker.ability== :WIMPOUT || (@attacker.itemWorks? && @attacker.item == :EJECTBUTTON))
			miniscore*=0.3
		elsif attackerHPpercent < 0.33
			miniscore*=0.3
		end
		miniscore*=1.3 if @opponent.effects[:HyperBeam]>0
		miniscore*=1.7 if @opponent.effects[:Yawn]>0
		miniscore*=0.6 if @attacker.effects[:LeechSeed]>=0 || @attacker.effects[:Attract]>=0
		miniscore*=0.5 if checkAImoves(PBStuff::PHASEMOVE)
		miniscore*=0.2 if @attacker.effects[:Confusion]>0
		miniscore*=0.3 if @attacker.pbOpposingSide.effects[:Retaliate]
		miniscore*=1.2 if (@attacker.hp/4.0)>checkAIdamage()
		miniscore*=1.2 if @attacker.turncount<2
		miniscore*=1.2 if !@opponent.status.nil?
		miniscore*=1.3 if @opponent.status== :SLEEP || @opponent.status== :FROZEN
		miniscore*=1.5 if @opponent.effects[:Encore]>0 && @opponent.moves[(@opponent.effects[:EncoreIndex])].basedamage==0
		miniscore*=0.5 if @battle.doublebattle
		miniscore*=2 if @attacker.ability== :SUPERLUCK || @attacker.ability== :SNIPER
		miniscore*=1.2 if @mondata.attitemworks && (@attacker.item == :SCOPELENS || (@attacker.item == :STICK && @attacker.pokemon.species==:FARFETCHD) || (@attacker.item == :LUCKYPUNCH && @attacker.pokemon.species==:CHANSEY))
		miniscore*=1.3 if (@mondata.attitemworks && @attacker.item == :LANSATBERRY)
		miniscore*=0.2 if @opponent.ability== :ANGERPOINT || @opponent.ability== :SHELLARMOR || @opponent.ability== :BATTLEARMOR
		miniscore*=0.5 if @attacker.pbHasMove?(:LASERFOCUS) || @attacker.pbHasMove?(:FROSTBREATH) || @attacker.pbHasMove?(:STORMTHROW)
		miniscore*= 2**(@attacker.moves.count{|moveloop| moveloop!=nil && moveloop.highCritRate?})
		return miniscore
	end

	def defogcode
		miniscore = 1.0
		yourpartycount = @battle.pbPokemonCount(@battle.pbPartySingleOwner(@attacker.index))
		theirpartycount = @battle.pbPokemonCount(@battle.pbPartySingleOwner(@opponent.index))
		if yourpartycount>1
			miniscore*=2 if @attacker.pbOwnSide.effects[:StealthRock]
			miniscore*=3 if @attacker.pbOwnSide.effects[:StickyWeb]
			miniscore*=(1.5**@attacker.pbOwnSide.effects[:Spikes])
			miniscore*=(1.7**@attacker.pbOwnSide.effects[:ToxicSpikes])
		end
		miniscore -= 1.0
		miniscore*=(yourpartycount-1) if yourpartycount>1
		minimini = 1.0
		if theirpartycount>1
			minimini*=0.5 if @opponent.pbOwnSide.effects[:StealthRock]
			minimini*=0.3 if @opponent.pbOwnSide.effects[:StickyWeb]
			minimini*=(0.7**@opponent.pbOwnSide.effects[:Spikes])
			minimini*=(0.6**@opponent.pbOwnSide.effects[:ToxicSpikes])
		end
		minimini -= 1.0
		minimini*=(theirpartycount-1) if theirpartycount>1
		miniscore+=minimini
		miniscore+=1.0
		if miniscore<0
			miniscore=0
		end
		miniscore*=2 if @opponent.pbOwnSide.effects[:Reflect]>0 && @battle.FE!=:DARKCRYSTALCAVERN
		miniscore*=2 if @opponent.pbOwnSide.effects[:LightScreen]>0 && @battle.FE!=:DARKCRYSTALCAVERN
		miniscore*=1.3 if @opponent.pbOwnSide.effects[:Safeguard]>0
		miniscore*=3 if @opponent.pbOwnSide.effects[:AuroraVeil]>0 && @battle.FE!=:DARKCRYSTALCAVERN
		miniscore*=1.3 if @opponent.pbOwnSide.effects[:Mist]>0
		if @move == :COURTCHANGE 
			miniscore*=3 if @opponent.pbOwnSide.effects[:Tailwind]>0

			miniscore*=0.5 if @attacker.pbOwnSide.effects[:Reflect]>0 && @battle.FE!=:DARKCRYSTALCAVERN
			miniscore*=0.5 if @attacker.pbOwnSide.effects[:LightScreen]>0 && @battle.FE!=:DARKCRYSTALCAVERN
			miniscore*=0.7 if @attacker.pbOwnSide.effects[:Safeguard]>0
			miniscore*=0.3 if @attacker.pbOwnSide.effects[:AuroraVeil]>0 && @battle.FE!=:DARKCRYSTALCAVERN
			miniscore*=0.7 if @attacker.pbOwnSide.effects[:Mist]>0
			miniscore*=0.2 if @attacker.pbOwnSide.effects[:Tailwind]>0
		end
		return miniscore
	end

	def volcanoeruptioncode
		return 1 if @battle.eruption
		miniscore = 1.0
		if PBTypes.twoTypeEff(:FIRE,@attacker.type1,@attacker.type2) == 0 || [:MAGMAARMOR,:FLASHFIRE,:FLAREBOOST,:BLAZE,:FLAMEBODY,:SOLIDROCK,:STURDY,:BATTLEARMOR,:SHELLARMOR,:WATERBUBBLE,:MAGICGUARD,:WONDERGUARD,:PRISMARMOR].include?(@attacker.ability) || @attacker.effects[:AquaRing] || (@attacker.isbossmon && @attacker.immunities[:fieldEffectDamage].include?(:VOLCANICTOP))
			miniscore*=1.0
		elsif PBTypes.twoTypeEff(:FIRE,@attacker.type1,@attacker.type2) == 1
			miniscore*=0.9
		elsif PBTypes.twoTypeEff(:FIRE,@attacker.type1,@attacker.type2) > 2
			miniscore*=0.75
		end
		if !@attacker.pbPartner.pokemon.nil?
			if PBTypes.twoTypeEff(:FIRE,@attacker.pbPartner.type1,@attacker.pbPartner.type2) == 0 || [:MAGMAARMOR,:FLASHFIRE,:FLAREBOOST,:BLAZE,:FLAMEBODY,:SOLIDROCK,:STURDY,:BATTLEARMOR,:SHELLARMOR,:WATERBUBBLE,:MAGICGUARD,:WONDERGUARD,:PRISMARMOR].include?(@attacker.pbPartner.ability) || @attacker.pbPartner.effects[:AquaRing] || (@attacker.pbPartner.isbossmon && @attacker.pbPartner.immunities[:fieldEffectDamage].include?(:VOLCANICTOP))
				miniscore*=1.0
			elsif PBTypes.twoTypeEff(:FIRE,@attacker.pbPartner.type1,@attacker.pbPartner.type2) == 1
				miniscore*=0.9
			elsif PBTypes.twoTypeEff(:FIRE,@attacker.pbPartner.type1,@attacker.pbPartner.type2) > 2
				miniscore*=0.75
			end
		end
		miniscore*=1.2 if PBTypes.twoTypeEff(:FIRE,@opponent.type1,@opponent.type2) > 2
		if !@opponent.pbPartner.pokemon.nil?
			miniscore*=1.2 if PBTypes.twoTypeEff(:FIRE,@opponent.pbPartner.type1,@opponent.pbPartner.type2) > 2
		end
		miniscore*=1.5 if (@attacker.ability== :FLASHFIRE && !@attacker.effects[:FlashFire]) 
		miniscore*=1.5 if (@attacker.pbPartner.ability== :FLASHFIRE && !@attacker.pbPartner.effects[:FlashFire])
		miniscore*=1.5 if (@attacker.ability== :BLAZE && !@attacker.effects[:Blazed]) 
		miniscore*=1.5 if (@attacker.pbPartner.ability== :BLAZE && !@attacker.pbPartner.effects[:Blazed])
		miniscore*=1.3 if @attacker.ability== :FLAREBOOST 
		miniscore*=1.3 if @attacker.pbPartner.ability== :FLAREBOOST
		# LAWDS eruptions activate thermal exchange
		miniscore*=1.3 if @attacker.ability== :THERMALEXCHANGE && !@attacker.pbTooHigh?(PBStats::ATTACK)
		miniscore*=1.3 if @attacker.pbPartner.ability== :THERMALEXCHANGE && !@attacker.pbPartner.pbTooHigh?(PBStats::ATTACK)

		miniscore*=1.75 if @attacker.ability== :MAGMAARMOR 
		miniscore*=1.75 if @attacker.pbPartner.ability== :MAGMAARMOR
		miniscore*=0.5 if (@opponent.ability== :FLASHFIRE && !@opponent.effects[:FlashFire]) 
		miniscore*=0.5 if (@opponent.pbPartner.ability== :FLASHFIRE && !@opponent.pbPartner.effects[:FlashFire])
		miniscore*=0.5 if (@opponent.ability== :BLAZE && !@opponent.effects[:Blazed]) 
		miniscore*=0.5 if (@opponent.pbPartner.ability== :BLAZE && !@opponent.pbPartner.effects[:Blazed])
		miniscore*=0.75 if @opponent.ability== :FLAREBOOST 
		miniscore*=0.75 if @opponent.pbPartner.ability== :FLAREBOOST
		miniscore*=0.2 if @opponent.ability== :MAGMAARMOR 
		miniscore*=0.2 if @opponent.pbPartner.ability== :MAGMAARMOR
		miniscore*=1.3 if @attacker.effects[:LeechSeed]>=0 
		miniscore*=1.3 if @attacker.pbPartner.effects[:LeechSeed]>=0
		miniscore*=0.8 if @opponent.effects[:LeechSeed]>=0 
		miniscore*=0.8 if @opponent.pbPartner.effects[:LeechSeed]>=0
		yourpartycount = @battle.pbPokemonCount(@battle.pbPartySingleOwner(@attacker.index))
		theirpartycount = @battle.pbPokemonCount(@battle.pbPartySingleOwner(@opponent.index))
		minimini1 = 1.0
		if yourpartycount>1
			minimini1*=1.5 if @attacker.pbOwnSide.effects[:StealthRock]
			minimini1*=2 if @attacker.pbOwnSide.effects[:StickyWeb]
			minimini1*=(1.3**@attacker.pbOwnSide.effects[:Spikes])
			minimini1*=(1.5**@attacker.pbOwnSide.effects[:ToxicSpikes])
		end
		minimini1 = -1.0
		minimini1*=(yourpartycount-1) if yourpartycount>1
		minimini2 = 1.0
		if theirpartycount>1
			minimini2*=0.75 if @opponent.pbOwnSide.effects[:StealthRock]
			minimini2*=0.5 if @opponent.pbOwnSide.effects[:StickyWeb]
			minimini2*=(0.9**@opponent.pbOwnSide.effects[:Spikes])
			minimini2*=(0.85**@opponent.pbOwnSide.effects[:ToxicSpikes])
		end
		minimini2 -= 1.0
		minimini2*=(theirpartycount-1) if theirpartycount>1
		subscore=(minimini1+minimini2+1.0)
		if subscore<0.5
			subscore=0.5
		end
		miniscore *= subscore
		return miniscore
	end

	def oppstatrestorecode
		return 1 if @opponent.effects[:Substitute] > 0
		miniscore = 1 + 0.05*statchangecounter(@opponent,1,7)
		miniscore *=1.1 if (@opponent.ability== :SPEEDBOOST || (@opponent.ability== :MOTORDRIVE && @battle.FE == :ELECTERRAIN) || (@opponent.ability== :STEAMENGINE && [:UNDERWATER,:WATERSURFACE,:VOLCANIC,:VOLCANICTOP,:INFERNAL].include?(@battle.FE)))
		return miniscore
	end

	def hazecode
		oppscore = 1.1 * statchangecounter(@opponent,1,7)
		attscore = -1.1 * statchangecounter(@attacker,1,7)
		if @battle.doublebattle
			oppscore += 1.1 * statchangecounter(@opponent.pbPartner,1,7) if @opponent.pbPartner.hp>0
			attscore += -1.1 * statchangecounter(@attacker.pbPartner,1,7) if @attacker.pbPartner.hp>0
		end
		miniscore = oppscore + attscore
		miniscore*=0.8 if ((@opponent.ability== :SPEEDBOOST || (@opponent.ability== :MOTORDRIVE && @battle.FE == :ELECTERRAIN) || (@opponent.ability== :STEAMENGINE && [:UNDERWATER,:WATERSURFACE,:VOLCANIC,:VOLCANICTOP,:INFERNAL].include?(@battle.FE))) || checkAImoves(PBStuff::SETUPMOVE))
		return miniscore
	end

	def statswapcode(stat1,stat2)
		attstages = @attacker.stages[stat1] + @attacker.stages[stat2]
		miniscore = -1.1 * attstages
		if (pbRoughStat(@attacker,stat1)>pbRoughStat(@attacker,stat2))
			miniscore*=2 if @attacker.stages[stat1]<0
		else
			miniscore*=2 if @attacker.stages[stat2]<0
		end
		oppstages = @opponent.stages[stat1] + @opponent.stages[stat2]
		minimini = -1.1 * attstages
		if (pbRoughStat(@opponent,stat1)>pbRoughStat(@opponent,stat2))
			minimini*=2 if @opponent.stages[stat1]>0
		else
			minimini*=2 if @opponent.stages[stat2]>0
		end
		miniscore+=minimini
		miniscore*=0.8 if @battle.doublebattle
		return miniscore
	end

	def psychupcode
		statarray = [0,0,0,0,0,0,0]
		boostarray = [0,0,0,0,0,0,0]
		droparray = [0,0,0,0,0,0,0]
		statarray[0] = (@opponent.stages[PBStats::ATTACK]-@attacker.stages[PBStats::ATTACK])
		statarray[1] = (@opponent.stages[PBStats::DEFENSE]-@attacker.stages[PBStats::DEFENSE])
		statarray[2] = (@opponent.stages[PBStats::SPATK]-@attacker.stages[PBStats::SPATK])
		statarray[3] = (@opponent.stages[PBStats::SPDEF]-@attacker.stages[PBStats::SPDEF])
		statarray[4] = (@opponent.stages[PBStats::SPEED]-@attacker.stages[PBStats::SPEED])
		statarray[5] = (@opponent.stages[PBStats::ACCURACY]-@attacker.stages[PBStats::ACCURACY])
		statarray[6] = (@opponent.stages[PBStats::EVASION]-@attacker.stages[PBStats::EVASION])
		for i in 0..6
			boostarray[i] = statarray[i] if i > 0
			droparray[i] = statarray[i]*-1 if i < 0
		end
		return boostarray,droparray
	end

	def mistcode
		miniscore = 1.0
		if @attacker.pbOwnSide.effects[:Mist]==0
			miniscore*=1.1
			# check opponent for stat decreasing moves
			miniscore*=1.3 if getAIMemory().any? {|j| j.function==0x42 || j.function==0x43 || j.function==0x44 || j.function==0x45 || j.function==0x46 || j.function==0x47 || j.function==0x48 || j.function==0x49 || j.function==0x4A || j.function==0x4B || j.function==0x4C || j.function==0x4D || j.function==0x4E || j.function==0x4F || j.function==0xE2 || j.function==0x138 || j.function==0x13B || j.function==0x13F}
		end
		return miniscore
	end

	def powertrickcode
		miniscore=1.0
		if @attacker.attack - @attacker.defense >= 100
			miniscore*=1.5 if pbAIfaster?(@move)
			miniscore*=2 if pbRoughStat(@opponent,PBStats::ATTACK)>pbRoughStat(@opponent,PBStats::SPATK)
			miniscore*=2 if @attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.isHealingMove?}
		elsif @attacker.defense - @attacker.attack >= 100
			if pbAIfaster?(@move)
				miniscore*=1.5
				miniscore*=2 if notOHKO?(@attacker, @opponent)
			else
				miniscore*=0
			end
		else
			miniscore*=0.1
		end
		miniscore*=0.1 if @attacker.effects[:PowerTrick]
		return miniscore
	end

	def splitcode(stat)
		return 0 if @opponent.effects[:Substitute] > 0
		miniscore=1.0
		case stat
			when PBStats::ATTACK
				if @opponent.attack > @opponent.spatk
					return 0 if @attacker.attack > @opponent.attack
					miniscore = @opponent.attack - @attacker.attack
					miniscore *= @attacker.attack > @attacker.spatk ? 2 : 0.5
				else
					return 0 if @attacker.spatk > @opponent.spatk
					miniscore = @opponent.spatk - @attacker.spatk
					miniscore *= @attacker.spatk > @attacker.attack ? 2 : 0.5
				end
			when PBStats::DEFENSE
				if @opponent.attack > @opponent.spatk
					return 0 if @attacker.defense > @opponent.defense
					miniscore = @opponent.defense - @attacker.defense
					miniscore *= @attacker.attack > @attacker.spatk ? 2 : 0.5
				else
					return 0 if @attacker.spdef > @opponent.spdef
					miniscore = @opponent.spdef - @attacker.spdef
					miniscore *= @attacker.spatk > @attacker.attack ? 2 : 0.5
				end
			when PBStats::HP
				return 0 if @opponent.effects[:Substitute]>0
				ministat = [(@opponent.hp + @attacker.hp) / 2.0, @attacker.totalhp].min
				maxdam = checkAIdamage()
				return 0 if maxdam > ministat
				if maxdam > @attacker.hp
					return pbAIfaster?(@move) ? 2 : 0
				else
					miniscore*=0.3 if checkAImoves(PBStuff::SETUPMOVE)
					miniscore*= @opponent.hp/(@attacker.hp).to_f
					return miniscore
				end
		end
		miniscore = 1 + miniscore/100.0
		return miniscore
	end

	def tailwindcode # LAWDS improved tailwind code as well as added checks for setup cap
		return 0 if @attacker.pbOwnSide.effects[:Tailwind]!=0
		# lawds crawli
		return 0 if @opponent.pbOwnSide.effects[:StickyWeb] && !@attacker.pbOwnSide.effects[:StickyWeb] && @opponent.pbOwnSide.effects[:Tailwind]==0
		aiparty = @battle.pbParty(@attacker.index)
		oppparty = @battle.pbParty(@opponent.index)
		miniscore = 1.0
		if pbAIfaster?(nil,nil,@attacker,@opponent) && pbAIfaster?(nil,nil,@attacker.pbPartner,@opponent) && !@mondata.roles.include?(:LEAD)
			miniscore*=0.9
			miniscore*=0.4 if @attacker.pbNonActivePokemonCount==0
		else 
			miniscore = 1.5
		end
		miniscore*=0.5 if (@opponent.ability== :SPEEDBOOST || (@opponent.ability== :MOTORDRIVE && @battle.FE == :ELECTERRAIN) || (@opponent.ability== :STEAMENGINE && [:UNDERWATER,:WATERSURFACE,:VOLCANIC,:VOLCANICTOP,:INFERNAL].include?(@battle.FE))) && $game_variables[:DifficultyModes]!=2
		miniscore*=0.1 if @battle.trickroom!=0 || checkAImoves([:TRICKROOM])
		miniscore*=1.4 if @mondata.roles.include?(:LEAD)
		miniscore*=2.5 if !@battle.opponent.nil? && !@battle.opponent.is_a?(Array) && @battle.opponent.trainertype==:ADRIENN
		return miniscore
	end

	def mimicsketchcode(blacklist,sketch)
		lastmove = (sketch) ? @opponent.lastMoveUsedSketch : @opponent.lastMoveUsed
		return 0 if lastmove == -1
		return 0 if @opponent.effects[:Substitute] > 0
		return 0 if pbAIfaster?(@move) && (blacklist.include?($cache.moves[lastmove].function) || lastmove.is_a?(Symbol))
		miniscore = ($cache.moves[lastmove].basedamage > 0) ? $cache.moves[lastmove].basedamage : 40
		miniscore=1 + miniscore/100.0
		miniscore*=0.5 if miniscore<=1.5
		miniscore*=0.5 if !pbAIfaster?(@move)
		return miniscore
	end

	def typechangecode(type)
		type = type.intern if !type.is_a?(Symbol)
		return 0 if type == @attacker.type1 && @attacker.type2.nil?
		return 0 if @attacker.ability== :MULTITYPE || @attacker.ability== :RKSSYSTEM || @attacker.crested == :SILVALLY || @attacker.ability== :PROTEAN || @attacker.ability== :LIBERO || @attacker.ability== :COLORCHANGE || (@attacker.ability== :DOWNLOAD && @battle.FE == :DIMENSIONAL)
		miniscore = [PBTypes.twoTypeEff(@opponent.type1,@attacker.type1,@attacker.type2),PBTypes.twoTypeEff(@opponent.type2,@attacker.type1,@attacker.type2)].max
		minimini = [@opponent.type1.nil? ? 0 : PBTypes.oneTypeEff(@opponent.type1,type), @opponent.type2.nil? ? 0 : PBTypes.oneTypeEff(@opponent.type2,type)].max
		return 0 if minimini > miniscore
		miniscore*=2
		miniscore*=pbAIfaster?(@move) ? 1.2 : 0.7
		stabvar = false
		newstabvar = false
		for i in @attacker.moves
			next if i.nil?
			stabvar = true if (i.pbType(@attacker)==@attacker.type1 || i.pbType(@attacker)==@attacker.type2) && i.basedamage != 0
			newstabvar = true if i.pbType(@attacker)==type && i.basedamage != 0
		end
		if stabvar && !newstabvar
			miniscore*=1.2
		else
			miniscore*=0.6
		end
		return miniscore
	end

	def opptypechangecode(type)
		# lawds adjusted code for desert's mark. we check damage instead of type matchup to also take into account immunity/resist abilities.
		defaultret = @move.function == 0x205 && !@opponent.effects[:DesertsMark] ? 1.0 : 0
		return defaultret if type == @opponent.type1 && @opponent.type2.nil?
		return defaultret if @opponent.ability== :MULTITYPE || @opponent.ability== :RKSSYSTEM || @opponent.crested == :SILVALLY || @opponent.ability== :PROTEAN || @opponent.ability== :LIBERO || @opponent.ability== :COLORCHANGE || (@opponent.ability== :DOWNLOAD && @battle.FE == :DIMENSIONAL) || @attacker.crested==:GOTHITELLE || @opponent.crested==:REUNICLUS
		miniscore = checkAIdamage(@opponent,@attacker)
		oppclone = pbCloneBattler(@opponent.index)
		type1buffer = @opponent.type1.clone
		type2buffer = @opponent.type2.clone
		oppclone.type1=type
		oppclone.type2=nil
		miniscore2 = checkAIdamage(oppclone,@attacker)
		if miniscore==0
		   	minimini = 0
			minimini = 1 if miniscore2 > 0
			minimini = 2 if miniscore2 >= @opponent.hp/4 
			minimini = 4 if miniscore2 >= @opponent.hp/2
			minimini = 8 if miniscore2 >= @opponent.hp
		else
			minimini = [(miniscore2.to_f)/(miniscore.to_f),16].min
		end
		if !(@move.function == 0x205)
			return 0 if miniscore2 < miniscore 
			minimini *= 0.5 if getAIMemory(@opponent).any?{|moveloop|moveloop!=nil && moveloop.pbType(@opponent) == type}
		end
		minimini *= 1.5 if @attacker.moves.any?{|moveloop| moveloop!=nil && PBTypes.oneTypeEff(moveloop.pbType(@attacker),type) > 2}
		# lawds easiest way to get conda to click mark on wind rider mons is simply to hard code it
		miniscore*= 1.5 if @attacker.species==:SANDACONDA && @opponent.ability==:WINDRIDER && PBTypes.twoTypeEff(:GROUND,@opponent.type1,@opponent.type2) < 2
		return minimini
	end

	def abilitychangecode(ability)
		return 0 if @opponent.ability== ability || (PBStuff::FIXEDABILITIES).include?(@opponent.ability)
		# Gen 9 Mod - Added Ability Shield
    	return 0 if (@mondata.oppitemworks && @opponent.item == :ABILITYSHIELD)
		miniscore = getAbilityDisruptScore(@attacker,@opponent)
		if @opponent.index == @attacker.pbPartner.index
			if miniscore < 2
			  	miniscore = 2 - miniscore
			else
			  	miniscore = 0
			end
		end
		if ability== :SIMPLE
			miniscore*=1.3 if @opponent.index==@attacker.pbPartner.index && @opponent.moves.any?{|moveloop| moveloop!=nil && (PBStuff::SETUPMOVE).include?(moveloop)}
			miniscore*=0.5 if checkAImoves(PBStuff::SETUPMOVE)
		elsif ability== :INSOMNIA
			miniscore*=1.3 if checkAImoves([:SNORE,:SLEEPTALK])
			miniscore*=2 if checkAImoves([:REST])
			miniscore*=0.3 if @attacker.moves.any?{|moveloop| moveloop!=nil && (PBStuff::SLEEPMOVE).include?(moveloop)}
		end
		return miniscore
	end

	def roleplaycode # Role Play
		return 0 if (PBStuff::ABILITYBLACKLIST).include?(@opponent.ability)
		return 0 if (PBStuff::FIXEDABILITIES).include?(@attacker.ability)
		return 0 if @opponent.ability== 0 || @attacker.ability== @opponent.ability
		# Gen 9 Mod - Added Ability Shield
    	return 0 if (@mondata.attitemworks && @attacker.item == :ABILITYSHIELD)
		miniscore = getAbilityDisruptScore(@opponent,@attacker)
		minimini = getAbilityDisruptScore(@attacker,@opponent)
		return (1 + (minimini-miniscore))
	end

	def entraincode(score)
		return 0 if (PBStuff::FIXEDABILITIES).include?(@opponent.ability)
		return 0 if @opponent.ability== :TRUANT
		return 0 if (PBStuff::ABILITYBLACKLIST).include?(@attacker.ability) && @attacker.ability != :WONDERGUARD
		return 0 if @opponent.ability== 0 || @attacker.ability== @opponent.ability
		# Gen 9 Mod - Added Ability Shield
		return 0 if (@mondata.attitemworks && @attacker.item == :ABILITYSHIELD)
		miniscore = getAbilityDisruptScore(@opponent,@attacker)
		minimini = getAbilityDisruptScore(@attacker,@opponent)
		if @opponent.index != @attacker.pbPartner.index
			score*= (1 + (minimini-miniscore))
			if (@attacker.ability== :TRUANT)
				score*=3
			elsif (@attacker.ability== :WONDERGUARD)
				score=0
			end
		else
			score *= (1 + (miniscore-minimini)) # LAWDS rewrote this for p3 compatibility
			score+=85 if @attacker.ability==:WONDERGUARD
			score+=25 if @attacker.ability==:SPEEDBOOST
			score+=30 if @opponent.ability==:DEFEATIST
			score+=50 if @opponent.ability==:SLOWSTART
		end
		return score
	end

	def skillswapcode
		return 0 if (PBStuff::FIXEDABILITIES).include?(@attacker.ability) && @attacker.ability != :ZENMODE
		return 0 if (PBStuff::FIXEDABILITIES).include?(@opponent.ability) && @opponent.ability != :ZENMODE
		return 0 if @opponent.ability== :ILLUSION || @attacker.ability== :ILLUSION
		return 0 if @opponent.ability== 0 || @attacker.ability== @opponent.ability
		# Gen 9 Mod - Added Poison Puppeteer
		return 0 if @opponent.ability== :POISONPUPPETEER || @attacker.ability== :POISONPUPPETEER
		return 0 if @opponent.ability== 0 || @attacker.ability== @opponent.ability
		# Gen 9 Mod - Added Ability Shield
		return 0 if (@mondata.oppitemworks && @opponent.item == :ABILITYSHIELD)
		return 0 if (@mondata.attitemworks && @attacker.item == :ABILITYSHIELD)
		miniscore = getAbilityDisruptScore(@opponent,@attacker)
		minimini = getAbilityDisruptScore(@attacker,@opponent)
		miniscore = [2-miniscore,0].max if @opponent.index == @attacker.pbPartner.index
		miniscore *= (1 + (minimini-miniscore)*2)
		miniscore*=2 if (@attacker.ability== :TRUANT && @opponent.index!=@attacker.pbPartner.index) || (@opponent.ability== :TRUANT && @opponent.index==@attacker.pbPartner.index)
		return miniscore
	end

	def gastrocode
		return 0 if @opponent.effects[:GastroAcid] || @opponent.effects[:Substitute]>0 || (PBStuff::FIXEDABILITIES).include?(@opponent.ability) || @opponent.hasType?(:POISON) # lawds
		# Gen 9 Mod - Added Ability Shield
		return 0 if (@mondata.oppitemworks && @opponent.item == :ABILITYSHIELD)
		return getAbilityDisruptScore(@attacker,@opponent)
	end

	def transformcode
		return 0 if @opponent.effects[:Transform] || @opponent.effects[:Illusion] || @opponent.effects[:Substitute]>0 || @attacker.effects[:Transform]
		miniscore = 1 + (@opponent.level - @attacker.level) / 20
		miniscore *= 1.1 * (statchangecounter(@opponent,1,5) - statchangecounter(@attacker,1,5))
		return miniscore
	end

	def endeavorcode
		return 0 if @attacker.hp > @opponent.hp
		miniscore = 1.0
		miniscore*=1.5 if @attacker.moves.any?{|moveloop| moveloop!=nil && moveloop.pbIsPriorityMoveAI(@attacker)}
		miniscore*=1.5 if notOHKO?(@attacker, @opponent, true)
		miniscore*=2 if @opponent.level - @attacker.level > 9
		return miniscore
	end

	def ohkode
		return 0 if (@opponent.level>@attacker.level) || notOHKO?(@opponent, @attacker, true)																						# Lawds Mod - Dust Devil, Wildfire
		return 3.5 if @opponent.effects[:LockOn]>0 || @opponent.ability==:NOGUARD || @attacker.ability==:NOGUARD || (@attacker.ability==:FAIRYAURA && @battle.FE == :FAIRYTALE) || (@attacker.ability==:DUSTDEVIL && (@battle.pbWeather == :SANDSTORM || [:DESERT, :ASHENBEACH].include?(@battle.FE))) || (attacker.ability== :WILDFIRE && (@battle.pbWeather == :SUNNYDAY || @battle.FE==:INFERNAL))
		return 0.7
	end

	def counterattackcode
		miniscore = 1.0
		maxdam = checkAIdamage()
		miniscore*=0.5 if pbAIfaster?()
		if notOHKO?(@attacker, @opponent, true)
			miniscore*=1.2
		else
			miniscore*=0.8
			miniscore*=0.8 if maxdam>@attacker.hp
		end
		miniscore*=0.7 if !$cache.moves[@attacker.lastMoveUsed].nil? &&
		$cache.moves[@attacker.lastMoveUsed].function == @move.function
		miniscore*=0.6 if checkAImoves(PBStuff::SETUPMOVE)
		miniscore*=(@attacker.hp/@attacker.totalhp)
		bestmove = checkAIbestMove()
		miniscore/=bestmove.pbNumHits(@attacker) if bestmove.pbIsMultiHit && bestmove.pbNumHits(@attacker)>0 # LAWDS - take into account that it only reflects the last hit
		if @move.function == 0x71 # Counter
			if pbRoughStat(@opponent,PBStats::ATTACK) > (pbRoughStat(@opponent,PBStats::SPATK) * 1.1) # attack is at least 10% higher than sp.atk
				miniscore*=1.1
			elsif pbRoughStat(@opponent,PBStats::ATTACK)<(pbRoughStat(@opponent,PBStats::SPATK) * 0.6)
				miniscore*=0.3
			else 
				miniscore*=0.6
			end
			miniscore*=0.05 if bestmove.pbIsSpecial?()
			miniscore*=0.15 if @opponent.crested == :TYPHLOSION || @opponent.ability== :PARENTALBOND # LAWDS - counter and metal burst reflect the second hit from crested typh and parental bond, so it wont be very good against that
			miniscore*=1.1 if !$cache.moves[@attacker.lastMoveUsed].nil? && 
			$cache.moves[@attacker.lastMoveUsed].function==0x72
		elsif @move.function == 0x72 # Mirror Coat
			if (pbRoughStat(@opponent,PBStats::ATTACK) * 1.1)<pbRoughStat(@opponent,PBStats::SPATK) # attack is at least 10% higher than sp.atk
				miniscore*=1.1
			elsif (pbRoughStat(@opponent,PBStats::ATTACK) * 0.6)>pbRoughStat(@opponent,PBStats::SPATK)
				miniscore*=0.3
			else 
				miniscore*=0.6
			end
			miniscore*=0.3 if @opponent.spatk<@opponent.attack
			miniscore*=0.05 if bestmove.pbIsPhysical?()
			miniscore*=0.15 if @opponent.ability== :DREADNOUGHT # LAWDS - same thing for dreadnought on special moves
			miniscore*=1.1 if !$cache.moves[@attacker.lastMoveUsed].nil? && 
			$cache.moves[@attacker.lastMoveUsed].function==0x71
		end
		miniscore*=0.15 if (@opponent.crested == :TYPHLOSION || [:DREADNOUGHT, :PARENTALBOND].include?(@opponent.ability)) && @move.function == 0x73 # LAWDS - same reasoning as above
		return miniscore
	end

	def revengecode
		miniscore = 1.0
		miniscore*= pbAIfaster?() ? 0.5 : 1.5
		if @attacker.hp==@attacker.totalhp
			miniscore*=1.2
			miniscore*=1.1 if notOHKO?(@attacker, @opponent, true)
		else
			miniscore*=0.3 if checkAIdamage()>@attacker.hp
		end
		miniscore*=0.8 if checkAImoves(PBStuff::SETUPMOVE)
		return miniscore
	end

	def pursuitcode
		miniscore=1-0.1*statchangecounter(@opponent,1,7,-1)
		miniscore*=1.2 if @opponent.effects[:Confusion]>0
		miniscore*=1.5 if @opponent.effects[:LeechSeed]>=0
		miniscore*=1.3 if @opponent.effects[:Attract]>=0
		miniscore*=0.7 if @opponent.effects[:Substitute]>0
		miniscore*=1.5 if @opponent.effects[:Yawn]>0
		miniscore*=1.5 if (pbTypeModNoMessages>4 && !hasgreatmoves()) || @initial_scores[@score_index] >= 110 # lawds slightly improved pursuit code
		return miniscore
	end

	def echocode
		miniscore = 1.0
		miniscore*=0.7 if @attacker.status== :PARALYSIS
		miniscore*=0.7 if @attacker.effects[:Confusion]>0
		miniscore*=0.7 if @attacker.effects[:Attract]>=0
		miniscore*=1.3 if @attacker.hp==@attacker.totalhp
		miniscore*=1.5 if checkAIdamage()<(@attacker.hp/3.0)
		return miniscore
	end

	def helpinghandcode # LAWDS improved helping hand code
		return 0 if !(@battle.doublebattle || @attacker.pbPartner.hp==0 || @attacker.pbPartner.effects[:HelpingHand] == true)
		miniscore = 1.0
		miniscore*=2 if !hasgreatmoves() && !@attacker.moves.any?{|moveloop| moveloop!=nil && pbRoughDamage(moveloop,@attacker,@opponent,false)>=@opponent.totalhp/2}
		move1, damage1 = checkAIMovePlusDamage(@opponent,@attacker.pbPartner)
		move2, damage2 = checkAIMovePlusDamage(@opponent.pbPartner,@attacker.pbPartner)
		faster1 = !pbAIfaster?(nil,move1,@attacker.pbPartner,@opponent)
		faster2 = !pbAIfaster?(nil,move2,@attacker.pbPartner,@opponent.pbPartner)
		partnerdies = (damage1 >= @attacker.pbPartner.hp && faster1) || # if partner dies before they can attack, dont click the move
					  (damage2 >= @attacker.pbPartner.hp && faster2) ||
					  (damage1+damage2 >= @attacker.pbPartner.hp && faster1 && faster2)
		miniscore*=0.1 if partnerdies

		# dont click hhand early on, to avoid fake out and setup stuff. not perfect atm but its better than nothing
		miniscore*=0.3 if @opponent.turncount<=1 && @opponent.lastMoveUsed==-1 && @opponent.pbHasMove?(:FAKEOUT) && !([:SHIELDDUST,:INNERFOCUS].include?(@attacker.pbPartner.ability) && !(@attacker.pbPartner.hasWorkingItem(:COVERTCLOAK))) && !prioBlocked?(@attacker.pbPartner,@opponent)
		miniscore*=0.3 if @opponent.pbPartner.turncount<=1 && @opponent.pbPartner.lastMoveUsed==-1 && @opponent.pbPartner.pbHasMove?(:FAKEOUT) && !([:SHIELDDUST,:INNERFOCUS].include?(@attacker.pbPartner.ability) && !(@attacker.pbPartner.hasWorkingItem(:COVERTCLOAK))) && !prioBlocked?(@attacker.pbPartner,@opponent.pbPartner)

		if (!partnerdies) && miniscore >= 1
			miniscore*=1.2 if !pbAIfaster?() && !pbAIfaster?(nil,nil,@attacker,@opponent.pbPartner)
			miniscore*=1.5 if @attacker.hp/@attacker.totalhp < 0.33
			miniscore*=1.5 if !faster1 && !faster2
			basepartnerdmg = checkAIdamage(@opponent,@attacker.pbPartner)
			miniscore*=2 if !hasgreatmoves && basepartnerdmg < @opponent.hp && basepartnerdmg*1.5 >= @opponent.hp # if the partner doesnt kill without helping hand, but does kill with helping hand, pop off
		else
			miniscore*=0.2 if hasgreatmoves()
		end
		miniscore *= 1+(([@attacker.pbPartner.attack,@attacker.pbPartner.spatk].max - [@attacker.attack,@attacker.spatk].max) / 100)
		if @battle.FE == :BIGTOP && ![:GUTS, :SHEERFORCE, :HUGEPOWER, :PUREPOWER].include?(@attacker.pbPartner.ability) # LAWDS - helping hand on big top
			strikemove = false
			for i in @attacker.pbPartner.moves
				strikemove = true if (i.pbType(@attacker.pbPartner) == :FIGHTING && i.pbIsPhysical?()) || (STRIKERMOVES).include?(i.move) && ![:GALESTRIKE, :GIGATONHAMMER].include?(i.move)
			end
			miniscore*=1.5 if strikemove
		end
		return miniscore
	end

	def mudsportcode
		return 0 if @battle.state.effects[:MudSport] != 0
		miniscore = 1.0
		eff1 = PBTypes.twoTypeEff(:ELECTRIC,@attacker.type1,@attacker.type2)
		eff2 = @attacker.pbPartner.hp >0 ?  PBTypes.twoTypeEff(:ELECTRIC,@attacker.pbPartner.type1,@attacker.pbPartner.type2) : 0
		miniscore*=1.5 if eff1>4 || eff2>4 && @opponent.hasType?(:ELECTRIC)
		miniscore*=0.7 if pbPartyHasType?(:ELECTRIC)
		return miniscore
	end

	def watersportcode
		return 0 if @battle.state.effects[:WaterSport] != 0
		miniscore = 1.0
		eff1 = PBTypes.twoTypeEff(:FIRE,@attacker.type1,@attacker.type2)
		eff2 = @attacker.pbPartner.hp >0 ? PBTypes.twoTypeEff(:FIRE,@attacker.pbPartner.type1,@attacker.pbPartner.type2) : 0	
		miniscore*=1.5 if eff1>4 || eff2>4 && @opponent.hasType?(:FIRE)
		miniscore*=0.7 if pbPartyHasType?(:FIRE)
		return miniscore
	end

	def permacritcode(initialscore)
		return 0 if @opponent.index == @attacker.pbPartner.index && (@opponent.ability != :ANGERPOINT || @opponent.stages[PBStats::ATTACK]==6)
		return 0 if @attacker.effects[:LaserFocus]!=0 && @move.function==0x165
		return 0.7 if @opponent.ability== :BATTLEARMOR || @opponent.ability== :SHELLARMOR
		miniscore = 1.0
		miniscore += 0.1 * @opponent.stages[PBStats::DEFENSE] if @opponent.stages[PBStats::DEFENSE]>0
		miniscore += 0.1 * @opponent.stages[PBStats::SPDEF] if @opponent.stages[PBStats::SPDEF]>0
		miniscore -= 0.1 * @attacker.stages[PBStats::ATTACK] if @attacker.stages[PBStats::ATTACK]<0
		miniscore -= 0.1 * @attacker.stages[PBStats::SPATK] if @attacker.stages[PBStats::SPATK]<0
		miniscore -= 0.1 * @attacker.effects[:FocusEnergy] if @attacker.effects[:FocusEnergy]>0
		return miniscore if !(@opponent.ability== :ANGERPOINT && @opponent.stages[PBStats::ATTACK]!=6)
		if @attacker.pbPartner.index == @opponent.index && @move.function != 0x165
			return 0 if @opponent.attack>@opponent.spatk || initialscore>80
			miniscore = (100-initialscore)
			if pbAIfaster?(nil,nil,@opponent,@attacker.pbOpposing2) && pbAIfaster?(nil,nil,@opponent,@attacker.pbOpposing1)
				miniscore*=1.3
			else
			    miniscore*=0.7
			end
		else
			if initialscore<100
			    miniscore*=0.7
			    miniscore*=0.2 if @opponent.attack>@opponent.spatk
			end
		end
		return miniscore
	end

	# Lawds Mod 6/19/2024 - updated screencode() to account for the Mr. Rime crest
	# LAWDS - aurora veil on DCC, dont think i actually need to change the AI here to account for the different effect, so long as teams are naturally built to take advantage
	def screencode
		return 0 if (@attacker.pbOwnSide.effects[:Reflect]>0 && @move.function == 0xA2) || (@attacker.pbOwnSide.effects[:LightScreen]>0 && @move.function == 0xA3) || (@attacker.pbOwnSide.effects[:AreniteWall]>0 && @move.function == 0x203)
		return 0 if @attacker.pbOwnSide.effects[:AuroraVeil]>0 && (@move.function == 0x15b || @move.function == 0x80C)																																																								      	
		return 0 if @move.function == 0x15b && !(@battle.pbWeather== :HAIL || (@mondata.skill >= BESTSKILL && (@battle.FE == :SNOWYMOUNTAIN || @battle.FE == :MIRROR || @battle.FE == :STARLIGHT || @battle.FE==:NEWWORLD || @battle.FE == :DARKCRYSTALCAVERN || @battle.FE == :RAINBOW || @battle.FE == :ICY || @battle.FE == :CRYSTALCAVERN || @battle.FE == :FROZENDIMENSION)))
		return 0 if @move.function == 0x203 && !(@battle.pbWeather== :SANDSTORM || (@mondata.skill >= BESTSKILL && (@battle.FE == :DESERT || @battle.FE == :ASHENBEACH || @battle.FE == :ROCKY || @battle.FE==:DARKCRYSTALCAVERN )))
		return 0 if @attacker.pbOwnSide.effects[:AuroraVeil]>3
		miniscore=1.2
		hasbreakermove = false
                if @battle.FE != :DARKCRYSTALCAVERN
		    for move in PBStuff::SCREENBREAKERMOVE
			return 0 if @opponent.pbHasMove?(move)
			return 0 if @opponent.pbPartner.pbHasMove?(move)
		    end
		end
		miniscore*=0.2 if @attacker.pbOwnSide.effects[:AuroraVeil]>0 && @move.function != 0x203 # Arenite Wall applies seperately
		# lawds - evaluate screens for the enemy's whole party
		if [0xA2,0xA3].include?(@move.function)
		  for mon in @battle.pbParty(@opponent.index)
			next if mon==nil || mon.hp <= 0
			if mon.ability==:INFILTRATOR
				miniscore*=0.9
				next
			end
		  if @move.function == 0xA2 # Reflect
			if mon.attack > (mon.spatk * 1.1) # attack is at least 10% higher than sp.atk
				miniscore*=1.1
			else
				miniscore*=0.9
			end
		  elsif @move.function == 0xA3 # Light Screen
			if (mon.attack * 1.1) < mon.spatk # attack is at least 10% higher than sp.atk
				miniscore*=1.1
			else
				miniscore*=0.9
			end
		  end
		end
		# end lawds party stuff
		end
		miniscore*=1.1 if (@mondata.attitemworks && @attacker.item == :LIGHTCLAY) || @attacker.crested == :MRRIME || ([:MIRROR,:DARKCRYSTALCAVERN].include?(@battle.FE))
		if pbAIfaster?(@move)
			miniscore*=1.1
			if @mondata.skill>=MEDIUMSKILL
				if getAIMemory().length > 0 #&& !hasbreakermove
					#patch this to check for physical or special based on function code
					maxdam=0
					for j in 0...@opponent.moves.length
						oppmove = @opponent.moves[j]
						next if !pbAIfaster?(@move,oppmove)
						next if @move.function == 0xA2 && !oppmove.pbIsPhysical?()
						next if @move.function == 0xA3 && !oppmove.pbIsSpecial?()
						next if @move.function == 0x203 && (pbTypeModNoMessages(oppmove.pbType(@opponent),@opponent,@attacker,oppmove) <= 4) # arenite wall
						tempdam = @aimondata[@opponent.index].roughdamagearray[@attacker.index][j]
						maxdam=tempdam if maxdam<tempdam
					end
					if maxdam>=100
						miniscore*=1.5
						miniscore*=2 if !hasgreatmoves()
					end
				end
			end
		end
		livecount = @battle.pbPokemonCount(@battle.pbParty(@opponent.index))
		if livecount<=2
			miniscore*=0.7
			miniscore*=0.5 if livecount==1
		else
			miniscore*=1.4 if (@mondata.attitemworks && @attacker.item == :LIGHTCLAY) || @attacker.crested == :MRRIME
		end
		miniscore*=1.3 if notOHKO?(@attacker, @opponent)
		if @attacker.index == 2 # for partners to guess if the player will use aurora veil
			miniscore *= 0.3 if @attacker.pbPartner.pbHasMove?(:AURORAVEIL) if @move.function != 0x203
			if @move.function == 0xA2 # Reflect
				miniscore *= 0.3 if @attacker.pbPartner.pbHasMove?(:REFLECT)
			elsif @move.function == 0xA3 # Light Screen
				miniscore *= 0.3 if @attacker.pbPartner.pbHasMove?(:LIGHTSCREEN)
			elsif @move.function == 0x203 # Arenite Wall
				miniscore *= 0.3 if @attacker.pbPartner.pbHasMove?(:ARENITEWALL)
			end
		end
		#miniscore*=0.1 if hasbreakermove
		miniscore*=2 if @battle.FE==:DARKCRYSTALCAVERN
		return miniscore
	end

	def secretcode
		case @battle.FE
			when :ELECTERRAIN,:SHORTCIRCUIT							then return paracode()
			when :GRASSY,:FOREST,:FAIRYTALE							then return sleepcode()
			when :MISTY,:HOLY 										then return oppstatdrop([0,0,1,0,0,0,0])
			when :CLOUDS  											then return oppstatdrop([0,0,0,0,0,1,0])
			when :CHESS, :DARKNESS1, :DARKNESS2, :DARKNESS3, :ROCKY, :MOUNTAIN	then return oppstatdrop([0,1,0,0,0,0,0])
			when :BIGTOP,:STARLIGHT,:ASHENBEACH 					then return oppstatdrop([0,0,0,1,0,0,0])
			when :BURNING,:SUPERHEATED,:DRAGONSDEN,:VOLCANIC,:VOLCANICTOP,:INFERNAL,:DANCEFLOOR 	then return burncode()
			when :SWAMP,:WATERSURFACE,:GLITCH,:DARKCRYSTALCAVERN 	then return oppstatdrop([0,0,0,0,1,0,0])
			when :RAINBOW											then return (paracode() + poisoncode() + burncode() + freezecode() + sleepcode()) / 5
			when :CORROSIVE,:CORROSIVEMIST,:MURKWATERSURFACE,:CORRUPTED,:BACKALLEY,:CITY 	then return poisoncode()
			when :ICY,:SNOWYMOUNTAIN,:FROZENDIMENSION 				then return oppstatdrop([0,0,0,0,1,0,0])
			when :CAVE,:DIMENSIONAL,:DEEPEARTH,:CONCERT1,:CONCERT2,:CONCERT3,:CONCERT4 	then return flinchcode()
			when :FACTORY,:UNDERWATER,:DESERT 						then return oppstatdrop([1,0,0,0,0,0,0])
			when :WASTELAND 										then return (paracode() + poisoncode() + burncode() + freezecode()) / 4
			when :CRYSTALCAVERN 									then return (confucode() + poisoncode() + burncode() + sleepcode()) / 4
			when :MIRROR,:FLOWERGARDEN1,:FLOWERGARDEN2				then return oppstatdrop([0,0,0,0,0,0,1])
			when :FLOWERGARDEN3,:FLOWERGARDEN4						then return oppstatdrop([0,1,0,1,0,0,1])
			when :FLOWERGARDEN5										then return oppstatdrop([0,2,0,2,0,0,2])
			when :NEWWORLD 											then return oppstatdrop([1,1,1,1,1,1,1])
			when :INVERSE, :PSYTERRAIN, :SKY						then return confucode()
			when :BEWITCHED											then return (paracode() + poisoncode() + sleepcode()) / 3
			when :HAUNTED											then return spoopycode()
			when :COLOSSEUM											then return selfstatboost([1,0,0,0,0,0,0])
			else 			return paracode()
		end
	end

	def nevermisscode(score)
		miniscore=1.0
		miniscore*=1.05 if score>=110																														# Lawds Mod - Dust Devil, Wildfire
		return miniscore if @attacker.ability== :NOGUARD || @opponent.ability== :NOGUARD || (@attacker.ability==:FAIRYAURA && @battle.FE == :FAIRYTALE) || (@attacker.ability==:DUSTDEVIL && (@battle.pbWeather == :SANDSTORM || [:DESERT, :ASHENBEACH].include?(@battle.FE))) || (attacker.ability== :WILDFIRE && (@battle.pbWeather == :SUNNYDAY || @battle.FE==:INFERNAL))
		miniscore*= (1 - 0.05*@attacker.stages[PBStats::ACCURACY]) if @attacker.stages[PBStats::ACCURACY]<0
		miniscore*= (1 + 0.05*@opponent.stages[PBStats::EVASION]) if @opponent.stages[PBStats::EVASION]>0
		#miniscore*=1.2 if (@mondata.oppitemworks && @opponent.item == :LAXINCENSE) || (@mondata.oppitemworks && @opponent.item == :BRIGHTPOWDER)
		miniscore*=1.3 if accuracyWeatherAbilityActive?(@opponent)
		#miniscore*=3 if opponent.vanished && pbAIfaster?()
		return miniscore
	end

	def lockoncode																																			# Lawds Mod - Dust Devil, Wildfire
		return 0 if @opponent.effects[:LockOn]>0 || @opponent.effects[:Substitute]>0 || @attacker.ability== :NOGUARD && @opponent.ability== :NOGUARD || (@attacker.ability==:FAIRYAURA && @battle.FE == :FAIRYTALE) || (@attacker.ability==:DUSTDEVIL && (@battle.pbWeather == :SANDSTORM || [:DESERT, :ASHENBEACH].include?(@battle.FE)))  || (attacker.ability== :WILDFIRE && (@battle.pbWeather == :SUNNYDAY || @battle.FE==:INFERNAL))
		miniscore=1.0
		miniscore*=3 if @attacker.pbHasMove?(:INFERNO) || @attacker.pbHasMove?(:ZAPCANNON) || @attacker.pbHasMove?(:DYNAMICPUNCH)
		miniscore*=10 if @attacker.pbHasMove?(:GUILLOTINE) || @attacker.pbHasMove?(:SHEERCOLD) || @attacker.pbHasMove?(:GUILLOTINE) || @attacker.pbHasMove?(:FISSURE) || @attacker.pbHasMove?(:HORNDRILL)
		ministat = (@attacker.stages[PBStats::ACCURACY]<0) ? @attacker.stages[PBStats::ACCURACY] : 0
		miniscore*=1 + 0.1*ministat
		miniscore*=1 + 0.1*@opponent.stages[PBStats::EVASION]
		return miniscore
	end

	def forecode5me #after doing hundreds of these this is how i survive
		return 0 if @opponent.effects[:Foresight]
		ministat = (@opponent.stages[PBStats::EVASION]>0) ? @opponent.stages[PBStats::EVASION] : 0
		miniscore=1+0.10*ministat
		if @opponent.hasType?(:GHOST)
			miniscore*=1.5
			miniscore*=5 if @attacker.ability != :SCRAPPY && !@attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.basedamage > 0 && moveloop.pbType(@attacker) != :NORMAL && moveloop.pbType(@attacker) != :FIGHTING}
		end
		return miniscore
	end

	def miracode
		return 0 if @opponent.effects[:MiracleEye]
		ministat = (@opponent.stages[PBStats::EVASION]>0) ? @opponent.stages[PBStats::EVASION] : 0
		miniscore=1+0.10*ministat
		if @opponent.hasType?(:DARK)
			miniscore*=1.1
			miniscore*=2 if !@attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.basedamage > 0 && moveloop.pbType(@attacker) != :PSYCHIC}
		end
		return miniscore
	end

	def chipcode
		ministat = 0
		ministat+=@opponent.stages[PBStats::EVASION] if @opponent.stages[PBStats::EVASION]>0
		ministat+=@opponent.stages[PBStats::DEFENSE] if @opponent.stages[PBStats::DEFENSE]>0
		ministat+=@opponent.stages[PBStats::SPDEF]   if @opponent.stages[PBStats::SPDEF]>0
		miniscore=1 + 0.05*ministat
		return miniscore
	end


	def protectcode
		return 0 if @opponent.ability== :UNSEENFIST
		return 0 if @attacker.effects[:ProtectRate] > 0
		speedboost = @attacker.ability== :SPEEDBOOST || 
					(@battle.FE==:INFERNAL && @attacker.ability==:STEADFAST && !@attacker.isAirborne?) || 
					(@attacker.ability== :MOTORDRIVE && @battle.FE==:ELECTERRAIN) ||
					(@attacker.ability== :STEAMENGINE && [:VOLCANIC,].include?(@battle.FE))
		miniscore = 1.0
		miniscore*=0.6 if !speedboost
		miniscore*= 1.3 if @battle.trickroom > 0 && !pbAIfaster?()
		miniscore*= 1.3 if @battle.field.duration > 0 && getFieldDisruptScore(@attacker,@opponent) > 1.0
		miniscore*= 1.5 if @attacker.pbOpposingSide.screenActive?
		miniscore*= 1.6 if @attacker.pbOpposingSide.effects[:Tailwind] > 0
		miniscore*= 0.3 if @opponent.moves.any? {|moveloop| moveloop!=nil && (PBStuff::SETUPMOVE).include?(moveloop.move)}
		miniscore*=1.3 if @attacker.effects[:SuckerPunch] && !pbAIfaster?() # LAWDS new sucker punch
		if @attacker.crested == :MAGMORTAR
			miniscore*=volcanoeruptioncode # free volcanic eruption!
			if @attacker.ability== :MAGMAARMOR # LAWDS - magmortar crest to get defensive boosts
				if @attacker.effects[:ProtectRate] < 1
					miniscore*=2.0 
					if !(hasgreatmoves && pbAIfaster?())
						miniscore*=2.0 
						miniscore*=2.0 if !@battle.doublebattle
						maxdam = checkAIdamage()
						miniscore*=2.0 if maxdam > @attacker.hp
						miniscore*=2.0 if @attacker.pbPartner.ability==:STALL
						miniscore*=5.0 if !@battle.doublebattle && maxdam > @attacker.hp
					end
				end
			end
		end

		miniscore*= (1 + (@attacker.pbFaintedPokemonCount*0.40)) if @attacker.crested == :SPIRITOMB && @attacker.effects[:ProtectRate] == 0 # LAWDS - add consideration to the enormous healing on spiritomb crest
		if ((@opponent.pbHasMove?(:FIRSTIMPRESSION) && @battle.FE != :COLOSSEUM) || @opponent.crested == :FERALIGATR) && @opponent.turncount == 0 && !prioBlocked?() && @move.function != 0x188 # LAWDS - playing around first impression and fera crest
			should_protect=false
			if @opponent.crested!=:FERALIGATR
				fimp_move = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(:FIRSTIMPRESSION),@opponent)
				damage = pbRoughDamage(fimp_move,@opponent,@attacker,false)
				damage = 0 if @attacker.pbPartner.effects[:FollowMe]==true && @opponent.ability!=:STALWART
				should_protect = damage >= @attacker.hp
			end
			if (should_protect || (@opponent.crested == :FERALIGATR && checkAIdamage()>=(@opponent.hp-1)))
				miniscore*= 5.0
				miniscore*=2.0 if @mondata.roles.include?(:SWEEPER) # more likely to click this if you're trying to sweep
				miniscore*=10.0 if !(@opponent.pbHasMove?(:AGILITY) || @opponent.pbHasMove?(:DRAGONDANCE) || @opponent.pbHasMove?(:QUIVERDANCE) || @opponent.pbHasMove?(:ROCKPOLISH)) && @attacker.effects[:ProtectRate] == 0 # it's a much safer click in singles unless fera is gonna try to abuse it to set up
			end
		end

		if speedboost && !pbAIfaster?() && @battle.trickroom==0
			miniscore*=3 if @attacker.effects[:ProtectRate] == 0
			#experimental -- cancels out drop if killing moves
			if @initial_scores.length>0
				miniscore*=6 if hasgreatmoves()
				miniscore*=6 if checkAIdamage() >= @attacker.hp
			end
			#end experimental
		end
		
		miniscore*=4 if @attacker.ability== :SLOWSTART && @attacker.turncount<5 && @battle.FE!=:DEEPEARTH
		miniscore*=(1.2*hpGainPerTurn) if hpGainPerTurn > 1
		miniscore*=1.1 if hpGainPerTurn > 1 && @attacker.pbHasMove?(:RAGEFIST) # LAWDS Mod - value chip healing more if you have Rage Fist
		miniscore*=0.1 if (hpGainPerTurn-1) * @attacker.totalhp - @attacker.hp < 0 && (hpGainPerTurn(@opponent)-1) * @opponent.totalhp - @opponent.hp > 0
		if @opponent.status== :POISON || @opponent.status== :BURN || @opponent.effects[:SaltCure] # Gen 9 Mod - Added Salt Cure
			miniscore*=1.2
			miniscore*=1.3 if @opponent.effects[:Toxic]>0
			# Gen 9 Mod - Additional Checks for Salt Cure
			miniscore*=1.2 if @opponent.effects[:SaltCure] && @opponent.ability != :MAGICGUARD
			miniscore*=1.2 if @opponent.effects[:SaltCure] && @opponent.ability != :MAGICGUARD && (@opponent.hasType?(:WATER) || @opponent.hasType?(:STEEL))
		end
		if @attacker.status== :POISON || @attacker.status== :BURN || @attacker.effects[:SaltCure] # Gen 9 Mod - Added Salt Cure
			miniscore*=0.7
			miniscore*=0.3 if @attacker.effects[:Toxic]>1
			# Gen 9 Mod - Additional Checks for Salt Cure
			miniscore*=0.6 if @attacker.effects[:SaltCure] && @attacker.ability != :MAGICGUARD
			miniscore*=0.6 if @attacker.effects[:SaltCure] && @attacker.ability != :MAGICGUARD && (@attacker.hasType?(:WATER) || @attacker.hasType?(:STEEL))
		end
		miniscore*=1.3 if @opponent.effects[:LeechSeed]>=0
		miniscore*=4 if @opponent.effects[:PerishSong]!=0
		if (PBStuff::TRAPPINGABILITIESAI.include?(@attacker.ability) || (@attacker.ability== :MAGNETPULL && @opponent.hasType?(:STEEL))  || @opponent.effects[:MeanLook])
			miniscore*=4 if @opponent.effects[:PerishSong]==3
			miniscore*=8 if @opponent.effects[:PerishSong]==1
		end
		if @opponent.effects[:FutureSight] == 1
			miniscore *= 4
			if @battle.FE == :STARLIGHT || @battle.FE == :NEWWORLD
				miniscore *= 4
			end
		end
		miniscore*=0.3 if @opponent.status== :SLEEP || @opponent.status== :FROZEN
		if @opponent.vanished
			miniscore*=12
			miniscore*=1.5 if !pbAIfaster?()
		end
		miniscore*=0.2 if checkAImoves(PBStuff::PROTECTIGNORINGMOVE)
		if @attacker.effects[:Wish]>0 && @attacker.turncount > 0
			miniscore*= checkAIdamage()>=@attacker.hp ? 15 : 2
		end
		miniscore/=(@attacker.effects[:ProtectRate]*2.0) if @attacker.effects[:ProtectRate] > 0
		miniscore*=0.7 if @attacker.effects[:ProtectRate] > 0 && @battle.doublebattle
		if @move.function == 0x133 || @move.function == 0x188 # obstruct now
			miniscore*=0.1 if checkAImoves([:WILLOWISP,:THUNDERWAVE,:TOXIC])
		end
		miniscore*=2 if (@attacker.ability==:STALL || @attacker.pbPartner.ability==:STALL) && miniscore > 1 # lawds
		# lawds
		if (checkAIdamage() + checkAIdamage(@attacker,@opponent.pbPartner)) >= @attacker.hp && @attacker.effects[:FollowMe]==true
			miniscore*=10
			miniscore*=6 if hasgreatmoves && checkAIdamage(@opponent,@attacker.pbPartner)>=@opponent.hp
		end
		return miniscore
	end

	def protecteffectcode
		return 0 if seedProtection?(@attacker)
		miniscore = protectcode
		miniscore*=1.5 if @opponent.turncount==0
		miniscore*=1.3 if getAIMemory().any?{|moveloop| moveloop!=nil && moveloop.contactMove?}
		return miniscore
	end

	def feintcode
		return 1 if !checkAImoves(PBStuff::PROTECTMOVE)
		miniscore = 1.1
		miniscore*=1.2 if !PBStuff::RATESHARERS.include?(@opponent.lastMoveUsed)
		return miniscore
	end

	def mirrorcode(copycat=false)
		return 0 if @opponent==false
		if copycat
			return 0 if !@battle.previousMove.is_a?(Symbol)
			mirrmove = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(@battle.previousMove.intern),@attacker)
		else
			return 0 if !@opponent.lastMoveUsed.is_a?(Symbol)
			mirrmove = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(@opponent.lastMoveUsed.intern),@attacker)
		end
		return 0 if mirrmove.canMirror?
		miniscore = [pbRoughDamage(mirrmove) / @opponent.hp.to_f, 100].min
		#score = pbGetMoveScore(mirrmove,@attacker,@opponent,@mondata.skill,rough)
		miniscore*=0.5 if !pbAIfaster?() && @attacker.ability != :PRANKSTER
		return miniscore
	end

	def yousecondcode
		return 0 if !pbAIfaster?(@move)
		miniscore = 1.0
		miniscore*= (checkAImoves(PBStuff::SETUPMOVE)) ? 0.8 : 1.5
		if checkAIpriority()
			miniscore*=0.6
		else
			miniscore*=1.5
		end
		miniscore*= (checkAIdamage()/(1.0*@opponent.hp)>@initial_scores.max) ? 2 : 0.5 if @opponent.hp>0 && @initial_scores.length>0
		return miniscore
	end

	
	
	def coatcode
		miniscore=1.0
		if @attacker.lastMoveUsed==:MAGICCOAT
			miniscore*=0.5
		else
			miniscore*=1.5 if @attacker.hp==@attacker.totalhp
			miniscore*=3 if !@opponent.moves.any? {|moveloop| moveloop!=nil && moveloop.basedamage>0}
		end
		return miniscore
	end

	def snatchcode
		return 0 if @attacker.turncount > 1 || @attacker.lastMoveUsed==:SNATCH
		miniscore=1.0
		if @attacker.lastMoveUsed==:SNATCH
			miniscore*=0.5
		else
			miniscore*=1.5 if @opponent.hp==@opponent.totalhp
			miniscore*=2 if checkAImoves(PBStuff::SETUPMOVE)
			if @opponent.attack>@opponent.spatk
				miniscore*= (@attacker.attack>@attacker.spatk) ? 1.5 : 0.7
			else
				miniscore*= (@attacker.spatk>@attacker.attack) ? 1.5 : 0.7
			end
			if @battle.FE == :BACKALLEY
				subscore = selfstatboost([2,0,0,0,0,0,0]) +selfstatboost([0,2,0,0,0,0,0]) + selfstatboost([0,0,2,0,0,0,0]) +selfstatboost([0,0,0,2,0,0,0]) +selfstatboost([0,0,0,0,2,0,0])
				subscore/=5
				miniscore *= subscore
			end
		end
		return miniscore
	end

	def specialprotectcode
		return 0 if @opponent.ability== :UNSEENFIST
		miniscore = 1.0
		miniscore/=(@attacker.effects[:ProtectRate]*2.0) if @attacker.effects[:ProtectRate] > 0
		miniscore*=2 if @battle.doublebattle
		miniscore*=0.3 if checkAIdamage() || checkAImoves(PBStuff::SETUPMOVE)
		miniscore*=0.1 if checkAImoves(PBStuff::PROTECTIGNORINGMOVE)
		if @attacker.effects[:Wish]>0
			miniscore*=2 if checkAIdamage()>@attacker.hp || (@attacker.pbPartner.hp*(1.0/@attacker.pbPartner.totalhp))<0.25
		end
		return miniscore
	end

	def sleeptalkcode(initialscores=[])
		return 5 if @attacker.ability==:COMATOSE && @attacker.item == :CHOICEBAND
		if @attacker.ability!=:COMATOSE
			return 0 if @attacker.status!=:SLEEP || @attacker.statusCount<=1
		end
		if !@attacker.pbHasMove?(:SNORE) # lawds improved sleep talk code
			talkscore = 5
			talkscore*=2 if hasgreatmoves()
			talkscore*=restcode()/2 if @attacker.pbHasMove?(:REST) && @battle.FE==:GLITCH
			return talkscore
		end
		otherscores = 0
		for i in 0..3
			currentid = @attacker.moves[i].move || nil
			next if currentid.nil? || currentid == :SLEEPTALK
			snorescore = initialscores[i] if currentid == :SNORE
			otherscores += initialscores[i] if currentid != :SNORE
		end
		otherscores *= 0.5
		return 0.1 if otherscores<snorescore
		return 5
	end

	def metronomecode(scorethreshold)
		return 0 if @attacker.pbNonActivePokemonCount > 0
		return @initial_scores.any?{|scores| scores > scorethreshold} ? 0.5 : 1.5
	end

	def tormentcode
		return @move.basedamage > 0 ? 1 : 0 if @opponent.effects[:Torment] || ((@opponent.ability== :AROMAVEIL || @opponent.pbPartner.ability== :AROMAVEIL || (@opponent.ability== :MINDSEYE && @battle.FE==:PSYTERRAIN)) && !moldBreakerCheck(@attacker,@move))
		if @opponent.lastMoveUsed.is_a?(Symbol)
			oldmove = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(@opponent.lastMoveUsed.intern),@opponent)
		else
			oldmove = -1
		end
		miniscore = 1.0
		miniscore*= pbAIfaster?(@move) ? 1.2 : 0.7
		if oldmove!=-1 && oldmove.basedamage > 0
			miniscore*=1.5
			bestmove, maxdam = checkAIMovePlusDamage()
			if oldmove!=-1 && bestmove.move == oldmove.move
				miniscore*=1.3
				miniscore*=1.5 if maxdam*3<@attacker.totalhp
			end
			miniscore*=1.5 if @attacker.moves.any? {|moveloop| moveloop!=nil && (PBStuff::PROTECTMOVE).include?(moveloop.move)} && @opponent.ability != :UNSEENFIST
			miniscore*=1.3 if hpGainPerTurn>1
		else
			miniscore*=0.5
		end
		return miniscore
	end

	def imprisoncode
		return 0 if @opponent.effects[:Imprison]
		miniscore = 1.0
		subscore = 1
		ourmoves = Array.new(@attacker.moves.length)
		for i in 0..3
			ourmoves[i] = @attacker.moves[i].move
		end
		miniscore*=1.3 if ourmoves.include?(@opponent.lastMoveUsed)
		for j in getAIMemory()
			if ourmoves.include?(j.move)
				subscore+=1
				miniscore*=1.5 if j.isHealingMove?
			else
				miniscore*=0.7
			end
		end
		miniscore*=subscore
		return miniscore
	end

	def disablecode
		return 0 if @opponent.effects[:Disable]>0 || ((@opponent.ability== :AROMAVEIL || @opponent.pbPartner.ability== :AROMAVEIL || (@opponent.ability== :MINDSEYE && @battle.FE==:PSYTERRAIN)) && !moldBreakerCheck(@attacker,@move))
		if @opponent.lastMoveUsed.is_a?(Symbol)
			oldmove = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(@opponent.lastMoveUsed.intern),@opponent)
		else
			oldmove = -1
		end
		return 0 if oldmove == -1 && pbAIfaster?(@move,nil)
		miniscore=1.0
		miniscore*= (oldmove!=-1 && pbAIfaster?(@move,oldmove)) ? 1.2 : 0.7
		if oldmove!=-1 && (oldmove.basedamage>0 || oldmove.isHealingMove?)
			miniscore*=1.5
			bestmove, maxdam = checkAIMovePlusDamage()
			if bestmove.move == oldmove.move
				miniscore*=1.3
				miniscore*=1.5 if maxdam*3 < @attacker.totalhp && opponent.pbPartner.hp <= 0
				miniscore*=1.5 if maxdam*3 > @attacker.totalhp && opponent.pbPartner.hp > 0
			end
		else
			miniscore*=0.5
		end
		return miniscore
	end

	# LAWDS general improvements to tauntcode
	def tauntcode
		return @move.basedamage > 0 ? 1 : 0 if @opponent.effects[:Taunt]>0 || @opponent.hasWorkingItem(:ASSAULTVEST) || ((@opponent.ability== :OBLIVIOUS || @opponent.ability== :AROMAVEIL || @opponent.pbPartner.ability== :AROMAVEIL || (@opponent.ability== :MINDSEYE && @battle.FE==:PSYTERRAIN)) && !moldBreakerCheck(@attacker,@move))
		nonattackmove=false
		for move in @opponent.moves
			if move.basedamage==0
				nonattackmove=true
				break
			end
		end
		return @move.basedamage > 0 ? 1 : 0 if !nonattackmove
		miniscore = 0.8
		miniscore*=1.5 if @opponent.pbHasMove?(:TOXICSPIKES) && @attacker.pbOwnSide.effects[:ToxicSpikes]<2 && @battle.opponent && !@battle.opponent.is_a?(Array) && @battle.opponent.trainertype==:QUEENSROYAL
		atkmove = @attacker.ability==:PRANKSTER ? @move : nil
		oppmove = @opponent.ability==:PRANKSTER ? @move : nil
		miniscore*= pbAIfaster?(atkmove,oppmove) ? 1.5 : 0.5
		if pbGetMonRoles(@opponent).include?(:LEAD)
			miniscore*=1.2
		else
			miniscore*=0.8
		end
		maxdmg = checkAIdamage(@opponent,@attacker)
		if checkAIhealing
			miniscore*=1.3 
			miniscore*=2 if maxdmg < @opponent.totalhp/2
		end 
		if @opponent.pbHasMove?(:HAZE)
			for stat in 1...@attacker.stages.length
				next if !(@attacker.stages[stat] > 0)
				multiplier = [PBStats::ATTACK, PBStats::SPATK, PBStats::SPEED].include?(stat) ? 0.2 : 0.1
				miniscore*=(1 + (multiplier*@attacker.stages[stat]))
			end
		end
		# LAWDS taunt on will-o-wisp pokemon
		if @opponent.pbHasMove?(:WILLOWISP) && @attacker.pbCanBurn?(false, false) && ![:GUTS,:QUICKFEET].include?(@attacker.ability) && @attacker.attack > @attacker.spatk*1.1 && !(@opponent.ability==:PRANKSTER && @attacker.hasType?(:DARK) && @battle.FE!=:BEWITCHED) && !(@battle.FE==:ROCKY && @attacker.stages[PBStats::DEFENSE]>0)
			willomove = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(:WILLOWISP),@opponent)
			miniscore*=5 if (maxdmg < @opponent.hp && pbAIfaster?(@move,willomove))
		end

		miniscore*=1.2 if @attacker.pbHasMove?(:RAGEFIST) # LAWDS Mod - cmon hit me. fucking hit me
		miniscore *= 0.6 if @battle.doublebattle
		return miniscore
	end

	def healblockcode
		if @opponent.effects[:HealBlock]==0 # LAWDS for psychic noise
			return @move.basedamage == 0 ? 0 : 1
		end
		miniscore = 1.0
		miniscore*=1.5 if pbAIfaster?(@move)
		miniscore*=2.5 if checkAIhealing()
		miniscore*=((hpGainPerTurn(@opponent))*4)
		return miniscore
	end

	def encorecode
		return 0 if @opponent.effects[:Encore]>0 || ((@opponent.ability== :AROMAVEIL || @opponent.pbPartner.ability== :AROMAVEIL || (@opponent.ability== :MINDSEYE && @battle.FE==:PSYTERRAIN)) && !moldBreakerCheck(@attacker,@move))
		return 0.2 if  !@opponent.lastMoveUsed.is_a?(Symbol)
		return 0 if [:WIDEGUARD,:QUICKGUARD,:REVIVALBLESSING].include?(@opponent.lastMoveUsed)
		oldmove = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(@opponent.lastMoveUsed.intern),@opponent)
		miniscore = 1.0
		miniscore*=1.5 if [:BIGTOP,:CONCERT1,:CONCERT2,:CONCERT3,:CONCERT4].include?(@battle.FE)
		miniscore*= pbAIfaster?(@move,oldmove) || oldmove.basedamage==0 ? 2.0 : 0.2
		miniscore*=0.3 if pbRoughDamage(oldmove,@opponent,@attacker,false) > @attacker.hp

		# Lawds Mod 6/18/2024 - Improvements to Encore AI. add screens and stuff here
		if (oldmove.move == :FAKEOUT || oldmove.move == :FIRSTIMPRESSION || oldmove.move == :SNATCH || (oldmove.move == :TAILWIND && @opponent.pbOwnSide.effects[:Tailwind]!=0)) && (pbAIfaster?() || @attacker.ability== :PRANKSTER)
			miniscore*=5
		elsif pbRoughDamage(oldmove,@opponent,@attacker) * 4 > @attacker.hp
			miniscore*=0.3 
		elsif @opponent.stages[PBStats::SPEED]>0
			if ((@opponent.hasType?(:DARK) && @battle.FE!=:BEWITCHED) || @attacker.ability != :PRANKSTER || @opponent.ability== :SPEEDBOOST)
				miniscore*=0.5
			else
				miniscore*=2
			end
		else
			miniscore*=2
		end
		return miniscore
	end

	def multihitcode
		miniscore = 1.0
		miniscore*=0.7 if @move.contactMove? && ((@mondata.oppitemworks && @opponent.item == :ROCKYHELMET) || @opponent.ability== :IRONBARBS || @opponent.ability== :ROUGHSKIN)
		miniscore*=1.3 if notOHKO?(@opponent, @attacker, true)
		miniscore*=1.3 if @opponent.effects[:Substitute]>0
		#miniscore*=1.3 if @attacker.itemWorks? && (@attacker.item == :RAZORFANG || @attacker.item == :KINGSROCK)	# lawds fuck kings rock
		return miniscore
	end

	def beatupcode(score) # only partner else multihit is used
		return 0 if @battle.pbPokemonCount(@battle.pbPartySingleOwner(@attacker.index))<1
		return 0 if @opponent.ability != :JUSTIFIED || @opponent.stages[PBStats::ATTACK]>3 || !@opponent.moves.any? {|moveloop| !moveloop.nil? && moveloop.pbIsPhysical?()} || pbRoughDamage > @opponent.hp
		score = 100-score
		if pbAIfaster?(nil, nil, @opponent, @attacker.pbOpposing1) && pbAIfaster?(nil, nil, @opponent, @attacker.pbOpposing2)
			score*=1.3
		else
			score*=0.7
		end
		return score
	end

	def hypercode()
		return 2 if !@battle.doublebattle && (!@battle.opponent.nil? && @battle.opponent.trainertype==:ZEL)
		miniscore = 1.0
		miniscore*=1.3 if @initial_scores[@score_index] >=110 && @battle.FE == :GLITCH
		if @initial_scores[@score_index] < 100
			
			miniscore*=0.5
			miniscore*=0.5 if checkAIhealing()
		end
		return miniscore if @battle.FE == :GLITCH # Glitch Field

		if @initial_scores.length>0
			miniscore*=0.3 if hasgreatmoves()
		end

		yourpartycount = @battle.pbPokemonCount(@battle.pbPartySingleOwner(@attacker.index))
		theirpartycount = @battle.pbPokemonCount(@battle.pbParty(@opponent.index))
		if theirpartycount > 1
			miniscore*=(10 -theirpartycount)*0.1
		else
			miniscore*=1.1
		end
		miniscore*=0.5 if @battle.doublebattle
		miniscore*=0.7 if theirpartycount>1 && yourpartycount==1

		return miniscore
	end

	def weaselslashcode
		miniscore = 1.0
		# lawds early bird
		return 1.0 if @attacker.ability==:EARLYBIRD
		if @attacker.item == :POWERHERB 
			miniscore=1.2 if !hasgreatmoves() && @move.move != :GEOMANCY
			miniscore=1.8 if @attacker.ability== :UNBURDEN
			return miniscore
		end
		return 0 if @attacker.effects[:Torment] # lawds dont try to use these if you're tormented and cant bypass the charge turn, it will fail
		if checkAIdamage()>@attacker.hp
			miniscore*=0.1 
		elsif (checkAIdamage()*2)>@attacker.hp
			if !pbAIfaster?(@move) 
				miniscore*=0.1 
			else
				miniscore*=0.7 
			end
		end
		miniscore*=0.6 if @attacker.hp/@attacker.totalhp.to_f<0.5
		if @opponent.effects[:TwoTurnAttack]!=0
			miniscore*= pbAIfaster?(@move) ? 2 : 0.5
		end
		miniscore*=0.1 if @initial_scores.any? {|score| score > 100}
		miniscore*=0.5 if @battle.doublebattle
		if @move.basedamage > 0
			miniscore*=0.1 if checkAImoves(PBStuff::PROTECTMOVE) && !(@move.contactMove? && @attacker.ability== :UNSEENFIST)
			miniscore*=0.7 if @initial_scores[@score_index] < 100
		elsif # probably geomancy
			miniscore*=0.4
		end
		return miniscore
	end

	def twoturncode
		miniscore=1.0
		# lawds early bird
		return 1.0 if @attacker.ability==:EARLYBIRD
		if @attacker.item == :POWERHERB
			miniscore=1.2
			miniscore=1.8 if @attacker.ability== :UNBURDEN
			return miniscore
		end
		if @opponent.status== :POISON || @opponent.status== :BURN || @opponent.effects[:LeechSeed]>=0 || @opponent.effects[:MultiTurn]>0 || @opponent.effects[:Curse] || (@attacker.ability==:STALL || @attacker.pbPartner.ability==:STALL) # lawds stall
			miniscore*=1.2
			# lawds
			oppHPGain = hpGainPerTurn(@opponent)
			miniscore/=oppHPGain if oppHPGain > 0
		else
			miniscore*=0.8 if @battle.pbPokemonCount(@battle.pbPartySingleOwner(@opponent.index))>1
		end
		miniscore*=0.5 if !@attacker.status.nil? || @attacker.effects[:Curse] || @attacker.effects[:Attract]>-1 || @attacker.effects[:Confusion]>0
		miniscore*=hpGainPerTurn()
		miniscore/=
		miniscore*=0.7 if @attacker.pbOwnSide.screenActive? || @attacker.pbOwnSide.effects[:Tailwind]>0 
		miniscore*=1.3 if @opponent.effects[:PerishSong]!=0 && @attacker.effects[:PerishSong]==0
		if pbAIfaster?()
			miniscore*=3 if @opponent.vanished
			miniscore*=1.1
		else
			miniscore*=0.8
			miniscore*=0.5 if checkAIhealing()
			miniscore*=0.7 if checkAIaccuracy()
		end
		return miniscore
	end

	def cooldownmovecode # Blood Moon, Gigaton Hammer
		miniscore = 1.0
		return 1.0 if @attacker.ability==:JUGGERNAUT # lawds
		miniscore *= 0.7 if @opponent.effects[:Substitute] > 0
		miniscore *= 0.95 if hasgreatmoves() # LAWDS if you can kill with some other move, disfavor this one ever so slightly (notably, the score cut is slighter than the one for a kill move that the opponent can safely switch into)
		miniscore *= 0.8 if checkAImoves(PBStuff::PROTECTMOVE) && !unseenFistCheck(@opponent) && @opponent.effects[:ProtectRate] < 1 # Gen 9 Mod - Method that also checks Punching Glove
		miniscore *= 0.9 if checkAImoves([:SUBSTITUTE]) && (!pbAIfaster?(@move) || @opponent.ability== :PRANKSTER)
		miniscore *= 0.8 if checkAImoves(PBStuff::TWOTURNMOVE) && !pbAIfaster?(@move)
		return miniscore
	end

	def firespincode()
		return @move.basedamage > 0 ? 1 : 0 if @initial_scores[@score_index] >= 110 || @opponent.effects[:MultiTurn]!=0 || @opponent.effects[:Substitute]>0
		miniscore=1.0
		miniscore*=1.2
		# lawds favor trapping to increase burning field damage on infernal
		if @battle.FE==:INFERNAL && @opponent.burningFieldPassiveDamage? && (!@opponent.isAirborne?() || @opponent.effects[:infernalPain]) && @opponent.effects[:MeanLook]==0 && 
		(!(@attacker.ability==:ARENATRAP || @attacker.pbPartner.ability==:ARENATRAP || ((@attacker.ability==:SHADOWTAG || @attacker.pbPartner.ability==:SHADOWTAG) && !@opponent.hasType?(:GHOST))) || @opponent.ability==:RUNAWAY) && @opponent.pbNonActivePokemonCount > 0
			multiplier = (PBTypes.twoTypeEff(:FIRE,@opponent.type1,@opponent.type2)).to_f
			multiplier = multiplier/64
			multiplier*=2 if [:GRASSPELT,:ICEBODY,:FLUFFY,:LEAFGUARD].include?(@opponent.ability)
			multiplier*=2 if [:COMPETITIVE,:DEFIANT].include?(@opponent.ability)
			multiplier*=2 if @opponent.ability==:RATTLED
			multiplier/=2 if @opponent.ability==:JUSTIFIED
			multiplier/=2 if @opponent.ability==:SUPREMEOVERLORD
			multiplier = [multiplier, 0.5].min
			miniscore*=(1.0+multiplier)
		end
		if @initial_scores.length>0
			miniscore*=1.2 if hasbadmoves(30)
		end
		if @opponent.totalhp == @opponent.hp
			miniscore*=1.2
		elsif @opponent.hp*2 < @opponent.totalhp
			miniscore*=0.8
		end
		miniscore*=1-0.05*statchangecounter(@opponent,1,7,1)
		if checkAIdamage()>@attacker.hp
			miniscore*=0.7
		elsif @attacker.hp*3<@attacker.totalhp
			miniscore*=0.7
		end
		miniscore*=1.5 if @opponent.effects[:LeechSeed]>=0 || @attacker.pbHasMove?(:LEECHSEED) # LAWDS also favor it if you can leech seed afterwards.
		# LAWDS make flora's tangrowth like clicking it, this can be generalized to any move that lowers stats
		miniscore*=1.5 if @attacker.pbHasMove?(:UPROOT) && ![:DEFIANT,:COMPETITIVE,:CLEARBODY,:WHITESMOKE,:FULLMETALBODY].include?(@opponent.ability) && !hasgreatmoves()
		miniscore*=1.3 if @opponent.effects[:Attract]>-1
		miniscore*=1.3 if @opponent.effects[:Confusion]>0
		miniscore*=1.2 if @mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL)
		miniscore*=1.1 if @attacker.moves.any? {|moveloop| moveloop!=nil && (PBStuff::PROTECTMOVE).include?(moveloop.move)} && !(@opponent.ability== :UNSEENFIST)
		miniscore*=1.3 if (@mondata.attitemworks && @attacker.item == :BINDINGBAND)
		miniscore*=1.1 if (@mondata.attitemworks && @attacker.item == :GRIPCLAW)
		miniscore*=2 if (@attacker.ability==:STALL || @opponent.ability==:STALL || @attacker.pbPartner.ability==:STALL) && miniscore > 1 # lawds
		return miniscore
	end

	def uproarcode
		miniscore = 1.0
		miniscore*=0.7 if @opponent.status== :SLEEP
		miniscore*=1.8 if checkAImoves([:REST])
		miniscore*=1.1 if @opponent.pbNonActivePokemonCount==0 || PBStuff::TRAPPINGABILITIESAI.include?(@attacker.ability) || (@attacker.ability== :MAGNETPULL && @opponent.hasType?(:STEEL))  || @opponent.effects[:MeanLook]>0
		miniscore*=0.7 if @move.pbTypeModifier(@move.pbType(@attacker),@attacker,@opponent)<4
		miniscore*=0.75 if @attacker.hp/@attacker.totalhp<0.75
		miniscore*=1+0.05*@attacker.stages[PBStats::SPATK] if @attacker.stages[PBStats::SPATK]<0
		return miniscore
	end

	def recovercode(amount=@attacker.totalhp/2.0)
		return 0 if @attacker.effects[:HealBlock]>0
		return 0 if @attacker.effects[:Wish]>0
		miniscore = 1.0
		amount *= 0.67 if @mondata.skill>=BESTSKILL && @battle.FE == :BACKALLEY
		recoverhp = [@attacker.hp + amount,@attacker.totalhp].min # the amount of hp we expect to have after recover
		statnerfmove = false
		for move in @opponent.moves # lawds dont fuck around with stat nerf moves, if they can affect you with one then dont heal if you have a kill and are faster.
			next if !(PBStuff::STATNERFMOVE).include?(move.move) && !(@battle.FE==:ROCKY && ([:ROCKSMASH,:NATUREPOWER].include?(move.move) || @opponent.ability==:TOUGHCLAWS))
			next if [:CLEARBODY,:WHITESMOKE,:INDUSTRYSTANDARD,:FULLMETALBODY].include?(@attacker.ability) && !moldBreakerCheck(@opponent,move)
			next if @battle.FE==:ROCKY && ([:ROCKSMASH,:NATUREPOWER,:TRIPLEARROWS,:SCREECH,:TAILWHIP,:LEER,:FIRELASH,:GRAVAPPLE,:THUNDEROUSKICK].include?(move.move) || (@opponent.ability==:TOUGHCLAWS && !((PBStuff::STATNERFMOVE).include?(move.move)))) && [:SHELLARMOR,:BATTLEARMOR].include?(@attacker.ability) && !moldBreakerCheck(@opponent,move)
			next if @attacker.ability==:GOODASGOLD && move.category==:status && !moldBreakerCheck(@opponent,move)
			next if @attacker.ability==:CONTRARY
			next if @attacker.itemWorks? && @attacker.item==:CLEARAMULET
			next if pbTypeModNoMessages(move.pbType(@opponent),@opponent,@attacker)<=0
			statnerfmove = true
		end
		if @mondata.skill>=BESTSKILL
			bestmove, maxdam = checkAIMovePlusDamage()
			if hasgreatmoves() && pbAIfaster?(nil,bestmove) # lawds see above, if we can outspeed and kill then dont fuck around with healing especially if we can just KO
				miniscore *= 0.8
				miniscore*= 0.6 if statnerfmove
			end
			if !@battle.doublebattle # lawds
				if pbAIfaster?(@move,bestmove)
				  hpafterturn =  [(recoverhp - maxdam + (hpGainPerTurn(@attacker,true))*@attacker.totalhp).floor, @attacker.totalhp].min
				  return 0 if hpafterturn < @attacker.hp && ((@opponent.hp + (hpGainPerTurn(@opponent,true)*@opponent.totalhp)) > 0)
				  return 0 if maxdam > recoverhp
				else
				  return 0 if maxdam > @attacker.hp
				  recoverhp = [@attacker.hp - maxdam + amount, @attacker.totalhp].min
				  hpafterturn = [recoverhp + (hpGainPerTurn(@attacker,true)*@attacker.totalhp).floor,@attacker.totalhp].min
				  return 0 if maxdam > recoverhp && ((@opponent.hp + (hpGainPerTurn(@opponent,true)*@opponent.totalhp)) > 0)
				end	
			end
			miniscore *= 0.2 if maxdam > amount # we take more damage than we heal
			miniscore *= 0.6 if maxdam > 1.4 * amount && [0x1C, 0x20].include?(bestmove.function)
			if maxdam>@attacker.hp
				if maxdam > recoverhp #if we expect to die after healing, don't bother
					return 0
				else # if we're not going to die, we really want to recover
					miniscore*=5
					if @initial_scores.length>0 && amount > maxdam*1.5 && !statnerfmove # lawds only offset kill moves if we can significantly outheal the damage and cant get stat dropped
						miniscore*=6 if hasgreatmoves() # offset killing moves
					end
				end
			else # if we're not going to die
				miniscore*=2 if maxdam*1.5>@attacker.hp # if a second attack would kill us next turn,
				if !pbAIfaster?(@move) 					# and we're slower, then heal pre-emptively
					if maxdam*2>@attacker.hp
						miniscore*=5
						if @initial_scores.length>0 && amount > maxdam*1.5 && !statnerfmove # lawds only offset kill moves if we can significantly outheal the damage and cant get stat dropped
							miniscore*=6 if hasgreatmoves() # offset killing moves
						end
					end
				end
			end
		elsif @mondata.skill>=MEDIUMSKILL
			miniscore*=3 if checkAIdamage()>@attacker.hp
		end
		yourpartycount = @battle.pbPokemonCount(@battle.pbPartySingleOwner(@attacker.index))
		theirpartycount = @battle.pbPokemonCount(@battle.pbParty(@opponent.index))
		miniscore*=1.1 if yourpartycount == 1
		miniscore*=0.3 if theirpartycount == 1 && hasgreatmoves()
		miniscore*=0.7 if @opponent.moves.any? {|moveloop| moveloop!=nil && (PBStuff::SETUPMOVE).include?(moveloop.move)}
		if (@attacker.hp.to_f)/@attacker.totalhp<0.5
			miniscore*=1.5
			miniscore*=2 if @attacker.effects[:Curse]
			if @attacker.hp*4<@attacker.totalhp
				miniscore*=1.5 if @attacker.status== :POISON
				miniscore*=2 if @attacker.effects[:LeechSeed]>=0
				if @attacker.hp<@attacker.totalhp*0.13
					miniscore*=2 if @attacker.status== :BURN
					miniscore*=2 if (@battle.pbWeather== :HAIL && !@attacker.hasType?(:ICE)) || (@battle.pbWeather== :SANDSTORM && !@attacker.hasType?(:ROCK) && !@attacker.hasType?(:GROUND) && !@attacker.hasType?(:STEEL)) || (@battle.pbWeather== :SHADOWSKY && !@attacker.hasType?(:SHADOW))
				end
			end
		else
			miniscore*=0.9
		end
		if @attacker.effects[:Toxic]>0
			miniscore*=0.5
			miniscore*=0.5 if @attacker.effects[:Toxic]>3
		end
		miniscore*=1.1 if @attacker.status== :PARALYSIS || @attacker.effects[:Attract]>=0 || @attacker.effects[:Confusion]>0
		if @opponent.status== :POISON || @opponent.status== :BURN || @opponent.effects[:LeechSeed]>=0 || @opponent.effects[:Curse]
			miniscore*=1.3
			miniscore*=1.3 if @opponent.effects[:Toxic]>0
		end
		miniscore*=1.3 if checkAImoves(PBStuff::CONTRARYBAITMOVE)
		miniscore*=1.2 if @opponent.vanished || @opponent.effects[:HyperBeam]>0
		return miniscore if move.function == 0xD7 #Wish doesn't do any of the remaining checks
		if ((@attacker.hp.to_f)/@attacker.totalhp)>0.8
			miniscore=0
		elsif ((@attacker.hp.to_f)/@attacker.totalhp)>0.6
			miniscore*=0.6
		elsif ((@attacker.hp.to_f)/@attacker.totalhp)<0.25
			miniscore*=2
		end
		return miniscore
	end

	def wishcode
		miniscore = recovercode
		maxdam = checkAIdamage()
		recoverhp = [@attacker.hp + @attacker.totalhp/2.0,@attacker.totalhp].min # the amount of hp we expect to have after recover
		if @attacker.moves.any? {|moveloop| moveloop!=nil && (PBStuff::PROTECTMOVE).include?(moveloop.move)} && @opponent.ability != :UNSEENFIST # if we have protect
			if (maxdam > @attacker.hp) && (maxdam < recoverhp) && !hasgreatmoves() # and we expect to die, and can't kill the opponent, and we can save ourselves
				miniscore*=4
			else
				miniscore*=0.6
			end
		else # if we don't have protect, we want to be using wish earlier
			miniscore*=2 if (maxdam*2 > @attacker.hp) && maxdam < @attacker.hp && (maxdam * 2 < recoverhp) 
		end
		if @mondata.roles.include?(:CLERIC)
			miniscore*=1.1 if @battle.pbPartySingleOwner(@attacker.index).any?{|i| i.hp.to_f<0.6*i.totalhp && i.hp.to_f>0.3*i.totalhp}
		end
		return miniscore
	end

	def restcode
		return 0 if !@attacker.pbCanSleep?(false,true,true) && (@attacker.status!=:SLEEP && @battle.FE==:GLITCH)
		return 0 if @attacker.hp*(1.0/@attacker.totalhp)>=0.8
		miniscore=1.0
		maxdam = checkAIdamage()
		if maxdam>@attacker.hp && maxdam * 2 < @attacker.totalhp * hpGainPerTurn
			miniscore*=3
		elsif @mondata.skill >= BESTSKILL && maxdam*2 < @attacker.totalhp * hpGainPerTurn
			miniscore*=1.5 if maxdam*1.5>@attacker.hp 
			miniscore*=2 if  maxdam*2>@attacker.hp && !pbAIfaster?()
		end
     	miniscore*=@attacker.hp < 0.5 * @attacker.totalhp ? 1.5 : 0.5
		miniscore*=1.2 if (@mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL))
		if @opponent.status== :POISON || @opponent.status== :BURN || @opponent.effects[:LeechSeed]>=0 || @opponent.effects[:Curse]
			miniscore*=1.3
			miniscore*=1.3 if @opponent.effects[:Toxic]>0
		end
		if @attacker.status== :POISON
			miniscore*=1.3
			miniscore*=1.3 if @opponent.effects[:Toxic]>0
		end
		if @attacker.status== :BURN
			miniscore*=1.3
			miniscore*=1.5 if @attacker.spatk<@attacker.attack
		end
		miniscore*=1.3 if @attacker.status== :PARALYSIS
		miniscore*=1.3 if checkAImoves(PBStuff::CONTRARYBAITMOVE)
		if !(@attacker.item == :LUMBERRY || @attacker.item == :CHESTOBERRY || hydrationCheck(@attacker))
			miniscore*=0.8
			if maxdam*2 > @attacker.totalhp
			  	miniscore*=0.4
			elsif maxdam*3 < @attacker.totalhp
				miniscore*=1.3
				if @initial_scores.length>0
					miniscore*=6 if hasgreatmoves()
				end
			end
			miniscore*=0.7 if checkAImoves([:WAKEUPSLAP,:NIGHTMARE,:DREAMEATER]) || @opponent.ability== :BADDREAMS
			miniscore*=1.3 if @attacker.pbHasMove?(:SLEEPTALK)
			miniscore*=1.2 if @attacker.pbHasMove?(:SNORE)
			miniscore*=1.1 if @attacker.ability== :SHEDSKIN #|| @attacker.ability== :EARLYBIRD
			miniscore*=0.8 if @battle.doublebattle
		else
			if @attacker.item == :LUMBERRY || @attacker.item == :CHESTOBERRY
				miniscore*= @attacker.ability== :HARVEST ? 1.2 : 0.8
			end
		end
		if @attacker.crested == :BASTIODON
			if @attacker.hp*(1.0/@attacker.totalhp)>=0.8
				miniscore*=2 # LAWDS - added a flat boost to rest here
				reflectdamage=maxdam
				reflectdamage=@attacker.hp-1 if maxdam>=@attacker.hp 
				reflectdamage*=0.5
				if (reflectdamage>=@opponent.hp)
					miniscore*=4
					miniscore*=6 if @initial_scores.length>0 && hasgreatmoves() #experimental -- cancels out drop if killing moves
				end
			end
		end
		if !@attacker.status.nil?
			miniscore*=1.4
			miniscore*=1.2 if @attacker.effects[:Toxic]>0
		end
		return miniscore
	end

	def aquaringcode
		return 0 if ((@move.function == 0xda || @move.function == 0x187) && @attacker.effects[:AquaRing]) || (@move.function == 0xdb && @attacker.effects[:Ingrain])
		miniscore = 1.0
		attackerHPpercent = @attacker.hp/@attacker.totalhp
		miniscore*=1.2 if attackerHPpercent>0.75
		if attackerHPpercent<0.50
			miniscore*=0.7
			miniscore*=0.5 if attackerHPpercent<0.33
		end
		miniscore*=1.2 if checkAIhealing()
		miniscore*=1.2 if @attacker.moves.any? {|moveloop| moveloop!=nil && (PBStuff::PROTECTMOVE).include?(moveloop.move)} && @opponent.ability != :UNSEENFIST
		miniscore*=0.8 if @attacker.moves.any? {|moveloop| moveloop!=nil && (PBStuff::PIVOTMOVE).include?(moveloop.move)}
		if checkAIdamage()*5 < @attacker.totalhp && (getAIMemory().length > 0)
			miniscore*=1.2
		elsif checkAIdamage() > @attacker.totalhp*0.4
			miniscore*=0.3
		end
		miniscore*=1.2 if (@mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL) || @mondata.roles.include?(:TANK))
		miniscore*=0.3 if checkAImoves(PBStuff::PHASEMOVE)
		miniscore*=0.5 if @battle.doublebattle
		return miniscore
	end

	def absorbcode(score)
		return @move.basedamage > 0 ? 1 : 0 if (@attacker.hp==@attacker.totalhp && pbAIfaster?(@move) || @opponent.effects[:Substitute]>0)
		return 1 if @attacker.effects[:HealBlock] != 0
		hpdrained = ([score,100].min)*@opponent.hp*0.01/2.0
		hpdrained*= 1.5 if @move.function == 0x139 #Draining Kiss
		hpdrained*= 1.5 if Rejuv && @battle.FE == :ELECTERRAIN && @move.move == :PARABOLICCHARGE
		# lawds infernal bitter blade
		hpdrained*= 1.5 if @battle.FE==:INFERNAL && @move.move==:BITTERBLADE
		if Rejuv && @battle.FE == :GRASSY
			hpdrained*= 1.6 if @attacker.itemWorks? && @attacker.item == :BIGROOT
		else
			hpdrained*= 1.3 if @attacker.itemWorks? && @attacker.item == :BIGROOT
		end
		hpdrained *= 1.3 if @attacker.crested == :SHIINOTIC
		if pbAIfaster?(@move)
			hpdrained = (@attacker.totalhp-@attacker.hp) if hpdrained > (@attacker.totalhp-@attacker.hp)
		else
			maxdam = checkAIdamage()
			hpdrained = (@attacker.totalhp-(@attacker.hp-maxdam)) if hpdrained > (@attacker.totalhp-(@attacker.hp-maxdam))
		end
		miniscore = hpdrained/@opponent.totalhp.to_f
		if @opponent.ability== :LIQUIDOOZE # lawds improved playing against liquid ooze, basically make it not want to kill itself if not necessary
			return 0 if hpdrained >= @attacker.hp && @initial_scores[@score_index] < @initial_scores.max
			miniscore = ((@attacker.totalhp.to_f)-hpdrained)/(@attacker.totalhp.to_f)
			return miniscore
		end
		miniscore*=0.5 if miniscore > 2 #arbitrary multiplier to make it value the HP less.
		miniscore*=1.5 if @attacker.pbHasMove?(:RAGEFIST) && hpdrained >= @attacker.totalhp/4 # Lawds Mod - experimental multiplier to make the AI value healing more if it has Rage Fist and can heal a lot
		miniscore+=1
		return miniscore
	end

	def healpulsecode
		return 0 if @opponent.index != @attacker.pbPartner.index || @attacker.effects[:HealBlock]>0 || @opponent.effects[:HealBlock]>0
		miniscore=1.0
		if @opponent.hp > 0.8*@opponent.totalhp
			if !pbAIfaster?(nil, nil, @attacker, @attacker.pbOpposing1) && !pbAIfaster?(nil, nil, @attacker, @attacker.pbOpposing2)
				miniscore*=0.5
			else
				return 0
			end
		elsif @opponent.hp < 0.7*@opponent.totalhp && @opponent.hp > 0.3*@opponent.totalhp
			miniscore*=3
		elsif @opponent.hp < 0.3*@opponent.totalhp
			miniscore*=1.7
		end
		if @opponent.status== :POISON || @opponent.status== :BURN || @opponent.effects[:LeechSeed]>=0 || @opponent.effects[:Curse]
			miniscore*=0.8
			miniscore*=0.7 if @opponent.effects[:Toxic]>0
		end
		return miniscore
	end

	def lifedewcode(amount=@attacker.totalhp/4.0)
		miniscore = recovercode(amount)
		miniscore += healpulsecode*0.5
		if @move == :JUNGLEHEALING
			miniscore += partyrefreshcode()
		end
		return miniscore
	end

	def deathcode
		miniscore = 1.0
		miniscore*=0.7
		miniscore*=0.3 if ((@opponent.effects[:Disguise] || (@opponent.effects[:IceFace] && (@move.pbIsPhysical? || @battle.FE == :FROZENDIMENSION))) && !moldBreakerCheck(@attacker,@move)) || @opponent.effects[:Substitute]>0
		miniscore*=0.3 if checkAImoves(PBStuff::PROTECTMOVE) && !(@move.contactMove? && @attacker.ability== :UNSEENFIST)
		return miniscore if @move.function == 0xe1 #Final gambit can go home
		if @attacker.hp==@attacker.totalhp
			miniscore*=0.2
		else
			miniscore*=1-(@attacker.hp.to_f/@attacker.totalhp)
			if @attacker.hp*4<@attacker.totalhp
				miniscore*=1.3
				miniscore*=1.4 if (@mondata.attitemworks && @attacker.item == :CUSTAPBERRY)
			end
		end
		miniscore*=1.2 if @mondata.roles.include?(:LEAD)
		return miniscore
	end

	def gambitcode
		miniscore = 0.7
		miniscore*= pbAIfaster?() ? 1.1 : 0.5
		miniscore*= @attacker.hp > @opponent.hp ? 1.1 : 0.5
		miniscore*=0.2 if notOHKO?(@opponent, @attacker, true)
		return miniscore
	end

	def mementcode(score)
		miniscore=1.0
		score = 15 if @initial_scores.length>0 && hasbadmoves(10)
		if @attacker.hp==@attacker.totalhp
			miniscore*=0.2
		else
			miniscore = 1-@attacker.hp*(1.0/@attacker.totalhp)
			miniscore*=1.3 if @attacker.hp*4<@attacker.totalhp
		end
		miniscore*=oppstatdrop([0,0,0,2,2,0,0])
		return miniscore*score
	end

	def grudgecode
		miniscore = 1.0
		damcount = getAIMemory().count {|moveloop| moveloop!=nil && moveloop.basedamage > 0}
		miniscore*=3 if getAIMemory().length >= 4 && damcount==1
		if @attacker.hp==@attacker.totalhp
			miniscore*=0.2
		else
			miniscore*=1-(@attacker.hp/@attacker.totalhp)
			if @attacker.hp*4<@attacker.totalhp
				miniscore*=1.3
				miniscore*=1.4 if (@mondata.attitemworks && @attacker.item == :CUSTAPBERRY)
			end
		end
		miniscore*= pbAIfaster?(@move) ? 1.3 :0.5
		return miniscore
	end

	def healwishcode
		miniscore=1.0
		count=0
		for mon in @battle.pbPartySingleOwner(@opponent.index)
			next if mon.nil?
			count+=1 if mon.hp!=mon.totalhp
		end
		count-=1 if @attacker.hp!=@attacker.totalhp
		return 0 if count==0
		maxscore = 0
		for mon in @battle.pbPartySingleOwner(@opponent.index)
			next if mon.nil?
			if mon.hp!=mon.totalhp
				miniscore = 1 - mon.hp*(1.0/mon.totalhp)
				miniscore*=2 if !mon.status.nil?
				maxscore=miniscore if miniscore>maxscore
			end
		end
		miniscore*=maxscore
		if @attacker.hp==@attacker.totalhp
			miniscore*=0.2
		else
			miniscore*=1-(@attacker.hp/@attacker.totalhp)
			if @attacker.hp*4<@attacker.totalhp
				miniscore*=1.3
				miniscore*=1.4 if (@mondata.attitemworks && @attacker.item == :CUSTAPBERRY)
			end
		end
		miniscore*= pbAIfaster?(@move) ? 1.1 : 0.5
		return miniscore
	end

	def endurecode
		return 0 if @attacker.hp==1
		return 0 if notOHKO?(@attacker, @opponent, true)
		return 0 if (@battle.pbWeather== :HAIL && !@attacker.hasType?(:ICE)) || (@battle.pbWeather== :SANDSTORM && !(@attacker.hasType?(:ROCK) || @attacker.hasType?(:GROUND) || @attacker.hasType?(:STEEL))) || (@battle.pbWeather== :SHADOWSKY && !@attacker.hasType?(:SHADOW))
		return 0 if @attacker.status== :POISON || @attacker.status== :BURN || @attacker.effects[:LeechSeed]>=0 || @attacker.effects[:Curse]
		return 0 if checkAIdamage()<@attacker.hp
		miniscore=1.0
		miniscore*= (pbAIfaster?(nil, nil, @attacker, @opponent.pbPartner)) ? 1.3 : 0.5
		if pbAIfaster?(nil, nil, @attacker, @opponent.pbPartner)
			miniscore*=3 if (@attacker.pbHasMove?(:PAINSPLIT) || @attacker.pbHasMove?(:FLAIL) || @attacker.pbHasMove?(:REVERSAL))
			miniscore*=5 if @attacker.pbHasMove?(:ENDEAVOR)
			miniscore*=5 if @opponent.effects[:TwoTurnAttack]!=0 
		end
		miniscore*=1.5 if @opponent.status== :POISON || @opponent.status== :BURN || @opponent.effects[:LeechSeed]>=0 || @opponent.effects[:Curse]
		miniscore/=(@attacker.effects[:ProtectRate]*2.0) if @attacker.effects[:ProtectRate] > 0
		return miniscore
	end

	def destinycode
		return 0 if @attacker.effects[:DestinyRate] #&& @battle.FE != :HAUNTED	# lawds - this is stupid sorry
		miniscore=1.0
		miniscore*=3 if getAIMemory().length>=4 && getAIMemory().all?{|moveloop| moveloop!=nil && moveloop.basedamage>0}
		miniscore*=0.1 if @initial_scores.length>0 && hasgreatmoves()
		miniscore*= (pbAIfaster?(@move)) ? 1.5 : 0.5
		if @attacker.hp==@attacker.totalhp
			miniscore*=0.2
		else
			miniscore*=1-@attacker.hp*(1.0/@attacker.totalhp)
			if @attacker.hp*4<@attacker.totalhp
				miniscore*=1.3
				miniscore*=1.5 if (@mondata.attitemworks && @attacker.item == :CUSTAPBERRY)
			end
		end
		return miniscore
	end

	def phasecode
		# Gen 9 Mod - Added Guard Dog
		return @move.basedamage > 0 ? 1 : 0 if @opponent.effects[:Ingrain] || @opponent.ability== :SUCTIONCUPS || @opponent.ability== :GUARDDOG || @opponent.pbNonActivePokemonCount==0 || @battle.FE == :COLOSSEUM
		return @move.basedamage > 0 ? 1 : 0 if @opponent.effects[:PerishSong]>0 || @opponent.effects[:Yawn]>0
		miniscore=1.0
		miniscore*=0.8 if pbAIfaster?()
		miniscore*= (1+ 0.1*statchangecounter(@opponent,1,7))
		miniscore*=1.3 if @opponent.status== :SLEEP
		miniscore*=1.3 if @opponent.ability== :SLOWSTART
		miniscore*=1.5 if @opponent.item.nil? && @opponent.unburdened
		miniscore*=0.7 if @opponent.ability== :INTIMIDATE
		# Gen 9 Mod - Discourage phasing when opponent's ability is Supersweet Syrup.
		miniscore*=0.7 if @opponent.ability== :SUPERSWEETSYRUP
		# Gen 9 Mod - Discourage status moves when current opponent has Good as Gold.
		miniscore*=0 if @opponent.ability== :GOODASGOLD && @move.category == :status && !(moldBreakerCheck(@attacker,@move))
		miniscore*=0.7 if @battle.FE == :DIMENSIONAL && (@opponent.ability== :PRESSURE || @opponent.ability== :UNNERVE)
		miniscore*=0.7 if @battle.FE == :CITY && @opponent.ability== :FRISK
		miniscore*=0.7 if @opponent.crested == :THIEVUL
		# Gen 9 Mod - Added Hospitality
		miniscore*=0.5 if @opponent.ability== :REGENERATOR || @opponent.ability== :NATURALCURE || @opponent.ability== :HOSPITALITY
		miniscore*=1.1 if @opponent.pbOwnSide.effects[:ToxicSpikes]>0
		miniscore*=1.4 if @opponent.effects[:Substitute]>0
		miniscore*=(@opponent.pbOwnSide.effects[:StealthRock]) ? 1.3 : 0.8
		miniscore*=(@opponent.pbOwnSide.effects[:Spikes]>0) ? (1.2**@opponent.pbOwnSide.effects[:Spikes]) : 0.8
		return miniscore
	end

	def pivotcode()
		# LAWDS - Last_Ace_Switch is not defined in system constants for some reason, im like 99% sure it was used for lin arceus in reborn, 
		# and got removed cause rejuv doesnt need it. but zetta solosis should be sent last in the same way. so im replacing all checks for Last_Ace_Switch with checks for NameOverwrite. 
		return 0 if @attacker.pbNonActivePokemonCount==1 && $game_switches[:NameOverwrite]
		return @move.basedamage > 0 ? 1 : 0 if @attacker.pbNonActivePokemonCount==0 || @battle.FE == :COLOSSEUM
		miniscore=1.0
		miniscore*=0.7 if @attacker.pbOwnSide.effects[:StealthRock]
		miniscore*=0.6 if @attacker.pbOwnSide.effects[:StickyWeb]
		miniscore*=0.9**@attacker.pbOwnSide.effects[:Spikes] if @attacker.pbOwnSide.effects[:Spikes]>0
		miniscore*=0.9**@attacker.pbOwnSide.effects[:ToxicSpikes] if @attacker.pbOwnSide.effects[:ToxicSpikes]>0
		miniscore*=1.1 if @attacker.ability== :INTIMIDATE
		miniscore*=1.1 if ([:DIMENSIONAL,:FROZENDIMENSION,:DARKCRYSTALCAVERN].include?(@battle.FE)) && (@attacker.ability== :PRESSURE || @attacker.ability== :UNNERVE)
		miniscore*=1.1 if @battle.FE == :CITY && @attacker.ability== :FRISK
		miniscore*=1.1 if @attacker.crested == :THIEVUL
		# Gen 9 Mod - Added Hospitality
		if (@attacker.ability== :REGENERATOR ||@attacker.ability== :HOSPITALITY) && ((@attacker.hp.to_f)/@attacker.totalhp)<0.75
			miniscore*=1.2
			miniscore*=1.2 if @attacker.ability== :REGENERATOR && ((@attacker.hp.to_f)/@attacker.totalhp)<0.5
			miniscore*=1.2 if @attacker.ability== :HOSPITALITY && ((@attacker.pbPartner.hp.to_f)/@attacker.pbPartner.totalhp)<0.5
		end
		if @attacker.ability== :REGENERATOR && ((@attacker.hp.to_f)/@attacker.totalhp)<0.75
			miniscore*=1.3
			miniscore*=1.5 if @attacker.ability== :REGENERATOR && ((@attacker.hp.to_f)/@attacker.totalhp)<0.5
		end
		miniscore*=1.5 if @mondata.partyroles.any? {|role| role.include?(:SWEEPER)} && @move.move == :PARTINGSHOT
		miniscore*=1.2 if @mondata.partyroles.any? {|role| role.include?(:SWEEPER)} && (@move.move == :UTURN || @move.move == :VOLTSWITCH) && !pbAIfaster?()
		movebackup = @move ; attackerbackup = @attacker ; oppbackup = @opponent
		if !(@battle.doublebattle) || @attacker.index==2
			this_switchscore = @mondata.switchscore.length > 0 ? @mondata.switchscore.max : (getSwitchInScoresParty(pbAIfaster?(@move))).max
			miniscore*=0.2 if this_switchscore < 50
		end
		@move = movebackup ; @attacker = attackerbackup ; @opponent = oppbackup
		miniscore*=1.2 if @attacker.effects[:typeChanged] && ![:PROTEAN,:LIBERO].include?(@attacker.ability) && ![:REUNICLUS,:GOTHITELLE].include?(@attacker.crested) # LAWDS - AI favors pivoting if it's had its type changed
		if @move.move == :BATONPASS #Baton Pass
			miniscore*=1+0.3*statchangecounter(@attacker,1,7)
			miniscore*=0 if @attacker.effects[:PerishSong]>0
			miniscore*=1.4 if @attacker.effects[:Substitute]>0
			miniscore*=0.5 if @attacker.effects[:Confusion]>0
			miniscore*=0.5 if @attacker.effects[:LeechSeed]>=0
			miniscore*=0.5 if @attacker.effects[:Curse]
			miniscore*=0.5 if @attacker.effects[:Yawn]>0
			miniscore*=0.5 if @attacker.turncount<1
			miniscore*=1.3 if !@attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.basedamage>0}
			miniscore*=1.2 if @attacker.effects[:Ingrain] || @attacker.effects[:AquaRing]
			if pbAIfaster?(@move)
				miniscore*=1.8 if checkAIdamage() > @attacker.hp && (getAIMemory().length > 0)
			else
				miniscore*=2 if (checkAIdamage()*2) > @attacker.hp && (getAIMemory().length > 0)
			end
		else		#U-turn / Volt Switch / Parting Shot
			miniscore*= 1-0.15*statchangecounter(@attacker,1,7,-1)
			miniscore*=1-0.25*statchangecounter(@attacker,1,7,1)
			miniscore*=1.2 if @mondata.roles.include?(:LEAD)
			miniscore*=1.2 if @mondata.roles.include?(:PIVOT)
			miniscore*=1.2 if pbAIfaster?(@move)
			miniscore*=1.3 if @attacker.effects[:Toxic]>0 || @attacker.effects[:Attract]>-1 || @attacker.effects[:Confusion]>0 || @attacker.effects[:Yawn]>0
			# Gen 9 Mod - Switching out is heavily favored if Salt Cured - Only way to get rid of it.
      		miniscore*=1.2 if @attacker.effects[:SaltCure] && @opponent.ability != :MAGICGUARD
      		miniscore*=1.3 if @attacker.effects[:SaltCure] && @attacker.ability != :MAGICGUARD && (@attacker.hasType?(:WATER) || @attacker.hasType?(:STEEL))
			miniscore*=1.5 if @attacker.effects[:LeechSeed]>-1
			miniscore*=0.5 if @attacker.effects[:Substitute]>0
			miniscore*=1.5 if @attacker.effects[:PerishSong]>0 || @attacker.effects[:Curse]
			if pbAIfaster?(@move)
				@opponent.hp -= pbRoughDamage()
				can_hard_switch = false
				@battle.pbParty(@attacker.index).each_with_index  {|mon, monindex|
					next if mon.nil? || mon.hp <= 0
					next if !@battle.pbIsOwner?(@attacker.index,monindex) && !@battle.pbIsOpposing?(@attacker.index)

					can_hard_switch = true if shouldHardSwitch?(@attacker, monindex)
				}
				miniscore *= 0.2 if !can_hard_switch && @opponent.hp > 0
			end
		end
		miniscore*=0.5 if hasgreatmoves()
		if hasbadmoves(25)
			miniscore*=2
		elsif hasbadmoves(40)
			miniscore*=1.2
		end
		return miniscore
	end

	def meanlookcode
		miniscore=1.0
		if @opponent.effects[:MeanLook]>=0 || @opponent.effects[:Ingrain] ||
			(@opponent.hasType?(:GHOST) && @move.move == :THOUSANDWAVES) ||
			secondaryEffectNegated?() || @opponent.effects[:Substitute]>0 || @battle.pbPokemonCount(@battle.pbPartySingleOwner(@opponent.index))==1
			return (@move.basedamage > 0) ? miniscore : 0
		end
		miniscore*=0.1 if checkAImoves(PBStuff::PIVOTMOVE)
		miniscore*=0.1 if @opponent.ability== :RUNAWAY
		miniscore*=1.5 if @attacker.pbHasMove?(:PERISHSONG)
		miniscore*=4   if @opponent.effects[:PerishSong]>0
		miniscore*=0   if PBStuff::TRAPPINGABILITIESAI.include?(@attacker.ability) || (@attacker.ability== :MAGNETPULL && @opponent.hasType?(:STEEL)) 
		miniscore*=1.3 if @opponent.effects[:Attract]>=0
		miniscore*=1.3 if @opponent.effects[:LeechSeed]>=0
		miniscore*=1.5 if @opponent.effects[:Curse]
		miniscore*=1.1 if @opponent.effects[:Confusion]>0
		miniscore*=0.7 if @attacker.moves.any? {|moveloop| moveloop!=nil && (PBStuff::PHASEMOVE).include?(moveloop.move)}
		miniscore*=1-0.05*statchangecounter(@opponent,1,7)
		miniscore=1.0 if miniscore < 1.0 && @move.basedamage > 0
		return miniscore
	end

	def knockcode
		return @move.basedamage > 0 ? 1 : 0 if @opponent.effects[:Substitute]>0
		return @move.basedamage > 0 ? 1 : 0 unless (@opponent.ability != :STICKYHOLD || moldBreakerCheck(@attacker,@move)) && @opponent.item && !@battle.pbIsUnlosableItem(@opponent,@opponent.item)
		if @opponent.item == :LEFTOVERS || (@opponent.item == :BLACKSLUDGE) && @opponent.hasType?(:POISON)
			return 1.3
		elsif @opponent.item == :LIFEORB || @opponent.item == :CHOICESCARF || @opponent.item == :CHOICEBAND || @opponent.item == :CHOICESPECS || @opponent.item == :ASSAULTVEST
			return 1.2
		elsif pbIsBerry?(@opponent.item) && @opponent.ability== :HARVEST
			return 1.3
		end
		return 1
	end

	def covetcode
		return 1 if !((@opponent.ability != :STICKYHOLD || moldBreakerCheck(@attacker,@move)) && @opponent.item && !@battle.pbIsUnlosableItem(@opponent,@opponent.item) && @attacker.item.nil? && @opponent.effects[:Substitute]<=0)
		return 0.9 if @battle.FE==:BACKALLEY && (hasgreatmoves() || @initial_scores[@score_index] < @initial_scores.max) # lawds dont waste the damage bonus on back alley
		miniscore = 1.2
		case @opponent.item
			when :LEFTOVERS, :LIFEORB, :LUMBERRY, :SITRUSBERRY
				miniscore*=1.5
				# LAWDS - seed
			when :ASSAULTVEST, :ROCKYHELMET, :MAGICALSEED, :SYNTHETICSEED, :TELLURICSEED, :ELEMENTALSEED, :SEED
				miniscore*=1.3
			when :FOCUSSASH, :MUSCLEBAND, :WISEGLASSES, :EXPERTBELT, :WIDELENS
				miniscore*=1.2
			when :CHOICESCARF
				miniscore*=1.1 if !pbAIfaster?()
			when :CHOICEBAND
				miniscore*=1.1 if @attacker.attack>@attacker.spatk
			when :CHOICESPECS
				miniscore*=1.1 if @attacker.spatk>@attacker.attack
			when :BLACKSLUDGE
				miniscore*= @attacker.hasType?(:POISON) ? 1.5 : 0.5
			when :TOXICORB, :FLAMEORB, :LAGGINGTAIL, :IRONBALL, :STICKYBARB
				miniscore*=0.5
		end
		return miniscore
	end

	def bestowcode
		return 1 if (@opponent.ability== :STICKYHOLD || !moldBreakerCheck(@attacker,@move))
		return 1 if @attacker.item.nil? || @battle.pbIsUnlosableItem(@attacker,@attacker.item) || (@opponent.item && @move.move != :TRICK)
		return 1 if opponent.effects[:Substitute] > 0
		miniscore = 1.0
		case @attacker.item
			when :LEFTOVERS, :LIFEORB, :LUMBERRY, :SITRUSBERRY
				miniscore*=0.5
			when :FOCUSSASH, :MUSCLEBAND, :WISEGLASSES, :EXPERTBELT, :WIDELENS
				miniscore*=0.8
				# LAWDS - seed
			when :ASSAULTVEST, :ROCKYHELMET, :MAGICALSEED, :SYNTHETICSEED, :TELLURICSEED, :ELEMENTALSEED, :SEED
				miniscore*=0.7
			when :CHOICESPECS
				miniscore*=1.7 if @opponent.attack>@opponent.spatk
				miniscore*=0.8 if @attacker.attack<@attacker.spatk
			when :CHOICESCARF
				miniscore*= pbAIfaster?() ? 0.9 : 1.5
			when :CHOICEBAND
				miniscore*=1.7 if @opponent.attack<@opponent.spatk
				miniscore*=0.8 if @attacker.attack>@attacker.spatk
			when :BLACKSLUDGE
				miniscore*= @attacker.hasType?(:POISON) ? 0.5 : 1.5
				miniscore*=1.3 if !@opponent.hasType?(:POISON)
			when :TOXICORB, :FLAMEORB, :LAGGINGTAIL, :IRONBALL, :STICKYBARB
				miniscore*=1.5
		end
		if [:CHOICESCARF,:CHOICEBAND,:CHOICESPECS].include?(@attacker.item) #choice locking
			miniscore*=3 if @opponent.lastMoveUsed.is_a?(Symbol) && pbAIfaster?(@move) && $cache.moves[@opponent.lastMoveUsed].category == :status
			miniscore*=1.5 if hasbadmoves(40)
			miniscore*=1.5 if @battle.turncount == 1
			maxdam = checkAIdamage()
			miniscore*=0.3 if maxdam > 0.5 * @attacker.hp
			miniscore*=1.3 if maxdam < 0.33 * @attacker.hp
		end
		return miniscore
	end

	def recoilcode
		return @move.basedamage > 0 ? 1 : 0 if @attacker.ability== :ROCKHEAD || @attacker.crested == :RAMPARDOS || @attacker.ability== :MAGICGUARD || (@attacker.ability== :WONDERGUARD && @battle.FE == :COLOSSEUM)
		return @move.basedamage > 0 ? 1 : 0 if @move.move == :WILDCHARGE && @battle.FE == :ELECTERRAIN
		recoilamount = @move.hasFlag?(:recoil)
		# LAWDS wave crash on water surface
		recoilamount/=2 if @move.move==:WAVECRASH && @battle.FE==:WATERSURFACE
		miniscore=0.9
		miniscore*=0.7 if notOHKO?(@attacker, @opponent, true)
		miniscore*=0.8 if @attacker.hp > 0.1 * @attacker.totalhp && @attacker.hp < 0.4 * @attacker.totalhp
		miniscore*=0.4 if ((@initial_scores[@score_index] * recoilamount)*@opponent.hp > @attacker.hp) && (@opponent.status == :SLEEP || @opponent.status == :FROZEN)
		# LAWDS dont care about recoil if you outheal it
		miniscore=1 if (@attacker.hp==@attacker.totalhp || @mondata.roles.include?(:SWEEPER)) && 
					   (@initial_scores[@score_index] * recoilamount)*@opponent.hp < @attacker.hp && 
					   @initial_scores[@score_index]*recoilamount*@opponent.hp <= hpGainPerTurn(@attacker,true)*@attacker.totalhp
		return miniscore
	end

	def weathercode
		if @battle.pbCheckGlobalAbility(:AIRLOCK) || @battle.pbCheckGlobalAbility(:CLOUDNINE) || @battle.pbCheckGlobalAbility(:DELTASTREAM) ||
			@battle.pbCheckGlobalAbility(:DESOLATELAND) || @battle.pbCheckGlobalAbility(:PRIMORDIALSEA) || @battle.pbCheckGlobalAbility(:TEMPEST)
			return @move.basedamage > 0 ? 1 : 0
		end
		return @move.basedamage > 0 ? 1 : 0 if [:NEWWORLD,:UNDERWATER].include?(@battle.FE)
		miniscore=1.0
		miniscore*=1.3 if notOHKO?(@attacker, @opponent, true)
		miniscore*=1.2 if @mondata.roles.include?(:LEAD)
		miniscore*=1.4 if @attacker.pbHasMove?(:WEATHERBALL) 
		miniscore*=1.5 if @attacker.ability== :FORECAST
		return miniscore
	end

	def suncode
		return @move.basedamage > 0 ? 1 : 0 if @battle.pbWeather== :SUNNYDAY
		return @move.basedamage > 0 ? 1 : 0 if @battle.FE == :DIMENSIONAL
		return 0 if @attacker.crested == :CHERRIM || @attacker.pbPartner.crested == :CHERRIM
		miniscore=1.0
		miniscore*=0.2 if @attacker.ability== :FORECAST && (@opponent.hasType?(:GROUND) || @opponent.hasType?(:ROCK))
		miniscore*=1.3 if (@mondata.attitemworks && @attacker.item == :HEATROCK) || [:DESERT,:MOUNTAIN,:SNOWYMOUNTAIN,:SKY].include?(@battle.FE)
		miniscore*=1.5 if @battle.pbWeather!=0 && @battle.pbWeather!=:SUNNYDAY
		miniscore*=1.5 if @attacker.pbHasMove?(:MOONLIGHT) || @attacker.pbHasMove?(:SYNTHESIS) || @attacker.pbHasMove?(:MORNINGSUN) || @attacker.pbHasMove?(:GROWTH) || @attacker.pbHasMove?(:SOLARBEAM) || @attacker.pbHasMove?(:SOLARBLADE)
		miniscore*=0.7 if checkAImoves([:SYNTHESIS, :MOONLIGHT, :MORNINGSUN])
		miniscore*=1.5 if @attacker.hasType?(:FIRE)
		if @attacker.ability== :CHLOROPHYLL || @attacker.ability== :FLOWERGIFT
			miniscore*=2
			miniscore*=2 if notOHKO?(@attacker, @opponent, true)
			miniscore*=3 if seedProtection?(@attacker)
		end
		miniscore*=1.3 if [:SOLARPOWER,:LEAFGUARD,:SOLARIDOL].include?(@attacker.ability) 
		miniscore*=0.5 if pbPartyHasType?(:WATER)
		miniscore*=0.7 if @attacker.pbHasMove?(:THUNDER) || @attacker.pbHasMove?(:HURRICANE)
		miniscore*=0.5 if @attacker.ability== :DRYSKIN
		miniscore*=1.5 if @attacker.ability== :HARVEST
		return miniscore
	end

	def raincode
		return 0 if @battle.pbWeather== :RAINDANCE
		return @move.basedamage > 0 ? 1 : 0 if [:DIMENSIONAL,:INFERNAL].include?(@battle.FE)
		miniscore=1.0
		miniscore*=0.2 if @attacker.ability== :FORECAST && (@opponent.hasType?(:GRASS) || @opponent.hasType?(:ELECTRIC))
		miniscore*=1.3 if (@mondata.attitemworks && @attacker.item == :DAMPROCK) || [:BIGTOP,:SKY,:CLOUDS].include?(@battle.FE)
		miniscore*=1.3 if @battle.pbWeather!=0 && @battle.pbWeather!=:RAINDANCE
		miniscore*=1.5 if @attacker.pbHasMove?(:THUNDER) || @attacker.pbHasMove?(:HURRICANE)
		miniscore*=1.5 if @attacker.hasType?(:WATER)
		if @attacker.ability== :SWIFTSWIM
			miniscore*=2
			miniscore*=2 if notOHKO?(@attacker, @opponent, true)
			miniscore*=3 if seedProtection?(@attacker)
		end
		miniscore*=1.5 if @attacker.ability== :DRYSKIN || @battle.pbWeather== :RAINDANCE
		miniscore*=0.5 if pbPartyHasType?(:FIRE)
		miniscore*=0.5 if @attacker.pbHasMove?(:MOONLIGHT) || @attacker.pbHasMove?(:SYNTHESIS) || @attacker.pbHasMove?(:MORNINGSUN) || @attacker.pbHasMove?(:GROWTH) || @attacker.pbHasMove?(:SOLARBEAM) || @attacker.pbHasMove?(:SOLARBLADE)
		miniscore*=1.5 if @attacker.ability== :HYDRATION
		return miniscore
	end

	def sandcode
		return 0 if @battle.pbWeather== :SANDSTORM
		return @move.basedamage > 0 ? 1 : 0 if @battle.FE == :DIMENSIONAL
		miniscore = 1.0
		miniscore*=1.3 if (@mondata.attitemworks && @attacker.item == :SMOOTHROCK) || [:DESERT,:ASHENBEACH,:SKY].include?(@battle.FE)
		miniscore*=2 if @battle.pbWeather!=0 && @battle.pbWeather!=:SANDSTORM
		miniscore*= (@attacker.hasType?(:ROCK) || @attacker.hasType?(:GROUND) || @attacker.hasType?(:STEEL)) ? 1.3 : 0.7
		miniscore*=1.5 if @attacker.hasType?(:ROCK)
		if @attacker.ability== :SANDRUSH || @attacker.ability== :DUSTDEVIL
			miniscore*=2
			miniscore*=2 if notOHKO?(@attacker, @opponent, true)
			miniscore*=3 if seedProtection?(@attacker)
			miniscore*=1.5 if @attacker.ability== :DUSTDEVIL
		end
		miniscore*=1.3 if @attacker.ability== :SANDVEIL
		miniscore*=0.5 if @attacker.pbHasMove?(:MOONLIGHT) || @attacker.pbHasMove?(:SYNTHESIS) || @attacker.pbHasMove?(:MORNINGSUN) || @attacker.pbHasMove?(:GROWTH) || @attacker.pbHasMove?(:SOLARBEAM) || @attacker.pbHasMove?(:SOLARBLADE)
		miniscore*=1.5 if @attacker.pbHasMove?(:SHOREUP)
		miniscore*=1.5 if @attacker.ability== :SANDFORCE
		return miniscore
	end

	def hailcode
		return 0 if @battle.pbWeather== :HAIL
		return @move.basedamage > 0 ? 1 : 0 if [:SUPERHEATED,:VOLCANIC,:VOLCANICTOP,:INFERNAL].include?(@battle.FE)
		return @move.basedamage > 0 ? 1 : 0 if Rejuv && @battle.FE == :DRAGONSDEN
		miniscore=1.0
		miniscore*=0.2 if @attacker.ability== :FORECAST && [:ROCK,:FIRE,:STEEL,:FIGHTING].any? {|type| @opponent.hasType?(type) }
		miniscore*=1.3 if (@mondata.attitemworks && @attacker.item == :ICYROCK) || [:ICY,:SNOWYMOUNTAIN,:FROZENDIMENSION,:CLOUDS,:SKY].include?(@battle.FE)
		miniscore*=1.3 if @battle.pbWeather!=0 && @battle.pbWeather!=:HAIL
		miniscore*= (@attacker.hasType?(:ICE)) ? 5 : 0.7
		if @attacker.ability== :SLUSHRUSH || @attacker.crested == :EMPOLEON
			miniscore*=2
			miniscore*=2 if notOHKO?(@attacker, @opponent, true)
			miniscore*=3 if seedProtection?(@attacker)
		end
		miniscore*=1.3 if [:SNOWCLOAK,:ICEBODY,:LUNARIDOL].include?(@attacker.ability) || (@attacker.ability== :ICEFACE && @attacker.form == 1)
		miniscore*=0.5 if @attacker.pbHasMove?(:MOONLIGHT) || @attacker.pbHasMove?(:SYNTHESIS) || @attacker.pbHasMove?(:MORNINGSUN) || @attacker.pbHasMove?(:GROWTH) || @attacker.pbHasMove?(:SOLARBEAM) || @attacker.pbHasMove?(:SOLARBLADE)
		miniscore*=2 if @attacker.pbHasMove?(:AURORAVEIL)
		miniscore*=1.3 if @attacker.pbHasMove?(:BLIZZARD)
		return miniscore
	end

	def subcode
		return 0 if @attacker.hp*4<=@attacker.totalhp && @move.function != 0x80C
		return 0 if @attacker.effects[:Substitute]>0 && pbAIfaster?(@move) || @opponent.effects[:LeechSeed]<0
		miniscore = 1.0
		miniscore*= (@attacker.hp==@attacker.totalhp) ? 1.1 : (@attacker.hp*(1.0/@attacker.totalhp))
		miniscore*=1.2 if @opponent.effects[:LeechSeed]>=0
		miniscore*=1.2 if hpGainPerTurn>1
		miniscore*=1.2 if @attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.isHealingMove?}
		miniscore*=1.2 if checkAImoves([:SPORE, :SLEEPPOWDER])
		miniscore*=1.5 if @attacker.pbHasMove?(:FOCUSPUNCH)
		miniscore*=1.5 if @opponent.status== :SLEEP
		miniscore*=0.3 if @opponent.ability== :INFILTRATOR
		miniscore*=0.3 if checkAImoves([:UPROAR, :HYPERVOICE, :ECHOEDVOICE, :SNARL, :BUGBUZZ, :BOOMBURST, :SPARKLINGARIA])
		miniscore*=2   if checkAIdamage()*4 < @attacker.totalhp && (getAIMemory().length > 0)
		miniscore*=1.3 if @opponent.effects[:Confusion]>0
		miniscore*=1.3 if @opponent.status== :PARALYSIS
		miniscore*=1.3 if @opponent.effects[:Attract]>=0
		miniscore*=1.2 if @attacker.pbHasMove?(:BATONPASS)
		miniscore*=1.1 if @attacker.ability== :SPEEDBOOST
		miniscore*=0.5 if @battle.doublebattle
		return miniscore
	end

	def futurecode
		return 0 if @opponent.effects[:FutureSight]>0
		miniscore=0.6
		miniscore*=0.7 if @battle.doublebattle
		miniscore*=0.7 if @attacker.pbNonActivePokemonCount==0
		miniscore*=1.2 if @attacker.effects[:Substitute]>0
		miniscore*=1.2 if @attacker.moves.any? {|moveloop| moveloop!=nil && [:PROTECT,:DETECT,:BANEFULBUNKER,:SPIKYSHIELD,:SILKTRAP,:BURNINGBULWARK].include?(moveloop.move) } # Gen 9 Mod - Added Silk Trap and Burning Bulwark
		miniscore*=1.1 if @mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL)
		miniscore*=1.2 if @attacker.pbHasMove?(:QUIVERDANCE) || @attacker.pbHasMove?(:NASTYPLOT) || @attacker.pbHasMove?(:TAILGLOW)# || @attacker.ability== :MOODY # LAWDS - removing moody handling for now
		return miniscore
	end

	def focuscode
		return 0 if @mondata.skill >= BESTSKILL && @battle.FE == :ELECTERRAIN
		miniscore=1.0
		soundcheck=getAIMemory().any? {|moveloop| moveloop!=nil && moveloop.isSoundBased? && moveloop.basedamage>0}
		multicheck=getAIMemory().any? {|moveloop| moveloop!=nil && moveloop.pbNumHits(@opponent)>1}
		if @attacker.effects[:Substitute]>0
			if multicheck || soundcheck || @opponent.ability== :INFILTRATOR
				miniscore*=0.9
			else
				miniscore*=1.3
			end
		else
			miniscore *= 0.8
		end
		miniscore*=1.2 if @opponent.status== :SLEEP && @opponent.ability != :SHEDSKIN #&& @opponent.ability != :EARLYBIRD
		miniscore*=0.5 if @battle.doublebattle
		miniscore*=1.5 if @opponent.effects[:HyperBeam]>0
		miniscore*=0.3 if miniscore<=1.0
		return miniscore
	end

	def suckercode
		# LAWDS completely overhauled this for new sucker punch
		miniscore = 1.0
		return 1.0 if @attacker.ability==:JUGGERNAUT
		miniscore *= 0.5 if pbAIfaster?() && hasgreatmoves() && !(checkAIpriority && !prioBlocked?)
		return miniscore if @opponent.effects[:Substitute]>0 # breaking substitute
		bestmove, damage = checkAIMovePlusDamage()
		bestattmove, bestattdamage = checkAIMovePlusDamage(@attacker,@opponent)
		faster_without_sucker = pbAIfaster?(nil, bestmove)
		faster_with_sucker = pbAIfaster?(@move, bestmove)
		miniscore*=0.5 if faster_without_sucker && bestattmove.function != 0x116 # if we don't need prio to outspeed, don't waste sucker unless its the strongest move
		miniscore*=0.5 if !faster_with_sucker && bestattmove.function != 0x116 # if we don't outspeed even with prio, don't use it unless its the strongest move

		# cases where we go first with sucker, but they go first without sucker
		if faster_with_sucker && !faster_without_sucker && (@initial_scores[@score_index] < 110 || notOHKO?(@opponent,@attacker))
			return miniscore if damage >= @attacker.hp # if they kill us this turn, dont worry about planning for the next turn cause youll be fucking dead
			if bestattmove.function!=0x116
				bestOtherAttDmg = bestattdamage
			else
				bestOtherAttDmg = 0
				for move in @attacker.moves
					next if move==nil || move.basedamage==0 || move.function==0x116
					movedmg = pbRoughDamage(move,@attacker,@opponent)
					bestOtherAttDmg = movedmg if movedmg > bestOtherAttDmg
				end
			end
			suckerdamage = [@initial_scores[@score_index]*@opponent.hp/100, @opponent.hp].min
			suckerdamage = 0 if suckerdamage < 0
			miniscore*=0.5 if @opponent.effects[:Disguise] && !moldBreakerCheck(@attacker)
			if suckerdamage + bestOtherAttDmg >= @opponent.hp
				miniscore*=0.5
			elsif damage >= @attacker.hp/2 # if we cant kill with sucker next turn after attacking with some different move, and they twoshot us, go for a different attack this turn, then sucker on the next turn
				miniscore*=0.5
			end
		end
		return miniscore
	end

	def followcode
		return 0 if !@battle.doublebattle || @attacker.pbPartner.hp==0
		return 0 if @opponent.ability== :PROPELLERTAIL || @opponent.ability== :STALWART
		return 0 if @move == :RAGEPOWDER && (@opponent.ability== :OVERCOAT || @opponent.hasType?(:GRASS) || @opponent.hasWorkingItem(:SAFETYGOGGLES)) # LAWDS - AI knows what ignores Rage Powder
		return 0 if ((@opponent.pbHasMove?(:FAKEOUT) && !pbAIfaster? && @opponent.turncount==0) || (@opponent.pbPartner.pbHasMove?(:FAKEOUT) && !pbAIfaster?(nil,nil,@attacker,@opponent.pbPartner) && @opponent.pbPartner.turncount==0)) # dont follow me if they can fake out before getting redirected
		return 0 if @attacker.effects[:FollowMe]
		miniscore=1.0
		miniscore*=1.2 if @mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL)
		#miniscore*=1.3 if @attacker.pbPartner.ability== :MOODY
		#miniscore*= (@attacker.pbPartner.turncount<1) ? 1.5 : 1.0
		miniscore*= 1.3 if @attacker.pbPartner.moves.any? {|moveloop| moveloop!=nil && (PBStuff::SETUPMOVE).include?(moveloop.move)}
		bestmove1,maxdam1 = checkAIMovePlusDamage(@attacker.pbOpposing1,@attacker.pbPartner)
		bestmove2,maxdam2 = checkAIMovePlusDamage(@attacker.pbOpposing2,@attacker.pbPartner)
		spread1 = false
		spread2 = false
		spread1 = true if (bestmove1.pbTargetsAll?(@attacker.pbOpposing1)) || [:PROPELLERTAIL,:STALWART].include?(@attacker.pbOpposing1.ability) || ([:THUNDERRAID,:SNIPESHOT].include?(bestmove1))
		spread2 = true if (bestmove2.pbTargetsAll?(@attacker.pbOpposing2)) || [:PROPELLERTAIL,:STALWART].include?(@attacker.pbOpposing2.ability) || ([:THUNDERRAID,:SNIPESHOT].include?(bestmove2))
		spreadDMGArray1 = [0,0,0,0]
		for oppmove1 in @attacker.pbOpposing1.moves
			next if oppmove1==nil
			spreadDMGArray1[@attacker.pbOpposing1.moves.index(oppmove1)] = pbRoughDamage(oppmove1,@attacker.pbOpposing1,@attacker.pbPartner) if oppmove1.pbTargetsAll?(@attacker.pbOpposing1)
		end
		spreadDMGArray2 = [0,0,0,0]
		for oppmove2 in @attacker.pbOpposing2.moves
			next if oppmove2==nil
			spreadDMGArray2[@attacker.pbOpposing2.moves.index(oppmove2)] = pbRoughDamage(oppmove2,@attacker.pbOpposing2,@attacker.pbPartner) if oppmove2.pbTargetsAll?(@attacker.pbOpposing2)
		end

		spread1 = true if spreadDMGArray1.max >= @attacker.pbPartner.hp
		spread2 = true if spreadDMGArray2.max >= @attacker.pbPartner.hp
		return 0 if spread1 && spread2
		return 0 if spreadDMGArray1.max + spreadDMGArray2.max >= @attacker.pbPartner.hp
		followme_saves = (maxdam1 >= @attacker.pbPartner.hp && !spread1 && maxdam2 < @attacker.pbPartner.hp) || 
						 ((maxdam1 + maxdam2 >= @attacker.pbPartner.hp) && 
						 !(spread1 && maxdam1 >= @attacker.pbPartner.hp) && 
						 !(spread2 && maxdam2 >= @attacker.pbPartner.hp) &&
						 !(spread1 && spread2))
		selfdam1 = pbRoughDamage(bestmove1,@attacker.pbOpposing1,@attacker,false)
		selfdam2 = pbRoughDamage(bestmove2,@attacker.pbOpposing2,@attacker,false)
		selfdam1 = 0 if seedProtection?(@attacker) && ![:FEINT,:MIGHTYCLEAVE].include?(bestmove1)
		selfdam2 = 0 if seedProtection?(@attacker) && ![:FEINT,:MIGHTYCLEAVE].include?(bestmove2)
		# lawds if the faster opponent KOs you and the slower mon KOs the partner, don't redirect
		if pbAIfaster?(nil,nil,@attacker.pbOpposing1,@attacker.pbOpposing2)
			return 0 if selfdam1 >= @attacker.hp && maxdam2 > @attacker.pbPartner.hp
		else
			return 0 if selfdam2 >= @attacker.hp && maxdam1 > @attacker.pbPartner.hp
		end
		# lawds discourage follow me if opp's best move is spread
		if @opponent==@attacker.pbOpposing1 && spread1
			miniscore*=0.3
		elsif spread2
			miniscore*=0.3
		end
		miniscore*=1.5 if notOHKO?(@attacker, @opponent, true)

		if (!spread1 && maxdam1 >= @attacker.pbPartner.hp && selfdam1 < 0.7*@attacker.hp) || 
		   (!spread2 && maxdam2 >= @attacker.pbPartner.hp && selfdam2 < 0.7*@attacker.hp)
		   miniscore*= 1.2
		   miniscore*=1.2 if selfdam1==0 && !spread1	# lawds - even bigger boost per redirected move you take 0 damage from
		   miniscore*=1.2 if selfdam2==0 && !spread2 
		end

		partnerdamage1 = checkAIdamage(@opponent,@attacker.pbPartner)
		partnerdamage2 = checkAIdamage(@opponent.pbPartner,@attacker.pbPartner)
		partnerkills1 = partnerdamage1 >= @opponent.hp
		partnerkills2 = partnerdamage2 >= @opponent.pbPartner.hp
		partnerkills1 = false if @attacker.pbPartner.status==:SLEEP && @attacker.pbPartner.statusCount > 1
		partnerkills2 = false if @attacker.pbPartner.status==:SLEEP && @attacker.pbPartner.statusCount > 1
		if followme_saves # LAWDS if the partner would be saved, encourage it, even more if it would kill
			miniscore*= 1.5 if (partnerkills1 || partnerkills2)
			if @attacker.pbOpposing1.pbHasMove?(:FIRSTIMPRESSION) && @attacker.pbOpposing1.turncount==0 # favor using it to beat first impression
				fimp = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(:FIRSTIMPRESSION),@attacker.pbOpposing1)
				if pbRoughDamage(fimp, @attacker.pbOpposing1,@attacker.pbPartner) >= @attacker.pbPartner.hp
					miniscore*=1.5
				end
			end
			if @attacker.pbOpposing2.pbHasMove?(:FIRSTIMPRESSION) && @attacker.pbOpposing2.turncount==0 && # favor using it to beat first impression
				fimp = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(:FIRSTIMPRESSION),@attacker.pbOpposing2)
				if pbRoughDamage(fimp, @attacker.pbOpposing2,@attacker.pbPartner) >= @attacker.pbPartner.hp
					miniscore*=1.5
				end
			end
		end
		# LAWDS - with seed protection
		if seedProtection?(@attacker)
			if followme_saves
				miniscore*= 2 if (partnerkills1 || partnerkills2)
			end
		end
		if @attacker.hp==@attacker.totalhp
			miniscore*=1.2
		else
			miniscore*=0.8
			miniscore*=0.5 if @attacker.hp*2 < @attacker.totalhp
		end
		miniscore*=1.2 if !pbAIfaster?() || !pbAIfaster?(nil,nil,@attacker,@opponent.pbPartner)
		miniscore*=1.2 if !pbAIfaster?(nil,nil,@attacker.pbPartner,@opponent) || !pbAIfaster?(nil,nil,@attacker.pbPartner,@opponent.pbPartner) # LAWDS - incentivize follow me if partner is slower than either enemy
		if !spread1 # only if opp aint gonna use a spread move.
			if @battle.state.effects[:IonDeluge] && @attacker.ability== :MOTORDRIVE && @attacker.crested==:ELECTIVIRE && (partnerkills1 || partnerkills2) # special case for electivire
				if !(@opponent.pbHasMove?(:FAKEOUT) && !pbAIfaster?) || (maxdam1 >= @attacker.pbPartner.hp && pbAIfaster?(bestmove1,nil,@opponent,@attacker.pbPartner))
					miniscore*=1.5
				else
					miniscore*=0.7
				end
			end
		end
		miniscore*=0.6 if hasgreatmoves() && (!(pbAIfaster?(nil,nil,@opponent,@attacker) && checkAIdamage() >= @attacker.hp) && !(pbAIfaster?(nil,nil,@opponent.pbPartner,@attacker) && checkAIdamage(@attacker,@opponent.pbPartner) >= @attacker.hp))
		return miniscore
	end

	def gravicode
		return 0 if @battle.state.effects[:Gravity]!=0
		return 0 if @attacker.moves.any? {|moveloop| moveloop!=nil && [:SKYDROP,:BOUNCE,:FLY,:JUMPKICK,:FLYINGPRESS,:HIJUMPKICK].include?(moveloop.move)}
		miniscore=1.0
		miniscore*=2 if @attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.accuracy<=70}
		miniscore*=3 if @attacker.pbHasMove?(:ZAPCANNON) || @attacker.pbHasMove?(:INFERNO)
		miniscore*=2 if [:SKYDROP,:BOUNCE,:FLY,:JUMPKICK,:FLYINGPRESS,:HIJUMPKICK].include?(checkAIbestMove().move)
		miniscore*=2 if @attacker.hasType?(:GROUND) && (@opponent.hasType?(:FLYING) || [:LEVITATE,:SOLARDIOL,:LUNARIDOL].include?(@opponent.ability) || (@mondata.oppitemworks && @opponent.item == :AIRBALLOON))
		return miniscore
	end

	def magnocode
		return 0 if @attacker.effects[:MagnetRise]>0 || @attacker.effects[:Ingrain] || @attacker.effects[:SmackDown]
		miniscore=1.0
		miniscore*=3 if checkAIbestMove().pbType(@opponent)==:GROUND# Highest expected dam from a ground move
		miniscore*=3 if @opponent.hasType?(:GROUND)
		return miniscore
	end

	def telecode
		return 0 if @opponent.effects[:Telekinesis]>0 || @opponent.effects[:Ingrain] || @opponent.effects[:SmackDown] || @battle.state.effects[:Gravity]!=0
		return 0 if @opponent.species==:DIGLETT || @opponent.species==:DUGTRIO || @opponent.species==:SANDYGAST || @opponent.species==:PALOSSAND
		return 0 if (@opponent.species==:GENGAR && @opponent.form==1) || @opponent.item == :IRONBALL
		score = @initial_scores[@score_index]
		score+=10 if @attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.accuracy<=70}
		score*=2 if @attacker.pbHasMove?(:ZAPCANNON) || @attacker.pbHasMove?(:INFERNO)
		score*=0.5 if @attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.pbType(@attacker)==:GROUND && moveloop.basedamage>0}
		miniscore = oppstatdrop([0,2,0,0,2,0,0]) if @battle.FE == :PSYTERRAIN
		score *= miniscore if miniscore && miniscore > 0
		return score
	end

	def afteryoucode
		return 1
	end

	def trcode # LAWDS improved trick room code to take into account both parties
		return 0 if !@mondata.roles.include?(:TRSETTER)
		return 0 if @battle.trickroom != 0 # if youve already set trick room, you dont need to run the check again since you know the outcome
		return 0 if opponent.hp > 0 && opponent.pokemon.piece == :KING
		miniscore=1.0
		miniscore*=1.3 if @mondata.partyroles.any? {|role| role.include?(:SWEEPER) }
		miniscore*=1.3 if @mondata.roles.include?(:TANK) || @mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL)
		miniscore*=1.5 if @mondata.roles.include?(:LEAD)
		miniscore*=1.3 if @battle.doublebattle
		miniscore*=1.5 if notOHKO?(@attacker, @opponent, true)
		if @opponent.pbPartner.hp > 0
			miniscore*=0.3 if @attacker.pbSpeed<pbRoughStat(@opponent,PBStats::SPEED) && @attacker.pbSpeed>pbRoughStat(@opponent.pbPartner,PBStats::SPEED)
			miniscore*=0.3 if @attacker.pbSpeed>pbRoughStat(@opponent,PBStats::SPEED) && @attacker.pbSpeed<pbRoughStat(@opponent.pbPartner,PBStats::SPEED)
		end
		if @battle.trickroom <= 0
			miniscore*=2
			miniscore*=6 if @initial_scores.length>0 && hasgreatmoves() #experimental -- cancels out drop if killing moves
			miniscore*=3 if !hasgreatmoves() && @battle.doublebattle # LAWDS - we love casting trick room
		else
			miniscore*=1.3
		end
    	return miniscore
	end

	def dinglenugget
		return 0 if checkAIdamage()>=@attacker.hp || @attacker.pbNonActivePokemonCount==0
		miniscore=1.3
		miniscore*=2 if @mondata.partyroles.any? {|role| role.include?(:SWEEPER) }
		miniscore*=2 if @attacker.pbNonActivePokemonCount<3
		miniscore*=0.5 if @attacker.pbOwnSide.effects[:StealthRock] || @attacker.pbOwnSide.effects[:Spikes]>0
		return miniscore
	end

	def wondercode
		return 0 if @battle.state.effects[:WonderRoom]!=0
		miniscore=1.0
		miniscore*=1.3 if (@mondata.attitemworks && @attacker.item == :AMPLIFIELDROCK) || @battle.FE == :NEWWORLD || @battle.FE == :PSYTERRAIN || (Rejuv && @battle.FE == :STARLIGHT)
		if pbRoughStat(@opponent,PBStats::ATTACK)>pbRoughStat(@opponent,PBStats::SPATK)
			miniscore*= (@attacker.defense>@attacker.spdef) ? 0.5 : 2
		else
			miniscore*= (@attacker.defense>@attacker.spdef) ? 2 : 0.5
		end
		if @attacker.attack>@attacker.spatk
			miniscore*= (pbRoughStat(@opponent,PBStats::DEFENSE)>pbRoughStat(@opponent,PBStats::SPDEF)) ? 2 : 0.5
		else
			miniscore*= (pbRoughStat(@opponent,PBStats::DEFENSE)>pbRoughStat(@opponent,PBStats::SPDEF)) ? 0.5 : 2
		end
		return miniscore
	end

	def lastcode
		return 0 unless @attacker.moves.all? {|moveloop| moveloop!=nil && (moveloop.function == 0x125 || @attacker.movesUsed.include?(moveloop.move)) }
		return 1
	end

	def powdercode
		return 0 if @opponent.hasType?(:GRASS) || @opponent.ability== :OVERCOAT || (@mondata.oppitemworks && @opponent.item == :SAFETYGOGGLES)
		return 0 if getAIMemory().length >= 4 && !getAIMemory().any? {|moveloop| moveloop!=nil && moveloop.pbType(@opponent)==:FIRE}
		miniscore=1.0
		miniscore*=1.2 if !pbAIfaster?()
		if checkAIbestMove().pbType(@opponent) == :FIRE
			miniscore*=3
		else
			miniscore*= @opponent.hasType?(:FIRE) ? 2 : 0.2
		end
		effcheck = PBTypes.twoTypeEff((:FIRE),@attacker.type1,@attacker.type2)
		miniscore*=2 if effcheck>4
		miniscore*=2 if effcheck>8
		miniscore*=0.6 if @attacker.lastMoveUsed==:POWDER
		miniscore*=0.5 if @opponent.ability== :MAGICGUARD || (@opponent.ability== :WONDERGUARD && @battle.FE == :COLOSSEUM)
		return miniscore
	end

	def burnupcode
		return 0 if !@attacker.hasType?(:FIRE)
		miniscore= (1-@opponent.pbNonActivePokemonCount*0.05)
		if @initial_scores[@score_index]<100
			miniscore*=0.9
			miniscore*=0.5 if getAIMemory().any? {|moveloop| moveloop!=nil && moveloop.isHealingMove?}
		end
		miniscore*=0.5 if @initial_scores.length>0 && hasgreatmoves()
		miniscore*=0.7 if @attacker.pbNonActivePokemonCount==0 && @opponent.pbNonActivePokemonCount!=0
		effcheck = PBTypes.twoTypeEff(@opponent.type1,(:FIRE),(:FIRE))
		miniscore*=1.5 if effcheck > 4
		miniscore*=0.5 if effcheck < 4
    	effcheck = PBTypes.twoTypeEff(@opponent.type2,(:FIRE),(:FIRE))
		miniscore*=1.5 if effcheck > 4
		miniscore*=0.5 if effcheck < 4
		effcheck = PBTypes.twoTypeEff(checkAIbestMove().pbType(@opponent),(:FIRE),(:FIRE))
		miniscore*=1.5 if effcheck > 4
		miniscore*=0.5 if effcheck < 4
		miniscore*=1.5 if @battle.FE == :INFERNAL
		return miniscore
	end

	def beakcode
		miniscore = burncode
		miniscore*=0.7 if pbAIfaster?()
		if getAIMemory().any?{|moveloop| moveloop!=nil && moveloop.contactMove?}
			miniscore*=1.5
		elsif @opponent.attack>@opponent.spatk
			miniscore*=1.3
		else
			miniscore*=0.3
		end
		return miniscore
	end

	def moldbreakeronalaser
		return 1 if moldBreakerCheck(@attacker,@move)
		damcount = @attacker.moves.count {|moveloop| moveloop!=nil && moveloop.basedamage>0}
		miniscore = 1.0
		case @opponent.ability
			when :SANDVEIL
				miniscore*=1.2 if @battle.pbWeather!=:SANDSTORM
			when :VOLTABSORB, :LIGHTNINGROD
				miniscore*=3 if @move.pbType(@attacker)==:ELECTRIC && damcount==1
				miniscore*=2 if @move.pbType(@attacker)==:ELECTRIC && PBTypes.twoTypeEff((:ELECTRIC),@opponent.type1,@opponent.type2)>4
			when :SPIRITSENVOY # LAWDS - Spirit's envoy
				miniscore*=3 if @move.pbType(@attacker)==:GHOST && damcount==1 && @battle.FE != :HAUNTED
				miniscore*=2 if @move.pbType(@attacker)==:GHOST && PBTypes.twoTypeEff((:GHOST),@opponent.type1,@opponent.type2)>4 && @battle.FE!=:HAUNTED
			when :WATERABSORB, :STORMDRAIN, :DRYSKIN
				miniscore*=3 if @move.pbType(@attacker)==:WATER && damcount==1
				miniscore*=2 if @move.pbType(@attacker)==:WATER && PBTypes.twoTypeEff((:WATER),@opponent.type1,@opponent.type2)>4
				miniscore*=0.5 if @opponent.ability== :DRYSKIN && @attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.pbType(@attacker)==:FIRE}
			when :ENTOMOPHAGY # lawds entomophagous
				miniscore*=3 if @move.pbType(@attacker)==:BUG && damcount==1
				miniscore*=2 if @move.pbType(@attacker)==:BUG && PBTypes.twoTypeEff((:BUG),@opponent.type1,@opponent.type2)>4
			when :FLASHFIRE, :WELLBAKEDBODY # Gen 9 Mod - Added Well-Baked Body
				miniscore*=3 if @move.pbType(@attacker)==:FIRE && damcount==1
				miniscore*=2 if @move.pbType(@attacker)==:FIRE && PBTypes.twoTypeEff((:FIRE),@opponent.type1,@opponent.type2)>4
			when :LEVITATE, :LUNARIDOL, :SOLARIDOL, :EARTHEATER # Gen 9 Mod - Added Earth Eater
				miniscore*=3 if @move.pbType(@attacker)==:GROUND && damcount==1
				miniscore*=2 if @move.pbType(@attacker)==:GROUND && PBTypes.twoTypeEff((:GROUND),@opponent.type1,@opponent.type2)>4
			when :WONDERGUARD
				miniscore*=5
			when :SOUNDPROOF
				miniscore*=3 if @move.isSoundBased?
			when :THICKFAT
				miniscore*=1.5 if @move.pbType(@attacker)==:FIRE || move.pbType(@attacker)==:ICE
			when :PURIFYINGSALT
				miniscore*=1.5 if @move.pbType(@attacker)==:GHOST # LAWDS - Purifying Salt
			when :MOLDBREAKER, :TURBOBLAZE, :TERAVOLT
				miniscore*=1.1
			when :UNAWARE
				miniscore*=1.7
			when :MULTISCALE, :SHADOWSHIELD, :TERASHELL
				miniscore*=1.5 if @attacker.hp==@attacker.totalhp
			when :SAPSIPPER
				miniscore*=3 if @move.pbType(@attacker)==:GRASS && damcount==1
				miniscore*=2 if @move.pbType(@attacker)==:GRASS && PBTypes.twoTypeEff((:GRASS),@opponent.type1,@opponent.type2)>4
			when :SNOWCLOAK
				miniscore*=1.1 if @battle.pbWeather!=:HAIL
			when :FURCOAT
				miniscore*=1.5 if @attacker.attack>@attacker.spatk
			when :FLUFFY
				miniscore*=1.5
				miniscore*=0.5 if @move.pbType(@attacker)==:FIRE
			when :WATERBUBBLE
				miniscore*=1.5
				miniscore*=1.3 if @move.pbType(@attacker)==:FIRE
			when :WELLBAKEDBODY # Gen 9 Mod - Added Well-Baked Body
				abilityscore*=3 if attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.pbType(attacker)==:FIRE}
			when :WINDPOWER # Gen 9 Mod - Added Wind Power
				abilityscore*=1.3 if attacker.moves.all? {|moveloop| moveloop!=nil && (moveloop.windMove?)}
			when :WINDRIDER # Gen 9 Mod - Added Wind Rider
				abilityscore*=3 if attacker.moves.all? {|moveloop| moveloop!=nil && (moveloop.windMove?)}
			when :ICESCALES
				miniscore*=1.5 if @attacker.spatk>@attacker.attack
		end
		return miniscore
	end

	def pussydeathcode(initialscore)
		return 0 if @move.move = :MINDBLOWN && @battle.pbCheckGlobalAbility(:DAMP)
		return 0 if @battle.FE == :FACTORY && @move.move == :STEELBEAM && (@attacker.ability != :MAGICGUARD && !(@attacker.ability== :WONDERGUARD && @battle.FE == :COLOSSEUM)) && @attacker.hp<@attacker.totalhp*0.25 || (@attacker.hp<@attacker.totalhp*0.5 && !pbAIfaster?())
		return 0 if (@attacker.ability != :MAGICGUARD && !(@attacker.ability== :WONDERGUARD && @battle.FE == :COLOSSEUM)) && @attacker.hp<@attacker.totalhp*0.5 || (@attacker.hp<@attacker.totalhp*0.75 && !pbAIfaster?())
		miniscore=1.0
		if @attacker.ability != :MAGICGUARD && !(@attacker.ability== :WONDERGUARD && @battle.FE == :COLOSSEUM)
			miniscore*=0.7
			miniscore*=0.7 if initialscore < 100
			miniscore*=0.5 if !pbAIfaster?()
			miniscore*=1.3 if checkAIdamage() < @attacker.totalhp*0.2
			miniscore*=1.2 if @attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.isHealingMove?}
			miniscore*=1.3 if @initial_scores.length>0 && hasbadmoves(25)
			miniscore*=0.5 if checkAImoves(PBStuff::PROTECTMOVE) && !(@move.contactMove? && @attacker.ability== :UNSEENFIST)
			miniscore*=(1-0.1*@opponent.stages[PBStats::EVASION])
			miniscore*=(1+0.1*@opponent.stages[PBStats::ACCURACY])
			#miniscore*=0.7 if @mondata.oppitemworks && (@opponent.item == :LAXINCENSE || @opponent.item == :BRIGHTPOWDER)
			miniscore*=0.7 if accuracyWeatherAbilityActive?(@opponent)
		else
			miniscore*=1.1
		end
		return miniscore
	end

	def chopcode
		return 1 if secondaryEffectNegated?()
		miniscore=1.0
		if checkAIbestMove().isSoundBased?
			miniscore*=1.5
		elsif getAIMemory().any? {|moveloop| moveloop!=nil && moveloop.isSoundBased?}
			miniscore*=1.3
		end
		return miniscore
	end

	def shelltrapcode
		miniscore=1.0
		miniscore*=0.5 if pbAIfaster?()
		bestmove, maxdam = checkAIMovePlusDamage()
		if notOHKO?(@attacker, @opponent, true)
			miniscore*=1.2
		else
			miniscore*=0.8
			miniscore*=0.8 if maxdam>@attacker.hp
		end
		miniscore*=0.7 if @attacker.lastMoveUsed==:SHELLTRAP
		miniscore*=0.6 if checkAImoves(PBStuff::SETUPMOVE)
		miniscore*=@attacker.hp*(1.0/@attacker.totalhp)
		miniscore*=0.3 if @opponent.spatk > @opponent.attack
		miniscore*=0.05 if bestmove.pbIsSpecial?()
		return miniscore
	end

	def almostuselessmovecode
		return 0 if @opponent.index!=@attacker.pbPartner.index || @opponent.status.nil?
		miniscore=1.5
		if @opponent.hp>@opponent.totalhp*0.8
			miniscore*=0.8
		elsif @opponent.hp>@opponent.totalhp*0.3
			miniscore*=2
		end
		miniscore*=1.3 if @opponent.effects[:Toxic]>3
		miniscore*=1.3 if checkAImoves([:HEX])
		return miniscore
	end

	def psychicterraincode
		return @move.basedamage > 0 ? 1 : 0 if @battle.FE == :UNDERWATER || @battle.FE == :NEWWORLD || @battle.FE == :PSYTERRAIN || (Rejuv && @battle.FE == :DRAGONSDEN)
		if Rejuv && @battle.FE != :INDOOR
			return @move.basedamage > 0 ? 1 : 0 if @battle.state.effects[:PSYTERRAIN] > 0 || @battle.FE == :FROZENDIMENSION
			miniscore = 1.0
			miniscore*=1.5 if @attacker.hasType?(:PSYCHIC)
			miniscore*=2 if pbPartyHasType?(:PSYCHIC)
			miniscore*=0.5 if @opponent.hasType?(:PSYCHIC)
			miniscore*=1.5 if @attacker.ability== :FOREWARN || @attacker.ability== :ANTICIPATION
			miniscore*=0.7  if @attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.pbIsPriorityMoveAI(@attacker)} && @attacker.isAirborne?
			miniscore*=2  if (@mondata.attitemworks && @attacker.item == :AMPLIFIELDROCK)
		else
			miniscore = getFieldDisruptScore(@attacker,@opponent)
			miniscore*=1.5 if @attacker.ability== :TELEPATHY
			miniscore*=1.5 if @attacker.hasType?(:PSYCHIC)
			miniscore*=2 if pbPartyHasType?(:PSYCHIC)
			miniscore*=0.5 if @opponent.hasType?(:PSYCHIC)
			miniscore*=1.5 if @attacker.ability== :ANTICIPATION
			miniscore*=0.7  if @attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.pbIsPriorityMoveAI(@attacker)} && @attacker.isAirborne?
			miniscore*=1.3 if checkAIpriority() && !@opponent.isAirborne?
			miniscore*=2  if (@mondata.attitemworks && @attacker.item == :AMPLIFIELDROCK)
		end
		return miniscore
	end

	def instructcode # function is only evaluated for the partner, never the opponent
		miniscore=3.0
		if @opponent.hp < 0.5*@opponent.totalhp
			miniscore*=0.5
		elsif @opponent.hp==@opponent.totalhp
			miniscore*=1.2
		end
		miniscore*=1.2 if @initial_scores.length>0 && hasbadmoves(20)
		lastmove = @attacker.pbPartner.lastMoveUsed
		lastmove = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(lastmove),@attacker.pbPartner)
		lastmovetarget = @attacker.pbPartner.lastMoveChoice[3]
		lastmovetarget = firstOpponent() if lastmovetarget == -1
		movescore = pbRoughDamage(lastmove, @attacker.pbPartner, @battle.battlers[lastmovetarget])
		if movescore == 0
			miniscore*=0
		elsif movescore > @battle.battlers[lastmovetarget].hp
			miniscore*=1.5
		end

		miniscore*=1.4 if !pbAIfaster?(nil, nil, @attacker.pbPartner, @attacker.pbOpposing1) && !pbAIfaster?(nil, nil, @attacker.pbPartner, @attacker.pbOpposing2)
		miniscore*= (1 + ([@opponent.attack,@opponent.spatk].max - [@attacker.attack,@attacker.spatk].max)/100.0)
		return miniscore
	end

	def antistatcode(stats,beginscore)
		miniscore=1.0
		miniscore*=(1-0.05*(@opponent.pbNonActivePokemonCount-2)) if @opponent.pbNonActivePokemonCount > 0
		miniscore*=1.2 if !@battle.doublebattle && @mondata.partyroles.any? {|role| role.include?(:PIVOT) }
		miniscore*=0.7 if @initial_scores.length>0 && hasgreatmoves()
		miniscore*=0.9 if beginscore < 100
		stats.unshift(0)
		for i in 0...stats.length
			next if stats[i].nil? || stats[i]==0
			case i
				when PBStats::ATTACK
					miniscore*=0.5 if beginscore < 100 && checkAIhealing()
					miniscore*=0.8 if @opponent.pbNonActivePokemonCount > 0 && @attacker.pbNonActivePokemonCount==0
				when PBStats::DEFENSE
					miniscore/=0.9 if beginscore < 100 && !pbAIfaster?() || checkAIpriority()
					miniscore/=0.9 if beginscore < 100 && @opponent.attack < @opponent.spatk
					miniscore*=0.8 if @mondata.roles.include?(:PHYSICALWALL)
				when PBStats::SPEED
					miniscore*=1.1 if @mondata.roles.include?(:TANK)
					miniscore*=0.8 if @attacker.pbSpeed>pbRoughStat(@opponent,PBStats::SPEED)
				when PBStats::SPATK
					miniscore*=0.5 if beginscore < 100 && checkAIhealing()
					miniscore*=0.8 if @opponent.pbNonActivePokemonCount > 0 && @attacker.pbNonActivePokemonCount==0
				when PBStats::SPDEF
					miniscore/=0.9 if !pbAIfaster?() || checkAIpriority()
					miniscore/=0.9 if beginscore < 100 && @opponent.attack > @opponent.spatk
					miniscore*=0.9 if @mondata.roles.include?(:SPECIALWALL)
			end
		end
		return miniscore
	end

	def smackcode
		return 1 if @opponent.effects[:Ingrain] || @opponent.effects[:SmackDown] || @battle.state.effects[:Gravity]!=0 || (@mondata.oppitemworks && @opponent.item == :IRONBALL) || @opponent.effects[:Substitute]>0
		miniscore=1.0
		if !pbAIfaster?()
			if checkAImoves([:BOUNCE, :FLY, :SKYDROP])
				miniscore*=1.3
			else
				miniscore*=2 if @opponent.effects[:TwoTurnAttack]!=0
			end
		end
		if (@opponent.hasType?(:FLYING) || [:LEVITATE,:SOLARDIOL,:LUNARIDOL].include?(@opponent.ability))
			miniscore*= (@attacker.moves.any?{|moveloop| moveloop!=nil && moveloop.pbType(@attacker)==:GROUND && moveloop.basedamage>0}) ? 2 : 1.2
		end
		return miniscore
	end

	def nightmarecode
		return 0 if @opponent.effects[:Nightmare] || (@opponent.status!=:SLEEP && @battle.FE != :INFERNAL) || @opponent.effects[:Substitute]>0
		miniscore=1.0
		miniscore*=4 if @opponent.statusCount>2
		miniscore*=6 if @opponent.ability== :COMATOSE
		miniscore*=6 if @initial_scores.length>0 && hasbadmoves(25)
		miniscore*=0.5 if @opponent.ability== :SHEDSKIN #|| @opponent.ability== :EARLYBIRD
		if PBStuff::TRAPPINGABILITIESAI.include?(@attacker.ability) || (@attacker.ability== :MAGNETPULL && @opponent.hasType?(:STEEL))  || @opponent.effects[:MeanLook]>=0 || @opponent.pbNonActivePokemonCount==0
			miniscore*=1.3
		else
			miniscore*=0.8
		end
		miniscore*=0.5 if @battle.doublebattle
		return miniscore
	end

	def spitecode(score)
		score+=10 if !$cache.moves[@opponent.lastMoveUsed].nil? && $cache.moves[@opponent.lastMoveUsed].basedamage>0 && (@opponent.moves.count {|moveloop| moveloop!=nil && moveloop.basedamage>0}) ==1
		score*=0.5 if !pbAIfaster?(@move)
		if !$cache.moves[@opponent.lastMoveUsed].nil? && $cache.moves[@opponent.lastMoveUsed].maxpp==5
			score*=1.5
		elsif !$cache.moves[@opponent.lastMoveUsed].nil? && $cache.moves[@opponent.lastMoveUsed].maxpp==10
			score*=1.2
		else
			score*=0.7
		end
		return score
	end

	def spoopycode
		return @move.basedamage > 0 ? 1 : 0 if @opponent.effects[:Curse] || (((@attacker.hp*2<@attacker.totalhp && @battle.FE != :HAUNTED) || (@attacker.hp*4<@attacker.totalhp)) && @move.function == 0x10d)
		miniscore=0.7
		miniscore*=0.5 if !pbAIfaster?(@move)
		miniscore*=1.3 if (getAIMemory().length > 0) && checkAIdamage()*5 < @attacker.hp if @move.function == 0x10d
		miniscore*=1.2 if @attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.isHealingMove?}
		miniscore*=(1+0.05*statchangecounter(@opponent,1,7))
		if PBStuff::TRAPPINGABILITIESAI.include?(@attacker.ability) || (@attacker.ability== :MAGNETPULL && @opponent.hasType?(:STEEL))  || @opponent.effects[:MeanLook]>=0 || @opponent.pbNonActivePokemonCount==0
			miniscore*=1.3
		else
			miniscore*=0.8
		end
		miniscore*=0.5 if @battle.doublebattle
		miniscore*=1.3 if @initial_scores.length>0 && hasbadmoves(25)
		return miniscore
	end

	def brickbreakcode(attacker=@attacker)
		miniscore = 1.0
		miniscore*=1.8 if attacker.pbOpposingSide.effects[:Reflect]>0
		miniscore*=1.3 if attacker.pbOpposingSide.effects[:LightScreen]>0
		miniscore*=2.0 if attacker.pbOpposingSide.effects[:AuroraVeil]>0
		miniscore*=1.3 if attacker.pbOpposingSide.effects[:AreniteWall]>0
		return miniscore
	end

	def jumpcode(score)
		miniscore=1.0
		miniscore*= 0.8 if score < 100
		miniscore*=0.5 if checkAImoves(PBStuff::PROTECTMOVE) && !(@move.contactMove? && @attacker.ability== :UNSEENFIST)
		miniscore*=(1-0.1*@opponent.stages[PBStats::EVASION])
		miniscore*=(1+0.1*@attacker.stages[PBStats::ACCURACY])
		miniscore*=0.7 if accuracyWeatherAbilityActive?(@opponent)
		#miniscore*=0.7 if (@mondata.oppitemworks && @opponent.item == :LAXINCENSE) || (@mondata.oppitemworks && @opponent.item == :BRIGHTPOWDER)
		return miniscore
	end

	def hazardcode
		return 0 if @battle.pbIsWild?
		if [:SPIKES,:CEASELESEDGE].include?(@move.move)
			for oppmon in @battle.pbParty(@opponent.index)
				#oppbattler = 
			end
		end # lawds dont set grounded hazards against all airborne teams and generally weigh value of spikes
		miniscore =1.0
		miniscore*=1.3 if @mondata.roles.include?(:LEAD) && !hasgreatmoves()
		miniscore*=1.3 if notOHKO?(@attacker, @opponent)
		miniscore*=1.5 if (!hasgreatmoves() && pbAIfaster?(@move)) # LAWDS - if the attacker is faster and cannot OHKO the opponent
		miniscore*=1.5 if @attacker.turncount<2
		miniscore*=0.80 if @attacker.stages[PBStats::ATTACK] > 0 || @attacker.stages[PBStats::SPATK] > 0 && @move.basedamage == 0
		miniscore*=1.5 if @move.function==0x105 && @battle.FE != :SKY && pbPartyHasAbility?(:GALEWINGS, @opponent.index) # LAWDS favor setting up rocks to break gale wings
		if pbPartyHasAbility?(:STURDY, @opponent.index) # LAWDS - if there's a sturdy mon on their team, then hazards are more valuable
			miniscore*=1.1
			miniscore*=1.1 if @move.function==0x105 # stealth rock especially is more valuable
		end
		if @move.basedamage == 0
			if @opponent.pbNonActivePokemonCount>2
				miniscore*=0.2*(@opponent.pbNonActivePokemonCount)
			else
				miniscore*=0.2
			end
			if !@battle.pbIsWild?
				oppparty = @battle.pbParty(@opponent.index).find_all.with_index {|mon,monindex| @battle.pbCanSwitch?(@opponent.index,monindex,false,true)}

				movecheck = false
				for mon in oppparty
					next if mon==@opponent.pokemon || mon==@opponent.pbPartner.pokemon
					for oppmove in mon.moves
						next if oppmove==nil
						if [:RAPIDSPIN,:DEFOG,:MORTALSPIN].include?(oppmove.move)
							movecheck = true 
							break
						end
					end
					if movecheck
						miniscore*=0.7 # LAWDS - only do a 0.7 multiplier for the party. 0.3 if theyre currently out
						break
					end
				end
				miniscore*=0.3 if (@opponent.pbHasMove?(:RAPIDSPIN) || @opponent.pbHasMove?(:DEFOG) || @opponent.pbHasMove?(:MORTALSPIN)) || 
				(@opponent.pbPartner && (@opponent.pbPartner.pbHasMove?(:RAPIDSPIN) || @opponent.pbPartner.pbHasMove?(:DEFOG) || @opponent.pbPartner.pbHasMove?(:MORTALSPIN)))

				miniscore*=0.001 if (@opponent.pbHasMove?(:MAGICCOAT) || @opponent.pbHasMove?(:MAGICCOAT)) && @move.basedamage==0
			end
		end
		miniscore*=1.5 if @attacker.effects[:seed_normalize]==true && @battle.FE == :INVERSE && !(@battle.doublebattle) && miniscore > 1.2 # LAWDS - makes Adam click Stealth Rock more often to set up for when the field changes
		return miniscore
	end

	def electricterraincode
		return @move.basedamage > 0 ? 1 : 0 if @battle.FE == :ELECTERRAIN || @battle.FE == :UNDERWATER || @battle.FE == :NEWWORLD || (Rejuv && @battle.FE == :DRAGONSDEN)
		if Rejuv && @battle.FE != :INDOOR
			return @move.basedamage > 0 ? 1 : 0 if @battle.state.effects[:ELECTERRAIN] > 0 || @battle.FE == :FROZENDIMENSION
			miniscore = 1
			miniscore*=1.5 if @attacker.ability== :SURGESURFER
			miniscore*=1.3 if @attacker.hasType?(:ELECTRIC)
			miniscore*=1.5 if pbPartyHasType?(:ELECTRIC)
			miniscore*=0.5 if @opponent.hasType?(:ELECTRIC)
			miniscore*=0.5 if @attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.function==0x03}
			miniscore*=1.6 if checkAImoves(PBStuff::SLEEPMOVE)
			miniscore*=2 if @mondata.attitemworks && @attacker.item == :AMPLIFIELDROCK
		else
			miniscore = getFieldDisruptScore(@attacker,@opponent)
			miniscore*=1.5 if @attacker.ability== :SURGESURFER
			miniscore*=1.3 if @attacker.hasType?(:ELECTRIC)
			miniscore*=1.5 if pbPartyHasType?(:ELECTRIC)
			miniscore*=0.5 if @opponent.hasType?(:ELECTRIC)
			miniscore*=0.5 if @attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.function==0x03}
			miniscore*=1.6 if checkAImoves(PBStuff::SLEEPMOVE)
			miniscore*=2 if @mondata.attitemworks && @attacker.item == :AMPLIFIELDROCK
		end
		return miniscore
	end

	def grassyterraincode
		return @move.basedamage > 0 ? 1 : 0 if @battle.FE == :GRASSY || @battle.FE == :UNDERWATER || @battle.FE == :NEWWORLD || (Rejuv && @battle.FE == :DRAGONSDEN)
		if Rejuv && @battle.FE != :INDOOR
			return @move.basedamage > 0 ? 1 : 0 if @battle.state.effects[:GRASSY] > 0 || @battle.FE == :FROZENDIMENSION
			miniscore = 1
			miniscore*=1.5 if @mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL)
			miniscore*=1.5 if @attacker.hasType?(:GRASS)
			miniscore*=2 if pbPartyHasType?(:GRASS)
			miniscore*=0.5 if checkAIhealing()
			miniscore*=1.5 if @attacker.ability== :GRASSPELT
			miniscore*=1.5 if @attacker.ability== :OVERGROW
			miniscore*=2 if @mondata.attitemworks && @attacker.item == :AMPLIFIELDROCK
		else
			miniscore = getFieldDisruptScore(@attacker,@opponent)
			miniscore*=1.5 if @mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL)
			miniscore*=1.5 if @attacker.hasType?(:FIRE)
			miniscore*=1.5 if pbPartyHasType?(:FIRE)
			if opponent.hasType?(:FIRE)
				miniscore*=0.5
				miniscore*=0.5 if @battle.pbWeather!=:RAINDANCE
				miniscore*=0.5 if @attacker.hasType?(:GRASS)
			elsif @attacker.hasType?(:GRASS)
				miniscore*=1.5
			end
			miniscore*=2 if pbPartyHasType?(:GRASS)
			miniscore*=0.5 if checkAIhealing()
			miniscore*=0.5 if checkAImoves([:SLUDGEWAVE])
			miniscore*=1.5 if @attacker.ability== :GRASSPELT
			miniscore*=2 if @mondata.attitemworks && @attacker.item == :AMPLIFIELDROCK
		end
		return miniscore
	end

	def mistyterraincode
		return 0 if @battle.FE == :MISTY || @battle.FE == :UNDERWATER || @battle.FE == :NEWWORLD || (Rejuv && @battle.FE == :DRAGONSDEN)
		if Rejuv && @battle.FE != :INDOOR
			return @move.basedamage > 0 ? 1 : 0 if @battle.state.effects[:MISTY] > 0 || @battle.FE == :FROZENDIMENSION
			miniscore = 1
			miniscore*=2 if pbPartyHasType?(:FAIRY)
			miniscore*=2 if !@attacker.hasType?(:FAIRY) && @opponent.hasType?(:DRAGON)
			miniscore*=0.5 if @attacker.hasType?(:DRAGON)
			miniscore*=0.5 if @opponent.hasType?(:FAIRY)
			miniscore*=2 if @attacker.hasType?(:FAIRY) && @opponent.spatk>@opponent.attack
			miniscore*=2 if @mondata.attitemworks && @attacker.item == :AMPLIFIELDROCK
		else
			miniscore = getFieldDisruptScore(@attacker,@opponent)
			miniscore*=2 if pbPartyHasType?(:FAIRY)
			miniscore*=2 if !@attacker.hasType?(:FAIRY) && @opponent.hasType?(:DRAGON)
			miniscore*=0.5 if @attacker.hasType?(:DRAGON)
			miniscore*=0.5 if @opponent.hasType?(:FAIRY)
			miniscore*=2 if @attacker.hasType?(:FAIRY) && @opponent.spatk>@opponent.attack
			miniscore*=2 if @mondata.attitemworks && @attacker.item == :AMPLIFIELDROCK
		end
		return miniscore
	end

	def arocode(stat)
		return 0 if !(@battle.doublebattle && @opponent.index==@attacker.pbPartner.index && @opponent.stages[stat]!=6)
		miniscore=1.0
		newopp = @attacker.pbOppositeOpposing
		miniscore*= newopp.spatk > newopp.attack ? 2 : 0.5
		miniscore*=1.3 if @initial_scores.length>0 && hasbadmoves(20)
		miniscore*=1.1 if @opponent.hp*(1.0/@opponent.totalhp)>0.75
		miniscore*=0.3 if @opponent.effects[:Yawn]>0 || @opponent.effects[:LeechSeed]>=0 || @opponent.effects[:Attract]>=0 || !@opponent.status.nil?
		if !@battle.pbIsWild?
			oppparty = @aiMoveMemory[@battle.pbGetOwner(newopp.index)]
			movecheck = false
			for key in oppparty.keys
				movecheck = true if oppparty[key].any? {|moveloop| moveloop!=nil && PBStuff::PHASEMOVE.include?(moveloop.move)}
			end
		end
		miniscore*=0.2 if movecheck
		miniscore*=2   if (@opponent.ability== :SIMPLE)
		miniscore*=0.5 if newopp.ability== :UNAWARE
		miniscore*=1.2 if hpGainPerTurn>1
		miniscore*=0 if @opponent.ability== :CONTRARY
		miniscore*=2 if @battle.FE == :MISTY && stat==PBStats::SPDEF
	end

	def flowershieldcode(score)
		return 0 unless @battle.doublebattle && @opponent.hasType?(:GRASS) && @opponent.index==@attacker.pbPartner.index && @opponent.stages[PBStats::DEFENSE]!=6
		opp1 = @attacker.pbOppositeOpposing
		opp2 = opp1.pbPartner
		if !@battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,2,5)
			score*= opp1.attack>opp1.spatk ? 2 : 0.5
			score*= opp2.attack>opp2.spatk ? 2 : 0.5
		else
			score*=2
		end
		score+=30 if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,1,4)
		if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,2,5)|| @battle.FE == :FAIRYTALE
			score+=20
			miniscore=100
			miniscore*=1.3 if @attacker.effects[:Substitute]>0 || ((@attacker.effects[:Disguise] || (@attacker.effects[:IceFace] && (@opponent.attack > @opponent.spatk || @battle.FE == :FROZENDIMENSION))) && !moldBreakerCheck(@opponent))
			miniscore*=1.3 if @initial_scores.length>0 && hasbadmoves(20)
			miniscore*=1.1 if (@opponent.hp.to_f)/@opponent.totalhp>0.75
			miniscore*=1.2 if opp1.effects[:HyperBeam]>0
			miniscore*=1.3 if opp1.effects[:Yawn]>0
			miniscore*=1.1 if checkAIdamage() < @opponent.hp*0.3
			miniscore*=1.1 if @opponent.turncount<2
			miniscore*=1.1 if !opp1.status.nil?
			miniscore*=1.3 if opp1.status== :SLEEP || opp1.status== :FROZEN
			miniscore*=1.5 if opp1.effects[:Encore]>0 && opp1.moves[(opp1.effects[:EncoreIndex])].basedamage==0
			miniscore*=0.5 if @opponent.effects[:Confusion]>0
			miniscore*=0.3 if @opponent.effects[:LeechSeed]>=0 || @attacker.effects[:Attract]>=0
			miniscore*=0.2 if @opponent.effects[:Toxic]>0
			# Gen 9 Mod - Additional Checks for Salt Cure similar to the the toxic check above.
      		miniscore*=0.6 if @opponent.effects[:SaltCure] && @opponent.ability != :MAGICGUARD
      		miniscore*=0.6 if @opponent.effects[:SaltCure] && @opponent.ability != :MAGICGUARD && (@opponent.hasType?(:WATER) || @opponent.hasType?(:STEEL))
			miniscore*=0.2 if checkAImoves(PBStuff::PHASEMOVE)
			miniscore*=2   if (@opponent.ability== :SIMPLE)
			miniscore*=0.5 if opp1.ability== :UNAWARE
			miniscore*=0.3 if @battle.doublebattle
			miniscore/=100.0
			score*=miniscore
			miniscore=100
			miniscore*=1.5 if @mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL)
			miniscore*=1.2 if (@mondata.attitemworks && @attacker.item == :LEFTOVERS) || ((@mondata.attitemworks && @attacker.item == :BLACKSLUDGE) && @attacker.hasType?(:POISON))
			miniscore*=1.7 if @attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.isHealingMove?}
			miniscore*=1.3 if @attacker.pbHasMove?(:LEECHSEED)
			miniscore*=1.2 if @attacker.pbHasMove?(:PAINSPLIT)
			score*=miniscore if @attacker.stages[PBStats::SPDEF]!=6 && @attacker.stages[PBStats::DEFENSE]!=6
			score=0 if @attacker.ability== :CONTRARY
		end
		return score
	end

	def rotocode(score)
		return 0 unless @battle.doublebattle && @opponent.index == @attacker.pbPartner.index
		return 0 if !(@battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,2,5)) && (!@opponent.hasType?(:GRASS) || @opponent.isAirborne?)
		miniscore = 1.0
		if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,2,5) && @attacker.hasType?(:GRASS) && !@attacker.isAirborne?
			score+=30
			miniscore*= selfstatboost([2,0,0,2,0,0,0])
		end
		if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN)
			score+=20
			miniscore*=1.3 if @attacker.effects[:Substitute]>0 || ((@attacker.effects[:Disguise] || (@attacker.effects[:IceFace] && (@opponent.attack > @opponent.spatk || @battle.FE == :FROZENDIMENSION))) && !moldBreakerCheck(@opponent))
			miniscore*=1.3 if @initial_scores.length>0 && hasbadmoves(20)
			miniscore*=1.1 if (@opponent.hp.to_f)/@opponent.totalhp>0.75
			miniscore*=1.2 if opp1.effects[:HyperBeam]>0
			miniscore*=1.3 if opp1.effects[:Yawn]>0
			miniscore*=1.1 if checkAIdamage() < @opponent.hp*0.25
			miniscore*=1.1 if @opponent.turncount<2
			miniscore*=1.1 if !opp1.status.nil?
			miniscore*=1.3 if opp1.status== :SLEEP || opp1.status== :FROZEN
			miniscore*=1.5 if opp1.effects[:Encore]>0 && opp1.moves[(opp1.effects[:EncoreIndex])].basedamage==0
			miniscore*=0.2 if @opponent.effects[:Confusion]>0
			miniscore*=0.6 if @opponent.effects[:LeechSeed]>=0 || @attacker.effects[:Attract]>=0
			miniscore*=0.5 if checkAImoves(PBStuff::PHASEMOVE)
			miniscore*=2   if (@opponent.ability== :SIMPLE)
			miniscore*=0.5 if opp1.ability== :UNAWARE
			miniscore*=0.3 if @battle.doublebattle
			miniscore*=1+0.05*@opponent.stages[PBStats::SPEED] if @opponent.stages[PBStats::SPEED]<0
			ministat=@opponent.stages[PBStats::ATTACK] + @opponent.stages[PBStats::SPEED] + @opponent.stages[PBStats::SPATK]
			miniscore*=1 -0.05*ministat if ministat > 0
			miniscore*=1.3 if checkAIhealing()
			miniscore*=1.5 if @attacker.pbSpeed>pbRoughStat(@opponent,PBStats::SPEED,@mondata.skill) && @battle.trickroom==0
			miniscore*=1.3 if @mondata.roles.include?(:SWEEPER)
			miniscore*=0.5 if @attacker.status== :PARALYSIS
			miniscore*=0.3 if checkAImoves([:FOULPLAY])
			miniscore*=1.4 if @attacker.hp==@attacker.totalhp && (@mondata.attitemworks && @attacker.item == :FOCUSSASH)
			miniscore*=0.4 if checkAIpriority()
			score*=miniscore
		end
		return score
	end

	def craftyshieldcode(score)
		if attacker.lastMoveUsed==:CRAFTYSHIELD
			score*=0.5
		else
			score+=10 if opponent.moves.all? {|moveloop| moveloop!=nil && moveloop.basedamage>0}
			score*=1.5 if attacker.hp==attacker.totalhp
		end
		if @battle.FE == :FAIRYTALE
			score+=25
			score*=selfstatboost([0,1,0,0,1,0,0])
		end
		return score
	end

	def turvycode
		miniscore = [(1 + 0.10*statchangecounter(@opponent,1,7)),0].max
		miniscore = 2-miniscore if @opponent.index == @attacker.pbPartner.index
		return miniscore
	end

	def fairylockcode
		return 0 if @attacker.effects[:PerishSong]==1 || @attacker.effects[:PerishSong]==2
	 	miniscore=1.0
		miniscore*=10 if @opponent.effects[:PerishSong]==2
		miniscore*=20 if @opponent.effects[:PerishSong]==1
		miniscore*=0.8 if @attacker.effects[:LeechSeed]>=0
		miniscore*=1.2 if @opponent.effects[:LeechSeed]>=0
		miniscore*=1.3 if @opponent.effects[:Curse]
		miniscore*=0.7 if @attacker.effects[:Curse]
		miniscore*=1.1 if @opponent.effects[:Confusion]>0
		miniscore*=1.1 if @attacker.effects[:Confusion]>0
		return miniscore
	end

	def flingcode
		return 0 if @attacker.item.nil? || @battle.pbIsUnlosableItem(@attacker,@attacker.item) || # @attacker.ability== :KLUTZ || lawds klutz rework
		(pbIsBerry?(@attacker.item) && (@opponent.ability== :UNNERVE || @opponent.ability== :ASONE)) || @attacker.effects[:Embargo]>0 || @battle.state.effects[:MagicRoom]>0
		miniscore=1.0
		case @attacker.item
			when :POISONBARB then miniscore*=1.2 if @opponent.pbCanPoison?(false) && @opponent.ability != :POISONHEAL && @opponent.crested != :ZANGOOSE
			when :TOXICORB
				if @opponent.pbCanPoison?(false) && @opponent.ability != :POISONHEAL && @opponent.crested != :ZANGOOSE
					miniscore*=1.2
					miniscore*=2 if @attacker.pbCanPoison?(false) && @attacker.ability != :POISONHEAL
				end
			when :FLAMEORB
				if @opponent.pbCanBurn?(false) && @opponent.ability != :GUTS && @opponent.ability != :QUICKFEET
					miniscore*=1.3
					miniscore*=2 if @attacker.pbCanBurn?(false) && @attacker.ability != :GUTS
				end
			when :LIGHTBALL then miniscore*=1.3 if @opponent.pbCanParalyze?(false) && @opponent.ability != :QUICKFEET
			when :KINGSROCK, :RAZORFANG then miniscore*=1.3 if @opponent.ability != :INNERFOCUS && pbAIfaster?(@move)
			when :LAXINCENSE, :CHOICESCARF, :CHOICEBAND, :CHOICESPECS, :SYNTHETICSEED, :TELLURICSEED, :ELEMENTALSEED, :MAGICALSEED, :EXPERTBELT, :FOCUSSASH, :LEFTOVERS, :MUSCLEBAND, :WISEGLASSES, :LIFEORB, :EVIOLITE, :ASSAULTVEST, :BLACKSLUDGE, :POWERHERB, :MENTALHERB
				miniscore*=0
			when :STICKYBARB then miniscore*=1.2
			when :LAGGINGTAIL then miniscore*=3
			when :IRONBALL then miniscore*=1.5 if @battle.FE!=:DEEPEARTH # lawds iron ball doesnt innately reduce speed while held on deep earth, so dont boost the miniscore
		end
		if !@attacker.item.nil? && pbIsBerry?(@attacker.item)
			if @attacker.item ==:FIGYBERRY || @attacker.item ==:WIKIBERRY || @attacker.item ==:MAGOBERRY || @attacker.item ==:AGUAVBERRY || @attacker.item ==:IAPAPABERRY
				miniscore*=1.3 if @opponent.pbCanConfuse?(false)
			else
				miniscore*=0
			end
		end
		miniscore*=1.5 if @attacker.ability==:UNBURDEN && @initial_scores[@score_index] >= 110 # lawds
		return miniscore
	end

	def recyclecode
		return 0 if @attacker.pokemon.itemRecycle.nil?
		return 0 if (@opponent.ability== :MAGICIAN && @opponent.item.nil?) || checkAImoves([:KNOCKOFF,:THIEF,:COVET])
		return 0 if @attacker.ability== :UNBURDEN || @attacker.ability== :HARVEST || @attacker.pbHasMove?(:ACROBATICS)
		miniscore=2.0
		miniscore*=2 if @attacker.pbHasMove?(:NATURALGIFT)
		case @attacker.pokemon.itemRecycle
			when :LUMBERRY
				miniscore*=2 if !@attacker.status.nil?
			when :SITRUSBERRY, :FIGYBERRY, :WIKIBERRY, :MAGOBERRY, :AGUAVBERRY, :IAPAPABERRY
				miniscore*=1.6 if @attacker.hp<0.66*@attacker.totalhp
				miniscore*=1.5 if @mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL)
		end

		if !@attacker.item.nil? && pbIsBerry?(@attacker.pokemon.itemRecycle)
			miniscore*=0 if @opponent.ability== :UNNERVE || @opponent.ability== :ASONE
			miniscore*=0 if checkAImoves([:INCINERATE,:PLUCK,:BUGBITE])
		end
		return miniscore
	end



	def embarcode(opponent=@opponent)
		return 0 if opponent.effects[:Embargo]>0  && opponent.effects[:Substitute]>0 || opponent.item.nil?
		miniscore = 1.1
		miniscore*=1.1 if !opponent.item.nil? && pbIsBerry?(opponent.item)
		case opponent.item
			# LAWDS - generic seed
			when :LAXINCENSE, :SYNTHETICSEED, :TELLURICSEED, :ELEMENTALSEED, :MAGICALSEED, :SEED, :EXPERTBELT, :MUSCLEBAND, :WISEGLASSES, :LIFEORB, :EVIOLITE, :ASSAULTVEST
				miniscore*=1.2
			when :LEFTOVERS, :BLACKSLUDGE
				miniscore*=1.3
		end
		miniscore*=1.4 if opponent.hp*2<opponent.totalhp
		return miniscore
	end

	def roastcode
		return 1 if !@opponent.item.nil? && !pbIsBerry?(@opponent.item) && !pbIsTypeGem?(@opponent.item) || @opponent.ability== :STICKYHOLD || @opponent.effects[:Substitute] > 0
		miniscore=1.0
		miniscore*=1.2 if !@opponent.item.nil? && pbIsBerry?(@opponent.item) && @opponent.item!=:OCCABERRY
		miniscore*=1.3 if @opponent.item ==:LUMBERRY || @opponent.item ==:SITRUSBERRY || @opponent.item ==:PETAYABERRY || @opponent.item ==:LIECHIBERRY || @opponent.item ==:SALACBERRY || @opponent.item ==:CUSTAPBERRY
		miniscore*=1.4 if !@opponent.item.nil? && pbIsTypeGem?(@opponent.item)
		return miniscore
	end

	def nomcode
		return 1 if @opponent.effects[:Substitute] > 0 || (!@opponent.item.nil? && !pbIsBerry?(@opponent.item))
		miniscore=1.0
		case @opponent.item
			when :LUMBERRY then miniscore*=2 if !@attacker.status.nil?
			when :CHERIBERRY then miniscore*=2 if @attacker.status == :PARALYSIS
			when :RAWSTBERRY then miniscore*=2 if @attacker.status == :BURN
			when :PECHABERRY then miniscore*=2 if @attacker.status == :POISON
			when :SITRUSBERRY, :FIGYBERRY, :WIKIBERRY, :MAGOBERRY, :AGUAVBERRY, :IAPAPABERRY then miniscore*=1.6 if @attacker.hp*(1.0/@attacker.totalhp)<0.66
			when :LIECHIBERRY then miniscore*=1.5 if @attacker.attack>@attacker.spatk
			when :PETAYABERRY then miniscore*=1.5 if @attacker.spatk>@attacker.attack
			when :CUSTAPBERRY, :SALACBERRY then miniscore*= pbAIfaster? ? 1.1 : 1.5
			else
				miniscore*=1.1
		end
		return miniscore
	end

	def teaslurpcode
		miniscore=1.0
		if !(@attacker.item.nil? || !pbIsBerry?(@attacker.item))
			case @attacker.item
				when :LUMBERRY then miniscore*=2 if !@attacker.status.nil?
				when :SITRUSBERRY, :FIGYBERRY, :WIKIBERRY, :MAGOBERRY, :AGUAVBERRY, :IAPAPABERRY then miniscore*=1.6 if @attacker.hp*(1.0/@attacker.totalhp)<0.66
				when :LIECHIBERRY then miniscore*=1.5 if @attacker.attack>@attacker.spatk
				when :PETAYABERRY then miniscore*=1.5 if @attacker.spatk>@attacker.attack
				when :CUSTAPBERRY, :SALACBERRY then miniscore*= pbAIfaster? ? 1.1 : 1.5
				else
					miniscore*=1.1
			end
		end
		return miniscore if @opponent.item.nil? || !pbIsBerry?(@opponent.item)
		case @opponent.item
			when :LUMBERRY then miniscore*=0.5 if !@opponent.status.nil?
			when :SITRUSBERRY, :FIGYBERRY, :WIKIBERRY, :MAGOBERRY, :AGUAVBERRY, :IAPAPABERRY then miniscore*=0.65 if @opponent.hp*(1.0/@opponent.totalhp)<0.66
			when :LIECHIBERRY then miniscore*=0.7 if @opponent.attack>@opponent.spatk
			when :PETAYABERRY then miniscore*=0.7 if @opponent.spatk>@opponent.attack
			when :CUSTAPBERRY, :SALACBERRY then miniscore*= !pbAIfaster? ? 0.9 : 0.5
			else
				miniscore*=0.9
		end
		return miniscore
	end

	def perishcode
		return 0 if @opponent.effects[:PerishSong]>0
		return 4 if @opponent.pbNonActivePokemonCount==0
		return 0 if @attacker.pbNonActivePokemonCount==0
		miniscore=1.0
		miniscore*=1.5 if @attacker.pbHasMove?(:UTURN) || @attacker.pbHasMove?(:VOLTSWITCH) || @attacker.pbHasMove?(:PARTINGSHOT)
		miniscore*=3 if PBStuff::TRAPPINGABILITIESAI.include?(@attacker.ability) || (@attacker.ability== :MAGNETPULL && @opponent.hasType?(:STEEL))  || @opponent.effects[:MeanLook]>0
		miniscore*=1.2 if @mondata.partyroles.any? {|role| role.include?(:SWEEPER)}
		miniscore*=1.2 if @attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.isHealingMove?}
		miniscore*=1.2 if @attacker.moves.any? {|moveloop| moveloop!=nil && (PBStuff::PROTECTMOVE).include?(moveloop.move)} && @opponent.ability != :UNSEENFIST
		miniscore*=1-0.05*statchangecounter(@attacker,1,7)
		miniscore*=1+0.05*statchangecounter(@opponent,1,7)
		miniscore*=0.5 if checkAImoves(PBStuff::PIVOTMOVE)
		miniscore*=0.1 if (PBStuff::TRAPPINGABILITIESAI.include?(@attacker.ability) || (@attacker.ability== :MAGNETPULL && @opponent.hasType?(:STEEL))  || @attacker.effects[:MeanLook]>0) && !(@attacker.pbHasMove?(:UTURN) || @attacker.pbHasMove?(:VOLTSWITCH) || @attacker.pbHasMove?(:PARTINGSHOT))
		miniscore*=1.5 if @mondata.partyroles.any? {|role| role.include?(:PIVOT)}
		return miniscore
    end

	def noLeechSeed(leechTarget)
		return true if leechTarget.effects[:LeechSeed] > -1
		return true if leechTarget.hasType?(:GRASS)
		return true if leechTarget.effects[:Substitute] > 0 
		return true if leechTarget.ability== :LIQUIDOOZE
		return true if leechTarget.ability== :MAGICBOUNCE
		return true if leechTarget.ability== :MAGICGUARD # LAWDS - dont leech seed a magic guard mon
		return true if leechTarget.ability== :REFLECTOR # LAWDS - Reflector acts like MBounce
		return true if leechTarget.effects[:MagicCoat]==true
		return true if leechTarget.hp == 0
		return false
	end

	def leechcode
		return 0 if noLeechSeed(@opponent)
		miniscore=1.0
		miniscore*=1.2 if (@mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL) || @mondata.roles.include?(:TANK))
		miniscore*=1.3 if @attacker.effects[:Substitute]>0
		miniscore*=1.2 if hpGainPerTurn(@opponent)>1 || (@mondata.attitemworks && @attacker.item == :BIGROOT) || @attacker.crested == :SHIINOTIC
		miniscore*=1.2 if @opponent.status== :PARALYSIS || @opponent.status== :SLEEP
		miniscore*=1.2 if @opponent.effects[:Confusion]>0
		miniscore*=1.2 if @opponent.effects[:Attract]>=0
		miniscore*=1.1 if @opponent.status== :POISON || @opponent.status== :BURN
		miniscore*=0.2 if checkAImoves(([:RAPIDSPIN,:MORTALSPIN] | PBStuff::PIVOTMOVE))
		if @opponent.hp==@opponent.totalhp
			miniscore*=1.1
		else
			miniscore*=(@opponent.hp*(1.0/@opponent.totalhp))
		end
		miniscore*=0.8 if @opponent.hp*2<@opponent.totalhp
		miniscore*=0.2 if @opponent.hp*4<@opponent.totalhp
		miniscore*=1.2 if @attacker.moves.any? {|moveloop| moveloop!=nil && (PBStuff::PROTECTMOVE).include?(moveloop.move)} && @opponent.ability != :UNSEENFIST
		miniscore*=1 + 0.05*statchangecounter(@opponent,1,7,1)
		return miniscore
	end

	def moveturnselectriccode(alltypes,damagemove)
		miniscore=1.0
		maxnormal= alltypes ? checkAIbestMove().type==:NORMAL : true
		if pbAIfaster?(@move)
			miniscore*=0.9
		elsif @attacker.ability== :MOTORDRIVE && maxnormal
			miniscore*=1.5
		end
		miniscore*=1.5 if (@attacker.ability== :LIGHTNINGROD || @attacker.ability== :VOLTABSORB) && @attacker.hp.to_f < 0.6*@attacker.totalhp && maxnormal
		miniscore*=1.1 if @attacker.hasType?(:GROUND)
		if @battle.doublebattle
			miniscore*=1.2 if [:MOTORDRIVE, :LIGHTNINGROD, :VOLTABSORB].include?(@attacker.pbPartner.ability)
			miniscore*=1.1 if @attacker.pbPartner.hasType?(:GROUND)
		end
		miniscore*=0.5 if !maxnormal
		return miniscore
	end

	def bidecode
		miniscore=@attacker.hp*(1.0/@attacker.totalhp)
		miniscore*=0.5 if hasgreatmoves()
		miniscore*=1.2 if notOHKO?(@attacker, @opponent, true)
		miniscore*=0.2 if checkAIdamage()*2 > @attacker.hp
		miniscore*=0.7 if @attacker.hp*3<@attacker.totalhp
		miniscore*=1.1 if (@mondata.attitemworks && @attacker.item == :LEFTOVERS) || ((@mondata.attitemworks && @attacker.item == :BLACKSLUDGE) && @attacker.hasType?(:POISON))
		miniscore*=1.3 if @mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL)
		miniscore*=1.3 if !pbAIfaster?()
		miniscore*=0.5 if checkAImoves(PBStuff::SETUPMOVE)
		
		if getAIMemory().any? {|moveloop| moveloop!=nil && moveloop.basedamage==0}
			miniscore*=0.8
		elsif getAIMemory().length==4
			miniscore*=1.3
		end
		return miniscore
	end

	def rolloutcode
		miniscore=1.0
		miniscore*=1.1 if @opponent.pbNonActivePokemonCount==0 || PBStuff::TRAPPINGABILITIESAI.include?(@attacker.ability) || (@attacker.ability== :MAGNETPULL && @opponent.hasType?(:STEEL)) || @opponent.effects[:MeanLook]>0
		miniscore*=0.75 if @attacker.hp*(1.0/@attacker.totalhp)<0.75
		miniscore*=1+0.05*@attacker.stages[PBStats::ACCURACY] if @attacker.stages[PBStats::ACCURACY]<0
		miniscore*=1+0.05*@attacker.stages[PBStats::ATTACK] if @attacker.stages[PBStats::ATTACK]<0
		miniscore*=1-0.05*@opponent.stages[PBStats::EVASION] if @opponent.stages[PBStats::EVASION]>0
		#miniscore*=0.8 if (@mondata.oppitemworks && @opponent.item == :LAXINCENSE) || (@mondata.oppitemworks && @opponent.item == :BRIGHTPOWDER)
		miniscore*=0.8 if accuracyWeatherAbilityActive?(@opponent)
		miniscore*=0.5 if @attacker.status== :PARALYSIS
		miniscore*=0.5 if @attacker.effects[:Confusion]>0
		miniscore*=0.5 if @attacker.effects[:Attract]>=0
		miniscore*= 1 - (@opponent.pbNonActivePokemonCount*0.05) if @opponent.pbNonActivePokemonCount>1
		miniscore*=1.2 if @attacker.effects[:DefenseCurl]
		miniscore*=1.5 if checkAIdamage()*3<@attacker.hp && (getAIMemory().length > 0)
		miniscore+=4 if hasbadmoves(15)
		miniscore*=0.8 if checkAImoves(PBStuff::PROTECTMOVE) && !(@move.contactMove? && @attacker.ability== :UNSEENFIST)
		return miniscore
	end

	def outragecode(score)
		return 1.3 if @attacker.ability== :OWNTEMPO
		return 1.3 if @move.move == :RAGINGFURY && [:VOLCANIC,:VOLCANICTOP].include?(@battle.FE)
		miniscore=1.0
		miniscore*=0.85 if score<100
		miniscore*=1.3 if (@mondata.attitemworks && @attacker.item == :LUMBERRY) || (@mondata.attitemworks && @attacker.item == :PERSIMBERRY)
		miniscore*=1-0.05*@attacker.stages[PBStats::ATTACK] if @attacker.stages[PBStats::ATTACK]>0
		miniscore*=1-0.025*(@battle.pbPokemonCount(@battle.pbPartySingleOwner(@attacker.index))) if (@battle.pbPokemonCount(@battle.pbPartySingleOwner(@attacker.index))) > 2
		miniscore*=0.7 if checkAImoves(PBStuff::PROTECTMOVE) && !(@move.contactMove? && @attacker.ability== :UNSEENFIST)
		miniscore*=0.7 if checkAIhealing()
		return miniscore
    end

	def spectralthiefcode
		miniscore= 0.10*statchangecounter(@opponent,1,7)
		miniscore*=(-1) if @attacker.ability== :CONTRARY
		miniscore*=2 if (@attacker.ability== :SIMPLE)
		miniscore+=1
		miniscore*=1.2 if @opponent.effects[:Substitute]>0
		return miniscore
	end

	def stupidmovecode
		return 0 if pbAIfaster?()
		return 0 if @opponent.stages[PBStats::SPEED]==0 && @attacker.stages[PBStats::SPEED]==0
		miniscore = 1 + 0.1*@opponent.stages[PBStats::SPEED] - 0.1*@attacker.stages[PBStats::SPEED]
		miniscore*=0.8 if @battle.doublebattle
		return miniscore
	end

	def spotlightcode
		return 0 if !@battle.doublebattle || @opponent.index!=@attacker.pbPartner.index
		miniscore=1.0
		bestmove1 = checkAIbestMove(@attacker.pbOpposing1) #grab moves opposing mons are going to use
		bestmove2 = checkAIbestMove(@attacker.pbOpposing2)
		if @opponent.ability== :FLASHFIRE || @opponent.crested == :DRUDDIGON
			miniscore*=3 if bestmove1.pbType(@attacker.pbOpposing1) ==:FIRE || bestmove2.pbType(@attacker.pbOpposing2) ==:FIRE
		elsif @opponent.ability== :STORMDRAIN || @opponent.ability== :DRYSKIN || @opponent.ability== :WATERABSORB
			miniscore*=3 if bestmove1.pbType(@attacker.pbOpposing1) ==:WATER || bestmove2.pbType(@attacker.pbOpposing2) ==:WATER
		elsif @opponent.ability== :ENTOMOPHAGY # lawds entomophagous
			miniscore*=3 if bestmove1.pbType(@attacker.pbOpposing1) ==:BUG || bestmove2.pbType(@attacker.pbOpposing2) ==:BUG
		elsif @opponent.ability== :MOTORDRIVE || @opponent.ability== :LIGHTNINGROD || @opponent.ability== :VOLTABSORB
			miniscore*=3 if bestmove1.pbType(@attacker.pbOpposing1) ==:ELECTRIC ||bestmove2.pbType(@attacker.pbOpposing2) ==:ELECTRIC
		elsif @opponent.ability== :SAPSIPPER || @opponent.pbPartner.crested == :WHISCASH
			miniscore*=3 if bestmove1.pbType(@attacker.pbOpposing1) ==:GRASS || bestmove2.pbType(@attacker.pbOpposing2) ==:GRASS
		elsif @opponent.crested == :SKUNTANK || @opponent.ability== :EARTHEATER # Gen 9 Mod - Added Earth Eater
			miniscore*=3 if bestmove1.pbType(@attacker.pbOpposing1) ==:GROUND || bestmove2.pbType(@attacker.pbOpposing2) ==:GROUND
		elsif @opponent.ability== :SPIRITSENVOY # LAWDS - spirit's envoy
			miniscore*=3 if (bestmove1.pbType(@attacker.pbOpposing1) ==:GHOST || bestmove2.pbType(@attacker.pbOpposing2) ==:GHOST) && @battle.FE!=:HAUNTED
		end
		miniscore*=2 if (bestmove1.contactMove? || bestmove2.contactMove?) && checkAImoves([:KINGSSHIELD, :BANEFULBUNKER, :SPIKYSHIELD, :SILKTRAP, :BURNINGBULWARK]) # Gen 9 Mod - Added Silky Trap and Burning Bulwark
		miniscore*=2 if checkAImoves([:COUNTER, :METALBURST, :MIRRORCOAT])
		miniscore*=1.5 if !pbAIfaster?(nil,nil,@attacker,@attacker.pbOpposing1)
		miniscore*=1.5 if !pbAIfaster?(nil,nil,@attacker,@attacker.pbOpposing2)
		miniscore*=100 if @battle.opponent && !@battle.opponent.is_a?(Array) && @battle.opponent.trainertype==:LEADER_MARIANETTE && @battle.state.effects[:GRASSY]==0 && @attacker.pbPartner.ability==:SEEDSOWER # lawds
		return miniscore
	end

	def saltcurecode # Salt Cure
		return 1 if (@opponent.effects[:SaltCure] || secondaryEffectNegated?() || @opponent.ability==:MAGICGUARD)
		miniscore=1.3
		miniscore*=3 if @opponent.hasType?(:WATER) || @opponent.hasType?(:STEEL) || @battle.FE == :HOLY # LAWDS - Salt Cure chip is always 1/4 on Blessed
		miniscore*=2 if (@attacker.ability==:STALL || @opponent.ability==:STALL || @attacker.pbPartner.ability==:STALL)
		return miniscore
	end

	def doodlecode # Gen 9 Mod - Doodle Code
		return 0 if (PBStuff::ABILITYBLACKLIST).include?(@opponent.ability)
		return 0 if (PBStuff::FIXEDABILITIES).include?(@attacker.ability)
		return 0 if (PBStuff::FIXEDABILITIES).include?(@attacker.pbPartner.ability)
		return 0 if @opponent.ability== 0 || (@attacker.ability== @opponent.ability && @attacker.pbPartner.ability== @opponent.ability)
		return 0 if ((@mondata.attitemworks && @attacker.item == :ABILITYSHIELD) || (@attacker.pbPartner.itemWorks? && @attacker.pbPartner.item == :ABILITYSHIELD))
		miniscore = getAbilityDisruptScore(@opponent,@attacker)
		miniminiPartner = getAbilityDisruptScore(@attacker.pbPartner,@opponent)
		minimini = getAbilityDisruptScore(@attacker,@opponent)
		return (1 + ((minimini+miniminiPartner)-miniscore))
	end

	def doubleshockcode # Double Shock
		return 0 if !@attacker.hasType?(:ELECTRIC)
		miniscore= (1-@opponent.pbNonActivePokemonCount*0.05)
		if @initial_scores[@score_index]<100
		miniscore*=0.9
		miniscore*=0.5 if getAIMemory().any? {|moveloop| moveloop!=nil && moveloop.isHealingMove?}
		end
		miniscore*=0.5 if @initial_scores.length>0 && hasgreatmoves()
		miniscore*=0.7 if @attacker.pbNonActivePokemonCount==0 && @opponent.pbNonActivePokemonCount!=0
		effcheck = PBTypes.twoTypeEff(@opponent.type1,(:ELECTRIC),(:ELECTRIC))
		miniscore*=1.5 if effcheck > 4
		miniscore*=0.5 if effcheck < 4
		effcheck = PBTypes.twoTypeEff(@opponent.type2,(:ELECTRIC),(:ELECTRIC))
		miniscore*=1.5 if effcheck > 4
		miniscore*=0.5 if effcheck < 4
		effcheck = PBTypes.twoTypeEff(checkAIbestMove().pbType(@opponent),(:ELECTRIC),(:ELECTRIC))
		miniscore*=1.5 if effcheck > 4
		miniscore*=0.5 if effcheck < 4
		return miniscore
	end

	def shedtailcode # Gen 9 Mod - Shed Tail - Combined version of pivotcode and subcode specific for shed tail.
		return 0 if @attacker.hp*2<=@attacker.totalhp
		return 0 if @attacker.effects[:Substitute]>0 && pbAIfaster?(@move)
		return 0 if @attacker.pbNonActivePokemonCount==1 && $game_switches[:NameOverwrite]
		return @move.basedamage > 0 ? 1 : 0 if @attacker.pbNonActivePokemonCount==0 || @battle.FE == :COLOSSEUM

		miniscore = 1.0
		miniscore*= (@attacker.hp==@attacker.totalhp) ? 1.1 : (@attacker.hp*(1.0/@attacker.totalhp))
		miniscore*=1.2 if @opponent.effects[:LeechSeed]>=0
		miniscore*=1.2 if checkAImoves([:SPORE, :SLEEPPOWDER])
		miniscore*=1.5 if @opponent.status== :SLEEP
		miniscore*=0.3 if @opponent.ability== :INFILTRATOR
		miniscore*=0.3 if checkAImoves([:UPROAR, :HYPERVOICE, :ECHOEDVOICE, :SNARL, :BUGBUZZ, :BOOMBURST, :SPARKLINGARIA, :CLANGINGSCALES, :OVERDRIVE, :TORCHSONG, :PSYCHICNOISE])
		miniscore*=2   if checkAIdamage()*4 < @attacker.totalhp && (getAIMemory().length > 0)
		miniscore*=1.3 if @opponent.effects[:Confusion]>0
		miniscore*=1.3 if @opponent.status== :PARALYSIS
		miniscore*=1.3 if @opponent.effects[:Attract]>=0
		miniscore*=0.5 if @battle.doublebattle

		miniscore=1.0
		miniscore*=0.7 if @attacker.pbOwnSide.effects[:StealthRock]
		miniscore*=0.6 if @attacker.pbOwnSide.effects[:StickyWeb]
		miniscore*=0.9**@attacker.pbOwnSide.effects[:Spikes] if @attacker.pbOwnSide.effects[:Spikes]>0
		miniscore*=0.9**@attacker.pbOwnSide.effects[:ToxicSpikes] if @attacker.pbOwnSide.effects[:ToxicSpikes]>0
		miniscore*=1.1 if @opponent.ability== :INTIMIDATE

		miniscore*=1.1 if @attacker.ability== :SUPERSWEETSYRUP
		miniscore*=1.1 if @battle.FE == :DIMENSIONAL && (@opponent.ability== :PRESSURE || @opponent.ability== :UNNERVE)
		miniscore*=1.1 if @battle.FE == :CITY && @opponent.ability== :FRISK
		miniscore*=1.1 if @opponent.crested == :THIEVUL

		if @attacker.ability== :REGENERATOR
		miniscore*=1.5
		end
		miniscore*=1.8 if @mondata.partyroles.any? {|role| role.include?(:SWEEPER)}

		movebackup = @move ; attackerbackup = @attacker ; oppbackup = @opponent
		if !(@battle.doublebattle) || @attacker.index==2
			this_switchscore = @mondata.switchscore.length > 0 ? @mondata.switchscore.max : (getSwitchInScoresParty(pbAIfaster?(@move))).max
			miniscore*=0.2 if this_switchscore < 50
		end
		@move = movebackup ; @attacker = attackerbackup ; @opponent = oppbackup

		miniscore*= 1-0.15*statchangecounter(@attacker,1,7,-1)
		miniscore*=1-0.25*statchangecounter(@attacker,1,7,1)
		miniscore*=1.1 if @mondata.roles.include?(:LEAD)
		miniscore*=1.1 if @mondata.roles.include?(:PIVOT)
		miniscore*=1.2 if pbAIfaster?(@move)
		miniscore*=1.3 if @attacker.effects[:Toxic]>0 || @attacker.effects[:Attract]>-1 || @attacker.effects[:Confusion]>0 || @attacker.effects[:Yawn]>0
		# Gen 9 Mod - Additinoal Checks for Salt Cure
		miniscore*=1.2 if @attacker.effects[:SaltCure] && @attacker.ability != :MAGICGUARD
		miniscore*=1.3 if @attacker.effects[:SaltCure] && @attacker.ability != :MAGICGUARD && (@attacker.hasType?(:WATER) || @attacker.hasType?(:STEEL))
		miniscore*=1.5 if @attacker.effects[:LeechSeed]>-1
		miniscore*=1.5 if @attacker.effects[:PerishSong]>0 || @attacker.effects[:Curse]

		miniscore*=0.5 if hasgreatmoves()
		if hasbadmoves(25)
		miniscore*=2
		elsif hasbadmoves(40)
		miniscore*=1.2
		end
		return miniscore
	end
	def tidyupcode # Tidy Up - Modified version of defogcode that doesn't deal with screens.
		miniscore = 1.0
		yourpartycount = @battle.pbPokemonCount(@battle.pbPartySingleOwner(@attacker.index))
		theirpartycount = @battle.pbPokemonCount(@battle.pbPartySingleOwner(@opponent.index))
		if yourpartycount>1
		  miniscore*=2 if @attacker.pbOwnSide.effects[:StealthRock]
		  miniscore*=3 if @attacker.pbOwnSide.effects[:StickyWeb]
		  miniscore*=(1.5**@attacker.pbOwnSide.effects[:Spikes])
		  miniscore*=(1.7**@attacker.pbOwnSide.effects[:ToxicSpikes])
		end
		miniscore -= 1.0
		miniscore*=(yourpartycount-1) if yourpartycount>1
		minimini = 1.0
		if theirpartycount>1
		  minimini*=0.5 if @opponent.pbOwnSide.effects[:StealthRock]
		  minimini*=0.3 if @opponent.pbOwnSide.effects[:StickyWeb]
		  minimini*=(0.7**@opponent.pbOwnSide.effects[:Spikes])
		  minimini*=(0.6**@opponent.pbOwnSide.effects[:ToxicSpikes])
		end
		minimini -= 1.0
		minimini*=(theirpartycount-1) if theirpartycount>1
		miniscore+=minimini
		miniscore+=1.0
		miniscore*= 0.8 if @attacker.effects[:Substitute]>0
		miniscore *= 1.25 if @opponent.effects[:Substitute]>0
		if miniscore<0
		  miniscore=0
		end
		return miniscore
	  end

	def dragoncheercode # Gen 9 Mod - Dragon Cheer - Modified version of focusenergycode that is affected by us having a
					  # Dragon type ally, and checks for effects on our ally instead of us.
					  
					  # LAWDS Mod - Added field interactions stuff
		partnerDragon = @attacker.pbPartner.hasType?(:DRAGON)
		return_multiplier = 0
		return_multiplier = 1 if [:COLOSSEUM, :CONCERT1, :CONCERT2, :CONCERT3, :CONCERT4, :BIGTOP, :DRAGONSDEN].include?(@battle.FE)
		return return_multiplier if (@attacker.pbPartner.hp==0 || !@battle.doublebattle)
		return return_multiplier if @attacker.pbPartner.effects[:FocusEnergy]>0
		miniscore = 1.0
		miniscore*=4.0 if partnerDragon || @battle.FE == :DRAGONSDEN
		miniscore*=4.0 if @battle.FE == :DRAGONSDEN && return_multiplier = 1 # the first use is heavily favored
		partnerHPpercent = (@attacker.pbPartner.hp.to_f)/@attacker.pbPartner.totalhp
		if partnerHPpercent>0.75
		miniscore*=1.2
		elsif partnerHPpercent > 0.5 && partnerHPpercent < 0.75 && (@attacker.pbPartner.ability== :EMERGENCYEXIT || @attacker.pbPartner.ability== :WIMPOUT || (@attacker.pbPartner.itemWorks? && @attacker.pbPartner.item == :EJECTBUTTON))
		miniscore*=0.3
		elsif partnerHPpercent < 0.33
		miniscore*=0.3
		end
		miniscore*=1.3 if @opponent.effects[:HyperBeam]>0
		miniscore*=1.7 if @opponent.effects[:Yawn]>0
		miniscore*=0.6 if @attacker.pbPartner.effects[:LeechSeed]>=0 || @attacker.pbPartner.effects[:Attract]>=0
		miniscore*=0.5 if checkAImoves(PBStuff::PHASEMOVE)
		miniscore*=0.2 if @attacker.pbPartner.effects[:Confusion]>0
		miniscore*=0.3 if @attacker.pbPartner.pbOpposingSide.effects[:Retaliate]
		miniscore*=1.2 if (@attacker.pbPartner.hp/4.0)>checkAIdamage()
		miniscore*=1.2 if !@opponent.status.nil?
		miniscore*=1.3 if @opponent.status== :SLEEP || @opponent.status== :FROZEN
		miniscore*=1.5 if @opponent.effects[:Encore]>0 && @opponent.moves[(@opponent.effects[:EncoreIndex])].basedamage==0
		miniscore*=2 if @attacker.pbPartner.ability== :SUPERLUCK || @attacker.pbPartner.ability== :SNIPER
		miniscore*=1.2 if @mondata.attitemworks && (@attacker.pbPartner.item == :SCOPELENS || (@attacker.pbPartner.item == :STICK && @attacker.pbPartner.pokemon.species==:FARFETCHD) || (@attacker.pbPartner.item == :LUCKYPUNCH && @attacker.pbPartner.pokemon.species==:CHANSEY))
		miniscore*=1.3 if (@mondata.attitemworks && @attacker.pbPartner.item == :LANSATBERRY)
		miniscore*=0.2 if @opponent.ability== :ANGERPOINT || @opponent.ability== :SHELLARMOR || @opponent.ability== :BATTLEARMOR
		miniscore*=0.5 if @attacker.pbPartner.pbHasMove?(:LASERFOCUS) || @attacker.pbPartner.pbHasMove?(:FROSTBREATH) || @attacker.pbPartner.pbHasMove?(:STORMTHROW)
		miniscore*= 2**(@attacker.pbPartner.moves.count{|moveloop| moveloop!=nil && moveloop.highCritRate?})
		return miniscore
 	end

######################################################
# Utility functions
######################################################

	def pbGetMonRoles(targetmon=nil)
		partyRoles = []
		party = targetmon ? [targetmon] : @mondata.party
		shouldtr = false
		shouldnt_tr = false
		for mon in party
			monRoles=[]
			movelist = []
			if targetmon && targetmon.class==PokeBattle_Pokemon || !targetmon
				for i in mon.moves
					next if i.nil?
					movelist.push(i.move)
				end
			elsif targetmon && targetmon.class==PokeBattle_Battler
				for i in targetmon.moves
					next if i.nil?
					movelist.push(i.move)
				end
			end
			monRoles.push(:LEAD) if @mondata.party.index(mon)==0 || (@mondata.party.index(mon)==1 && @battle.doublebattle && @battle.pbParty(@mondata.index)==@battle.pbPartySingleOwner(@mondata.index))
			monRoles.push(:ACE) if @mondata.party.index(mon)==(@mondata.party.length-1)
			secondhighest=true
			if party.length>2
				for i in 0..(party.length-2)
					next if party[i].nil?
					secondhighest=false if mon.level<party[i].level
				end
			end
			for i in movelist
				next if i.nil?
				trickroommove=true if i == :TRICKROOM # LAWDS new check for trickroom role
				healingmove=true if $cache.moves[i] && $cache.moves[i].checkFlag?(:healingmove)
				curemove=true if (i == :HEALBELL || i == :AROMATHERAPY)
				wishmove=true if i == :WISH
				phasemove=true if PBStuff::PHASEMOVE.include?(i)
				pivotmove=true if PBStuff::PIVOTMOVE.include?(i)
				spinmove=true if (i == :RAPIDSPIN || i == :MORTALSPIN)
				batonmove=true if i == :BATONPASS
				screenmove=true if PBStuff::SCREENMOVE.include?(i) || (i==:NATUREPOWER && @battle.FE==:DARKCRYSTALCAVERN) # lawds DCC nature power
				tauntmove=true if i == :TAUNT
				restmove=true if i == :REST
				weathermove=true if (i == :SUNNYDAY || i == :RAINDANCE || i == :HAIL || i == :SANDSTORM || i == :SHADOWSKY)
				fieldmove=true if (i == :GRASSYTERRAIN || i == :ELECTRICTERRAIN || i == :MISTYTERRAIN || i == :PSYCHICTERRAIN || i == :MIST || i == :IONDELUGE)
			end
			# LAWDS improved role assignment
			monRoles.push(:SWEEPER) 		if (mon.ev[5]>199 || (mon.ev[5] > 0 && [:DUSTDEVIL,:CHLOROPHYLL,:SANDRUSH,:SLUSHRUSH,:SWIFTSWIM,:SURGESURFER].include?(mon.ability))) && (mon.nature==:MODEST || mon.nature==:JOLLY || mon.nature==:TIMID || mon.nature==:ADAMANT) || (mon.item==(:CHOICEBAND) || mon.item==(:CHOICESPECS) || mon.item==(:CHOICESCARF) || mon.ability== :GORILLATACTICS)
			monRoles.push(:PHYSICALWALL) if healingmove && (mon.ev[2]>199 && (mon.nature==:BOLD || mon.nature==:RELAXED || mon.nature==:IMPISH || mon.nature==:LAX))
			monRoles.push(:SPECIALWALL)	if healingmove && (mon.ev[4]>199 && (mon.nature==:CALM || mon.nature==:GENTLE || mon.nature==:SASSY || mon.nature==:CAREFUL))
			monRoles.push(:CLERIC) 		if curemove || (wishmove && mon.ev[0]>199)
			monRoles.push(:PHAZER) 		if @battle.FE!=:COLOSSEUM && (phasemove || mon.item==(:REDCARD) || (@battle.FE==:DESERT && mon.ability==:SANDSPIT)) # LAWDS new sand spit
			monRoles.push(:SCREENER) 	if (mon.item==(:LIGHTCLAY) || mon.species==:MRRIME || (@battle.FE==:DARKCRYSTALCAVERN)) && screenmove
			# Gen 9 Mod - Added Hospitality
			monRoles.push(:PIVOT) 		if (pivotmove && healingmove) || (mon.ability== :REGENERATOR) || (mon.ability== :HOSPITALITY) || mon.ability== :HITANDRUN # lawds hit and run
			monRoles.push(:SPINNER) 		if spinmove
			monRoles.push(:TANK) 		if (mon.ev[0]>199 && !healingmove) || mon.item==(:ASSAULTVEST)
			monRoles.push(:BATONPASSER) 	if batonmove
			monRoles.push(:STALLBREAKER) if tauntmove || mon.item==(:CHOICEBAND) || mon.item==(:CHOICESPECS) || mon.ability== :GORILLATACTICS
			monRoles.push(:STATUSABSORBER) if restmove || (mon.ability== :COMATOSE) || mon.item==(:TOXICORB) || mon.item==(:FLAMEORB) || (mon.ability== :GUTS) || (mon.ability== :QUICKFEET)|| (mon.ability== :FLAREBOOST) || (mon.ability== :TOXICBOOST) || (mon.ability== :NATURALCURE) || (mon.ability== :MAGICGUARD) || (mon.ability== :MAGICBOUNCE) || (mon.ability== :REFLECTOR) || (mon.species == :ZANGOOSE && mon.item == :ZANGCREST) || hydrationCheck(mon)
			monRoles.push(:TRAPPER) 		if PBStuff::TRAPPINGABILITIES.include?(mon.ability) && @battle.FE != :COLOSSEUM
			monRoles.push(:WEATHERSETTER) if weathermove || (mon.ability== :DROUGHT) || (mon.ability== :SANDSPIT)  || (mon.ability== :SANDSTREAM) || (mon.ability== :DRIZZLE) || (mon.ability== :SNOWWARNING) || (mon.ability== :PRIMORDIALSEA) || (mon.ability== :DESOLATELAND) || (mon.ability== :DELTASTREAM)
			monRoles.push(:FIELDSETTER) 	if fieldmove || (mon.ability== :GRASSYSURGE) || (mon.ability== :ELECTRICSURGE) || (mon.ability== :MISTYSURGE) || (mon.ability== :PSYCHICSURGE) || mon.item==(:AMPLIFIELDROCK)|| (mon.ability== :DARKSURGE) 
			# LAWDS - new trick room setter role
			if trickroommove && !shouldtr && !shouldnt_tr
				numfaster = 0 # number of speed matchups that the AI wins. 
				aipartylength = @battle.party2.length
				opppartylength = @battle.party1.length
				for aimon in @battle.party2
					next if aimon==nil || aimon.hp <= 0 || aimon.piece==:KING
					if aimon.ability==:SPEEDBOOST
						numfaster+=opppartylength
						next	
					end
					for oppmon in @battle.party1
						next if oppmon==nil || oppmon.hp <= 0
						next if (oppmon.piece==:KING) || oppmon.ability==:SPEEDBOOST
						numfaster+=1 if (aimon.speed >= oppmon.speed)
					end
				end
				if numfaster < (aipartylength*opppartylength)/2 # if your mons are outsped in more than half of speed matchups, then use trick room for the battle.
					monRoles.push(:TRSETTER) 
					shouldtr=true
				else
					shouldnt_tr=true
				end
			elsif trickroommove && shouldtr
				monRoles.push(:TRSETTER) 
			end

			monRoles.push(:SECOND) 		if secondhighest
			partyRoles.push(monRoles)
		end
		return partyRoles[0] if targetmon
		return partyRoles
	end

	def pbMakeFakeBattler(pokemon, partyindex, batonpass = false, index = @index)
		return nil if pokemon.nil?
		
		pokemon = pokemon.clone
		battler = PokeBattle_Battler.new(@battle, index, true)
		battler.pbInitPokemon(pokemon, partyindex)
		battler.pbInitEffects(batonpass, true)
		battler.pbInitBoss(pokemon,index) if battler.isbossmon # LAWDS initializing boss data
		return battler
	end

	def pbSereneGraceCheck(miniscore)
		miniscore-=1
		if @move.effect != 100
			addedeffect = @move.effect.to_f
			# LAWDS - made dire claw an exception to rainbow field doubling effect chance.
			addedeffect*=2 if @attacker.ability== :SERENEGRACE || (@battle.FE == :RAINBOW && @move.move != :DIRECLAW)
			addedeffect=100 if addedeffect>100
			# lawds cancel random effects for rift hippowdon
			addedeffect=0 if addedeffect < 100 && @battle.opponent && !@battle.opponent.is_a?(Array) && @battle.opponent.trainertype==:RIFT_HIPPO
			miniscore*=addedeffect/100.0
		end
		miniscore+=1
		return miniscore
	end

	def pbReduceWhenKills(miniscore)
		return miniscore if @initial_scores[@score_index] < 100
		return Math.sqrt(miniscore)
	end

	def statchangecounter(mon,initial,final,limiter=0)
		count = 0
		case limiter
		  when 0 #all stats
			for i in initial..final
			  count += mon.stages[i]
			end
		  when 1 #increases only
			for i in initial..final
			  count += mon.stages[i] if mon.stages[i]>0
			end
		  when -1 #decreases only
			for i in initial..final
			  count += mon.stages[i] if mon.stages[i]<0
			end
		end
		return count
	end

	def hasgreatmoves()
		#slight variance in precision based on trainer skill
		threshold = 100
		threshold = 105 if @mondata.skill>=HIGHSKILL
		threshold = 110 if @mondata.skill>=BESTSKILL
		for i in 0...@initial_scores.length
			next if i == @score_index
			if @initial_scores[i]>=threshold
				return true
			end
		end
		return false
	end
	
	def hasbadmoves(threshold,initialscores=@initial_scores,scoreindex=@score_index)
		return false if initialscores == nil # lawds - catch nil
		for i in 0...initialscores.length
			next if i==scoreindex
			return false if initialscores[i]>threshold
		end
		return true
	end

	def getStatusDamage(move=@move)
		return 20 if move.zmove && (move.move == :CONVERSION || move.move == :SPLASH || move.move == :CELEBRATE)
		return 50 if move.move==:MAGICPOWDER && [:HAUNTED,:BEWITCHED].include?(@battle.FE) # lawds
		return PBStuff::STATUSDAMAGE[move.move] if PBStuff::STATUSDAMAGE[move.move]
		return 0
	end

	def pbRoughStat(battler,stat)
		return battler.pbSpeed if stat==PBStats::SPEED
		stagemul=[2,2,2,2,2,2,2,3,4,5,6,7,8]
		stagediv=[8,7,6,5,4,3,2,2,2,2,2,2,2]
		stage=battler.stages[stat]+6
		value=0
		value=battler.attack if stat==PBStats::ATTACK
		value=battler.defense if stat==PBStats::DEFENSE
		value=battler.speed if stat==PBStats::SPEED
		value=battler.spatk if stat==PBStats::SPATK
		value=battler.spdef if stat==PBStats::SPDEF
		return (value*1.0*stagemul[stage]/stagediv[stage]).floor
	end
	# lawds - added noguard_disrupt flag to use this function for scoring no guard in ability disruption
	def pbRoughAccuracy(move,attacker,opponent, noguard_disrupt = false)
		# start with stuff that has set accuracy
		# Override accuracy																															# Lawds Mod - Dust Devil, Wildfire
		return 100 if (attacker.ability== :NOGUARD && !noguard_disrupt) || opponent.ability== :NOGUARD || (attacker.ability== :FAIRYAURA && @battle.FE == :FAIRYTALE) || (attacker.ability==:DUSTDEVIL && (@battle.pbWeather == :SANDSTORM || [:DESERT, :ASHENBEACH].include?(@battle.FE)))  || (attacker.ability== :WILDFIRE && (@battle.pbWeather == :SUNNYDAY || @battle.FE==:INFERNAL))
		return 100 if move.accuracy==0   # Doesn't do accuracy check (always hits)
		if @mondata.skill>=BESTSKILL
			baseaccuracy=move.accuracy
			fieldmove = @battle.field.moveData(move.move)
			baseaccuracy = fieldmove[:accmod] if fieldmove && fieldmove[:accmod]
			return 100 if baseaccuracy == 0 # Doesn't do accuracy check (always hits)
		end
		return 100 if move.function==0xA5 # Swift
		if @mondata.skill>=MEDIUMSKILL
			return 100 if opponent.effects[:LockOn]>0 && opponent.effects[:LockOnPos]==attacker.index			
			if move.function==0x70 # OHKO moves
				return 0 if opponent.ability== :STURDY || opponent.level>attacker.level || (@battle.FE == :CHESS && opponent.pokemon.piece==:PAWN) || (@battle.FE == :COLOSSEUM && opponent.ability== :STALWART)
				return move.accuracy+attacker.level-opponent.level
			end
			return 100 if opponent.effects[:Telekinesis]>0
			return 100 if move.function==0x0D && @battle.pbWeather == :HAIL # Blizzard
			# LAWDS genie moves bar enam dont miss in rain
			return 100 if (move.function==0x08 || move.function==0x15 || [:BLEAKWINDSTORM,:WILDBOLTSTORM,:SANDSEARSTORM].include?(move.move)) && @battle.pbWeather == :RAINDANCE# Thunder, Hurricane
			return 100 if move.function==0x08 && (@battle.FE == :MOUNTAIN || @battle.FE == :SNOWYMOUNTAIN) # Thunder
			return 100 if move.type == :ELECTRIC && @battle.FE == :UNDERWATER
			return 100 if attacker.hasType?(:POISON) && move.move == :TOXIC
			if @mondata.skill>=HIGHSKILL
				return 100 if (move.function==0x10 || move.move == :BODYSLAM || move.function==0x137 || move.function==0x9B || move.function==0x806) && opponent.effects[:Minimize] # Flying Press, Stomp, DRush, Mal. Moonsault
				return 100 if @battle.FE == :MIRROR && (PBFields::BLINDINGMOVES + [:MIRRORSHOT]).include?(move.move)
				return 100 if @battle.FE == :MIRROR && move.basedamage>0 && move.target==:SingleNonUser && !move.contactMove? && move.pbIsSpecial?(move.type) && opponent.stages[PBStats::EVASION]>0
			end
		end
		# Get base accuracy
		baseaccuracy=move.accuracy
		if @mondata.skill>=BESTSKILL
			fieldmove = @battle.field.moveData(move.move)
			baseaccuracy = fieldmove[:accmod] if fieldmove && fieldmove[:accmod]
		end
		if @mondata.skill>=MEDIUMSKILL
			baseaccuracy=50 if @battle.pbWeather== :SUNNYDAY && (move.function==0x08 || move.function==0x15) # Thunder, Hurricane
		end
		# Accuracy stages
		accstage=attacker.stages[PBStats::ACCURACY]
		accstage=0 if opponent.ability== :UNAWARE && !moldBreakerCheck(attacker,move)
		# lawds - actually implemented this accuracy stage thing for ashen beach. in vanilla only evasion was handled
    	accstage=0 if @battle.FE == :ASHENBEACH && [:OWNTEMPO, :INNERFOCUS,:PUREPOWER,:STEADFAST,:SANDVEIL].include?(attacker.ability)
		accuracy=(accstage>=0) ? (accstage+3)*100.0/3 : 300.0/(3-accstage)
		evastage=opponent.stages[PBStats::EVASION]
		evastage=0 if opponent.effects[:Foresight] || opponent.effects[:MiracleEye] || move.function==0xA9 || attacker.ability== :UNAWARE && !moldBreakerCheck(opponent)
		evastage-=2 if @battle.state.effects[:Gravity]!=0
		evastage=-6 if evastage<-6
		evasion=(evastage>=0) ? (evastage+3)*100.0/3 : 300.0/(3-evastage)
		# Accuracy modifiers
		if @mondata.skill>=MEDIUMSKILL							# Lawds Mod - Illuminate boosts accuracy
			if (attacker.ability== :COMPOUNDEYES || attacker.ability== :ILLUMINATE)
				accuracy*=1.3 
			end
			accuracy*=1.1 if attacker.ability== :VICTORYSTAR || attacker.ability==:KEENEYE
			if @mondata.skill>=HIGHSKILL
				accuracy*=1.1 if attacker.pbPartner.ability== :VICTORYSTAR
				accuracy*= [:BACKALLEY,:CITY].include?(@battle.FE) ? 0.67 : 0.8 if attacker.ability== :HUSTLE && move.basedamage>0 && move.pbIsPhysical?(move.pbType(attacker)) && !moldBreakerCheck(opponent)
			end
			if @mondata.skill>=BESTSKILL
				accuracy*=0.9 if attacker.ability== :LONGREACH && (@battle.FE == :ROCKY || @battle.FE == :FOREST) # Rocky Field # Forest Field
				accuracy*= @battle.FE == :RAINBOW ? 0 : 0.5 if opponent.ability== :WONDERSKIN && @basedamage==0 && attacker.pbIsOpposing?(opponent.index) && !moldBreakerCheck(attacker,move)
				accuracy*=0.5 if Rejuv && @battle.FE == :PSYTERRAIN && opponent.ability== :MAGICIAN && @basedamage==0 && attacker.pbIsOpposing?(opponent.index) && !moldBreakerCheck(attacker,move)
				#evasion*=1.2 if opponent.ability== :TANGLEDFEET && opponent.effects[:Confusion]>0 && !moldBreakerCheck(attacker,move)
				#evasion*=1.2 if (@battle.pbWeather== :SANDSTORM || @battle.FE == :DESERT || @battle.FE == :ASHENBEACH) && opponent.ability== :SANDVEIL && !moldBreakerCheck(attacker,move)
				#evasion*=1.2 if (@battle.pbWeather== :HAIL || @battle.FE == :ICY || @battle.FE == :SNOWYMOUNTAIN) && opponent.ability== :SNOWCLOAK && !moldBreakerCheck(attacker,move)
			end
			if attacker.itemWorks?
				accuracy*=1.1 if attacker.item == :WIDELENS
				accuracy*=1.2 if attacker.item == :ZOOMLENS && attacker.pbSpeed<opponent.pbSpeed
				if attacker.item == :MICLEBERRY
					accuracy*=1.2 if (attacker.ability== :GLUTTONY && attacker.hp<=(attacker.totalhp/2.0).floor) || attacker.hp<=(attacker.totalhp/4.0).floor
				end
				#if @mondata.skill>=HIGHSKILL
					#evasion*=1.1 if opponent.item == :BRIGHTPOWDER
					#evasion*=1.1 if opponent.item == :LAXINCENSE
				#end
			end
		end
		evasion = 100 if attacker.ability== :KEENEYE || attacker.ability== :MINDSEYE
		evasion = 100 if @mondata.skill>=BESTSKILL && @battle.FE == :ASHENBEACH && [:OWNTEMPO,:INNERFOCUS,:PUREPOWER,:SANDVEIL,:STEADFAST].include?(attacker.ability) && opponent.ability != :UNNERVE && @opponent.ability != :ASONE
		# LAWDS enemies have a 30% accuracy boost on Awesome Mode.
		accuracy*=1.3 if $game_variables[:DifficultyModes]==2 && !@battle.pbOwnedByPlayer?(attacker.index) 
		accuracy*=baseaccuracy/evasion.to_f
		accuracy=100 if accuracy>=80 # lawds
		
		return accuracy
	end

	def pbAIfaster?(attackermove=nil, opponentmove=nil, attacker=@attacker, opponent=@opponent, field = @battle.FE)
		return true if !opponent || opponent.hp == 0
		return false if !attacker || attacker.hp == 0
		trUp = @battle.trickroom!=0
		# LAWDS see magical seed on dimensional, to see if trick room will be up on switch-in
		trUp = !trUp if field == :DIMENSIONAL && ((attacker.pokemon.seeded && attacker.turncount < 1) || (opponent.pokemon.seeded && opponent.turncount < 1))
		return (opponent.pbSpeed < attacker.pbSpeed) ^ (trUp) if @mondata.skill < HIGHSKILL
		priorityarray =[[0,0,0,attacker],[0,0,0,opponent]]
		index = -1
		for battler in [attacker, opponent]
			if @battle.pbCanMegaEvolveAI?(battler,battler.index)
			    if @battle.pbOwnedByPlayer?(battler.index)
					battler = pbCloneBattler(battler.index) if @battle.battlers[battler.index] == battler
					battler.pokemon.makeMega
					battler.pbUpdate(true)
			    else
					battler = pbCloneBattler(battler.index) if @battle.battlers[battler.index] == battler
					battler.pokemon.makeMega
					battler.pbUpdate(true)
			    end
			end
			index += 1
			battlermove = (battler==attacker) ? attackermove : opponentmove
			#priorityarray[index][1] = -1 if battler.ability== :STALL
			priorityarray[index][1] = 1 if battler.hasWorkingItem(:CUSTAPBERRY) && ((battler.ability== :GLUTTONY && battler.hp<=(battler.totalhp/2.0).floor) || battler.hp<=(battler.totalhp/4.0).floor)
			priorityarray[index][1] = -2 if (battler.itemWorks? && (battler.item == :LAGGINGTAIL || battler.item == :FULLINCENSE))
			#speed priority
			priorityarray[index][2] = battler.pbSpeed(field) if !trUp
			priorityarray[index][2] = -battler.pbSpeed(field) if trUp
			next if !battlermove
			pri = 0
			pri = battlermove.priority if !battlermove.zmove
			pri = pri.nil? ? 0 : pri
			pri += 1 if battler.ability== :PRANKSTER && battlermove.basedamage==0 # Is status move
			pri -= 1 if battler.ability== :MYCELIUMMIGHT && battlermove.basedamage==0 && battler.effects[:TwoTurnAttack] == 0 # LAWDS - Mycelium Might
			pri += 1 if battler.crested == :MRRIME && [:REFLECT,:LIGHTSCREEN,:AURORAVEIL,:ARENITEWALL].include?(battlermove.move) # Lawds Mod 6/19/2024
			# LAWDS - Gale Wings doesn't work on specific fields. also updated to use pbType rather than @type
			pri += 1 if battler.ability== :GALEWINGS && battlermove.pbType(battler)==:FLYING && ((battler.hp == battler.totalhp) || field == :SKY || ((field == :MOUNTAIN || field == :SNOWYMOUNTAIN || field == :VOLCANICTOP) && @battle.weather == :STRONGWINDS)) && ![:UNDERWATER, :CAVE, :DEEPEARTH].include?(field)
			pri += 1 if field == :CHESS && battler.pokemon && battler.pokemon.piece == :KING
			pri += 1 if battlermove.move == :GRASSYGLIDE && (field == :GRASSY || @battle.state.effects[:GRASSY] > 0 || @gonnaTerrains.include?(:GRASSY))
			pri += 3 if battler.ability== :TRIAGE && (PBStuff::HEALFUNCTIONS).include?(battlermove.function)
			pri -= 1 if field == :DEEPEARTH && battlermove.move == :COREENFORCER
			priorityarray[index][0] = pri
		end
		priorityarray.sort_by! {|a|[a[0],a[1],a[2]]}
		priorityarray.reverse!
		return false if priorityarray[0][0]==priorityarray[1][0] && priorityarray[0][1]==priorityarray[1][1] && priorityarray[0][2]==priorityarray[1][2]
		return priorityarray[0][3] == attacker
	end

	def pbMoveOrderAI(bestmove1=nil,bestmove2=nil) #lol it's just pbPriority # lawds let you plug in the moves your AI pokemon will use
		priorityarray = []
		for i in 0..3
			battler = pbCloneBattler(i)
			checkMega(battler)
			priorityarray[i] =[0,0,0,i]
			if battler.hp == 0
				priorityarray[i] =[-1,0,0,i]
				next 
			end
			priorityarray[i][0] = 1 if battler.pokemon && battler.pokemon.piece == :KING && @battle.FE == :CHESS
			priorityarray[i][0] += bestmove1.priorityCheck(battler) if i==1 && bestmove1 != nil
			priorityarray[i][0] += bestmove2.priorityCheck(battler) if i==3 && bestmove2 != nil
			#priorityarray[i][1] = -1 if battler.ability== :STALL # lawds
			priorityarray[i][1] = 1 if battler.hasWorkingItem(:CUSTAPBERRY) && ((battler.ability== :GLUTTONY && battler.hp<=(battler.totalhp/2.0).floor) || battler.hp<=(battler.totalhp/4.0).floor)
			priorityarray[i][1] = -2 if (battler.itemWorks? && (battler.item == :LAGGINGTAIL || battler.item == :FULLINCENSE))
			#speed priority
			priorityarray[i][2] = pbRoughStat(battler,PBStats::SPEED) if @battle.trickroom==0
			priorityarray[i][2] = -pbRoughStat(battler,PBStats::SPEED) if @battle.trickroom>0
		end
		priorityarray.sort!
		priorityarray.reverse!
		moveorderarray = []
		for i in 0..3
			moveorderarray[i] = priorityarray[i][3]
		end
		return moveorderarray
	end

	def hpGainPerTurn(attacker=@attacker,getchip=false) # LAWDS added parameter to instead check for % hp gained or lost every turn, for hard switches
		healing = getchip ? 0 : 1.0
		stallMult = 1
		# lawds stall
		for i in 0...4
			battler = @battle.battlers[i]
			battler = attacker if i == attacker.index && battler.pokemon != attacker.pokemon
			stallMult+=1 if battler.ability==:STALL
		end
		# Negative healing effects
		if attacker.ability != :MAGICGUARD && !(attacker.ability== :WONDERGUARD && @battle.FE == :COLOSSEUM)
			# lawds added infernal to the burning field check here
			if (@battle.FE == :BURNING || @battle.FE == :VOLCANIC || @battle.FE == :INFERNAL) && attacker.burningFieldPassiveDamage? && (!attacker.isAirborne? || attacker.effects[:infernalPain])
				subscore = 0
				subscore += PBTypes.twoTypeEff(:FIRE,attacker.type1,attacker.type2)/64.0
				subscore*=2.0 if (attacker.ability== :LEAFGUARD)
				subscore*=2.0 if (attacker.ability== :ICEBODY)
				subscore*=2.0 if (attacker.ability== :FLUFFY)
				subscore*=2.0 if (attacker.ability== :GRASSPELT)
				subscore*=2.0 if attacker.effects[:TarShot]
				# LAWDS infernal
				if @battle.FE==:INFERNAL
				  subscore*=2.0 if (attacker.ability== :RATTLED)
				  subscore*=2.0 if (attacker.ability== :DEFIANT)
				  subscore*=2.0 if (attacker.ability== :COMPETITIVE)
				  trapped = true
				  no_alive_mons = true
                  for partyindex in 0... @battle.pbParty(attacker.index).length
                    next if partyindex==attacker.pokemonIndex
                    next if @battle.pbParty(attacker.index)[partyindex]==nil
                    next if @battle.pbParty(attacker.index)[partyindex].hp <= 0
                    next if @battle.pbParty(attacker.index)[partyindex].isEgg?
                    no_alive_mons = false
                    if @battle.pbCanSwitch?(attacker.index,partyindex,false)
                      trapped = false
                      break
                    end
				  end
				  subscore*=2.0 if trapped && !no_alive_mons
				end
				healing -= subscore
			end
			if @battle.FE == :UNDERWATER && attacker.underwaterFieldPassiveDamamge?
				subscore = 0
				subscore += PBTypes.twoTypeEff(:WATER,attacker.type1,attacker.type2)/32.0
				subscore*=2.0 if (attacker.ability== :FLAMEBODY) || (attacker.ability== :MAGMAARMOR)
				healing -= subscore
			end
			if @battle.FE == :MURKWATERSURFACE && attacker.murkyWaterSurfacePassiveDamage?
				subscore = 0
				subscore += PBTypes.twoTypeEff(:POISON,attacker.type1,attacker.type2)/32.0
				subscore*=2.0 if (attacker.ability== :FLAMEBODY) || (attacker.ability== :MAGMAARMOR) || attacker.ability== :DRYSKIN || attacker.ability== :WATERABSORB
				healing -= subscore
			end
			# Field effect induced
			healing -= 0.125 if @battle.FE == :CORROSIVE && (attacker.ability== :GRASSPELT || attacker.ability== :DRYSKIN)
			# LAWDS spirit eater 
			if attacker.ability!=:MAGICGUARD && !(@battle.FE==:COLOSSEUM && attacker.ability==:WONDERGUARD)
			for i in [attacker.pbOpposing1,attacker.pbOpposing2]
				if i.ability==:SPIRITEATER && !i.isFainted? && i.ability!=:MAGICGUARD && !(i.ability==:WONDERGUARD && @battle.FE!=:COLOSSEUM)
					fraction = [:DEEPEARTH,:HAUNTED].include?(@battle.FE) ? 0.125 : 0.0625
					healing -= fraction
				end
			end
			end
			if attacker.ability==:SPIRITEATER
				for j in [attacker.pbOpposing1, attacker.pbOpposing2]
					next if j==nil
          			next if j.hp<=0
          			next if j.ability==:MAGICGUARD || (@battle.FE==:COLOSSEUM && j.ability==:WONDERGUARD)
					fraction = [:DEEPEARTH,:HAUNTED].include?(@battle.FE) ? 0.125 : 0.0625
					selffraction = (fraction*((j.totalhp.to_f)/(attacker.totalhp.to_f))).floor
					selffraction *=-1 if j.ability==:LIQUIDOOZE
					healing+=selffraction
				end
			end
			healing -= 0.125 if @battle.FE == :CORRUPTED && attacker.ability== :DRYSKIN && !attacker.hasType?(:POISON)
			healing -= 0.125 if Rejuv && @battle.FE == :DESERT && @battle.pbWeather == :SUNNYDAY && (attacker.hasType?(:GRASS) || attacker.hasType?(:WATER)) && ![:CHLOROPHYLL,:SOLARPOWER].include?(attacker.ability)
			healing -= 0.0625 if attacker.effects[:Ingrain] && (@battle.FE == :SWAMP || @battle.FE == :CORROSIVE || @battle.FE == :CORRUPTED) && !(attacker.hasType?(:STEEL) || attacker.hasType?(:POISON))
			healing -= 0.0625 if @battle.FE == :HAUNTED && attacker.status == :SLEEP && !attacker.hasType?(:GHOST)
			healing -= 0.0625 if (@battle.FE == :DIMENSIONAL && attacker.effects[:HealBlock])
			healing -= 0.125 if @battle.FE == :CORROSIVE && (attacker.ability== :GRASSPELT || attacker.ability== :LEAFGUARD || attacker.ability== :FLOWERVEIL)
			healing -= 0.125 if @battle.FE == :INFERNAL && attacker.effects[:Torment]

			# weather induced
			# lawds change to dry skin on desert
			if @battle.pbWeather == :SUNNYDAY && (attacker.ability== :DRYSKIN)
				amt = @battle.FE == :DESERT ? 0.25 : 0.125
				healing -= amt
			end
			# LAWDS - solar power on sky
			healing -= 0.125 if (@battle.pbWeather == :SUNNYDAY || (@battle.FE == :SKY && ![:RAINDANCE,:SANDSTORM,:HAIL].include?(@battle.pbWeather))) && (attacker.ability== :SOLARPOWER)
			healing -= 0.125 if @battle.pbWeather == :SUNNYDAY && (attacker.crested == :CASTFORM && attacker.form == 1)
			healing -= (Rejuv && @battle.FE == :DESERT) ? 0.125 : 0.0625 if @battle.pbWeather == :SANDSTORM && (!(attacker.hasType?(:GROUND) || attacker.hasType?(:ROCK) || attacker.hasType?(:STEEL) || [:SANDFORCE,:SANDRUSH,:SANDVEIL,:MAGICGUARD,:DUSTDEVIL,:OVERCOAT,:TEMPEST].include?(attacker.ability)) || attacker.effects[:DesertsMark])
			healing -= (@battle.FE == :FROZENDIMENSION) ? 0.125 : 0.0625 if @battle.pbWeather == :HAIL && !(attacker.hasType?(:ICE) || [:SNOWCLOAK,:ICEBODY,:LUNARIDOL,:SLUSHRUSH,:MAGICGUARD,:OVERCOAT,:TEMPEST].include?(attacker.ability))
			healing -= (@battle.FE == :DIMENSIONAL || @battle.FE == :FROZENDIMENSION) ? 0.125 : 0.0625 if (@battle.pbWeather== :SHADOWSKY && !@attacker.hasType?(:SHADOW))
			healing -= 0.125 if attacker.crested == :PORYGONZ # lawds - pz crest
			# Status induced
			healing -= 0.125 if attacker.status == :POISON && attacker.ability != :POISONHEAL && attacker.crested != :ZANGOOSE && attacker.statusCount==0
			stallToxicDMG = 0 # lawds for toxic with stall, find the total damage after accumulation
			if attacker.status == :POISON && attacker.ability != :POISONHEAL && attacker.crested != :ZANGOOSE  && attacker.statusCount > 0
				toxicDMG = [15,attacker.effects[:Toxic]].min / 16.0
				healing -= toxicDMG
				for j in 1...stallMult
					stallToxicDMG += j / 16.0 if (attacker.effects[:Toxic]+j) < 15
				end
			end
			healing -= 0.0625 if attacker.status == :BURN
			if attacker.status == :SLEEP || (attacker.ability== :COMATOSE && @battle.FE != :ELECTERRAIN)
				sleepdmg =  (@battle.FE == :DIMENSIONAL || @battle.FE == :BEWITCHED || @battle.FE == :SWAMP) ? 0.0625 : 0.0
				# rejuv specific swamp field mechanic
				if Rejuv &&  @battle.FE == :SWAMP
					sleepdmg *= 2.0 if attacker.effects[:MultiTurn] > 0
				end
				if (attacker.pbOpposing1.ability== :BADDREAMS || attacker.pbOpposing2.ability== :BADDREAMS) && @battle.FE != :RAINBOW
					if @battle.FE == :INFERNAL || @battle.FE == :DARKNESS3
						sleepdmg += 0.25
					elsif @battle.FE == :DARKNESS2
						sleepdmg += 0.166
					else
						sleepdmg += 0.125
					end
				end
				healing -= sleepdmg
			end
			healing -= 0.0625 if attacker.status == :SLEEP && (@battle.FE == :DIMENSIONAL || @battle.FE == :BEWITCHED)

			# Other
			healing -= 0.125 if attacker.effects[:LeechSeed]>=0 && attacker.ability != :LIQUIDOOZE
			healing -= 0.125 if attacker.status == :PETRIFIED && attacker.ability != :LIQUIDOOZE
			healing -= 0.125 if @battle.FE == :WASTELAND && attacker.effects[:LeechSeed]>=0 && attacker.ability != :LIQUIDOOZE
			healing -= (@battle.FE == :DARKNESS3 || @battle.FE == :HAUNTED) ? 0.33 : 0.25 if attacker.effects[:Nightmare] && @battle.FE != :RAINBOW && attacker.status== :SLEEP
			healing -= 0.3 if attacker.effects[:Curse] && @battle.FE != :HOLY
			# Gen 9 Mod - Taking damage if attacker is being Salt Cured.
      		healing -= 0.125 if attacker.effects[:SaltCure]
      		healing -= 0.125 if attacker.effects[:SaltCure] && (attacker.hasType?(:WATER) || attacker.hasType?(:STEEL) || @battle.FE == :HOLY) # LAWDS - salt cure damage is 1/4 for everyone on Holy
			if attacker.effects[:MultiTurn] > 0
				if attacker.effects[:BindingBand]
					healing -= 0.1667
				else
					case attacker.effects[:MultiTurnAttack]
					when :FIRESPIN then healing -= (@battle.FE == :BURNING || @battle.FE == :HAUNTED) ? 0.1667 : 0.125
					when :MAGMASTORM then healing -= @battle.FE == :DRAGONSDEN ? 0.1667 : 0.125
					when :SANDTOMB then healing -= @battle.FE == :DESERT ? 0.1667 : 0.125
					when :WHIRLPOOL then healing -= (@battle.FE == :WATERSURFACE || @battle.FE == :UNDERWATER) ? 0.1667 : 0.125
					when :THUNDERCAGE then healing -= @battle.FE == :ELECTERRAIN ? 0.1667 : 0.125
					when :SNAPTRAP then healing -= @battle.FE == :GRASSY ? 0.1667 : 0.125
					when :INFESTATION
						if @battle.FE == :FOREST || @battle.FE == :FLOWERGARDEN3
							healing -= 0.1667
						elsif @battle.FE == :FLOWERGARDEN4
							healing -= 0.25
						elsif @battle.FE == :FLOWERGARDEN5
							healing -= 0.33
						else
							healing -= 0.125
						end
					else healing -= 0.125
					end
				end
			end
			healing -= 0.125 if attacker.item == :STICKYBARB
			healing -= @battle.FE == :CORRUPTED ? 0.25 : 0.125 if (attacker.item == :BLACKSLUDGE && !attacker.hasType?(:POISON))
		end
		healing = 0 if healing < 0 && !getchip

		# Positive healing effects
		return healing if attacker.effects[:HealBlock]!=0
		if attacker.effects[:AquaRing]
			subscore = 0
			subscore = 0.0625
			subscore = 0.125 if @battle.FE == :MISTY || @battle.FE == :SWAMP || @battle.FE == :WATERSURFACE || @battle.FE == :UNDERWATER
			if Rejuv && @battle.FE == :GRASSY
				subscore *= 1.6 if attacker.itemWorks? && attacker.item == :BIGROOT
			else
				subscore *= 1.3 if attacker.itemWorks? && attacker.item == :BIGROOT
			end
			subscore *= 1.3 if (@attacker.crested == :SHIINOTIC)
			healing += subscore
		end
		if attacker.effects[:Ingrain]
			subscore = 0
			subscore = 0.0625 if @battle.FE != :SWAMP && @battle.FE != :CORROSIVE
			subscore = 0.0625 if (@battle.FE == :SWAMP || @battle.FE == :CORROSIVE) && (attacker.hasType?(:STEEL) && attacker.hasType?(:POISON))
			if Rejuv && @battle.FE == :GRASSY
				subscore *= 1.6 if attacker.itemWorks? && attacker.item == :BIGROOT
			else
				subscore *= 1.3 if attacker.itemWorks? && attacker.item == :BIGROOT
			end
			subscore *= 1.3 if (@attacker.crested == :SHIINOTIC)
			subscore *= 2.0 if (@battle.FE == :FOREST || @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN) || (Rejuv && @battle.FE == :GRASSY)) || @battle.state.effects[:GRASSY] > 0 || @gonnaTerrains.include?(:GRASSY)
			subscore *= 2.0 if (@battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,4,5))
			healing += subscore
		end
		if attacker.ability== :DRYSKIN
			healing += 0.0625 if ((@battle.FE == :CORROSIVE || @battle.FE == :CORRUPTED) && attacker.hasType?(:POISON) && !attacker.hasType?(:STEEL)) || @battle.pbWeather== :RAINDANCE || [:MISTY,:SWAMP,:WATERSURFACE,:UNDERWATER].include?(@battle.FE) || @battle.state.effects[:MISTY] > 0 || @gonnaTerrains.include?(:MISTY)
		end
		healing += @battle.FE == :CORRUPTED ? 0.125 : 0.0625 if attacker.itemWorks? && (attacker.item == :BLACKSLUDGE && attacker.hasType?(:POISON))
		healing += 0.0625 if attacker.ability== :EARTHEATER && [:DEEPEARTH,:DESERT].include?(@battle.FE)
		healing += 0.0625 if attacker.itemWorks? && attacker.item == :LEFTOVERS 
		healing += 0.0625 if attacker.crested == :INFERNAPE
		healing += 0.0625 if attacker.crested == :GOTHITELLE && attacker.type1 == :PSYCHIC
		healing += 0.0625 if attacker.crested == :VESPIQUEN && attacker.effects[:VespiCrest] == false
		healing += (attacker.pbFaintedPokemonCount*0.05) if attacker.crested == :SPIRITOMB # lawds - spiritomb crest uses own side fainted for healing
		healing += 0.0625 if attacker.ability== :RAINDISH && @battle.pbWeather== :RAINDANCE
		healing += 0.0625 if (attacker.crested == :CASTFORM && attacker.form == 2) && @battle.pbWeather== :RAINDANCE
		healing += 0.0625 if attacker.ability== :ICEBODY && (@battle.pbWeather== :HAIL || @battle.FE == :ICY || @battle.FE == :SNOWYMOUNTAIN || @battle.FE == :FROZENDIMENSION)
		healing += 0.0625 if attacker.ability== :ICEBODY && @battle.FE == :FROZENDIMENSION # lawds double ice body healing on fdim
		healing += 0.0625 if attacker.crested == :DRUDDIGON && @battle.pbWeather== :SUNNYDAY
		healing += 0.0625 if attacker.crested == :MEGANIUM || attacker.pbPartner.crested == :MEGANIUM
		healing += 0.0625 if attacker.crested == :BASTIODON # LAWDS - Bastiodon crest gives some small healing, main purpose is to stop you from cheesing it with fake out
		healing += 0.0625 if attacker.crested == :PACHIRISU
		healing += 0.125 if (attacker.status == :POISON || @battle.FE == :CORROSIVE || @battle.FE == :WASTELAND) && (attacker.ability== :POISONHEAL || attacker.crested == :ZANGOOSE)
		healing += 0.0625 if Rejuv && (@battle.FE == :GRASSY || @battle.state.effects[:GRASSY] > 0) && attacker.ability== :SAPSIPPER
		healing += 0.0625 if (@battle.FE == :GRASSY || @battle.state.effects[:GRASSY] > 0 || @gonnaTerrains.include?(:GRASSY)) && !attacker.isAirborne? && !PBStuff::TWOTURNMOVE.include?(attacker.effects[:TwoTurnAttack])
		healing += 0.0625 if Rejuv && (@battle.FE == :ELECTERRAIN || @battle.state.effects[:ELECTERRAIN ] > 0) && attacker.ability== :VOLTABSORB
		if @battle.FE != :INDOOR
			healing += 0.0625 if @battle.FE == :RAINBOW && attacker.status == :SLEEP
			healing += 0.0625 if @battle.FE == :FOREST && attacker.ability== :SAPSIPPER
			healing += 0.0625 if @battle.FE == :SHORTCIRCUIT && attacker.ability== :VOLTABSORB
			healing += 0.0625 if (@battle.FE == :WATERSURFACE || @battle.FE == :UNDERWATER) && attacker.ability== :WATERABSORB
			healing += 0.0625 if @battle.FE == :BEWITCHED && attacker.hasType?(:GRASS) && !attacker.isAirborne?
			if @battle.FE == :SKY && attacker.pbOwnSide.effects[:Tailwind] != 0 # LAWDS - wind rider, flying type pokemon recover hp in tailwind on sky field
				healing += 0.0625 if attacker.ability== :WINDRIDER
				healing += 0.0625 if attacker.hasType?(:FLYING)
			end
			#healing *= 0.67 if @battle.FE == :BACKALLEY # lawds
		end
		num = getchip ? 0 : 1
		healing = ((healing - num)*stallMult) + num
		return healing
	end

	def getTerrainsWeathersOnSwitch(pkmn) # lawds checks for any terrain effects or weather effects that will be set after a pokemon switches in
	end

	def pbPartyHasType?(type,index=@index)
		typevar=false
		for mon in @battle.pbParty(index)
			next if mon.nil? || mon.isEgg?
			typevar=true if mon.hp > 0 && mon.hasType?(type)
		end
		return typevar
	end

	def pbPartyHasAbility?(ability,index=@index,singleowner=true) # LAWDS - checking either party for abilities to dissuade stuff like magic bounce cheese
		abilvar=false
		if !singleowner
			party = @battle.pbParty(index)
		else
			party = @battle.pbPartySingleOwner(index)
		end
		for mon in party
			next if mon.nil? || mon.isEgg? || mon.hp<=0
			if mon.ability== ability
				abilvar=true 
				break
			end
		end
		return abilvar
	end

	def illusionCheck(attacker = @attacker, opponent = @opponent)
		return false if @battle.pbOwnedByPlayer?(attacker.index) # LAWDS assume player can always see through illusion
		return false if attacker.index==2 # LAWDS player AI partner always sees through enemy illusion, its just frustrating if they dont imo
		return false if opponent.index == attacker.pbPartner.index || opponent.index==attacker.index
		# LAWDS - if AI was fooled once, it will never be fooled again
		return false unless opponent.effects[:Illusion]!=nil && !opponent.pokemon.zoro_illusion_detected
	
		return true
	end

	def pbTypeModNoMessages(type=@move.type,attacker=@attacker,opponent=@opponent,move=@move,skill=@mondata.skill,field: @battle.FE)
		return 4 if !type || type==nil
		id = move.move
		secondtype = move.getSecondaryType(attacker)
		if !moldBreakerCheck(attacker,move) && !opponent.hasWorkingItem(:ABILITYSHIELD) && !(move.isSoundBased? && attacker.ability==:LIQUIDVOICE) # lawds just put this here manually ig
			abil = []
			if opponent.ability.is_a?(PokeAbility)
			  if opponent.PULSE3==true || opponent.ability.ability.is_a?(Array)
				for i in opponent.ability.ability
				  abil.push(i)
				end
			  else
				abil=[opponent.ability.ability]
			  end
			end 
			for i in abil
				next if i==nil
				case i
					when :SAPSIPPER 					 	then return -1 if type == :GRASS || (!secondtype.nil? && secondtype.include?(:GRASS))
					when :LEVITATE,:SOLARIDOL,:LUNARIDOL 	then return 0 if (type == :GROUND || (!secondtype.nil? && secondtype.include?(:GROUND))) && field != :CAVE && !opponent.hasWorkingItem(:IRONBALL) && @battle.state.effects[:Gravity]==0 && field != :DEEPEARTH
					when :MAGNETPULL,:CONTRARY,:UNAWARE,:OBLIVIOUS 	then return 0 if (type == :GROUND || (!secondtype.nil? && secondtype.include?(:GROUND))) && field == :DEEPEARTH
						# LAWDS punk rock and surge surfer on concert 4
					when :PUNKROCK,:SURGESURFER				then return -1 if (type == :GROUND || (!secondtype.nil? && secondtype.include?(:GROUND))) && [:CONCERT3,:CONCERT4].include?(field) && !opponent.hasWorkingItem(:IRONBALL)
					when :STORMDRAIN 						then return -1 if type == :WATER || (!secondtype.nil? && secondtype.include?(:WATER))
					when :LIGHTNINGROD,:MOTORDRIVE			
						if type == :ELECTRIC || (!secondtype.nil? && secondtype.include?(:ELECTRIC)) # LAWDS dont care about boosting lightning rod partner if they're a phys attacker
							return 0 if !(opponent == attacker.pbPartner && i==:LIGHTNINGROD && opponent.attack > opponent.spatk*1.1)
							return 0
						end
					when :DRYSKIN 							then return -1 if type == :WATER || (!secondtype.nil? && secondtype.include?(:WATER)) && opponent.effects[:HealBlock]==0
					when :VOLTABSORB 						then return -1 if type == :ELECTRIC || (!secondtype.nil? && secondtype.include?(:ELECTRIC)) && opponent.effects[:HealBlock]==0
					when :WATERABSORB 						then return -1 if type == :WATER || (!secondtype.nil? && secondtype.include?(:WATER)) && opponent.effects[:HealBlock]==0
					# Gen 9 Mod - Added Earth Eater
					when :EARTHEATER             			then return -1 if type == :GROUND || (!secondtype.nil? && secondtype.include?(:GROUND)) && opponent.effects[:HealBlock]==0
					# lawds entomophagous
					when :ENTOMOPHAGY           			then return -1 if type == :BUG || (!secondtype.nil? && secondtype.include?(:BUG)) && opponent.effects[:HealBlock]==0
					when :BULLETPROOF 						then return 0 if (PBStuff::BULLETMOVE).include?(id)
					when :IMMUNITY, :POISONHEAL				then return 0 if type==:POISON || (!secondtype.nil? && secondtype.include?(:POISON))
					when :FLASHFIRE 						then return -1 if type == :FIRE || (!secondtype.nil? && secondtype.include?(:FIRE))
					when :WELLBAKEDBODY 					then return -1 if type == :FIRE || (!secondtype.nil? && secondtype.include?(:FIRE))
					# LAWDS - changed this to -1 to catch AI trying to go for moves into immunities, its fine
					when :MAGMAARMOR 						then return -1 if (type == :FIRE || (!secondtype.nil? && secondtype.include?(:FIRE))) && (field == :DRAGONSDEN || field == :INFERNAL || field == :VOLCANICTOP)
					when :TELEPATHY 						then return 0 if  move.basedamage>0 && opponent.index == attacker.pbPartner.index
					# LAWDS spirit's envoy
					when :SPIRITSENVOY						then return -1 if (type == :GHOST || (!secondtype.nil? && secondtype.include?(:GHOST))) && field != :HAUNTED
				end
			end
		end
		case opponent.crested
			when :WHISCASH					 		then return -1 if type == :GRASS || (!secondtype.nil? && secondtype.include?(:GRASS))
			when :SKUNTANK 							then return -1 if type == :GROUND || (!secondtype.nil? && secondtype.include?(:GROUND))
			when :DRUDDIGON							then return -1 if type == :FIRE || (!secondtype.nil? && secondtype.include?(:FIRE))
		end
		if attacker.ability==:TELEPATHY && move.basedamage>0 && opponent.index == attacker.pbPartner.index# lawds telepathy works the other way around
			return 0
		end
		if field == :ROCKY && (opponent.effects[:Substitute]>0 || opponent.stages[PBStats::DEFENSE] > 0) && attacker.ability!=:TRUESHOT # LAWDS - trueshot ignores rocky bs
		  	return 0 if (PBStuff::BULLETMOVE).include?(id)
		end
		if (field == :WATERSURFACE || field == :MURKWATERSURFACE) && (type == :GROUND || (!secondtype.nil? && secondtype.include?(:GROUND)))
		  	return 0
		end
		if field == :HOLY && move.basedamage>0 && opponent.index == attacker.pbPartner.index
			return 0
		end
		if Rejuv && field == :DESERT && @battle.pbWeather == :SUNNYDAY && (type == :WATER || (!secondtype.nil? && secondtype.include?(:WATER))) && (opponent.hasType?(:WATER) || opponent.hasType?(:GRASS)) && opponent.effects[:HealBlock]==0
			return -1
		end
		if Rejuv && field == :GLITCH && opponent.species == :GENESECT
			if opponent.item == :BURNDRIVE && (type == :FIRE || (!secondtype.nil? && secondtype.include?(:FIRE)))
				return -1
			elsif opponent.item == :DOUSEDRIVE && (type == :WATER || (!secondtype.nil? && secondtype.include?(:WATER)))
				return -1
			elsif opponent.item == :CHILLDRIVE && (type == :ICE || (!secondtype.nil? && secondtype.include?(:ICE)))
				return -1
			elsif opponent.item == :SHOCKDRIVE && (type == :ELECTRIC || (!secondtype.nil? && secondtype.include?(:ELECTRIC)))
				return -1
			end
		end
		zorovar = illusionCheck(attacker,opponent)
		typemod=move.pbTypeModifier(type,attacker,opponent,zorovar,true,field) # lawds field parameter for field change stuff
		typemod*=2 if type == :FIRE && opponent.effects[:TarShot]
		case opponent.crested
			when :LUXRAY
			  typemod /= 2 if (type == :GHOST || type == :DARK)
			  typemod = 0 if type == :PSYCHIC 
			when :SAMUROTT, :BRAVIARY # Lawds Mod - Braviary Crest
			  typemod /= 2 if (type == :BUG || type == :DARK || type == :ROCK)
			when :LEAFEON
			  typemod /= 4 if (type == :FIRE || type == :FLYING)
			when :GLACEON
			  typemod /= 4 if (type == :ROCK || type == :FIGHTING)
			when :SIMISEAR
			  typemod /= 2 if [:STEEL, :FIRE,:ICE].include?(type)
			  typemod /= 2 if type == :WATER && field != :UNDERWATER
			when :SIMIPOUR
			  typemod /= 2 if [:GROUND,:WATER,:GRASS,:ELECTRIC].include?(type)
			when :SIMISAGE
			  typemod /= 2 if [:BUG,:STEEL,:FIRE,:GRASS,:FAIRY].include?(type)
			  typemod /= 2 if type == :ICE && field != :GLITCH
			when :TORTERRA
			  if !($game_switches[:Inversemode] ^ (field == :INVERSE))
				typemod = 16 / typemod if typemod != 0
			  end
			when :DHELMISE
				typemod /= 2 if [:BUG,:STEEL,:PSYCHIC,:FLYING,:GRASS,:ROCK,:ICE,:FAIRY,:NORMAL,:DRAGON].include?(type)
				typemod = 0 if type == :POISON && opponent.ability!=:CORROSION
		end
		typemod*= 4 if id == :FREEZEDRY && (opponent.hasType?(:WATER))
		typemod*= 2 if id == :CUT && (opponent.hasType?(:GRASS)) && (field == :FOREST || @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,2,5))
		# LAWDS - Tinkaton Crest, Barbed Web
		typemod*= 4 if (type == :STEEL && opponent.hasType?(:STEEL) && attacker.crested == :TINKATON)
		typemod*= 4 if (id == :BARBEDWEB && opponent.hasType?(:FLYING))
		if id == :FLYINGPRESS
			if field == :SKY
			  if ((PBTypes.oneTypeEff(:FLYING, opponent.type1) > 2) || (PBTypes.oneTypeEff(:FLYING, opponent.type1) < 2 && $game_switches[:Inversemode]))
				typemod*=2
			  end
			  if ((PBTypes.oneTypeEff(:FLYING, opponent.type2) > 2) || (PBTypes.oneTypeEff(:FLYING, opponent.type2) < 2 && $game_switches[:Inversemode]))
				typemod*=2
			  end
			else
			  typemod2=move.pbTypeModifier(:FLYING,attacker,opponent)
			  typemod3= ((typemod*typemod2)/4)
			  typemod=typemod3
			end
		end
		if id == :SCENTEDGEYSER # LAWDS - Scented Geyser secondary typings
			incense_type = :QMARKS
			case attacker.item
			when :ODDINCENSE
				incense_type = :PSYCHIC
			when :WAVEINCENSE, :ODDINCENSE
				incense_type = :WATER
			when :ROCKINCENSE
				incense_type = :ROCK
			when :ROSEINCENSE
				incense_type = :GRASS
			end
			typemod2=move.pbTypeModifier(incense_type,attacker,opponent)
			typemod3= ((typemod*typemod2)/4)
			typemod=typemod3
		end
		typemod=0 if opponent.ability==:WONDERGUARD && !moldBreakerCheck(attacker,move) && typemod <= 4 && !opponent.hasWorkingItem(:ABILITYSHIELD) && !(move.isSoundBased? && attacker.ability==:LIQUIDVOICE) # lawds just put this here manually ig
		
		# Field Effect type changes go here
		typemod=move.fieldTypeChange(attacker,opponent,typemod,false)
		typemod=move.overlayTypeChange(attacker,opponent,typemod,false)
		
		# Cutting super effectiveness in half                                                     # LAWDS - Rocky Payload lets its boosted moves always hit Flying for SE regardless of weather
		if @battle.pbWeather==:STRONGWINDS && ((opponent.hasType?(:FLYING)) && !opponent.effects[:Roost]) &&  !(attacker.ability== :ROCKYPAYLOAD && (type == :ROCK || (type == :ICE && field == :SNOWYMOUNTAIN))) && 
			((PBTypes.oneTypeEff(type, :FLYING) > 2) || (PBTypes.oneTypeEff(type, :FLYING) < 2 && ($game_switches[:Inversemode] || (field == :INVERSE))))
		  	typemod /= 2
		end
		if field == :SNOWYMOUNTAIN && opponent.ability== :ICESCALES && opponent.hasType?(:ICE) && !moldBreakerCheck(attacker,move) && !opponent.hasWorkingItem(:ABILITYSHIELD) && !(move.isSoundBased? && attacker.ability==:LIQUIDVOICE) && # lawds just put this here manually ig
			((PBTypes.oneTypeEff(type, :ICE) > 2) || (PBTypes.oneTypeEff(type, :ICE) < 2 && ($game_switches[:Inversemode] || (field == :INVERSE))))
			typemod /= 2
		end
		if field == :FROZENDIMENSION && opponent.ability== :BADSEEDS && opponent.hasType?(:ICE) && !moldBreakerCheck(attacker,move) && !opponent.hasWorkingItem(:ABILITYSHIELD) && !(move.isSoundBased? && attacker.ability==:LIQUIDVOICE) && # lawds just put this here manually ig
			((PBTypes.oneTypeEff(type, :ICE) > 2) || (PBTypes.oneTypeEff(type, :ICE) < 2 && ($game_switches[:Inversemode] || (field == :INVERSE))))
			typemod /= 2
		end
		if field == :DRAGONSDEN && opponent.ability== :MULTISCALE && opponent.hasType?(:DRAGON) && !moldBreakerCheck(attacker,move) && !opponent.hasWorkingItem(:ABILITYSHIELD) && !(move.isSoundBased? && attacker.ability==:LIQUIDVOICE) && # lawds just put this here manually ig
			((PBTypes.oneTypeEff(type, :DRAGON) > 2) || (PBTypes.oneTypeEff(type, :DRAGON) < 2 && ($game_switches[:Inversemode] || (field == :INVERSE))))
			typemod /= 2
		end
		if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,4,5) && opponent.hasType?(:GRASS) && !opponent.hasWorkingItem(:ABILITYSHIELD) && !(move.isSoundBased? && attacker.ability==:LIQUIDVOICE) && # lawds just put this here manually ig
			((PBTypes.oneTypeEff(type, :GRASS) > 2) || (PBTypes.oneTypeEff(type, :GRASS) < 2 && ($game_switches[:Inversemode] || (field == :INVERSE))))
			typemod /= 2
		end
		if field == :BEWITCHED && opponent.hasType?(:FAIRY) && (opponent.ability== :PASTELVEIL || opponent.pbPartner.ability== :PASTELVEIL) && !moldBreakerCheck(attacker,move) && !opponent.hasWorkingItem(:ABILITYSHIELD) && !(move.isSoundBased? && attacker.ability==:LIQUIDVOICE) && # lawds just put this here manually ig
			((PBTypes.oneTypeEff(type, :FAIRY) > 2) || (PBTypes.oneTypeEff(type, :FAIRY) < 2 && ($game_switches[:Inversemode] || (field == :INVERSE))))
			typemod /= 2
		end
		if field == :HAUNTED && opponent.ability== :CURSEDBODY && !moldBreakerCheck(attacker,move) && opponent.hasType?(:GHOST) && !opponent.hasWorkingItem(:ABILITYSHIELD) && !(move.isSoundBased? && attacker.ability==:LIQUIDVOICE) && # lawds just put this here manually ig# LAWDS cursed body on haunted
			((PBTypes.oneTypeEff(type, :GHOST) > 2 || (PBTypes.oneTypeEff(type, :GHOST) < 2 && ($game_switches[:Inversemode]))))
			typemod /= 2
		end
		if field == :NEWWORLD && opponent.hasType?(:SHADOW) # LAWDS shadow pokemon have no weaknesses on new world
			typemod=4
		  end
		return 1 if typemod==0 && move.function==0x111
		return typemod
	end

	#@scorearray = [[-1,-1,-1,-1],[-1,-1,-1,-1],[-1,-1,-1,-1],[-1,-1,-1,-1]]
	def getMaxScoreIndex(scores)
		maxscore=scores.max {|a,b| a.max <=> b.max}
		maxscoreindex = scores.find_index {|score| score == maxscore}
		return [maxscoreindex,scores[maxscoreindex].find_index {|score| score == scores[maxscoreindex].max}]
	end
	# lawds field parameter
	def pbChangeMove(move,attacker,field=@battle.FE)
		if field==@battle.FE
			fieldobj = @battle.field
		else
			fieldobj = PokeBattle_Field.new
			fieldobj.effect = field
		end
		return move unless [:WEATHERBALL, :HIDDENPOWER, :TERRAINPULSE, :NATUREPOWER, :IVYCUDGEL, :RAGINGBULL, :TERASTARSTORM].include?(move.move) # Gen 9 Mod - Added Ivy Cudgel, Raging Bull and Tera Starstorm
		attacker = @opponent if caller_locations.any? {|call| call.label=="buildMoveScores"} && attacker.nil?
		#make new instance of move
		move = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(move.move),attacker)
		case move.move
			when :WEATHERBALL
				weather=@battle.pbWeather
				move.type=(:NORMAL)
				move.type=:FIRE if (weather== :SUNNYDAY && !attacker.hasWorkingItem(:UTILITYUMBRELLA)) || attacker.crested == :CHERRIM || attacker.pbPartner.crested == :CHERRIM
				move.type=:WATER if (weather== :RAINDANCE && !attacker.hasWorkingItem(:UTILITYUMBRELLA))
				move.type=:ROCK if weather== :SANDSTORM
				move.type=:ICE if weather== :HAIL
				#move.basedamage*=2 if @battle.pbWeather !=0 || @battle.FE == :RAINBOW && move.basedamage == 50
		
			when :HIDDENPOWER
				move.type = move.pbType(attacker) if attacker
			when :TERRAINPULSE
				move.type = fieldobj.mimicry if fieldobj.mimicry
			when :NATUREPOWER
				move = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(fieldobj.naturePower),attacker)
				move.priority = 1 if attacker.ability== :PRANKSTER
			when :RAGE # lawds added rage AI
				move.type = :DARK if [:DIMENSIONAL,:FROZENDIMENSION].include?(field)
		end
		return move
	end

	def scoreDecrease(threat_index, killable, decreased_by, ai_leader)
		if killable[ai_leader] == :both
			# changing scoring for leader on mon that the leader doesn't kill
			@aimondata[ai_leader].scorearray[threat_index^2].map! {|score| score>80 ? 80 : score }
			# decreasing score for follower on mon that the leader kills
			@aimondata[ai_leader^2].scorearray[threat_index].map! {|score| score * decreased_by} 
		elsif killable[ai_leader] == :left
			@aimondata[ai_leader^2].scorearray[0].map! {|score| score * decreased_by}
		elsif killable[ai_leader] == :right
			@aimondata[ai_leader^2].scorearray[2].map! {|score| score * decreased_by}
		end
	end

	def totalHazardDamage(pkmn,field=@battle.FE)
		percentdamage = 0
		if pkmn.pbOwnSide.effects[:Spikes]>0 && !pkmn.isAirborne?(field) && !pkmn.ability== :MAGICGUARD && !(pkmn.ability== :WONDERGUARD && field == :COLOSSEUM) && !pkmn.hasWorkingItem(:HEAVYDUTYBOOTS)
			spikesdiv=[8,8,6,4][pkmn.pbOwnSide.effects[:Spikes]]
			if Rejuv && field == :ELECTERRAIN && @mondata.skill>BESTSKILL
              eff=PBTypes.twoTypeEff(:ELECTRIC,pkmn.type1,pkmn.type2)
              if eff>0
				percentdamage += 100*eff/4*spikesdiv
              end
			else
				percentdamage += (100.0/spikesdiv).floor
			end
		end																																											
		if pkmn.pbOwnSide.effects[:StealthRock] && !pkmn.ability== :MAGICGUARD && !(pkmn.ability== :WONDERGUARD && field == :COLOSSEUM) && !pkmn.hasWorkingItem(:HEAVYDUTYBOOTS)
			eff=PBTypes.twoTypeEff(:ROCK,pkmn.type1,pkmn.type2)
			if @mondata.skill>BESTSKILL && field == :CRYSTALCAVERN
				eff1=PBTypes.twoTypeEff(:WATER,pkmn.type1,pkmn.type2)
				eff2=PBTypes.twoTypeEff(:GRASS,pkmn.type1,pkmn.type2)
				eff3=PBTypes.twoTypeEff(:FIRE,pkmn.type1,pkmn.type2)
				eff4=PBTypes.twoTypeEff(:PSYCHIC,pkmn.type1,pkmn.type2)
				eff = [eff1,eff2,eff3,eff4].max
			elsif @mondata.skill>BESTSKILL && field == :CORRUPTED
				eff=PBTypes.twoTypeEff(:POISON,pkmn.type1,pkmn.type2)
			elsif @mondata.skill>BESTSKILL && (field == :VOLCANICTOP || field == :INFERNAL || (Rejuv && field == :DRAGONSDEN))
				eff1=PBTypes.twoTypeEff(:FIRE,pkmn.type1,pkmn.type2)
			elsif field == :INVERSE # LAWDS stealth rocks on inverse
				if @field.effect == :INVERSE
					switcheff = { 16 => 1, 8 => 2, 4 => 4, 2 => 8, 1 => 16, 0 => 16}
					eff = switcheff[eff]
				  end
			end
			if eff>0
				if @mondata.skill>BESTSKILL && (field == :ROCKY || field == :CAVE)
					eff*=2
					eff/=4 if pkmn.hasType?(:ROCK) # LAWDS - SR damage is halved instead of doubled on rock types on these fields
				end
				eff/=4 if @battle.pbWeather == :STRONGWINDS && pkmn.hasType?(:FLYING) && field != :VOLCANICTOP # LAWDS - flying weakness cut also applies to stealth rock now. this line does not apply on vtop where SR is fire
				
				percentdamage += 100*(eff/32.0)
			end
		end
		if @mondata.skill>=BESTSKILL
			# Corrosive Field Entry
			if field == :CORROSIVE
				if ![:MAGICGUARD, :POISONHEAL, :IMMUNITY, :WONDERGUARD, :TOXICBOOST, :PASTELVEIL].include?(pkmn.ability) && pkmn.crested != :ZANGOOSE
					if !pkmn.isAirborne?(field) && !pkmn.hasType?(:POISON) && !pkmn.hasType?(:STEEL)
						eff=PBTypes.twoTypeEff(:POISON,pkmn.type1,pkmn.type2)
						eff*=2
						percentdamage += 100*(eff/32.0)
					end
				end
			# Icy field + Seed activation spike damage
			elsif field == :ICY
				if pkmn.item == :ELEMENTALSEED && # pkmn.ability != :KLUTZ && # lawds klutz rework
					!pkmn.isAirborne?(field) && pkmn.ability != :MAGICGUARD
					spikesdiv=[8,8,6,4][pkmn.pbOwnSide.effects[:Spikes]]
					percentdamage += (100.0/spikesdiv).floor
				end
			# Cave field + Seed activation stealth rock damage
			elsif field == :CAVE
				if pkmn.item == :TELLURICSEED && # pkmn.ability != :KLUTZ && # lawds klutz rework
					pkmn.ability != :MAGICGUARD
					eff=PBTypes.twoTypeEff(:ROCK,pkmn.type1,pkmn.type2)
					if eff>0
						eff = eff*2
						eff/=
						percentdamage += 100*(eff/32.0)
					end
				end
			elsif field == :CONCERT3 || field == :CONCERT4
				if pkmn.status == :SLEEP || pkmn.ability== :COMATOSE
					percentdamage += 25
				end
			elsif field == :PSYTERRAIN && pkmn.item == :WAVEINCENSE && pkmn.ability != :MAGICGUARD && pkmn.ability != :ROCKHEAD # LAWDS - wave incense on psychic terrain
				percentdamage += 33
			end
		end
		return percentdamage
	end
	# lawds - added threatscoring field to bypass ability shield check for threat assessment, as well as to allow threatAssessment to ignore abilities whose effects are already accounted for elsewhere in threatAssessment
	# added more abilities accounted for here, starting from the top
	def getAbilityDisruptScore(attacker,opponent,threatscoring=false)
		abilityscore=100.0
		return (abilityscore/100) if opponent.ability.nil? #if the ability doesn't work, then nothing here matters
		# LAWDS implementation of Gen 9 - if you can't disrupt the ability, then nothing here matters unless you're trying to see the ability value for threat scoring
		return (abilityscore/100) if opponent.item == :ABILITYSHIELD && !threatscoring
		abil = []
		if opponent.ability.is_a?(PokeAbility)
		  if opponent.PULSE3==true || opponent.ability.ability.is_a?(Array)
			for i in opponent.ability.ability
			  abil.push(i)
			end
		  else
			abil=[opponent.ability.ability]
		  end
		end
		for i in abil
		case i
			when :BADSEEDS # lawds bad seeds spread on FDim
				abilityscore*=0.2 if (@battle.FE==:FROZENDIMENSION && !(opponent.hasType?(:ICE))) 
			when :SANDRUSH, :DUSTDEVIL
				abilityscore*=2 if (@battle.pbWeather== :SANDSTORM || [:ASHENBEACH, :DESERT].include?(@battle.FE)) && !threatscoring
			when :SPIRITEATER,:INDUSTRYSTANDARD
				abilityscore*=2.0
			when :SLUSHRUSH
				abilityscore*=2 if (@battle.pbWeather== :HAIL || [:FROZENDIMENSION, :ICY, :SNOWYMOUNTAIN].include?(@battle.FE)) && !threatscoring
			when :CHLOROPHYLL
				abilityscore*=2 if (@battle.pbWeather== :SUNNYDAY || [:FLOWERGARDEN4, :FLOWERGARDEN5].include?(@battle.FE) || opponent.pbPartner.crested == :CHERRIM) && !threatscoring
			when :SWIFTSWIM
				abilityscore*=2 if (@battle.pbWeather== :RAINDANCE || [:WATERSURFACE, :MURKWATERSURFACE, :UNDERWATER].include?(@battle.FE)) && !threatscoring
				abilityscore*=1.3 if @battle.FE == :SWAMP && !opponent.isAirborne?
			when :AERILATE
				if !threatscoring
					abilityscore*=1.5
					abilityscore*=1.5 if [:MOUNTAIN,:SNOWYMOUNTAIN,:SKY].include?(@battle.FE)
				end
			when :PIXILATE
				if !threatscoring
					abilityscore*=1.5
					abilityscore*=1.5 if @battle.FE == :MISTY || @battle.state.effects[:MISTY] != 0
				end
			when :SOLARPOWER, :WILDFIRE
				abilityscore*=1.5 if ((@battle.pbWeather == :SUNNYDAY && @battle.FE != :FROZENDIMENSION) || (@battle.FE == :SKY && ![:RAINDANCE, :SANDSTORM, :HAIL].include?(@battle.pbWeather) && i==:SOLARPOWER) || opponent.pbPartner.crested == :CHERRIM || (i==:WILDFIRE && @battle.FE==:INFERNAL)) && !threatscoring
			when :CLEARBODY, :FULLMETALBODY
				if !opponent.isAirborne?
					abilityscore*=1.3 if @battle.FE == :SWAMP
					abilityscore*=1.3 if [:NEWWORLD,:WATERSURFACE,:MURKWATERSURFACE].include?(@battle.FE)
				end
			when :INDUSTRYSTANDARD
				if !opponent.isAirborne?
					abilityscore*=1.3 if @battle.FE == :SWAMP
					abilityscore*=1.3 if [:NEWWORLD,:WATERSURFACE,:MURKWATERSURFACE].include?(@battle.FE)
				end
				abilityscore*=1.5 if opponent.pbHasMove?(:DRACOMETEOR) # only mega duraludon has this ability and it mainly enables draco spam, so its fine to just check for it specifically outside of standard clear body stuff
			when :STAMINA
				abilityscore*=1.3 if opponent.stages[PBStats::DEFENSE] < 2 && attacker.attack > attacker.spatk && !threatscoring
			when :NOGUARD
				if !threatscoring
					for i in opponent.moves
						acc = pbRoughAccuracy(i, attacker, opponent, true)
						accmult = 1+((100.0-acc)/100.0)
						abilityscore*=accmult
					end
					for i in attacker.moves
						acc = pbRoughAccuracy(i, opponent, attacker, true)
						accmult = 1+((100.0-acc)/100.0)
						abilityscore/=accmult if accmult != 0
					end
				end
			when :MAGMAARMOR
				if [:VOLCANIC,:VOLCANICTOP,:INFERNAL].include?(@battle.FE)
					abilityscore*=1.3
					for i in attacker.moves
						next if i.nil?
						firemove=i if i.pbType(attacker)==:FIRE
					end
					if attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.pbType(attacker) == :FIRE}
						abilityscore*=3 if attacker.moves.all? {|moveloop| moveloop!=nil && moveloop.pbType(attacker) == :FIRE}
						abilityscore*=2 if pbTypeModNoMessages(firemove.pbType(attacker),attacker,opponent,firemove)>4
					end
				end
			# End of LAWDS ability handling, this is a WIP
			when :SPEEDBOOST
				#abilityscore*=1.1
				abilityscore*=1.3 if opponent.stages[PBStats::SPEED]<2
			when :SANDVEIL
				abilityscore*=1.3 if @battle.pbWeather== :SANDSTORM
			when :VOLTABSORB, :LIGHTNINGROD, :MOTORDRIVE
				for i in attacker.moves
					next if i.nil?
					elecmove=i if i.pbType(attacker)==:ELECTRIC
				end
				if attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.pbType(attacker) == :ELECTRIC}
					abilityscore*=3 if attacker.moves.all? {|moveloop| moveloop!=nil && moveloop.pbType(attacker) == :ELECTRIC}
					abilityscore*=2 if pbTypeModNoMessages(elecmove.pbType(attacker),attacker,opponent,elecmove)>4
				end
			when :WATERABSORB, :STORMDRAIN, :DRYSKIN
				for i in attacker.moves
					next if i.nil?
					watermove=i if i.pbType(attacker)==:WATER
				end
				if attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.pbType(attacker) == :WATER}
					abilityscore*=3 if attacker.moves.all? {|moveloop| moveloop!=nil && moveloop.pbType(attacker) == :WATER}
					abilityscore*=2 if pbTypeModNoMessages(watermove.pbType(attacker),attacker,opponent,watermove)>4
				end
				abilityscore*=0.5 if opponent.ability== :DRYSKIN && attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.pbType(attacker) == :FIRE}
			when :SAPSIPPER
				for i in attacker.moves
					next if i.nil?
					grassmove=i if i.pbType(attacker) == :GRASS
				end
				if attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.pbType(attacker) == :GRASS}
					abilityscore*=3 if attacker.moves.all? {|moveloop| moveloop!=nil && moveloop.pbType(attacker) == :GRASS}
					abilityscore*=2 if pbTypeModNoMessages(grassmove.pbType(attacker),attacker,opponent,grassmove)>4
				end
			when :SPIRITSENVOY # LAWDS - spirit's envoy
				for i in attacker.moves
					next if i.nil?
					ghostmove=i if i.pbType(attacker) == :GHOST
				end
				if attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.pbType(attacker) == :GHOST} && @battle.FE != :HAUNTED
					abilityscore*=3 if attacker.moves.all? {|moveloop| moveloop!=nil && moveloop.pbType(attacker) == :GHOST}
					abilityscore*=2 if pbTypeModNoMessages(ghostmove.pbType(attacker),attacker,opponent,ghostmove)>4
				end
			when :ENTOMOPHAGY
				for i in attacker.moves
					next if i.nil?
					bugmove=i if i.pbType(attacker) == :BUG
				end
				if attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.pbType(attacker) == :BUG}
					abilityscore*=3 if attacker.moves.all? {|moveloop| moveloop!=nil && moveloop.pbType(attacker) == :BUG}
					abilityscore*=2 if pbTypeModNoMessages(bugmove.pbType(attacker),attacker,opponent,bugmove)>4
				end
			when :FLASHFIRE,:WELLBAKEDBODY # LAWDS - well-baked body
				for i in attacker.moves
					next if i.nil?
					firemove=i if i.pbType(attacker) == :FIRE
				end
				if attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.pbType(attacker) == :FIRE}
					abilityscore*=3 if attacker.moves.all? {|moveloop| moveloop!=nil && moveloop.pbType(attacker) == :FIRE}
					abilityscore*=2 if pbTypeModNoMessages(firemove.pbType(attacker),attacker,opponent,firemove)>4
				end
			when :LEVITATE, :LUNARIDOL, :SOLARIDOL, :EARTHEATER # Gen 9 Mod - Added Earth Eater
				for i in attacker.moves
					next if i.nil?
					groundmove=i if i.pbType(attacker) == :GROUND
				end
				if attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.pbType(attacker) == :GROUND}
					abilityscore*=3 if attacker.moves.all? {|moveloop| moveloop!=nil && moveloop.pbType(attacker) == :GROUND}
					abilityscore*=2 if pbTypeModNoMessages(groundmove.pbType(attacker),attacker,opponent,groundmove)>4
				end
			when :SHADOWTAG
				abilityscore*=1.5 if (!attacker.hasType?(:GHOST) || @battle.FE == :DIMENSIONAL) && !attacker.ability==:RUNAWAY
			when :ARENATRAP
				abilityscore*=1.5 if !attacker.isAirborne? && !attacker.ability==:RUNAWAY # LAWDS they forgot to negate the conditional
			when :WONDERGUARD
				abilityscore*=5 if !attacker.moves.any? {|moveloop| moveloop!=nil && pbTypeModNoMessages(moveloop.pbType(attacker),attacker,opponent,moveloop)>4}
			when :SERENEGRACE
				abilityscore*=1.3
			when :PUREPOWER, :HUGEPOWER
				abilityscore*=2
			when :SOUNDPROOF
				abilityscore*=3 if attacker.moves.all? {|moveloop| moveloop!=nil && (moveloop.isSoundBased? || moveloop.basedamage==0)}
			when :THICKFAT
				abilityscore*=1.5 if attacker.moves.all? {|moveloop| moveloop!=nil && (moveloop.pbType(attacker) == :FIRE || moveloop.pbType(attacker) == :ICE) }
			when :TRUANT
				abilityscore*=0.1
			when :GUTS, :QUICKFEET, :MARVELSCALE
				abilityscore*=1.5 if !opponent.status.nil?
			when :LIQUIDOOZE
				abilityscore*=2 if opponent.effects[:LeechSeed]>=0 || attacker.pbHasMove?(:LEECHSEED)
			when :AIRLOCK, :CLOUDNINE
				abilityscore*=1.1
			when :HYDRATION
				abilityscore*=1.3 if hydrationCheck(attacker)
			when :ADAPTABILITY
				abilityscore*=1.3
			when :SKILLLINK
				abilityscore*=1.5
			when :POISONHEAL
				abilityscore*=2 if opponent.status== :POISON
			when :NORMALIZE
				abilityscore*=0.6 if @battle.FE != :INVERSE # LAWDS - normalize is good on inverse so dont cut it there
			when :MAGICGUARD
				abilityscore*=1.4
			when :STALL
				abilityscore*=hpGainPerTurn(opponent) # lawds
			when :TECHNICIAN
				abilityscore*=1.3
			when :MOLDBREAKER, :TERAVOLT, :TURBOBLAZE
				abilityscore*=1.1
			when :UNAWARE
				abilityscore*=1.7
			when :SLOWSTART
				abilityscore*=0.3 if @battle.FE!-:DEEPEARTH # lawds
			when :MULTITYPE, :STANCECHANGE, :SCHOOLING, :SHIELDSDOWN, :DISGUISE, :RKSSYSTEM, :POWERCONSTRUCT, :ICEFACE
				abilityscore*=0
			when :SHEERFORCE
				abilityscore*=1.2
			when :CONTRARY
				abilityscore*=1.4
				abilityscore*=2 if opponent.stages[PBStats::ATTACK]>0 || opponent.stages[PBStats::SPATK]>0 || opponent.stages[PBStats::DEFENSE]>0 || opponent.stages[PBStats::SPDEF]>0 || opponent.stages[PBStats::SPEED]>0
			when :DEFEATIST
				abilityscore*=0.5
			when :MULTISCALE, :SHADOWSHIELD, :TERAPAGOS
				abilityscore*=1.5 if opponent.hp==opponent.totalhp
			when :HARVEST
				abilityscore*=1.2
			when :MOODY # LAWDS - removing Moody handling for now
				#abilityscore*=1.8
			when :PRANKSTER
				abilityscore*=1.5 if pbAIfaster?(nil,nil,attacker,opponent)
			when :SNOWCLOAK
				abilityscore*=1.1 if @battle.pbWeather== :HAIL
			when :FURCOAT
				abilityscore*=1.5 if attacker.attack>attacker.spatk
			when :PARENTALBOND, :DREADNOUGHT
				abilityscore*=3
			when :PROTEAN, :LIBERO
				abilityscore*=3
			when :TOUGHCLAWS
				abilityscore*=1.2
			when :BEASTBOOST
				abilityscore*=1.1
			when :COMATOSE
				abilityscore*=1.3
			when :FLUFFY
				abilityscore*=1.5
				abilityscore*=0.5 if attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.pbType(attacker)==:FIRE}
			when :MERCILESS
				abilityscore*=1.3
			when :WATERBUBBLE
				abilityscore*=1.5
				abilityscore*=1.3 if attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.pbType(attacker)==:FIRE}
			when :WELLBAKEDBODY # Gen 9 Mod - Added Well-Baked Body
				abilityscore*=3 if attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.pbType(attacker)==:FIRE}
			when :WINDPOWER # Gen 9 Mod - Added Wind Power
				abilityscore*=1.3 if attacker.moves.all? {|moveloop| moveloop!=nil && (moveloop.windMove?)}
			when :WINDRIDER # Gen 9 Mod - Added Wind Rider
				abilityscore*=3 if attacker.moves.all? {|moveloop| moveloop!=nil && (moveloop.windMove?)}
			when :ICESCALES
				abilityscore*=1.5 if attacker.spatk>attacker.attack
			when :MYCELIUMMIGHT # Gen 9 Mod - Added Mycelium Might
				abilityscore*=1.5
			when :CUDCHEW # Gen 9 Mod - Added Cud Chew
				abilityscore*=1.2
			else
				if attacker.pbPartner==opponent && abilityscore!=0
					abilityscore=200 if abilityscore>200
					tempscore = abilityscore
					abilityscore = 200 - tempscore
				end
		end
		end
		abilityscore*=0.01
		return abilityscore
	end

	def getFieldDisruptScore(attacker=@attacker,opponent=@opponent,fieldeffect=@battle.FE, violent=false)
		fieldscore=100.0
		# LAWDS - dont care about disrupting the field if shits locked
		return 100 if @battle.state.effects[:FIELDLOCK]==true || ($game_variables[:DifficultyModes]==2 && !(@battle.ProgressiveFieldCheck(PBFields::CONCERT)) && !(@battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN)) && ![:FACTORY,:SHORTCIRCUIT].include?(@battle.FE))
		aroles = pbGetMonRoles(attacker)
		oroles = pbGetMonRoles(opponent)
		aimem = getAIMemory(opponent)
		case fieldeffect
			when :INDOOR # No field
			when :ELECTERRAIN # Electric Terrain
				fieldscore*=1.5 if opponent.hasType?(:ELECTRIC) || opponent.pbPartner.hasType?(:ELECTRIC)
				fieldscore*=0.5 if attacker.hasType?(:ELECTRIC)
				fieldscore*=0.5 if pbPartyHasType?(:ELECTRIC)
				fieldscore*=1.3 if opponent.ability== :SURGESURFER
				fieldscore*=0.7 if attacker.ability== :SURGESURFER
			when :GRASSY # Grassy Terrain
				fieldscore*=1.5 if opponent.hasType?(:GRASS) || opponent.pbPartner.hasType?(:GRASS)
				fieldscore*=0.5 if attacker.hasType?(:GRASS)
				fieldscore*=1.8 if opponent.hasType?(:FIRE) || opponent.pbPartner.hasType?(:FIRE)
				fieldscore*=0.2 if attacker.hasType?(:FIRE)
				fieldscore*=0.5 if pbPartyHasType?(:GRASS)
				fieldscore*=0.2 if pbPartyHasType?(:FIRE)
				fieldscore*=1.3 if attacker.hasType?(:WATER)
				fieldscore*=1.5 if pbPartyHasType?(:WATER)
				fieldscore*=0.8 if aroles.include?(:SPECIALWALL) || aroles.include?(:PHYSICALWALL)
				fieldscore*=1.2 if oroles.include?(:SPECIALWALL) || oroles.include?(:PHYSICALWALL)
			when :MISTY # Misty Terrain
				fieldscore*=1.3 if attacker.spatk>attacker.attack && (opponent.hasType?(:FAIRY) || opponent.pbPartner.hasType?(:FAIRY))
				fieldscore*=0.7 if attacker.hasType?(:FAIRY) && opponent.spatk>opponent.attack
				fieldscore*=0.5 if opponent.hasType?(:DRAGON) || opponent.pbPartner.hasType?(:DRAGON)
				fieldscore*=1.5 if attacker.hasType?(:DRAGON)
				fieldscore*=0.7 if pbPartyHasType?(:FAIRY)
				fieldscore*=1.5 if pbPartyHasType?(:DRAGON)
				fieldscore*=1.8 if @battle.field.counter==1 && (!(attacker.hasType?(:POISON) || attacker.hasType?(:STEEL)))
			when :DARKCRYSTALCAVERN # Dark Crystal Cavern # LAWDS improved scoring. no need to improve rock-type scoring here since the fields DCC transitions from still benefit rock types
				fieldscore*=1.3 if opponent.hasType?(:DARK) || opponent.pbPartner.hasType?(:DARK) || opponent.hasType?(:GHOST) || opponent.pbPartner.hasType?(:GHOST)
				fieldscore*=0.7 if attacker.hasType?(:DARK) || attacker.hasType?(:GHOST)
				fieldscore*=0.7 if pbPartyHasType?(:DARK) || pbPartyHasType?(:GHOST)
				fieldscore*=0.7 if pbPartyHasAbility?(:PRESSURE,attacker.index) || pbPartyHasAbility?(:UNNERVE,attacker.index) || pbPartyHasAbility?(:ILLUMINATE,attacker.index)
			when :CHESS # Chess field
				fieldscore*=1.3 if opponent.hasType?(:PSYCHIC) || opponent.pbPartner.hasType?(:PSYCHIC)
				fieldscore*=0.7 if attacker.hasType?(:PSYCHIC)
				fieldscore*=0.7 if pbPartyHasType?(:PSYCHIC)
				fieldscore*= attacker.pbSpeed>opponent.pbSpeed ? 1.3 : 0.7
			when :BIGTOP # Big Top field
				fieldscore*=1.5 if opponent.hasType?(:FIGHTING) || opponent.pbPartner.hasType?(:FIGHTING)
				fieldscore*=0.5 if attacker.hasType?(:FIGHTING)
				fieldscore*=0.5 if pbPartyHasType?(:FIGHTING)
				fieldscore*=1.5 if opponent.ability== :DANCER
				fieldscore*=0.5 if attacker.ability== :DANCER
				fieldscore*=0.5 if attacker.pbHasMove?(:SING) || attacker.pbHasMove?(:DRAGONDANCE) || attacker.pbHasMove?(:QUIVERDANCE)
				fieldscore*=1.5 if checkAImoves([:SING,:DRAGONDANCE,:QUIVERDANCE],aimem)
			when :BURNING # Burning Field
				fieldscore*=1.8 if opponent.hasType?(:FIRE) || opponent.pbPartner.hasType?(:FIRE)
				if attacker.hasType?(:FIRE)
					fieldscore*=0.2
				else
					fieldscore*=1.5
					fieldscore*=1.8 if attacker.hasType?(:GRASS) || attacker.hasType?(:ICE) || attacker.hasType?(:BUG) || attacker.hasType?(:STEEL)
				end
				fieldscore*=0.2 if pbPartyHasType?(:FIRE)
				fieldscore*=1.5 if pbPartyHasType?(:GRASS) || pbPartyHasType?(:ICE) || pbPartyHasType?(:BUG) || pbPartyHasType?(:STEEL)
			when :SWAMP # Swamp field
				fieldscore*=0.7 if attacker.pbHasMove?(:SLEEPPOWDER)
				fieldscore*=1.3 if checkAImoves([:SLEEPPOWDER],aimem)
			when :RAINBOW # Rainbow field
				fieldscore*=1.5 if opponent.hasType?(:NORMAL) || opponent.pbPartner.hasType?(:NORMAL)
				fieldscore*=0.5 if attacker.hasType?(:NORMAL)
				fieldscore*=0.5 if pbPartyHasType?(:NORMAL)
				#fieldscore*=1.4 if opponent.ability== :CLOUDNINE # LAWDS - removing this for now as the interaction was heavily nerfed
				#fieldscore*=0.6 if attacker.ability== :CLOUDNINE
				fieldscore*=0.8 if attacker.pbHasMove?(:SONICBOOM)
				fieldscore*=1.2 if checkAImoves([:SONICBOOM],aimem)
			when :CORROSIVE # Corrosive field
				fieldscore*=1.3 if opponent.hasType?(:POISON) || opponent.pbPartner.hasType?(:POISON)
				fieldscore*=0.7 if attacker.hasType?(:POISON)
				fieldscore*=0.7 if pbPartyHasType?(:POISON)
				fieldscore*=1.5 if opponent.ability== :CORROSION
				fieldscore*=0.5 if attacker.ability== :CORROSION
				fieldscore*=0.7 if attacker.pbHasMove?(:SLEEPPOWDER)
				fieldscore*=1.3 if checkAImoves([:SLEEPPOWDER],aimem)
			when :CORROSIVEMIST # Corromist field
				fieldscore*=1.3 if opponent.hasType?(:POISON) || opponent.pbPartner.hasType?(:POISON)
				if attacker.hasType?(:POISON)
					fieldscore*=0.7
				elsif !attacker.hasType?(:STEEL)
					fieldscore*=1.4
				end
				fieldscore*=1.4 if !pbPartyHasType?(:POISON)
				fieldscore*=1.5 if opponent.ability== :CORROSION
				fieldscore*=0.5 if attacker.ability== :CORROSION
				fieldscore*=1.5 if opponent.hasType?(:FIRE) || opponent.pbPartner.hasType?(:FIRE)
				fieldscore*=0.8  if attacker.hasType?(:FIRE)
				fieldscore*=0.8  if pbPartyHasType?(:FIRE)
			when :DESERT # Desert field
				fieldscore*=1.3 if attacker.spatk > attacker.attack && (opponent.hasType?(:GROUND) || opponent.pbPartner.hasType?(:GROUND))
				fieldscore*=0.7 if opponent.spatk > opponent.attack && (attacker.hasType?(:GROUND))
				fieldscore*=1.5 if attacker.hasType?(:ELECTRIC) || attacker.hasType?(:WATER)
				fieldscore*=0.5 if opponent.hasType?(:ELECTRIC) || opponent.pbPartner.hasType?(:WATER)
				fieldscore*=0.7 if pbPartyHasType?(:GROUND)
				fieldscore*=1.5 if pbPartyHasType?(:WATER) || pbPartyHasType?(:ELECTRIC)
				fieldscore*=1.3 if (opponent.ability== :SANDRUSH || opponent.ability== :DUSTDEVIL) && @battle.pbWeather!=:SANDSTORM
				fieldscore*=0.7 if (attacker.ability== :SANDRUSH || attacker.ability== :DUSTDEVIL) && @battle.pbWeather!=:SANDSTORM
			when :ICY # Icy field
				fieldscore*=1.3 if opponent.hasType?(:ICE) || opponent.pbPartner.hasType?(:ICE)
				fieldscore*=0.5 if attacker.hasType?(:ICE)
				fieldscore*=0.5 if pbPartyHasType?(:ICE)
				fieldscore*=0.5 if opponent.hasType?(:FIRE) || opponent.pbPartner.hasType?(:FIRE)
				fieldscore*=1.1 if attacker.hasType?(:FIRE)
				fieldscore*=1.1 if pbPartyHasType?(:FIRE)
				fieldscore*=1.3 if (opponent.ability== :SLUSHRUSH || opponent.crested == :EMPOLEON || (opponent.crested == :CASTFORM && opponent.form == 3)) && @battle.pbWeather!=:HAIL
				fieldscore*=0.7 if (attacker.ability== :SLUSHRUSH || attacker.crested == :EMPOLEON || (attacker.crested == :CASTFORM && attacker.form == 3)) && @battle.pbWeather!=:HAIL
			when :ROCKY # Rocky field
				fieldscore*=1.5 if opponent.hasType?(:ROCK) || opponent.pbPartner.hasType?(:ROCK)
				fieldscore*=0.5 if attacker.hasType?(:ROCK)
				fieldscore*=0.5 if pbPartyHasType?(:ROCK)
			when :FOREST # Forest field
				fieldscore*=1.5 if opponent.hasType?(:GRASS) || opponent.hasType?(:BUG) || opponent.pbPartner.hasType?(:GRASS) || opponent.pbPartner.hasType?(:BUG)
				fieldscore*=0.5 if attacker.hasType?(:GRASS) || attacker.hasType?(:BUG)
				fieldscore*=0.5 if pbPartyHasType?(:GRASS) || pbPartyHasType?(:BUG)
				fieldscore*=1.8 if opponent.hasType?(:FIRE) || opponent.pbPartner.hasType?(:FIRE)
				fieldscore*=0.2 if attacker.hasType?(:FIRE)
				fieldscore*=0.2 if pbPartyHasType?(:FIRE)
			when :SUPERHEATED # Superheated field
				fieldscore*=1.8 if opponent.hasType?(:FIRE) || opponent.pbPartner.hasType?(:FIRE)
				fieldscore*=0.2 if attacker.hasType?(:FIRE)
				fieldscore*=0.2 if pbPartyHasType?(:FIRE)
				fieldscore*=0.7 if opponent.hasType?(:ICE) || opponent.pbPartner.hasType?(:ICE)
				fieldscore*=1.5 if attacker.hasType?(:ICE)
				fieldscore*=1.5 if pbPartyHasType?(:ICE)
				fieldscore*=0.8 if opponent.hasType?(:WATER) || opponent.pbPartner.hasType?(:WATER)
				fieldscore*=1.2 if attacker.hasType?(:WATER)
				fieldscore*=1.2 if pbPartyHasType?(:WATER)
			when :FACTORY # Factory field
				fieldscore*=1.2 if opponent.hasType?(:ELECTRIC) || opponent.pbPartner.hasType?(:ELECTRIC)
				fieldscore*=0.8 if attacker.hasType?(:ELECTRIC)
				fieldscore*=0.8 if pbPartyHasType?(:ELECTRIC)
			when :SHORTCIRCUIT # Short-Circuit field
				fieldscore*=1.4 if opponent.hasType?(:ELECTRIC) || opponent.pbPartner.hasType?(:ELECTRIC)
				fieldscore*=0.6 if attacker.hasType?(:ELECTRIC)
				fieldscore*=0.6 if pbPartyHasType?(:ELECTRIC)
				fieldscore*=1.3 if opponent.ability== :SURGESURFER
				fieldscore*=0.7 if attacker.ability== :SURGESURFER
				fieldscore*=1.3 if opponent.hasType?(:DARK) || opponent.pbPartner.hasType?(:DARK) || opponent.hasType?(:GHOST) || opponent.pbPartner.hasType?(:GHOST)
				fieldscore*=0.7 if attacker.hasType?(:DARK) || attacker.hasType?(:GHOST)
				fieldscore*=0.7 if pbPartyHasType?(:DARK) || pbPartyHasType?(:GHOST)
			when :WASTELAND # Wasteland field
				fieldscore*=1.3 if opponent.hasType?(:POISON) || opponent.pbPartner.hasType?(:POISON)
				fieldscore*=0.7 if attacker.hasType?(:POISON)
				fieldscore*=0.7 if pbPartyHasType?(:POISON)
			when :ASHENBEACH # Ashen Beach field
				fieldscore*=1.3 if opponent.hasType?(:FIGHTING) || opponent.pbPartner.hasType?(:FIGHTING) || opponent.hasType?(:PSYCHIC) || opponent.pbPartner.hasType?(:PSYCHIC)
				fieldscore*=0.7 if attacker.hasType?(:FIGHTING) || attacker.hasType?(:PSYCHIC)
				fieldscore*=0.7 if pbPartyHasType?(:FIGHTING) || pbPartyHasType?(:PSYCHIC)
				fieldscore*=1.3 if (opponent.ability== :SANDRUSH || opponent.ability== :DUSTDEVIL) && @battle.pbWeather!=:SANDSTORM
				fieldscore*=0.7 if (attacker.ability== :SANDRUSH || attacker.ability== :DUSTDEVIL) && @battle.pbWeather!=:SANDSTORM
			when :WATERSURFACE # Water Surface field
				fieldscore*=1.6 if opponent.hasType?(:WATER) || opponent.pbPartner.hasType?(:WATER)
				if attacker.hasType?(:WATER)
					fieldscore*=0.4
				elsif !attacker.isAirborne?
					fieldscore*=1.3
				end
				fieldscore*=0.4 if pbPartyHasType?(:WATER)
				fieldscore*=1.3 if opponent.ability== :SWIFTSWIM && @battle.pbWeather!=:RAINDANCE
				fieldscore*=0.7 if attacker.ability== :SWIFTSWIM && @battle.pbWeather!=:RAINDANCE
				fieldscore*=1.3 if opponent.ability== :SURGESURFER
				fieldscore*=0.7 if attacker.ability== :SURGESURFER
				fieldscore*=1.3 if !attacker.hasType?(:POISON) && @battle.field.counter==1
			when :UNDERWATER # Underwater field
				fieldscore*=2.0 if opponent.hasType?(:WATER) || opponent.pbPartner.hasType?(:WATER)
				if attacker.hasType?(:WATER)
					fieldscore*=0.1
				else
					fieldscore*=1.5
					fieldscore*=2 if attacker.hasType?(:ROCK) || attacker.hasType?(:GROUND)
				end
				fieldscore*=1.2 if attacker.attack > attacker.spatk
				fieldscore*=0.8 if opponent.attack > opponent.spatk
				fieldscore*=0.1 if pbPartyHasType?(:WATER)
				fieldscore*=0.9 if opponent.ability== :SWIFTSWIM
				fieldscore*=1.1 if attacker.ability== :SWIFTSWIM
				fieldscore*=1.1 if opponent.ability== :SURGESURFER
				fieldscore*=0.9 if attacker.ability== :SURGESURFER
				fieldscore*=1.3 if !attacker.hasType?(:POISON) && @battle.field.counter==1
			when :CAVE # Cave field
				fieldscore*=1.5 if opponent.hasType?(:ROCK) || opponent.pbPartner.hasType?(:ROCK)
				fieldscore*=0.5 if attacker.hasType?(:ROCK)
				fieldscore*=0.5 if pbPartyHasType?(:ROCK)
				fieldscore*=1.2 if opponent.hasType?(:GROUND) || opponent.pbPartner.hasType?(:GROUND)
				fieldscore*=0.8 if attacker.hasType?(:GROUND)
				fieldscore*=0.8 if pbPartyHasType?(:GROUND)
				fieldscore*=0.7 if opponent.hasType?(:FLYING) || opponent.pbPartner.hasType?(:FLYING)
				fieldscore*=1.3 if attacker.hasType?(:FLYING)
				fieldscore*=1.3 if pbPartyHasType?(:FLYING)
			when :GLITCH # Glitch field
				fieldscore*=1.3 if attacker.hasType?(:DARK) || attacker.hasType?(:STEEL) || attacker.hasType?(:FAIRY)
				fieldscore*=1.3 if pbPartyHasType?(:DARK) || pbPartyHasType?(:STEEL) || pbPartyHasType?(:FAIRY)
				ratio1 = attacker.spatk/attacker.spdef.to_f
				ratio2 = attacker.spdef/attacker.spatk.to_f
				if ratio1 < 1
					fieldscore*=ratio1
				elsif ratio2 < 1
					fieldscore*=ratio2
				end
				oratio1 = opponent.spatk/attacker.spdef.to_f
				oratio2 = opponent.spdef/attacker.spatk.to_f
				if oratio1 > 1
					fieldscore*=oratio1
				elsif oratio2 > 1
					fieldscore*=oratio2
				end
			when :CRYSTALCAVERN # Crystal Cavern field
				fieldscore*=1.5 if opponent.hasType?(:ROCK) || opponent.pbPartner.hasType?(:ROCK) || opponent.hasType?(:DRAGON) || opponent.pbPartner.hasType?(:DRAGON)
				fieldscore*=0.5 if attacker.hasType?(:ROCK) || attacker.hasType?(:DRAGON)
				fieldscore*=0.5 if pbPartyHasType?(:ROCK) || pbPartyHasType?(:DRAGON)
			when :MURKWATERSURFACE # Murkwater Surface field
				fieldscore*=1.6 if opponent.hasType?(:WATER) || opponent.pbPartner.hasType?(:WATER)
				if attacker.hasType?(:WATER)
					fieldscore*=0.4 
				elsif !attacker.isAirborne?
					fieldscore*=1.3
				end
				fieldscore*=0.4 if pbPartyHasType?(:WATER)
				fieldscore*=1.3 if opponent.ability== :SWIFTSWIM && @battle.pbWeather!=:RAINDANCE
				fieldscore*=0.7 if attacker.ability== :SWIFTSWIM && @battle.pbWeather!=:RAINDANCE
				fieldscore*=1.3 if opponent.ability== :SURGESURFER
				fieldscore*=0.7 if attacker.ability== :SURGESURFER
				fieldscore*=1.3 if opponent.hasType?(:STEEL) || opponent.pbPartner.hasType?(:STEEL) || opponent.hasType?(:POISON) || opponent.pbPartner.hasType?(:POISON)
				if attacker.hasType?(:POISON)
					fieldscore*=0.7
				elsif !attacker.hasType?(:STEEL)
					fieldscore*=1.8
				end
				fieldscore*=0.7 if pbPartyHasType?(:POISON)
			when :MOUNTAIN # Mountain field
				fieldscore*=1.5 if opponent.hasType?(:ROCK) || opponent.pbPartner.hasType?(:ROCK) || opponent.hasType?(:FLYING) || opponent.pbPartner.hasType?(:FLYING)
				fieldscore*=0.5 if attacker.hasType?(:ROCK) || attacker.hasType?(:FLYING)
				fieldscore*=0.5 if pbPartyHasType?(:ROCK) || pbPartyHasType?(:FLYING)
			when :SNOWYMOUNTAIN # Snowy Mountain field
				fieldscore*=1.5 if opponent.hasType?(:ROCK) || opponent.pbPartner.hasType?(:ROCK) || opponent.hasType?(:FLYING) || opponent.pbPartner.hasType?(:FLYING) || opponent.hasType?(:ICE) || opponent.pbPartner.hasType?(:ICE)
				fieldscore*=0.5 if attacker.hasType?(:ROCK) || attacker.hasType?(:FLYING) || attacker.hasType?(:ICE)
				fieldscore*=0.5 if pbPartyHasType?(:ROCK) || pbPartyHasType?(:FLYING) || pbPartyHasType?(:ICE)
				fieldscore*=0.5 if opponent.hasType?(:FIRE) || opponent.pbPartner.hasType?(:FIRE)
				fieldscore*=1.5 if attacker.hasType?(:FIRE)
				fieldscore*=1.5 if pbPartyHasType?(:FIRE)
				fieldscore*=1.3 if (opponent.ability== :SLUSHRUSH || opponent.crested == :EMPOLEON || (opponent.crested == :CASTFORM && opponent.form == 3)) && @battle.pbWeather!=:HAIL
				fieldscore*=0.7 if (attacker.ability== :SLUSHRUSH || attacker.crested == :EMPOLEON || (attacker.crested == :CASTFORM && attacker.form == 3)) && @battle.pbWeather!=:HAIL
			when :HOLY # Holy field
				fieldscore*=1.4 if opponent.hasType?(:NORMAL) || opponent.pbPartner.hasType?(:NORMAL) || opponent.hasType?(:FAIRY) || opponent.pbPartner.hasType?(:FAIRY)
				fieldscore*=0.6 if attacker.hasType?(:NORMAL) || attacker.hasType?(:FAIRY)
				fieldscore*=0.6 if pbPartyHasType?(:NORMAL) || pbPartyHasType?(:FAIRY)
				fieldscore*=0.5 if opponent.hasType?(:DARK) || opponent.pbPartner.hasType?(:DARK) || opponent.hasType?(:GHOST) || opponent.pbPartner.hasType?(:GHOST)
				fieldscore*=1.5 if attacker.hasType?(:DARK) || attacker.hasType?(:GHOST)
				fieldscore*=1.5 if pbPartyHasType?(:DARK) || pbPartyHasType?(:GHOST)
				fieldscore*=1.2 if opponent.hasType?(:DRAGON) || opponent.pbPartner.hasType?(:DRAGON) || opponent.hasType?(:PSYCHIC) || opponent.pbPartner.hasType?(:PSYCHIC)
				fieldscore*=0.8 if attacker.hasType?(:DRAGON) || attacker.hasType?(:PSYCHIC)
				fieldscore*=0.8 if pbPartyHasType?(:DRAGON) || pbPartyHasType?(:PSYCHIC)
			when :MIRROR # Mirror field
				fieldscore*=1+0.1*opponent.stages[PBStats::ACCURACY]
				fieldscore*=1+0.1*opponent.stages[PBStats::EVASION]
				fieldscore*=1-0.1*attacker.stages[PBStats::ACCURACY]
				fieldscore*=1-0.1*attacker.stages[PBStats::EVASION]
			when :FAIRYTALE # Fairytale field
				fieldscore*=1.5 if opponent.hasType?(:DRAGON) || opponent.pbPartner.hasType?(:DRAGON) || opponent.hasType?(:STEEL) || opponent.pbPartner.hasType?(:STEEL) || opponent.hasType?(:FAIRY) || opponent.pbPartner.hasType?(:FAIRY)
				fieldscore*=0.5 if attacker.hasType?(:DRAGON) || attacker.hasType?(:STEEL) || attacker.hasType?(:FAIRY)
				fieldscore*=0.5 if pbPartyHasType?(:DRAGON) || pbPartyHasType?(:STEEL) || pbPartyHasType?(:FAIRY)
				fieldscore*=1.3 if opponent.ability== :STANCECHANGE
				fieldscore*=0.7 if attacker.ability== :STANCECHANGE
			when :DRAGONSDEN # Dragon's Den field
				fieldscore*=1.7 if opponent.hasType?(:DRAGON) || opponent.pbPartner.hasType?(:DRAGON)
				fieldscore*=0.3 if attacker.hasType?(:DRAGON)
				fieldscore*=0.3 if pbPartyHasType?(:DRAGON)
				fieldscore*=1.5 if opponent.hasType?(:FIRE) || opponent.pbPartner.hasType?(:FIRE)
				fieldscore*=0.5 if attacker.hasType?(:FIRE)
				fieldscore*=0.5 if pbPartyHasType?(:FIRE)
				fieldscore*=1.3 if opponent.ability== :MULTISCALE
				fieldscore*=0.7 if attacker.ability== :MULTISCALE
			when :FLOWERGARDEN4 # Flower Garden field
				fieldscore*=1.5  if opponent.hasType?(:BUG) || opponent.pbPartner.hasType?(:BUG) || opponent.hasType?(:GRASS) || opponent.pbPartner.hasType?(:GRASS)
				fieldscore*=0.33 if attacker.hasType?(:GRASS) || attacker.hasType?(:BUG)
				fieldscore*=0.33 if pbPartyHasType?(:BUG) || pbPartyHasType?(:GRASS)
				fieldscore*=1.2  if opponent.hasType?(:FIRE) || opponent.pbPartner.hasType?(:FIRE)
				fieldscore*=0.33 if attacker.hasType?(:FIRE)
				fieldscore*=0.33 if pbPartyHasType?(:FIRE)
			when :FLOWERGARDEN5 # Flower Garden field
				fieldscore*=2.0  if opponent.hasType?(:BUG) || opponent.pbPartner.hasType?(:BUG) || opponent.hasType?(:GRASS) || opponent.pbPartner.hasType?(:GRASS)
				fieldscore*=0.25 if attacker.hasType?(:GRASS) || attacker.hasType?(:BUG)
				fieldscore*=0.25 if pbPartyHasType?(:BUG) || pbPartyHasType?(:GRASS)
				fieldscore*=1.6  if opponent.hasType?(:FIRE) || opponent.pbPartner.hasType?(:FIRE)
				fieldscore*=0.25 if attacker.hasType?(:FIRE)
				fieldscore*=0.25 if pbPartyHasType?(:FIRE)
			when :STARLIGHT # Starlight Arena field
				fieldscore*=1.5 if opponent.hasType?(:PSYCHIC) || opponent.pbPartner.hasType?(:PSYCHIC)
				fieldscore*=0.5 if attacker.hasType?(:PSYCHIC)
				fieldscore*=0.5 if pbPartyHasType?(:PSYCHIC)
				fieldscore*=1.3 if opponent.hasType?(:FAIRY) || opponent.pbPartner.hasType?(:FAIRY) || opponent.hasType?(:DARK) || opponent.pbPartner.hasType?(:DARK)
				fieldscore*=0.7 if attacker.hasType?(:FAIRY) || attacker.hasType?(:DARK)
				fieldscore*=0.7 if pbPartyHasType?(:FAIRY) || pbPartyHasType?(:DARK)
			when :NEWWORLD # New World field
				#fieldscore = 0
			when :INVERSE # Inverse field
				fieldscore*=1.7 if opponent.hasType?(:NORMAL) || opponent.pbPartner.hasType?(:NORMAL)
				fieldscore*=0.3 if attacker.hasType?(:NORMAL)
				fieldscore*=0.3 if pbPartyHasType?(:NORMAL)
				fieldscore*=1.5 if opponent.hasType?(:ICE) || opponent.pbPartner.hasType?(:ICE)
				fieldscore*=0.5 if attacker.hasType?(:ICE)
				fieldscore*=0.5 if pbPartyHasType?(:ICE)
			when :PSYTERRAIN # Psychic Terrain
				fieldscore*=1.7 if opponent.hasType?(:PSYCHIC) || opponent.pbPartner.hasType?(:PSYCHIC)
				fieldscore*=0.3 if attacker.hasType?(:PSYCHIC)
				fieldscore*=0.3 if pbPartyHasType?(:PSYCHIC)
				fieldscore*=1.3 if opponent.ability== :TELEPATHY
				fieldscore*=0.7 if attacker.ability== :TELEPATHY
		end
		fieldscore*=0.01
		return fieldscore
	end

################################################################################
# Item score functions
################################################################################

	def getItemScore
		#check if we have items
		return # LAWDS - never use an item no matter what
		@mondata.itemscore = {}

		return if !@battle.internalbattle
		return if @attacker.effects[:Embargo]>0
		items = @battle.pbGetOwnerItems(@index)
		return if !items || items.empty?
		party = @battle.pbPartySingleOwner(@attacker.index)
		opponent1 = @attacker.pbOppositeOpposing
		return if @attacker.isFainted?
		movecount = -1
		maxplaypri = -1
		partynumber = 0
		aimem = getAIMemory(opponent1)
		for i in party
			next if i.nil?
			next if i.hp == 0
			partynumber+=1
		end
		#highest score
		for i in 0...@attacker.moves.length
			next if @attacker.moves[i].nil?
			if @mondata.roughdamagearray.transpose[i].max >= 100 && @attacker.moves[i] && @attacker.moves[i].priority>maxplaypri
				maxplaypri = @attacker.moves[i].priority
			end
		end
		highscore = @mondata.roughdamagearray.max {|a,b| a.max <=> b.max}.max
		highdamage = -1
		maxopppri = -1
		pridam = -1
		bestid = -1
		#expected damage
		for i in aimem
			tempdam = pbRoughDamage(i,opponent1,@attacker)
			if tempdam>highdamage
				highdamage = tempdam
				bestid = i.move
			end
			if i.priority > maxopppri
				maxopppri = i.priority
				pridam = tempdam
			end
		end
		highdamage = checkAIdamage()
		highratio = -1
		#expected damage percentage
		highratio = highdamage*(1.0/@attacker.hp) if @attacker.hp!=0
		PBDebug.log(sprintf("Beginning AI Item use check.\n")) if $INTERNAL
		for i in items
			next @mondata.itemscore[i] = -100000 if $cache.items[i].checkFlag?(:noUseInBattle)
			next @mondata.itemscore[i] = -8000 if $game_switches[:Stop_Items_Password] || $game_switches[:No_Items_Password] 
			next if @mondata.itemscore.key?(i)
			itemscore=100
			if PBStuff::HPITEMS.include?(i)
				PBDebug.log(sprintf("This is a HP-healing item.")) if $INTERNAL
				restoreamount=0
				case i
					when  :POTION 		then restoreamount=20
					when  :ULTRAPOTION 	then restoreamount=200
					when  :SUPERPOTION 	then restoreamount=60
					when  :HYPERPOTION 	then restoreamount=120
					when  :MAXPOTION, :FULLRESTORE then restoreamount=@attacker.totalhp
					when  :FRESHWATER 	then restoreamount=30
					when  :SODAPOP 		then restoreamount=50
					when  :LEMONADE 	then restoreamount=70
					when  :MOOMOOMILK 	then restoreamount=100
					when  :BUBBLETEA 	then restoreamount=180
					when  :MEMEONADE 	then restoreamount=103
					when  :STRAWBIC 	then restoreamount=90
					when  :CHOCOLATEIC 	then restoreamount=70
					when  :BLUEMIC 		then restoreamount=200
				end
				resratio=restoreamount*(1.0/@attacker.totalhp)
				itemscore*= (2 - (2.0*@attacker.hp/@attacker.totalhp))
				if highdamage > (@attacker.totalhp - @attacker.hp) # if we take more damage from full than we currently have, don't bother
					itemscore*= 0  
				elsif ([@attacker.hp+restoreamount,@attacker.totalhp].min - highdamage) < ((@attacker.totalhp / 4.0) + attacker.hp) # and if we're not gaining at least 25% hp, don't bother
					itemscore*= 0.3
				end
				if highdamage>=@attacker.hp
					if highdamage > [@attacker.hp+restoreamount,@attacker.totalhp].min
						itemscore*=0
					else
						itemscore*=1.2
					end
					if @attacker.moves.any? {|moveloop| !moveloop.zmove && moveloop.isHealingMove? && moveloop.move != :WISH}
						if !pbAIfaster?(nil,nil,@attacker, opponent1)
							if highdamage>=@attacker.hp
								itemscore*=1.1
							else
								itemscore*=0.6
								itemscore*=0.2 if resratio<0.55
							end
						end
					end
				else
					itemscore*=0.4
				end
				if highdamage > restoreamount
					itemscore*=0
				elsif restoreamount-highdamage < 15
					itemscore*=0.5
				end
				if pbAIfaster?(nil,nil,@attacker, opponent1)
					itemscore*=0.8
					if highscore >=110
						if maxopppri > maxplaypri
							itemscore*=1.3
							if pridam>@attacker.hp
								itemscore*= pridam>(@attacker.hp/2.0) ? 0 : 2
							end
						elsif !notOHKO?(@attacker, opponent1, true) && hpGainPerTurn >= 1
							itemscore*=0
						end
					end
					itemscore*=1.1 if @mondata.roles.include?(:SWEEPER)
				else
					if highdamage*2 > [@attacker.hp+restoreamount,@attacker.totalhp].min
						itemscore*=0
					else
						itemscore*=1.5
						itemscore*=1.5 if highscore >=110
					end
				end
				if @attacker.hp == @attacker.totalhp
					itemscore*=0
				elsif @attacker.hp >= (@attacker.totalhp*0.8)
					itemscore*=0.2
				elsif @attacker.hp >= (@attacker.totalhp*0.6)
					itemscore*=0.3
				elsif @attacker.hp >= (@attacker.totalhp*0.5)
					itemscore*=0.5
				end
				minipot = (partynumber-1)
				minimini = -1
				for j in items
					next if !PBStuff::HPITEMS.include?(j)
					minimini+=1
				end
				if minipot>minimini
					itemscore*=(0.9**(minipot-minimini))
					minipot=minimini
				elsif minimini>minipot
					itemscore*=(1.1**(minimini-minipot))
					minimini=minipot
				end
				itemscore*=0.6 if @mondata.roles.include?(:LEAD) || @mondata.roles.include?(:SCREENER)
				itemscore*=1.1 if @mondata.roles.include?(:TANK)
				itemscore*=1.1 if @mondata.roles.include?(:SECOND)
				itemscore*=0.9 if hpGainPerTurn>1
				itemscore*=1.3 if hpGainPerTurn<1
				if !@attacker.status.nil? && i != :FULLRESTORE
					itemscore*=0.7
					itemscore*=0.2 if @attacker.effects[:Toxic]>0 && partynumber>1
				end
				eff1 = PBTypes.twoTypeEff(opponent1.type1,@attacker.type1,@attacker.type2)
				itemscore*=0.7 if eff1>4
				itemscore*=1.1 if eff1<4
				itemscore*=1.2 if eff1==0
				eff2 = PBTypes.twoTypeEff(opponent1.type2,@attacker.type1,@attacker.type2)
				itemscore*=0.7 if eff2>4
				itemscore*=1.1 if eff2<4
				itemscore*=1.2 if eff2==0
				itemscore*=0.7 if @attacker.ability== :REGENERATOR && partynumber>1
			end
			if PBStuff::STATUSITEMS.include?(i)
				PBDebug.log(sprintf("This is a status-curing item.")) if $INTERNAL
				if !(i== :FULLRESTORE)
					itemscore*=2 if highdamage < @attacker.hp / 2
					itemscore*=0 if @attacker.status.nil?
					if highdamage>@attacker.hp
						if (bestid==:WAKEUPSLAP && @attacker.status== :SLEEP) || (bestid==:SMELLINGSALTS && @attacker.status== :PARALYSIS) || bestid==:HEX
							itemscore*= highdamage*0.5 > @attacker.hp ? 0 : 1.4
						else
							itemscore*=0
						end
					end
					if @attacker.status== :SLEEP
						itemscore*=0.6 if @attacker.pbHasMove?(:SLEEPTALK) || @attacker.pbHasMove?(:SNORE) || @attacker.pbHasMove?(:REST) || @attacker.ability== :COMATOSE
						itemscore*=1.3 if checkAImoves([:DREAMEATER,:NIGHTMARE],aimem) || opponent1.ability== :BADDREAMS
						itemscore*= highdamage > 0.2 * @attacker.hp ? 1.3 : 0.7
					end
					if @attacker.status== :PARALYSIS
						itemscore*=0.5 if @attacker.ability== :QUICKFEET || @attacker.ability== :GUTS
						itemscore*=1.3 if @attacker.pbSpeed>opponent1.pbSpeed && (@attacker.pbSpeed*0.5)<opponent1.pbSpeed
						itemscore*=1.1
					end
					if @attacker.status== :BURN
						itemscore*=1.1
						itemscore*= @attacker.attack>@attacker.spatk ? 1.2 : 0.8
						itemscore*=0.6 if @attacker.ability== :GUTS || @attacker.ability== :QUICKFEET
						itemscore*=0.7 if @attacker.ability== :MAGICGUARD
						itemscore*=0.7 if @attacker.ability== :WONDERGUARD && @battle.FE == :COLOSSEUM
						itemscore*=0.8 if @attacker.ability== :FLAREBOOST
					end
					if @attacker.status== :POISON
						itemscore*=1.1
						itemscore*=0.5 if @attacker.ability== :GUTS
						itemscore*=0.5 if @attacker.ability== :MAGICGUARD
						itemscore*=0.5 if @attacker.ability== :WONDERGUARD && @battle.FE == :COLOSSEUM
						itemscore*=0.5 if @attacker.ability== :TOXICBOOST
						itemscore*=0.2 if @attacker.ability== :POISONHEAL || @attacker.crested == :ZANGOOSE
						itemscore*=1.1 if @attacker.effects[:Toxic]>0
						itemscore*=1.5 if @attacker.effects[:Toxic]>3
					end
					if @attacker.status== :FROZEN
						itemscore*=1.3
						itemscore*=0.5 if @attacker.moves.any? {|moveloop| moveloop!=nil && moveloop.canThawUser?}
						itemscore*=  highdamage > 0.15 * @attacker.hp ? 1.1 : 0.9
					end
				end
				itemscore*=0.5 if @attacker.pbHasMove?(:REFRESH) || @attacker.pbHasMove?(:REST) || @attacker.pbHasMove?(:PURIFY)
				itemscore*=0.2 if @attacker.ability== :NATURALCURE && partynumber>1
				itemscore*=0.3 if @attacker.ability== :SHEDSKIN
				
			end
			# General "Is it a good idea to use an item at all right now" checks
			if partynumber==1 || @mondata.roles.include?(:ACE)
				itemscore*=1.2
			else
				itemscore*=0.8
				itemscore*=0.6 if @attacker.itemUsed2
			end
			itemscore*=2 if @attacker.effects[:Toxic]>3 && i == :FULLRESTORE
			itemscore*=0.9 if @attacker.effects[:Confusion]>0
			itemscore*=0.6 if @attacker.effects[:Attract]>=0
			itemscore*=1.1 if @attacker.effects[:Substitute]>0
			itemscore*=0.5 if @attacker.effects[:LeechSeed]>=0
			itemscore*=0.5 if @attacker.effects[:Curse]
			itemscore*=0.2 if @attacker.effects[:PerishSong]>0
			minipot=0
			for s in [PBStats::ATTACK,PBStats::DEFENSE,PBStats::SPEED, PBStats::SPATK,PBStats::SPDEF,PBStats::ACCURACY,PBStats::EVASION]
				minipot+=@attacker.stages[s]
			end
			if @mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL)
				for s in [PBStats::DEFENSE,PBStats::SPDEF]
					minipot+=@attacker.stages[s]
				end
			end
			if @mondata.roles.include?(:SWEEPER)
				minipot+=@attacker.stages[PBStats::SPEED]
				minipot+= @attacker.attack>@attacker.spatk ? @attacker.stages[PBStats::ATTACK] : @attacker.stages[PBStats::SPATK]
			end
			
			
			itemscore*=0.05*minipot + 1
			itemscore*=1.2 if opponent1.effects[:TwoTurnAttack]!=0 || opponent1.effects[:HyperBeam]>0
			itemscore*= highscore>70 ? 1.1 : 0.9

			fielddisrupt = getFieldDisruptScore(@attacker,opponent1)
			fielddisrupt=0.6 if fielddisrupt <= 0
			itemscore*= (1.0/fielddisrupt)

			itemscore*=0.9 if @battle.trickroom > 0
			itemscore*=0.6 if @attacker.pbOwnSide.effects[:Tailwind]>0
			itemscore*=0.9 if @attacker.pbOwnSide.effects[:Reflect]>0
			itemscore*=0.9 if @attacker.pbOwnSide.effects[:LightScreen]>0
			itemscore*=0.8 if @attacker.pbOwnSide.effects[:AuroraVeil]>0
			itemscore*=0.8 if @battle.doublebattle
			itemscore*=0.3 if @attacker.effects[:Rollout] > 0
			itemscore-=100
			PBDebug.log(sprintf("Score for %s: %d",getItemName(i),itemscore)) if $INTERNAL && !i.nil?
			$ai_log_data[@attacker.index].items.push(getItemName(i))
			$ai_log_data[@attacker.index].items_scores.push(itemscore)
			@mondata.itemscore[i] = itemscore
		end
		#somehow register that this would be the item that should be used
		PBDebug.log(sprintf("Highest item score: %d",(@mondata.itemscore.values.max))) if $INTERNAL
		#score the item if we have it
	end


################################################################################
# Switching functions
################################################################################
	#function for getting the new switch-in when sending new mon out cuz fainted # LAWDS or due to hit-and-run
	def pbDefaultChooseNewEnemy(index,party)
		#index is index of battler
		@mondata = @aimondata[index]
		@attacker = @battle.battlers[index]
		@index = index
		@opponent = firstOpponent()
		switchscores = getSwitchInScoresParty(false)
		@aimondata[index].switchscore = switchscores
		return switchscores.index(switchscores.max)
	end

	def getSwitchingScore
		#Set up some basic checks to prompt the remainder of the switch code
		#upon passing said checks:
		@mondata.shouldswitchscore = shouldSwitch?()
		$ai_log_data[@attacker.index].should_switch_score = @mondata.shouldswitchscore
		PBDebug.log(sprintf("ShouldSwitchScore: %d \n",@mondata.shouldswitchscore)) if $INTERNAL
		# LAWDS get party scores here in singles so we can check if the mon should use a priority move and die instead of switch
		if (@mondata.shouldswitchscore > 0) && (!@battle.doublebattle || (@attacker.ability==:ZEROTOHERO && @attacker.form==0))
			@mondata.switchscore = getSwitchInScoresParty(true)
		end
	end

	def getSwitchInScoresParty(hard_switch)
		# lawds skip switch-in scoring if we already calced the party switch-in scores. if sameopps then we can use the same calcs as both player mons were present during the sending of the first mon, so no new calcs need to be done
		skip_known_calcs = @battle.doublebattle && (hard_switch || @sameopps==[@battle.battlers[0],@battle.battlers[2]]) && @battle.pbIsOpposing?(@attacker.index) && @aimondata[@attacker.pbPartner.index].switchscore.length > 0
		@sameopps = [@battle.battlers[0],@battle.battlers[2]]
		party = @battle.pbParty(@attacker.index)

		partyScores = []
		aimem = getAIMemory(@opponent)
		aimem2 = @opponent.pbPartner.hp > 0 ? getAIMemory(@opponent.pbPartner) : []

		# For checks at end for all pokemon
		survivors = Array.new(party.length, false)
		partycheck = []
		for partyindex in 0...party.length
			@gonnaTerrains = []
			@gonnaWeather = 0
			monscore = 0
			i = pbMakeFakeBattler(party[partyindex],partyindex) rescue nil
			nonmegaform = pbMakeFakeBattler(party[partyindex],partyindex) rescue nil
			if i.nil?
				partyScores.push(-10000000)
				PBDebug.log(sprintf("Score: -10000000\n")) if $INTERNAL
				$ai_log_data[@attacker.index].switch_scores.push(-10000000)
				$ai_log_data[@attacker.index].switch_name.push("")
				next
			end
			PBDebug.log(sprintf("Scoring for %s switching to: %s",getMonName(@attacker.species),getMonName(i.species))) if $INTERNAL
			if hard_switch
				if !@battle.pbCanSwitch?(@attacker.index,partyindex,false)
					partyScores.push(-10000000)
					PBDebug.log(sprintf("Score: -10000000\n")) if $INTERNAL
					$ai_log_data[@attacker.index].switch_scores.push(-10000000)
					$ai_log_data[@attacker.index].switch_name.push(getMonName(i.pokemon.species))
					next
				end
			else #not hard switch ergo dead mon
				if !@battle.pbCanSwitchLax?(@attacker.index,partyindex,false)
					partyScores.push(-10000000)
					PBDebug.log(sprintf("Score: -10000000\n")) if $INTERNAL
					$ai_log_data[@attacker.index].switch_scores.push(-10000000)
					$ai_log_data[@attacker.index].switch_name.push(getMonName(i.pokemon.species))
					next
				end
			end
			if !i.moves.any? {|moveloop| moveloop != nil && moveloop.move != 0 && moveloop.move != :LUNARDANCE}
				partyScores.push(-1000)
				PBDebug.log(sprintf("Lunar mon sacrifice- Score: -1000\n")) if $INTERNAL
				$ai_log_data[@attacker.index].switch_scores.push(-1000)
				$ai_log_data[@attacker.index].switch_name.push(getMonName(i.pokemon.species))
				next
			end
			# Gen 9 Mod - Preserve a pokemon with Last Respects for later.
			if i.pbHasMove?(:LASTRESPECTS) && !(@battle.opponent && !@battle.opponent.is_a?(Array) && @battle.opponent.trainertype==:RIFT_HIPPO && i.pbFaintedPokemonCount > 8)
				partyScores.push(-5000)
				PBDebug.log(sprintf("Last Respects later- Score: -5000\n")) if $INTERNAL
				$ai_log_data[@attacker.index].switch_scores.push(-5000)
				$ai_log_data[@attacker.index].switch_name.push(getMonName(i.pokemon.species))
				next
			end
			if partyindex == party.length-1 && $game_switches[:NameOverwrite]
				partyScores.push(-10000)
				PBDebug.log(sprintf("Ace Switch Prevention- Score: -10000\n")) if $INTERNAL
				$ai_log_data[@attacker.index].switch_scores.push(-10000)
				$ai_log_data[@attacker.index].switch_name.push(getMonName(i.pokemon.species))
				next
			end
			# lawds atlantis
			if i.species==:COALOSSAL && @battle.opponent && !@battle.opponent.is_a?(Array) && @battle.opponent.trainertype == :BEAST && @battle.FE == :WATERSURFACE
				partyScores.push(-1000)
				$ai_log_data[@attacker.index].switch_scores.push(-1000)
				$ai_log_data[@attacker.index].switch_name.push(getMonName(i.pokemon.species))
				next
			end
			if i.crested==:SPIRITOMB 
				partyScores.push(-10000)
				$ai_log_data[@attacker.index].switch_scores.push(-10000)
				$ai_log_data[@attacker.index].switch_name.push(getMonName(i.pokemon.species))
				next
			end
			if skip_known_calcs && @aimondata[@attacker.pbPartner.index].switchscore[partyindex] > -10000000 && 
				# conditions where we need to score that mon differently if the partner is different for supporting reasons
				!i.pbHasMove?(:RAGEPOWDER) && !i.pbHasMove?(:FOLLOWME) && !i.pbHasMove?(:TAILWIND) && !i.pbHasMove?(:AURORAVEIL) && 
				!(i.pbHasMove?(:TRICKROOM) && !@attacker.pbPartner.pbHasMove?(:TRICKROOM)) && ![:ARENATRAP,:MAGNETPULL,:SHADOWTAG].include?(i.ability) &&
				(i.ability!=:COSTAR) && !(i.ability==:STALL && i.pbPartner.hp > 0 && i.pbPartner.ability!=:STALL) && !(i.ability!=:STALL && i.pbPartner.hp > 0 && i.pbPartner.ability==:STALL)
				partyScores.push(@aimondata[@attacker.pbPartner.index].switchscore[partyindex])
				$ai_log_data[@attacker.index].switch_scores.push(@aimondata[@attacker.pbPartner.index].switchscore[partyindex])
				$ai_log_data[@attacker.index].switch_name.push(getMonName(i.pokemon.species))
				next
			end
			# LAWDS MoN hands
			if @battle.opponent && !@battle.opponent.is_a?(Array) && @battle.opponent.trainertype==:MASTEROFNIGHTMARES && i.species==:DARKRAI
			  if i.form==1
				scorepenalty = 0
				for mon in @battle.pbParty(i.index)
					next if mon==nil || mon.hp <= 0 || mon.species!=:DARKRAI || mon==i.pokemon
					scorepenalty-=1000 if mon.species==:DARKRAI && mon.form > 1
				end
				if scorepenalty < 0
					partyScores.push(scorepenalty)
					$ai_log_data[@attacker.index].switch_scores.push(scorepenalty)
					$ai_log_data[@attacker.index].switch_name.push(getMonName(i.pokemon.species))
					next
				end
			  elsif i.form > 0 # dont send out a hand while another hand is out
				if @attacker.pbPartner.species==:DARKRAI
					partyScores.push(-1000)
					$ai_log_data[@attacker.index].switch_scores.push(-1000)
					$ai_log_data[@attacker.index].switch_name.push(getMonName(i.pokemon.species))
					next
				end
			  end
			end
			if @battle.opponent && !@battle.opponent.is_a?(Array) && @battle.opponent.trainertype==:RIFT_HIPPO && i.species==:HIPPOWDON && i.form==1 && (i.pbFaintedPokemonCount < 6 || i.pbPartner.species==:HIPPOWDON)
				partyScores.push(-10000)
				$ai_log_data[@attacker.index].switch_scores.push(-10000)
				$ai_log_data[@attacker.index].switch_name.push(getMonName(i.pokemon.species))
				next
			end
			# LAWDS - see trainer effects
			field_on_switch_in = @battle.FE
			delayed_field_switch = false
			trainer = @battle.pbGetOwner(i.index)
			if !@battle.pbOwnedByPlayer?(i.index)
				if !(trainer.trainereffect.nil? || trainer.trainereffect[:effectmode].nil?)
					if trainer.trainereffect[:effectmode] == :Party
						trainereffect = trainer.trainereffect[partyindex]
					elsif trainer.trainereffect[:effectmode] == :Fainted
						trainereffect = trainer.trainereffect[i.pbFaintedPokemonCount]
					end
					if trainereffect && (trainer.trainereffect[:buffactivation] == :Always || (trainer.trainereffect[:buffactivation] == :Limited && trainer.trainereffectused!=nil && !trainer.trainereffectused.include?(partyindex)))
						# field changes	- what about saki tinkaton and archaludon?
						if trainereffect[:fieldChange]
							field_on_switch_in = trainereffect[:fieldChange][0]
							if trainereffect[:delayedaction]
								if trainereffect[:delayedaction][:fieldChange]
									if trainereffect[:delayedaction][:fieldChange][0]!=field_on_switch_in
										i = pbStatChangingSwitch(i,field_on_switch_in)
										@opponent = pbCloneBattler(@opponent.index)
										pbStatChangingSwitchOpponent(i,@opponent,field_on_switch_in)
										field_on_switch_in = trainereffect[:delayedaction][:fieldChange][0]
										delayed_field_switch = true
									end
								end
							end
						end
						# type changes
						if trainereffect[:typeChange]
							i.type1 = trainereffect[:typeChange][0]
							i.type2 = trainereffect[:typeChange][1] if trainereffect[:typeChange][1]
						end
						# pokemon effects
						trainereffect[:pokemonEffect].each_pair {|effect,effectval|
							i.effects[effect] = effectval[0]
					  		} if trainereffect[:pokemonEffect] 
						# stat changes
						trainereffect[:pokemonStatChanges].each_pair {|stat,statval|
							statval *= -1 if i.ability== :CONTRARY
							i.stages[stat]+=statval
							} if trainereffect[:pokemonStatChanges]
						# lawds stat innates
						if trainereffect[:statInnates]
							i.pokemon.setInnates(trainereffect[:statInnates])
							i.pbUpdate
						end
						# see terrains that will be set, if any
						trainereffect[:stateChanges].each_pair {|effect,effectval|
							if [:GRASSY,:MISTY,:PSYTERRAIN,:ELECTERRAIN].include?(effect) && effectval != 0
								@gonnaTerrains.push(effect) if !@gonnaTerrains.include?(effect)
							end
						} if trainereffect[:stateChanges]
						if trainereffect[:instantMove]
							moveid = trainereffect[:instantMove][0]
							case moveid # list out instant moves manually. just do the ones that are actually currently used by trainers
								when :CHTHONICMALADY
									@opponent=pbCloneBattler(@opponent.index)
									if ![:CLEARBODY,:WHITESMOKE,:FULLMETALBODY,:INDUSTRYSTANDARD].include?(@opponent.ability) && !@opponent.hasWorkingItem(:CLEARAMULET)
										@opponent.stages[PBStats::ATTACK]-=2 if ![:HYPERCUTTER,:DEFIANT].include?(@opponent.ability)
										@opponent.stages[PBStats::SPATK]-=2 if @opponent.ability!=:COMPETITIVE && !(hard_switch)
									end
								when :SUNNYDAY
									@gonnaWeather = @battle.pbWeather(:SUNNYDAY)
								when :HAIL
									@gonnaWeather = @battle.pbWeather(:HAIL)
							end
						end
					end
				end
			end 
			# end trainer effect coding		

			theseRoles = @mondata.partyroles[partyindex%6] if @mondata.partyroles[partyindex%6]
			theseRoles = pbGetMonRoles(i) if !theseRoles
			mega_var = false
			if @battle.pbCanMegaEvolveAI?(i,@attacker.index)
				mega_var = checkMega(i,field_on_switch_in)
				# if we should mega, then check if the partner can KO
				if i.ability==:SUGARRUSH && @battle.doublebattle && !hard_switch
					if checkAIdamage(@opponent,i.pbPartner) >= @opponent.hp
					    monscore+=100
					end
				end
			end

			#speed changing
			# LAWDS see the effects of intimidate, etc. if both sending new mons during the same round
			# lawds if the opponent also becomes active this turn, we do stat changes
			@opponent = pbCloneBattler(@opponent.index,illusionCheck(i, @opponent))
			checkMega(@opponent,field_on_switch_in)
			if @battle.onactive_mons.include?(@opponent.index) # if opponent becomes active at the same time
				if pbAIfaster?(nil,nil,i,@opponent) # if this mon is faster than the opponent
					pbStatChangingSwitch(nonmegaform,field_on_switch_in,seedonly: delayed_field_switch)
					pbStatChangingSwitch(i,field_on_switch_in,seedonly: delayed_field_switch)
					
					pbStatChangingSwitchOpponent(i, @opponent,field_on_switch_in,mirrorswitch: true)
					pbStatChangingSwitch(@opponent,field_on_switch_in,seedonly: delayed_field_switch)
					pbStatChangingSwitchOpponent(@opponent,nonmegaform,field_on_switch_in,mirrorswitch: true)
				else # if the opponent is faster than this mon
					pbStatChangingSwitch(@opponent,field_on_switch_in,seedonly: delayed_field_switch)
					pbStatChangingSwitchOpponent(@opponent,nonmegaform,field_on_switch_in,mirrorswitch: true)
					pbStatChangingSwitch(nonmegaform,field_on_switch_in,seedonly: delayed_field_switch)
					pbStatChangingSwitch(i,field_on_switch_in,seedonly: delayed_field_switch)
					pbStatChangingSwitchOpponent(i, @opponent,field_on_switch_in,mirrorswitch: true)
				end
			else # if opponent is already active, only run switch-in effects for the AI mon
				pbStatChangingSwitch(i,field_on_switch_in,seedonly:delayed_field_switch)
				pbStatChangingSwitch(nonmegaform,field_on_switch_in,seedonly:delayed_field_switch)
				pbStatChangingSwitchOpponent(i, @opponent,field_on_switch_in,mirrorswitch: true)
			end
			if i.effects[:HyperBeam] && (i.ability!=:SUCTIONCUPS || moldBreakerCheck(@opponent))
				hasphasemove = false
				for move in @opponent.moves
					movesym = move.move
					if (PBStuff::PHASEMOVE).include?(movesym)
						hasphasemove = true
						break
					end
				end
				monscore -= 1000 if hasphasemove
			end
			if i.ability== :MIMICRY
				type = :NORMAL
				type = @battle.field.mimicry
				i.type1=type
				i.type2=nil
			end
			if (i.ability== :IMPOSTER)
				transformed = true
				i = pbMakeFakeBattler(@opponent.pokemon,partyindex)
				i.hp = nonmegaform.hp
				i.item = nonmegaform.item

				# LAWDS imposter no longer copies stat boosts
				#monscore += 20*@opponent.stages[PBStats::ATTACK]
				#monscore += 20*@opponent.stages[PBStats::SPATK]
				#monscore += 20*@opponent.stages[PBStats::SPEED]
			end
			# Lawds Mod - Cofagrigus Crest mummifies on switch-in
			if (i.crested == :COFAGRIGUS) && !i.pokemon.crestUsed
				if !((PBStuff::FIXEDABILITIES).include?(@opponent.ability)) && !(@opponent.ability== :MUMMY || @opponent.ability== :SHIELDDUST)
					mummyscore = getAbilityDisruptScore(@opponent,@attacker)
					# Gen 9 Mod - Added Ability Shield
          			mummyscore = 1 if (@mondata.oppitemworks && @opponent.item == :ABILITYSHIELD)
					mummyscore = mummyscore < 2 ? 2 - mummyscore : 0
					monscore*=mummyscore
				end
			end
			
			partycheck.push(i)
			# Information gathering
			# lawds when making hard switches, consider the nonmega form's defensive traits since you won't be able to mega evolve before damage hits you on the way in
			defmon = hard_switch || !mega_var ? nonmegaform : i
			opp_best_move, incomingdamage = checkAIMovePlusDamage(@opponent, defmon, nil, field_on_switch_in)
			# lawds see if you consume a berry on switching in. not perfect but good enough
			oppmovetype = opp_best_move.pbType(@opponent)
			berrycheck = false
			movetypemod = pbTypeModNoMessages(oppmovetype,@opponent,defmon,opp_best_move,field: field_on_switch_in)
			if movetypemod > 4 && !([:UNNERVE,:ASONE].include?(@opponent.ability) || [:UNNERVE,:ASONE].include?(@opponent.pbPartner.ability))
				case defmon.item
					when :CHOPLEBERRY	then berrycheck=true if oppmovetype == :FIGHTING
					when :COBABERRY		then berrycheck=true if oppmovetype == :FLYING
					when :KEBIABERRY	then berrycheck=true if oppmovetype == :POISON
					when :SHUCABERRY	then berrycheck=true if oppmovetype == :GROUND
					when :CHARTIBERRY   then berrycheck=true if oppmovetype == :ROCK
					when :TANGABERRY	then berrycheck=true if oppmovetype == :BUG
					when :KASIBBERRY	then berrycheck=true if oppmovetype == :GHOST
					when :BABIRIBERRY 	then berrycheck=true if oppmovetype == :STEEL
					when :OCCABERRY 	then berrycheck=true if oppmovetype == :FIRE
					when :PASSHOBERRY 	then berrycheck=true if oppmovetype == :WATER
					when :RINDOBERRY 	then berrycheck=true if oppmovetype == :GRASS
					when :WACANBERRY 	then berrycheck=true if oppmovetype == :ELECTRIC
					when :PAYAPABERRY 	then berrycheck=true if oppmovetype == :PSYCHIC
					when :YACHEBERRY 	then berrycheck=true if oppmovetype == :ICE
					when :HABANBERRY 	then berrycheck=true if oppmovetype == :DRAGON
					when :COLBURBERRY 	then berrycheck=true if oppmovetype == :DARK
					when :ROSELIBERRY 	then berrycheck=true if oppmovetype == :FAIRY
				end
			end
			berrycheck = false if defmon.ability==:HARVEST && @battle.pbWeather==:SUNNYDAY
			defmon.item=nil if berrycheck
			i.item=nil if berrycheck
			berrycheck=false
			#end lawds berry checking
			defmon.effects[:Anticipation]=false # lawds anticipation goes away after a turn so set it to false
			incomingdamage*=2 if hard_switch && @opponent.ability==:STAKEOUT
			roughdamagearray = [[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]] #Order: First Opp, Second Opp, Partner, Sum if multi-target
			for moveindex in 0...i.moves.length
				@move = i.moves[moveindex]
				next if @move==nil
				roughdamagearray[0][moveindex] = [(pbRoughDamage(@move,i,@opponent,true,nil,field_on_switch_in)*100)/(@opponent.hp.to_f),100].min if @opponent.hp > 0
				roughdamagearray[0][moveindex] = 0 if roughdamagearray[0][moveindex]==nil
				roughdamagearray[1][moveindex] = 0 if roughdamagearray[1][moveindex]==nil
				if @battle.doublebattle
					roughdamagearray[1][moveindex] = [(pbRoughDamage(@move,i,@opponent.pbPartner,true,nil,field_on_switch_in)*100)/(@opponent.pbPartner.hp.to_f),100].min if @opponent.pbPartner.hp > 0
					next if @move.target != :AllNonUsers && !PARTNERFUNCTIONS.include?(@move.function)
					roughdamagearray[2][moveindex] = [(pbRoughDamage(@move,i,@attacker.pbPartner,true,nil,field_on_switch_in)*100)/(@attacker.pbPartner.hp.to_f),100].min if @attacker.pbPartner.hp > 0
				end
				if i.pbTarget(@move)==:AllOpposing
					roughdamagearray[3][moveindex] = roughdamagearray[0][moveindex] + roughdamagearray[1][moveindex]
				elsif i.pbTarget(@move)==:AllNonUsers
					roughdamagearray[3][moveindex] = roughdamagearray[0][moveindex] + roughdamagearray[1][moveindex] - 2*roughdamagearray[2][moveindex]
				elsif i.pbTarget(@move)==:RandomOpposing && @battle.doublebattle
					roughdamagearray[3][moveindex] = (roughdamagearray[3][moveindex] + roughdamagearray[3][moveindex])/2
				end
			end
			bestmoveindex = (roughdamagearray[0]+roughdamagearray[1]).index((roughdamagearray[0]+roughdamagearray[1]).max) % 4
			bestmove = i.moves[bestmoveindex]

			#Defensive
			defscore = 0
			incomingdamage = checkAIdamage(defmon,@opponent,nil,field_on_switch_in).to_f
			incomingdamage*=2 if hard_switch && @opponent.ability==:STAKEOUT
			
			# LAWDS if the opponent can click fake out on a non-hard switch, assume that they will, and evaluate the rest of the matchup from there. only singles since this is almost entirely non applicable in doubles
			fakeoutvar = false
			if (!@battle.doublebattle && !hard_switch && @opponent.turncount==0 && @opponent.pbHasMove?(:FAKEOUT) && !prioBlocked?(i,@opponent) && !(defmon.effects[:Substitute] > 0 || i.ability== :INNERFOCUS))
				fakemove = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(:FAKEOUT),@opponent)
				
				if !secondaryEffectNegated?(fakemove,@opponent,i)
					fakeoutvar = true # if you get fake outed, you can't first impression
					hpbuffer = defmon.hp
					damage = pbRoughDamage(fakemove, @opponent,defmon)
					incomingdamage += damage
					healing = (hpGainPerTurn(defmon,true)*defmon.totalhp).floor
					incomingdamage -= healing if healing < damage
					opphp = @opponent.hp
					if @opponent.ability!=:MAGICGUARD && @opponent.ability!=:LONGREACH && @opponent.item!=:PROTECTIVEPADS
						
						if defmon.ability==:ROUGHSKIN
							opphp -= (@opponent.totalhp/8).floor
						end
						if defmon.ability==:IRONBARBS
							opphp -= (@opponent.totalhp/8).floor
						end
						if defmon.item==:ROCKYHELMET
							opphp -= (@opponent.totalhp/6).floor
						end
					end
					opphp += (hpGainPerTurn(@opponent,true)*@opponent.totalhp).floor if opphp > 0
					# if the player mon would die by clicking fake out into you, assume they won't. that also means you can first impression.
					if opphp <= 0 && @battle.pbOwnedByPlayer?(@opponent.index)
						defmon.hp = hpbuffer
						@opponent.hp = opphp
						fakeoutvar = false
					end
				end
			end

			# if we get fakeouted when switching in, we can't click first impression, so set its damage to 0.
			if fakeoutvar && i.pbHasMove?(:FIRSTIMPRESSION)
				for moveindex in 0...4
					move = i.moves[moveindex]
					next if move==nil || move.move!=:FIRSTIMPRESSION
					roughdamagearray[0][moveindex] = 0 if roughdamagearray[0][moveindex] != nil && roughdamagearray[0][moveindex] > 0
					break
				end
			end

			# LAWDS if the opponent can click first impression on a non-hard switch, see if it kills ur guy.
			fimp_check = 0
			if !hard_switch && @opponent.turncount==0 && @opponent.pbHasMove?(:FIRSTIMPRESSION) && !prioBlocked?(i,@opponent)
				fimp = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(:FIRSTIMPRESSION),@opponent)
				# note, dont look at protection moves or fake out as a way to get around fimp since they can abuse that by just switching something else in on that turn. dont give away momentum
				dmg = pbRoughDamage(fimp, @opponent, i)
				fimp_check = dmg
			end

			incomingdamage2 = 0
			if @battle.doublebattle
				incomingdamage2 += checkAIdamage(defmon,@opponent.pbPartner,nil,field_on_switch_in).to_f 
				incomingdamage2*=2 if hard_switch && @opponent.pbPartner.ability==:STAKEOUT
			end
			combined_incoming_damage = incomingdamage + incomingdamage2
			# LAWDS - moved hazpercent definition up here to take hazard damage into account before calculating defensive score
			hazpercent = (totalHazardDamage(nonmegaform,field_on_switch_in).to_f)/100
			i.hp -= (hazpercent*(i.totalhp))
			incomingpercentage = (combined_incoming_damage) / ((i.hp).to_f)

			# LAWDS take end-of-turn chip into account when making hard switches
			if hard_switch==true && incomingpercentage < 1.0
				chip = hpGainPerTurn(nonmegaform,true) 
				incomingpercentage -= chip #if chip < 0
			end

			incomingpercentage = 1.0 if incomingpercentage >= 0.99 # lawds treat sash triggers as kills; dont just throw away sashes
			incomingpercentage = 0 if incomingpercentage < 0
			#cprint "incoming percentage on #{getMonName(i.species)}: #{incomingpercentage}\n"
			maxsingulardamage = [incomingdamage2, incomingdamage].max / i.hp.to_f
			if seedProtection?(i) && !(@opponent.pbHasMove?(:FEINT)) && !(@opponent.pbHasMove?(:MIGHTYCLEAVE))
				defscore+=20 if @opponent.pbOwnSide.effects[:Tailwind] > 0 # bonus for stalling tailwind turns
				if @battle.doublebattle && (i.pbHasMove?(:RAGEPOWDER) || i.pbHasMove?(:FOLLOWME) || (i.crested==:DACHSBUN && !i.pokemon.crestUsed)) # if you have follow me + seed, dont care about seed if you can't get a ton of value out of protecting the partner
				  if @attacker.pbPartner.hp > 0 && hard_switch==false && ((pbAIfaster?(nil,nil,@attacker.pbOpposing1,@attacker.pbPartner) && checkAIdamage(@attacker.pbPartner,@attacker.pbOpposing1) >= @attacker.pbPartner.hp) || (pbAIfaster?(nil,nil,@attacker.pbOpposing2,@attacker.pbPartner) && checkAIdamage(@attacker.pbPartner,@attacker.pbOpposing2) >= @attacker.pbPartner.hp))
					incomingpercentage = 0 
					maxsingulardamage = 0
				  end
				else
					incomingpercentage = 0 
					maxsingulardamage = 0
				end
			end
			#cprint "incoming damage: #{combined_incoming_damage}\n"
			PBDebug.log(sprintf("incoming percentage: %f",incomingpercentage)) if $INTERNAL
			# LAWDS dont bring stuff in that will just die, regardless if they can kill on the next turn
			if incomingpercentage >= 1.0 && (!canKillBeforeOpponentKills?(i,@opponent,false,field_on_switch_in) || hard_switch==true || (i.effects[:HyperBeam]>0))
				defscore -= 350 # lawds increased this to 350 from 150
			else
				survivors[partyindex]=true
			end
			# lawds dont throw away shadow shield/multiscale or disguise
			defscore -= 50 if hard_switch && [:MULTISCALE,:SHADOWSHIELD].include?(i.ability) && (i.hp + (hazpercent*i.totalhp))>=i.totalhp && (hpGainPerTurn(i)-(incomingpercentage).to_f/100 < 1) 
			defscore -= 50 if hard_switch && i.effects[:Disguise] && incomingpercentage > 0
			# LAWDS - try to account for bastiodon crest recoil and healing on the switch
			if i.crested == :BASTIODON && incomingdamage > 0
				can_survive_single_hit =  (incomingdamage < (i.hp*0.9).round) || notOHKO?(i,@opponent)
				if can_survive_single_hit || bestmove.pbIsMultiHit
					incomingpercentage = (incomingpercentage/2).round if can_survive_single_hit # if you dont die, you heal half of it back
					reflectdamage = (incomingdamage/2).round
					incomingdamage = reflectdamage if can_survive_single_hit
					if (reflectdamage>=@opponent.hp)
						defscore += 30 # if they're gonna die from the recoil, then pog
					end
				end
			end
			# end crest bastiodon stuff

			# LAWDS added to stop very risky switches
			if hard_switch
				#cprint "weighing penalty of taking #{incomingpercentage} on #{getMonName(i.species)}\n"
				scalar = incomingpercentage < 1 ? Math.sqrt(incomingpercentage) : 1
				value_penalty = scalar * 1.5 * getPokemonMatchupTotal(i) * 50
				defscore -= value_penalty
			end
			defscore += 25 if incomingpercentage < 0.5
			defscore += 10 if maxsingulardamage < 0.45
			defscore += 10 if maxsingulardamage < 0.4
			defscore += 10 if maxsingulardamage < 0.35
			defscore += 20 if maxsingulardamage < 0.3
			defscore += 50 if 2*incomingpercentage + hpGainPerTurn(i)-1 < 0.5
			defscore += 20 if maxsingulardamage < 0.2
			defscore += 30 if maxsingulardamage < 0.1
			defscore += 50 if 3*incomingpercentage + 2*(hpGainPerTurn(i)-1) < 0.3
			# LAWDS as checked earlier, if you die to first impression on coming in, dont switch in.
			if fimp_check > 0
				defscore -= 500 if fimp_check >= i.hp
				defscore -= 100 if fimp_check >= i.hp-1 # for sashes etc.
			end
			#check if hard switch_in lives assumed move
			if hard_switch==true && !@battle.doublebattle && (maxsingulardamage < 1.0 || pbAIfaster?(nil,nil,@opponent,i))
				assumed_move = checkAIbestMove(@opponent,i,nil,field_on_switch_in)
				assumed_damage = pbRoughDamage(assumed_move,@opponent,nonmegaform,true,nil,field_on_switch_in)
				assumed_percentage = assumed_damage / nonmegaform.hp
				defscore += 30 if assumed_damage < 0.5
				defscore += 50 if assumed_damage < 0.3
				defscore += 90 if assumed_damage < 0.1
			end
			defscore *= 2 if @opponent.effects[:Substitute] > 0

			# lawds stall scoring for doubles
			if defscore > 50 && i.ability==:STALL && !@battle.pbCheckGlobalAbility(:STALL) && @battle.doublebattle && 
			   !(@battle.opponent && !@battle.opponent.is_a?(Array) && @battle.opponent.trainertype==:RIFT_HIPPO)
				hpLossScore1 = @opponent.hp > 0 ? hpGainPerTurn(@opponent) : 1
				hpLossScore2 = @opponent.pbPartner.hp > 0 ? hpGainPerTurn(@opponent.pbPartner) : 1
				hpLossScore3 = @attacker.pbPartner.hp > 0 ? hpGainPerTurn(@attacker.pbPartner) : 1
				hpLossMultiplier = (hpLossScore3/(hpLossScore1*hpLossScore2))
				hpLossMultiplier *= 1.2 if hpLossMultiplier > 1
				hpLossMultiplier *= 0.8 if hpLossMultiplier < 1
				defscore = (defscore.to_f)*hpLossMultiplier
				defscore*=1.2 if @opponent.pbOwnSide.effects[:Tailwind] > 1
				defscore*=1.2 if @opponent.pbOwnSide.effects[:AuroraVeil] > 1
				defscore*=1.2 if @opponent.pbOwnSide.effects[:Reflect] > 1
				defscore*=1.2 if @opponent.pbOwnSide.effects[:LightScreen] > 1
				defscore*=1.2 if @opponent.pbOwnSide.effects[:AreniteWall] > 1
				defscore*=0.8 if i.pbOwnSide.effects[:Tailwind] > 1
				defscore*=0.8 if i.pbOwnSide.effects[:AuroraVeil] > 1
				defscore*=0.8 if i.pbOwnSide.effects[:Reflect] > 1
				defscore*=0.8 if i.pbOwnSide.effects[:LightScreen] > 1
				defscore*=0.8 if i.pbOwnSide.effects[:AreniteWall] > 1
			end

			# LAWDS we set defscore to 0 here because shield seeds are much more valuable if you can move on the turn it's active. we want to discourage AI from hard switching into a seeded mon and wasting that value.
			defscore = -5000 if hard_switch && seedProtection?(i) && @battle.doublebattle
			defscore = 25 if seedProtection?(i) && !(@battle.doublebattle) && defscore > 0 # lawds if we have seed protection, reduce defscore to 25 to not overvalue sending them too early in singles.
			monscore += defscore
			PBDebug.log(sprintf("Defensive: %d",defscore)) if $INTERNAL

			#Offensive
			offscore=0
			
			#check damage
			offscore += 30 if roughdamagearray[3].max > 180
			offscore += 50 if roughdamagearray[0].max >= 100 || roughdamagearray[1].max >= 100
			offscore += 10 if [roughdamagearray[0].max, roughdamagearray[1].max].max > 90
			offscore += 10 if [roughdamagearray[0].max, roughdamagearray[1].max].max > 80
			offscore += 10 if [roughdamagearray[0].max, roughdamagearray[1].max].max > 70
			offscore += 10 if [roughdamagearray[0].max, roughdamagearray[1].max].max > 60
			offscore += 50 if roughdamagearray[0].max >= 50 || roughdamagearray[1].max >= 50
			offscore += 50 if roughdamagearray[0].max >= 100 && roughdamagearray[1].max >= 100
			bestmoveindex = (roughdamagearray[0]+roughdamagearray[1]).index((roughdamagearray[0]+roughdamagearray[1]).max) % 4
			faster_with_best_move = pbAIfaster?(i.moves[bestmoveindex],opp_best_move,i,@opponent,field_on_switch_in)
			offscore *= faster_with_best_move ? 1.25 : 0.75
			# LAWDS don't bring a physical attacker in on will-o-wisp
			if @opponent.hp > 0 && (hard_switch || (roughdamagearray[0].max < 100) || !faster_with_best_move || (@opponent.ability==:PRANKSTER && !prioBlocked?(i,@opponent))) &&
				  (@opponent.pbHasMove?(:WILLOWISP) || (@opponent.pbHasMove?(:PSYCHOSHIFT) && @opponent.status==:BURN)) &&
				 (@opponent.effects[:Taunt] <= 0) && i.pbCanBurn?(false, false) && ![:GUTS,:QUICKFEET].include?(i.ability) && i.attack > i.spatk*1.1 && 
				!(@opponent.ability==:PRANKSTER && i.hasType?(:DARK) && @battle.FE!=:BEWITCHED) &&
				!(@battle.FE==:ROCKY && i.stages[PBStats::DEFENSE]>0 && !(@opponent.pbHasMove?(:PSYCHOSHIFT) && @opponent.status==:BURN))
				offscore -= 200
				offscore -= 200 if roughdamagearray[0].max < 50
			end

			# lawds in single battles, discourage sending in a faster mon to revenge kill if the opponent can break sash/sturdy
			if !@battle.doublebattle && !hard_switch && i.hp==i.totalhp && pbAIfaster?(nil,nil,i,@opponent) &&
				(i.ability==:STURDY || (i.ability==:STALWART && field_on_switch_in==:COLOSSEUM) || (i.item==:FOCUSSASH) || (field_on_switch_in==:CHESS && i.pokemon.piece==:PAWN))
				# if the opponent has a move that outspeeds all of our kill moves and can deal damage to us, cut offense score. penalize it further if defscore is high to offset it
				if @opponent.moves.any? {|oppmove| i.moves.all? {|ourmove| roughdamagearray[0][i.moves.index(ourmove)] < 100 || pbAIfaster?(oppmove,ourmove,@opponent,i)} && pbRoughDamage(oppmove,@opponent,i,true,nil,field_on_switch_in) > 0 }
					offscore -= 20
					offscore -= 20 if defscore > 50
					offscore -= 20 if defscore > 100
				end
			end

			monscore += offscore
			PBDebug.log(sprintf("Offensive: %d",offscore)) if $INTERNAL
			# Roles
			rolescore=0
			# LAWDS eliminate any weird redundant rolescores here - like defensive comparisons should be accounted for in damage calculation
			# lawds melia meganium
			rolescore+= 100 if @battle.doublebattle && i.ability==:MISTYSURGE && i.pbOwnSide.effects[:MISTY]==0 && !@battle.opponent.is_a?(Array) && [:ENIGMA,:ENIGMA1,:ENIGMA2].include?(@battle.opponent.trainertype)
			if @mondata.skill >= HIGHSKILL
				if theseRoles.include?(:SWEEPER)
					rolescore+= @attacker.pbNonActivePokemonCount<2 ? 60 : -50
					#rolescore+=30 if i.attack >= i.spatk && (@opponent.defense<@opponent.spdef || @opponent.pbPartner.defense<@opponent.pbPartner.spdef)
					#rolescore+=30 if i.spatk >= i.attack && (@opponent.spdef<@opponent.defense || @opponent.pbPartner.spdef<@opponent.pbPartner.defense)
					rolescore+= (-10)* statchangecounter(@opponent,1,7,-1)
					rolescore+= (-10)* statchangecounter(@opponent.pbPartner,1,7,-1)
					rolescore+=10 if pbAIfaster?(nil,nil,i,@opponent) && rolescore > 0 
					rolescore*= pbAIfaster?(nil,nil,i,@opponent) && rolescore > 0 ? 1.5 : 0.5 
					rolescore+=50 if @opponent.status== :SLEEP || @opponent.status== :FROZEN
					rolescore+=50 if @opponent.pbPartner.status== :SLEEP || @opponent.pbPartner.status== :FROZEN
					# Gen 9 Mod - Last Respects / Supreme Overlord Pokemon aren't ready to sweep if enough other party pokemon aren't fainted.
					faintcount = @attacker.pbFaintedPokemonCount
					rolescore+= (25*(faintcount - 4)) if i.ability== :SUPREMEOVERLORD
          			rolescore+= (50*(faintcount - 2)) if i.pbHasMove?(:LASTRESPECTS)
				end
				if theseRoles.include?(:PHYSICALWALL) || theseRoles.include?(:SPECIALWALL)
					rolescore+=30 if theseRoles.include?(:PHYSICALWALL) && (@opponent.spatk>@opponent.attack || @opponent.pbPartner.spatk>@opponent.pbPartner.attack)
					rolescore+=30 if theseRoles.include?(:SPECIALWALL) && (@opponent.spatk<@opponent.attack || @opponent.pbPartner.spatk<@opponent.pbPartner.attack)
					rolescore+=30 if @opponent.status== :BURN || @opponent.status== :POISON || @opponent.effects[:LeechSeed]>0
					rolescore+=30 if @opponent.pbPartner.status== :BURN || @opponent.pbPartner.status== :POISON || @opponent.pbPartner.effects[:LeechSeed]>0
				end
				if theseRoles.include?(:TANK)
					rolescore+=40 if @opponent.status== :PARALYSIS || @opponent.effects[:LeechSeed]>0
					rolescore+=40 if @opponent.pbPartner.status== :PARALYSIS || @opponent.pbPartner.effects[:LeechSeed]>0
					rolescore+=30 if @attacker.pbOwnSide.effects[:Tailwind]!=0
				end
				if theseRoles.include?(:LEAD)
					rolescore+=10
					rolescore+=20 if (party.length - @attacker.pbNonActivePokemonCount) <= (party.length / 2).ceil
				end
				if @attacker.effects[:LunarDance] && (field_on_switch_in == :NEWWORLD || field_on_switch_in == :DANCEFLOOR)
					rolescore -= 100 if @attacker.pbNonActivePokemonCount > 2 # this might still need to be adjusted
					rolescore += 200 if @attacker.pbNonActivePokemonCount == 1
				end
				if theseRoles.include?(:CLERIC)
					partymidhp = false
					for k in party
						next if k.nil? || k==i || k.totalhp==0
						rolescore+=50 if !k.status.nil?
						partymidhp = true if 0.3<((k.hp.to_f)/k.totalhp) && ((k.hp.to_f)/k.totalhp)<0.6
					end
					rolescore+=50 if partymidhp
				end
				#now only does for lowered stats, but would also be very good for raised stats right?
				#evasion / accuracy doesn't make sense to me
				#lawds what the fuck why did it check for lowered stats. i don't understand. help. changed to raised stats i guess?
				if theseRoles.include?(:PHAZER)
					for opp in [@opponent, @opponent.pbPartner]
						next if opp.hp <=0
						rolescore+= (10)*opp.stages[PBStats::ATTACK]	if opp.stages[PBStats::ATTACK]>0
						rolescore+= (20)*opp.stages[PBStats::DEFENSE]	if opp.stages[PBStats::DEFENSE]>0
						rolescore+= (10)*opp.stages[PBStats::SPATK]		if opp.stages[PBStats::SPATK]>0
						rolescore+= (20)*opp.stages[PBStats::SPDEF]		if opp.stages[PBStats::SPDEF]>0
						rolescore+= (10)*opp.stages[PBStats::SPEED]		if opp.stages[PBStats::SPEED]>0
						rolescore+= (20)*opp.stages[PBStats::EVASION]	if opp.stages[PBStats::ACCURACY]>0
					end
				end
				# LAWDS - screener role only gets a boost if they can actually get a screen up before fainting
				rolescore+=60 if theseRoles.include?(:SCREENER) && (notOHKO?(i,@opponent) || pbAIfaster?(nil,nil,i,@opponent) || i.ability== :PRANKSTER || i.crested == :MRRIME) && i.pbFaintedPokemonCount < 3
				
				
				#This is role related because it's the replacement for revenge killer
				# LAWDS only checked for non-hard switches bc thats what revenge killing is
				if hard_switch==false
					for moveindex in 0...i.moves.length
						next if i.moves[moveindex].nil?
						if pbAIfaster?(i.moves[moveindex],nil,i,@opponent)
							if roughdamagearray[0][moveindex] >= 100 || roughdamagearray[1][moveindex] >= 100
								rolescore+=110
								break
							end
						end
					end
				end

				if theseRoles.include?(:SPINNER)
					if !@opponent.hasType?(:GHOST) && (@opponent.pbPartner.hp==0 || !@opponent.pbPartner.hasType?(:GHOST))
						rolescore+=20*@attacker.pbOwnSide.effects[:Spikes]
						rolescore+=20*@attacker.pbOwnSide.effects[:ToxicSpikes]
						rolescore+=30 if @attacker.pbOwnSide.effects[:StickyWeb]
						rolescore+=30 if @attacker.pbOwnSide.effects[:StealthRock]
					end
				end
				# lawds absorb tspikes
				if @attacker.pbOwnSide.effects[:ToxicSpikes] > 0 && i.hasType?(:POISON) && !i.isAirborne?(field_on_switch_in)
					vulncount = 0
					spikeparty = @battle.pbParty(@attacker.index)
					for partymon in spikeparty
						next if partymon==nil || partymon.hp <= 0 || partymon.isEgg?
						next if partymon.status!=nil
						next if partymon.hasType?(:STEEL) || partymon.hasType?(:POISON)
						next if [:IMMUNITY,:POISONHEAL,:MAGICGUARD,:PURIFYINGSALT,:COMATOSE,:SHEDSKIN].include?(partymon.ability)
						partybattler = pbMakeFakeBattler(partymon,spikeparty.index(partymon),false,@attacker.index)
						next if partybattler.isAirborne?() || [:DHELMISE,:ZANGOOSE].include?(partybattler.crested)
						vulncount+=1
					end
					rolescore+=10*vulncount*@attacker.pbOwnSide.effects[:ToxicSpikes]
				end
				if theseRoles.include?(:PIVOT)
					rolescore+=40
				end
				if theseRoles.include?(:BATONPASSER)
					rolescore+=50
				end
				if theseRoles.include?(:STALLBREAKER)
					rolescore+=80 if checkAIhealing(aimem) || checkAIhealing(aimem2)
				end
				if theseRoles.include?(:STATUSABSORBER)
					for specificmemory in [aimem, aimem2]
						next if specificmemory.length == 0
						for j in specificmemory
							statusmove = PBStuff::BURNMOVE.include?(j.move) || PBStuff::PARAMOVE.include?(j.move) || PBStuff::SLEEPMOVE.include?(j.move) || PBStuff::SCREENMOVE.include?(j.move)
						end
					end
					rolescore+=70 if statusmove
				end
				if theseRoles.include?(:TRAPPER) # LAWDS 10/17/2024 improved trapping code. also added stipulation for run away.
					cantrap = !(@opponent.hasType?(:GHOST) && !(i.ability==:SHADOWTAG && @battle.FE==:DIMENSIONAL)) && @opponent.ability!=:RUNAWAY && ((i.ability==:ARENATRAP && !(@opponent.isAirborne?(field_on_switch_in))) || (i.ability==:MAGNETPULL && @opponent.hasType?(:STEEL)) || (i.ability==:SHADOWTAG))
					if cantrap
						trapperdmg = roughdamagearray[0].max
						rolescore+=30 if pbAIfaster?(nil,nil,i,@opponent) && @opponent.totalhp!=0 && (@opponent.hp.to_f)/@opponent.totalhp<0.6 
						rolescore+=80 if @opponent.totalhp!=0 && incomingdamage < hpGainPerTurn(i,true)*i.totalhp && !@battle.doublebattle
						rolescore+=80 if @opponent.totalhp!=0 && @opponent.hp > @opponent.totalhp/2 && pbAIfaster?(nil,nil,i,@opponent) && trapperdmg >= 100 && (!checkAIpriority() || prioBlocked?(i,@opponent)) && (!checkAIpriority(nil,@opponent.pbPartner) || prioBlocked?(i,@opponent.pbPartner))
						# trap to help partner
						rolescore+=80 if @attacker.pbPartner.hp > 0 && pbAIfaster?(nil,nil,@attacker.pbPartner,@opponent) && checkAIdamage(@opponent,@attacker.pbPartner)>=@opponent.hp
						# doubling enemy field damage on infernal
						rolescore+=15 if field_on_switch_in==:INFERNAL && (!@opponent.isAirborne?(field_on_switch_in) || @opponent.effects[:infernalPain]) && @opponent.burningFieldPassiveDamage?
					end
				end
				if (i.pbHasMove?(:PURSUIT) || i.pbHasMove?(:VILEASSAULT)) && !hard_switch # LAWDS pursuit trapping
					pursuitmove = nil
					pursuitmoveindex = -1
					for index in 0...4
						move = i.moves[index]
						next if move==nil
						if move.move==:PURSUIT
							pursuitmove = move
							pursuitmoveindex = index
							break
						end
					end
					if pursuitmove != nil
						pursuitdamage = roughdamagearray[0][pursuitmoveindex]
						if pbAIfaster?(pursuitmove, nil, i, @opponent) && pursuitdamage >= @opponent.hp
							pursuitadd = 0
							pursuitadd += 75 * ((@opponent.hp).to_f)/((@opponent.totalhp).to_f)
							pursuitadd = 100 if i.ability==:HITANDRUN
							rolescore+=pursuitadd
						end
					end
				end
				if theseRoles.include?(:WEATHERSETTER) && !(@battle.state.effects[:WEATHERLOCK]) # LAWDS - if you cant set weather, ignore weather setting factors
					 # lawds - why is there a global 30 boost here ? removing it and changing all the conditionals to 90 from 60.
					if (i.ability== :DROUGHT) || (nonmegaform.ability== :DROUGHT) || i.pbHasMove?(:SUNNYDAY)
						rolescore+=90 if @battle.weather!=:SUNNYDAY
					elsif (i.ability== :DRIZZLE) || (nonmegaform.ability== :DRIZZLE) || i.pbHasMove?(:RAINDANCE)
						rolescore+=90 if @battle.weather!=:RAINDANCE
					elsif (i.ability== :SANDSTREAM) || (nonmegaform.ability== :SANDSTREAM) || (i.ability== :SANDSPIT) || (nonmegaform.ability== :SANDSPIT) || i.pbHasMove?(:SANDSTORM)
						rolescore+=90 if @battle.weather!=:SANDSTORM
					elsif (i.ability== :SNOWWARNING) || (nonmegaform.ability== :SNOWWARNING) || i.pbHasMove?(:HAIL)
						rolescore+=90 if @battle.weather!=:HAIL
					elsif (i.ability== :PRIMORDIALSEA) || (i.ability== :DESOLATELAND) || (i.ability== :DELTASTREAM) ||
						(nonmegaform.ability== :PRIMORDIALSEA) || (nonmegaform.ability== :DESOLATELAND) || (nonmegaform.ability== :DELTASTREAM)
						rolescore+=90
					end
				end
			end
			monscore += rolescore
			PBDebug.log(sprintf("Roles: %d",rolescore)) if $INTERNAL
			# Weather
			weatherscore=0
			if !(@battle.state.effects[:WEATHERLOCK]) # LAWDS - if you cant set weather, ignore weather setting factors
				case @battle.pbWeather
					when :HAIL
						weatherscore+=25 if (i.ability== :MAGICGUARD) || (i.ability== :OVERCOAT) || i.hasType?(:ICE) || (i.ability== :WONDERGUARD && field_on_switch_in == :COLOSSEUM)
						weatherscore+=50 if (i.ability== :SNOWCLOAK) || (i.ability== :ICEBODY) || i.ability== :LUNARIDOL
						weatherscore+=80 if (i.ability== :SLUSHRUSH) || (i.item == :EMPCREST && i.species == :EMPOLEON)
						weatherscore+=30 if (i.ability== :ICEFACE) && i.form == 1
					when :RAINDANCE
						weatherscore+=50 if (i.ability== :DRYSKIN) || (i.ability== :HYDRATION) || (i.ability== :RAINDISH)
						weatherscore+=80 if (i.ability== :SWIFTSWIM)
					when :SUNNYDAY
						weatherscore-=40 if (i.ability== :DRYSKIN)									# Lawds Mod - Wildfire
						weatherscore+=50 if (i.ability== :SOLARPOWER) || (i.ability== :SOLARIDOL) || (i.ability== :WILDFIRE)
						weatherscore+=80 if (i.ability== :CHLOROPHYLL)
					when :SANDSTORM
						weatherscore+=25 if (i.ability== :MAGICGUARD) || (i.ability== :OVERCOAT) || i.hasType?(:ROCK) || i.hasType?(:GROUND) || i.hasType?(:STEEL) || (i.ability== :WONDERGUARD && field_on_switch_in == :COLOSSEUM)
						weatherscore+=50 if (i.ability== :SANDVEIL) || (i.ability== :SANDFORCE)
						weatherscore+=80 if (i.ability== :SANDRUSH || i.ability== :DUSTDEVIL)
				end
				if @battle.trickroom>0
					weatherscore+= i.pbSpeed<@opponent.pbSpeed ? 50 : -50
					weatherscore+= i.pbSpeed<@opponent.pbPartner.pbSpeed ? 50 : -50 if @opponent.pbPartner.hp > 0
				end
			end
				monscore += weatherscore
			PBDebug.log(sprintf("Weather: %d",weatherscore)) if $INTERNAL
			#Moves
			movesscore=0
			if @mondata.skill>=HIGHSKILL
				if @attacker.pbOwnSide.effects[:ToxicSpikes] > 0
					movesscore+=80 if nonmegaform.hasType?(:POISON) && !nonmegaform.hasType?(:FLYING) && ![:LEVITATE,:SOLARDIOL,:LUNARIDOL].include?(nonmegaform.ability)
					movesscore+=30 if nonmegaform.hasType?(:FLYING) || nonmegaform.hasType?(:STEEL) || [:LEVITATE,:SOLARDIOL,:LUNARIDOL].include?(nonmegaform.ability)
				end
				if i.pbHasMove?(:CLEARSMOG) || i.pbHasMove?(:HAZE) || i.pbHasMove?(:HEAVENLYWING) # LAWDS - added heavenly wing consideration here
					movesscore+= (10)* statchangecounter(@opponent,1,7,1)
					movesscore+= (10)* statchangecounter(@opponent.pbPartner,1,7,1)
				end
				movesscore+=25 if i.pbHasMove?(:FAKEOUT) || i.pbHasMove?(:FIRSTIMPRESSION)
				if @attacker.pbPartner.totalhp != 0
					movesscore+=70 if i.pbHasMove?(:FUSIONBOLT) && @attacker.pbPartner.pbHasMove?(:FUSIONFLARE)
					movesscore+=70 if i.pbHasMove?(:FUSIONFLARE) && @attacker.pbPartner.pbHasMove?(:FUSIONBOLT)
				end
				movesscore+=30 if i.pbHasMove?(:RETALIATE) && @attacker.pbOwnSide.effects[:Retaliate]
				if i.pbHasMove?(:FELLSTINGER) 
					movesscore+=50 if pbAIfaster?(nil,nil,i,@opponent) && (@opponent.hp.to_f)/@opponent.totalhp<0.2
					movesscore+=50 if pbAIfaster?(nil,nil,i,@opponent.pbPartner) && (@opponent.pbPartner.hp.to_f)/@opponent.pbPartner.totalhp<0.2
				end
				if i.pbHasMove?(:TAILWIND)
					movesscore+= @attacker.pbOwnSide.effects[:Tailwind]!=0 ? -60 : 30
				end
				if i.pbHasMove?(:PURSUIT) || (i.pbHasMove?(:SANDSTORM) || i.pbHasMove?(:HAIL)) && @opponent.item != :SAFETYGOGGLES ||
					 i.pbHasMove?(:TOXIC) || i.pbHasMove?(:LEECHSEED)
					movesscore+=150 if (@opponent.ability== :WONDERGUARD)
					movesscore+=150 if (@opponent.pbPartner.ability== :WONDERGUARD)
				end
			end
			monscore+=movesscore
			PBDebug.log(sprintf("Moves: %d",movesscore)) if $INTERNAL
			#Abilities
			abilityscore=0
			if @mondata.skill >= HIGHSKILL
				abil = [] # LAWDS P3
				if i.ability.is_a?(PokeAbility)
					if i.ability.ability.is_a?(Array)
						for ability in i.ability.ability
							next if ability==nil
							abil.push(ability)
						end
					else
						abil = [i.ability.ability]
					end
				end
				for ability in abil
					# LAWDS note to self i wanna look at these and see which ones are redundant, ive already crossed out a few.
					# defensive abilities should logically be accounted for in defscore.
				case ability
					when :DISGUISE
						if i.effects[:Disguise] && (!moldBreakerCheck(@opponent) || i.item==:ABILITYSHIELD)
							abilityscore+= (10)* statchangecounter(@opponent,1,7,1)
							abilityscore+= (10)* statchangecounter(@opponent.pbPartner,1,7,1)
							abilityscore+= 50 if roughdamagearray[0].max >= 100 || roughdamagearray[1].max >= 100
						end
					when :ICEFACE
						if i.effects[:IceFace] && (@opponent.attack > @opponent.spatk || field_on_switch_in == :FROZENDIMENSION)
							abilityscore+= (10)* statchangecounter(@opponent,1,7,1)
							abilityscore+= (10)* statchangecounter(@opponent.pbPartner,1,7,1)
							abilityscore+= 50 if roughdamagearray[0].max >= 100 || roughdamagearray[1].max >= 100
						end
					when :UNAWARE
						abilityscore+= (10)* statchangecounter(@opponent,1,7,1)
						abilityscore+= (10)* statchangecounter(@opponent.pbPartner,1,7,1)
					when :DROUGHT,:DESOLATELAND
						abilityscore+=40 if @opponent.hasType?(:WATER)
						abilityscore+=40 if @opponent.pbPartner.hasType?(:WATER)
						for specificmemory in [aimem,aimem2]
							abilityscore+=15 if specificmemory.any? {|moveloop| moveloop!=nil && moveloop.pbType(specificmemory==aimem ? @opponent : @opponent.pbPartner) == :WATER}
						end
					when :DRIZZLE,:PRIMORDIALSEA
						abilityscore+=40 if @opponent.hasType?(:FIRE)
						abilityscore+=40 if @opponent.pbPartner.hasType?(:FIRE)
						for specificmemory in [aimem,aimem2]
							abilityscore+=15 if specificmemory.any? {|moveloop| moveloop!=nil && moveloop.pbType(specificmemory==aimem ? @opponent : @opponent.pbPartner) == :FIRE}
						end
					when :LIMBER
						abilityscore+=15 if checkAImoves(PBStuff::PARAMOVE,aimem)
						abilityscore+=15 if checkAImoves(PBStuff::PARAMOVE,aimem2)
					when :OBLIVIOUS
						abilityscore+=20 if (@opponent.ability== :CUTECHARM) || (@opponent.pbPartner.ability== :CUTECHARM)
						abilityscore+=20 if checkAImoves([:ATTRACT],aimem)
						abilityscore+=20 if checkAImoves([:ATTRACT],aimem2)
					when :COMPOUNDEYES
						abilityscore+=25 if @opponent.stages[PBStats::EVASION]>0 || accuracyWeatherAbilityActive?(@opponent)
						abilityscore+=25 if @opponent.pbPartner.stages[PBStats::EVASION]>0 || accuracyWeatherAbilityActive?(@opponent.pbPartner)
					when :COMATOSE
						abilityscore+=20 if checkAImoves(PBStuff::BURNMOVE,aimem)
						abilityscore+=20 if checkAImoves(PBStuff::PARAMOVE,aimem)
						abilityscore+=20 if checkAImoves(PBStuff::SLEEPMOVE,aimem)
						abilityscore+=20 if checkAImoves(PBStuff::POISONMOVE,aimem)
					when :INSOMNIA,:VITALSPIRIT
						abilityscore+=20 if checkAImoves(PBStuff::SLEEPMOVE,aimem)
					when :POISONHEAL,:TOXICBOOST,:IMMUNITY
						abilityscore+=20 if checkAImoves(PBStuff::POISONMOVE,aimem)
					when :MAGICGUARD
						abilityscore+=20 if checkAImoves([:LEECHSEED],aimem)
						abilityscore+=20 if checkAImoves([:WILLOWISP],aimem)
						abilityscore+=20 if checkAImoves(PBStuff::POISONMOVE,aimem)
					# Gen 9 Mod - Added Thermal Exchange
					when :WATERBUBBLE,:WATERVEIL,:FLAREBOOST,:THERMALEXCHANGE
						if checkAImoves(PBStuff::BURNMOVE,aimem)
							abilityscore+=10
							abilityscore+=10 if (i.ability== :FLAREBOOST)
						end
					when :OWNTEMPO
						abilityscore+=20 if checkAImoves(PBStuff::CONFUMOVE,aimem)
					when :SCREENCLEANER
						abilityscore-=10 if @attacker.pbOwnSide.effects[:Reflect]>1
						abilityscore-=10 if @attacker.pbOwnSide.effects[:LightScreen]>1
						abilityscore-=20 if @attacker.pbOwnSide.effects[:AuroraVeil]>1
						abilityscore-=20 if @attacker.pbOwnSide.effects[:AreniteWall]>1
					when :CURIOUSMEDICINE
						abilityscore-= (10)* statchangecounter(@opponent,1,7,1)
					when :INTIMIDATE,:STAMINA#,:FURCOAT
						abilityscore+=40 if @opponent.attack> @opponent.spatk
						abilityscore+=40 if @opponent.pbPartner.attack> @opponent.pbPartner.spatk
					when :WONDERGUARD
						dievar = false
						instantdievar=false
						for j in aimem
							dievar=true if [:FIRE, :GHOST, :DARK, :ROCK, :FLYING].include?(j.pbType(@opponent))
						end
						if @mondata.skill>=BESTSKILL
							for j in aimem2
								dievar=true if [:FIRE, :GHOST, :DARK, :ROCK, :FLYING].include?(j.pbType(@opponent.pbPartner))
							end
						end
						if @battle.weather == :HAIL || @battle.weather == :SANDSTORM || @battle.weather == :SHADOWSKY
							dievar=true
							instantdievar=true
						end
						if i.status== :BURN || i.status== :POISON
							dievar=true
							instantdievar=true
						end
						if @attacker.pbOwnSide.effects[:StealthRock] || @attacker.pbOwnSide.effects[:Spikes]>0 || @attacker.pbOwnSide.effects[:ToxicSpikes]>0
							dievar=true
							instantdievar=true
						end
						dievar=true if moldBreakerCheck(@opponent)
						dievar=true if moldBreakerCheck(@opponent.pbPartner)
						abilityscore+=90 if !dievar
						abilityscore-=90 if instantdievar
					when :EFFECTSPORE,:STATIC,:POISONPOINT,:ROUGHSKIN,:IRONBARBS,:FLAMEBODY,:CUTECHARM,:MUMMY,:AFTERMATH,:GOOEY,:FLUFFY,:PERISHBODY,:WANDERINGSPIRIT,:WATERRETENTION
						if checkAIbestMove(@opponent,i,nil,field_on_switch_in).contactMove? || (@opponent.pbPartner.hp > 0 && checkAIbestMove(@opponent.pbPartner,i,nil,field_on_switch_in).contactMove?)
							abilityscore+=30 unless (i.ability== :FLUFFY && (@opponent.hasType?(:FIRE) || @opponent.pbPartner.hasType?(:FIRE))) || (i.ability== :PERISHBODY && field_on_switch_in == :HOLY)
						end
					when :COTTONDOWN
						if incomingpercentage<0.5
							if roughdamagearray[0].max >= 60
								abilityscore+=50
							else
								abilityscore+=30
							end
						end
					when :PURIFYINGSALT # LAWDS - take into account purifying salt on haunted and holy
						abilityscore+=getFieldDisruptScore(i,@opponent,:HOLY) if field_on_switch_in == :HAUNTED
					when :TRACE 	# Gen 9 Mod - Earth Eater, Well-Baked Body, Wind Rider
						if ([:WATERABSORB,:VOLTABSORB,:STORMDRAIN,:MOTORDRIVE,:FLASHFIRE,:LEVITATE,:LUNARIDOL,:SOLARIDOL,:LIGHTNINGROD,:SPIRITSENVOY, # LAWDS - spirit's envoy
							:SAPSIPPER,:DRYSKIN,:SLUSHRUSH,:SANDRUSH,:DUSTDEVIL,:SWIFTSWIM,:CHLOROPHYLL,:SPEEDBOOST,
							:WONDERGUARD,:PRANKSTER, :EARTHEATER, :WELLBAKEDBODY, :WINDRIDER,:ENTOMOPHAGY].include?(@opponent.ability) || 
							(pbAIfaster?() && ((@opponent.ability== :ADAPTABILITY) || (@opponent.ability== :DOWNLOAD) || (@opponent.ability== :PROTEAN) || (@opponent.ability== :LIBERO))) || 
							(@opponent.attack>@opponent.spatk && (@opponent.ability== :INTIMIDATE)) || (@opponent.ability== :UNAWARE) || (i.hp==i.totalhp && ((@opponent.ability== :MULTISCALE) || (@opponent.ability== :SHADOWSHIELD))))  && i.item != :ABILITYSHIELD # Gen 9 Mod - Added Ability Shield
							abilityscore+=60
						end
					when :MAGMAARMOR
						abilityscore+=20 if aimem.any? {|moveloop| moveloop!=nil && moveloop.pbType(@opponent) == :ICE}
						abilityscore+=20 if aimem2.any? {|moveloop| moveloop!=nil && (@opponent.pbPartner.hp > 0 && moveloop.pbType(@opponent.pbPartner) == :ICE)}
					when :SOUNDPROOF
						#abilityscore+=60 if checkAIbestMove(@opponent,i,nil,field_on_switch_in).isSoundBased? || (@opponent.pbPartner.hp>0 && checkAIbestMove(@opponent.pbPartner,i,nil,field_on_switch_in).isSoundBased?)
					when :THICKFAT
						#abilityscore+=30 if (@opponent.pbPartner.hp > 0 && ([:ICE,:FIRE].include?(checkAIbestMove(@opponent.pbPartner,i,nil,field_on_switch_in).pbType(@opponent.pbPartner)) || [:ICE,:FIRE].include?(checkAIbestMove(@opponent,i,nil,field_on_switch_in).pbType(@opponent))))
					when :WATERBUBBLE
						abilityscore+=30 if :FIRE ==checkAIbestMove(@opponent,i,nil,field_on_switch_in).pbType(@opponent) || (@opponent.pbPartner.hp > 0 && :FIRE == checkAIbestMove(@opponent.pbPartner,i,nil,field_on_switch_in).pbType(@opponent.pbPartner))
					when :WELLBAKEDBODY # Gen 9 Mod - Added Well-Baked Body
						abilityscore+=30 if :FIRE ==checkAIbestMove(@opponent,i,nil,field_on_switch_in).pbType(@opponent) || (@opponent.pbPartner.hp > 0 && :FIRE == checkAIbestMove(@opponent.pbPartner,i,nil,field_on_switch_in).pbType(@opponent.pbPartner))
					when :LIQUIDOOZE
						for j in aimem
							abilityscore+=40 if j.move==:LEECHSEED || j.function==0xDD || j.function==0x139 || j.function==0x158
						end
					when :RIVALRY # LAWDS - rivalry rework
						abilityscore+=10
					when :SCRAPPY, :MINDSEYE
						abilityscore+=30 if @opponent.hasType?(:GHOST)
						abilityscore+=30 if (@opponent.pbPartner.hp > 0 && @opponent.pbPartner.hasType?(:GHOST))
					when :LIGHTMETAL
						#abilityscore+=10 if checkAImoves([:GRASSKNOT,:LOWKICK],aimem)
						#abilityscore+=10 if checkAImoves([:GRASSKNOT,:LOWKICK],aimem2) && @mondata.skill>=BESTSKILL
					when :ANALYTIC
						#abilityscore+=30 if !pbAIfaster?(nil,nil,i,@opponent)
						#abilityscore+=30 if (@opponent.pbPartner.hp > 0 && !pbAIfaster?(nil,nil,i,@opponent.pbPartner))
					when :ILLUSION
						abilityscore+=40
					when :MOXIE,:BEASTBOOST,:SOULHEART,:GRIMNEIGH,:CHILLINGNEIGH,:ASONE
						abilityscore+=40 if pbAIfaster?(nil,nil,i,@opponent) && ((@opponent.hp.to_f)/@opponent.totalhp<0.5)
						abilityscore+=40 if (@opponent.pbPartner.hp > 0 && pbAIfaster?(nil,nil,i,@opponent.pbPartner) && ((@opponent.pbPartner.hp.to_f)/@opponent.pbPartner.totalhp<0.5))
					when :SPEEDBOOST
						abilityscore+=25 if pbAIfaster?(nil,nil,i,@opponent) && ((@opponent.hp.to_f)/@opponent.totalhp<0.3)
						abilityscore+=25 if (@opponent.pbPartner.hp > 0 && pbAIfaster?(nil,nil,i,@opponent.pbPartner) && ((@opponent.pbPartner.hp.to_f)/@opponent.pbPartner.totalhp<0.3))
					when :JUSTIFIED
						abilityscore+=30 if (@opponent.pbPartner.hp > 0 && :DARK == checkAIbestMove(@opponent,i,nil,field_on_switch_in).pbType(@opponent) || :DARK == checkAIbestMove(@opponent.pbPartner,i,nil,field_on_switch_in).pbType(@opponent.pbPartner))
					when :RATTLED
						abilityscore+=15 if [:DARK,:GHOST, :BUG].include?(checkAIbestMove(@opponent,i,nil,field_on_switch_in).pbType(@opponent)) || (@opponent.pbPartner.hp > 0 && [:DARK,:GHOST, :BUG].include?(checkAIbestMove(@opponent.pbPartner,i,nil,field_on_switch_in).pbType(@opponent.pbPartner)))
					when :IRONBARBS,:ROUGHSKIN
						#abilityscore+=30 if (@opponent.ability== :SKILLLINK)
						#abilityscore+=30 if (@opponent.pbPartner.hp > 0 && @opponent.pbPartner.ability== :SKILLLINK)
					when :PRANKSTER
						abilityscore+=50 if !pbAIfaster?(nil,nil,i,@opponent) && !@opponent.hasType?(:DARK)
						abilityscore+=50 if (@opponent.pbPartner.hp > 0 && !pbAIfaster?(nil,nil,i,@opponent.pbPartner) && !@opponent.pbPartner.hasType?(:DARK))
					when :GALEWINGS
						abilityscore+=50 if !pbAIfaster?(nil,nil,i,@opponent) && i.hp==i.totalhp && !@attacker.pbOwnSide.effects[:StealthRock]
						abilityscore+=50 if @opponent.pbPartner.hp > 0 && !pbAIfaster?(nil,nil,i,@opponent.pbPartner) && i.hp==i.totalhp && !@attacker.pbOwnSide.effects[:StealthRock]
					when :BULLETPROOF
						#abilityscore+=60 if (PBStuff::BULLETMOVE).include?(checkAIbestMove(@opponent,i,nil,field_on_switch_in).move) || (@opponent.pbPartner.hp > 0 && (PBStuff::BULLETMOVE).include?(checkAIbestMove(@opponent.pbPartner,i,nil,field_on_switch_in).move))
					when :AURABREAK
						abilityscore+=50 if (@opponent.ability== :FAIRYAURA) || (@opponent.ability== :DARKAURA)
						abilityscore+=50 if (@opponent.pbPartner.hp > 0 && (@opponent.pbPartner.ability== :FAIRYAURA) || (@opponent.pbPartner.ability== :DARKAURA))
					when :PROTEAN, :LIBERO
						abilityscore+=40 if pbAIfaster?(nil,nil,i,@opponent) || (@opponent.pbPartner.hp > 0 && pbAIfaster?(nil,nil,i,@opponent.pbPartner))
					when :DANCER
						abilityscore+=30 if checkAImoves(PBStuff::DANCEMOVE,aimem)
						abilityscore+=30 if checkAImoves(PBStuff::DANCEMOVE,aimem2) && @mondata.skill>=BESTSKILL
					when :MERCILESS
						abilityscore+=50 if @opponent.status== :POISON || (@opponent.pbPartner.hp > 0 && @opponent.pbPartner.status== :POISON)
					when :DAZZLING,:QUEENLYMAJESTY,:ARMORTAIL # Gen 9 Mod - added armor tail
						abilityscore+=20 if checkAIpriority(aimem) && (pbAIfaster?(nil,nil,@attacker,@opponent) || pbAIfaster?(nil,nil,@attacker.pbPartner,@opponent)) 
						abilityscore+=20 if checkAIpriority(aimem2) && (pbAIfaster?(nil,nil,@attacker,@opponent) || pbAIfaster?(nil,nil,@attacker.pbPartner,@opponent)) 
					when :FOREWARN # LAWDS new forewarn and sucker punch
						if !prioBlocked?()
						  suckermove = false
						  for battler in [@opponent, @opponent.pbPartner]
							next if battler==nil || battler.hp<=0
							suckermove = true if (battler.pbHasMove?(:SUCKERPUNCH) || battler.pbHasMove?(:ELECTROCLAP) || battler.pbHasMove?(:THUNDERCLAP)) && pbAIfaster?(nil,nil,@attacker,battler)
						  end
						  abilityscore+=20 if suckermove
						end
					when :SANDSTREAM,:SNOWWARNING,:SANDSTREAM,:SNOWWARNING,:SANDSPIT
						abilityscore+=70 if (@opponent.ability== :WONDERGUARD)
						abilityscore+=70 if (@opponent.pbPartner.hp > 0 && (@opponent.pbPartner.ability== :WONDERGUARD))
					when :DEFEATIST # LAWDS added hard_switch checks to sturdy
						abilityscore -= 80 if @attacker.hp != 0 && hard_switch==true # hard switch
					when :STURDY
						abilityscore -= 80 if @attacker.hp != 0 && i.hp == i.totalhp && hard_switch==true # hard switch
					when :ICESCALES
						#abilityscore+=40 if @opponent.spatk> @opponent.attack
						#abilityscore+=40 if @opponent.pbPartner.spatk> @opponent.pbPartner.attack
					when :MIRRORARMOR
						if field_on_switch_in == :STARLIGHT
							abilityscore+=20 if checkAIpriority(aimem)
							abilityscore+=20 if checkAIpriority(aimem2) && @mondata.skill>=BESTSKILL
						end
					when :UNSEENFIST
						abilityscore+=30 if checkAImoves(PBStuff::PROTECTMOVE,aimem)
						abilityscore+=30 if checkAImoves(PBStuff::PROTECTMOVE,aimem2) && @mondata.skill>=BESTSKILL
					when :WINDPOWER # Gen 9 Mod - Added Wind Power
						abilityscore+=10 if checkAIbestMove(@opponent,i,nil,field_on_switch_in).windMove? || (@opponent.pbPartner.hp>0 && checkAIbestMove(@opponent.pbPartner,i,nil,field_on_switch_in).windMove?)
					when :WINDRIDER # Gen 9 Mod - Added Wind Rider
						abilityscore+=20 if checkAIbestMove(@opponent,i,nil,field_on_switch_in).windMove? || (@opponent.pbPartner.hp>0 && checkAIbestMove(@opponent.pbPartner,i,nil,field_on_switch_in).windMove?)
					when :THERMALEXCHANGE # Gen 9 Mod - Added Thermal Exchange
						abilityscore+=30 if (@opponent.pbPartner.hp > 0 && :FIRE == checkAIbestMove(@opponent,i,nil,field_on_switch_in).pbType(@opponent) || :FIRE == checkAIbestMove(@opponent.pbPartner,i,nil,field_on_switch_in).pbType(@opponent.pbPartner))
					when :ELECTROMORPHOSIS # Gen 9 Mod - Added Electromorphosis
						abilityscore+=30 # I got no clue on the conditions, so i'mma just leave it at just a pure 30 
					when :SUPREMEOVERLORD
						abilityscore += ((40*i.pbFaintedPokemonCount) - 100) # Lawds Mod - Disfavor sending a supreme overlord mon with fewer mons fainted, favor it more the more faint
				end
				end
			end
			if transformed  #pokemon has imposter ability. because we copy pokemon, we can use i to see ability opponent
				abilityscore+=50 if (i.ability== :PUREPOWER) || (i.ability== :HUGEPOWER) || (i.ability== :MOXIE) || (i.ability== :CHILLINGNEIGH) || (i.ability== :GRIMNEIGH) || (i.ability== :SPEEDBOOST) || (i.ability== :BEASTBOOST) || (i.ability== :SOULHEART) || (i.ability== :WONDERGUARD) || (i.ability== :PROTEAN) || (i.ability== :LIBERO)
				abilityscore+=30 if (i.level>nonmegaform.level) || pbGetMonRoles(@opponent).include?(:SWEEPER)
				abilityscore = -200 if i.effects[:Substitute] > 0
				abilityscore = -500 if i.species == :DITTO
			end
			if i.ability==:COSTAR # costar favor speed boosts a lot
				abilityscore+=20 if @attacker.pbPartner.stages[PBStats::SPEED] > 0 && (pbAIfaster?(nil,nil,@attacker.pbPartner,@opponent) && pbAIfaster?(nil,nil,@attacker.pbPartner,@opponent.pbPartner))
			end
			monscore+=abilityscore
			PBDebug.log(sprintf("Abilities: %d",abilityscore)) if $INTERNAL
			#Items
			itemscore = 0
			if @mondata.skill>=HIGHSKILL
				case i.item
				when :ROCKYHELMET
					itemscore+=30 if (@opponent.ability== :SKILLLINK || @opponent.item == :LOADEDDICE)
					itemscore+=30 if (@opponent.pbPartner.ability== :SKILLLINK || @opponent.pbPartner.item == :LOADEDDICE)
					itemscore+=30 if checkAIbestMove(@opponent,i,nil,field_on_switch_in).contactMove? || (@opponent.pbPartner.hp > 0 && checkAIbestMove(@opponent.pbPartner,i,nil,field_on_switch_in).contactMove?)
				when :AIRBALLOON
					allground=true
					for j in aimem
						allground=false if !(j.pbType(@opponent) == :GROUND)
					end
					if @mondata.skill>=BESTSKILL
						for j in aimem2
							allground=false if !(j.pbType(@opponent.pbPartner) == :GROUND)
						end
					end
					itemscore+=60 if :GROUND == checkAIbestMove(@opponent,i,nil,field_on_switch_in).pbType(@opponent) || (@opponent.pbPartner.hp > 0 && :GROUND == checkAIbestMove(@opponent.pbPartner,i,nil,field_on_switch_in).pbType(@opponent.pbPartner))
					itemscore+=100 if allground
				when :FLOATSTONE
					itemscore+=10 if checkAImoves([:LOWKICK,:GRASSKNOT],aimem)
				when :DESTINYKNOT
					itemscore+=20 if (@opponent.ability== :CUTECHARM)
					itemscore+=20 if checkAImoves([:ATTRACT],aimem)
				when :ABSORBBULB
					itemscore+=25 if :WATER == checkAIbestMove(@opponent,i,nil,field_on_switch_in).pbType(@opponent) ||  (@opponent.pbPartner.hp > 0 && :WATER == checkAIbestMove(@opponent.pbPartner,i,nil,field_on_switch_in).pbType(@opponent.pbPartner))
					itemscore+=25 if field_on_switch_in == :DESERT # LAWDS - absorb bulb in desert
				when :CELLBATTERY # Lawds Mod - Electric Terrain Overlay now activates Cell Battery as well
					if !(Rejuv && (field_on_switch_in == :ELECTERRAIN || @battle.state.effects[:ELECTERRAIN] > 0) || @gonnaTerrains.include?(:ELECTERRAIN))
					itemscore+=25 if :ELECTRIC == checkAIbestMove(@opponent,i,nil,field_on_switch_in).pbType(@opponent) ||  (@opponent.pbPartner.hp > 0 && :ELECTRIC == checkAIbestMove(@opponent.pbPartner,i,nil,field_on_switch_in).pbType(@opponent.pbPartner))
					end

				when :SNOWBALL
						itemscore+=25 if :ICE == checkAIbestMove(@opponent,i,nil,field_on_switch_in).pbType(@opponent) ||  (@opponent.pbPartner.hp > 0 && :ICE == checkAIbestMove(@opponent.pbPartner,i,nil,field_on_switch_in).pbType(@opponent.pbPartner))
				when :PROTECTIVEPADS
						itemscore+=25 if (i.ability== :EFFECTSPORE) || (i.ability== :STATIC) || (i.ability== :POISONPOINT) || (i.ability== :ROUGHSKIN) || (i.ability== :WANDERINGSPIRIT) || (i.ability== :PERISHBODY && field_on_switch_in != :HOLY)  || (i.ability== :IRONBARBS) || (i.ability== :FLAMEBODY) || (i.ability== :CUTECHARM) || (i.ability== :MUMMY) || (i.ability== :AFTERMATH) || (i.ability== :GOOEY) || ((i.ability== :FLUFFY) && (!@opponent.hasType?(:FIRE) && !@opponent.pbPartner.hasType?(:FIRE))) || (@opponent.item == :ROCKYHELMET)
				when :MAGICALSEED
						itemscore+=75 if (field_on_switch_in == :NEWWORLD || (!Rejuv && field_on_switch_in == :INVERSE)) && @attacker.hp != 0 #New World or Inverse Field, hard switch		
				end
				# LAWDS - just improved sash handling and added checks for rampardos crest
				if ((i.item == :FOCUSSASH || (field_on_switch_in == :CHESS && i.pokemon.piece==:PAWN) || i.ability== :STURDY || (field_on_switch_in == :CHESS && i.ability== :STALWART)) && i.hp == i.totalhp) || (i.crested == :RAMPARDOS && i.pokemon.rampCrestUsed == false)
					can_use_sash = true
					if 	(((@battle.pbWeather== :SANDSTORM && !(i.hasType?(:ROCK) || i.hasType?(:GROUND) || i.hasType?(:STEEL)))  || (@battle.pbWeather== :HAIL && !(i.hasType?(:ICE)))) && !((i.ability== :OVERCOAT)))  || @attacker.pbOwnSide.effects[:StealthRock] ||
						@attacker.pbOwnSide.effects[:Spikes]>0 || @attacker.pbOwnSide.effects[:ToxicSpikes]>0
						if !(i.ability== :MAGICGUARD) && !(i.ability== :WONDERGUARD && field_on_switch_in == :COLOSSEUM) && !(i.crested == :RAMPARDOS && i.pokemon.rampCrestUsed == false)
							itemscore-=40
							can_use_sash = false
						end
					end
					if hard_switch==true && !(i.crested == :RAMPARDOS && i.pokemon.rampCrestUsed == false) # hard switch
						itemscore -= 80
					end
					itemscore+= (30)*@opponent.stages[PBStats::ATTACK] if can_use_sash
					itemscore+= (30)*@opponent.stages[PBStats::SPATK] if can_use_sash
					itemscore+= (30)*@opponent.stages[PBStats::SPEED] if can_use_sash
				end
			end
			monscore+=itemscore
			# lawds make erick not want to send toge while raichu is out so it can spam espeed
			if @battle.state.effects[:IonDeluge] && @attacker.pbPartner && @attacker.pbPartner.pbHasMove?(:EXTREMESPEED)
				monscore-=50
			end
			PBDebug.log(sprintf("Items: %d",itemscore)) if $INTERNAL
			#Fields
			fieldscore=0
			if @mondata.skill>=BESTSKILL
			  case field_on_switch_in
				when :ELECTERRAIN
				  	fieldscore+=50 if (i.ability== :SURGESURFER)
				  	fieldscore+=50 if Rejuv && (i.ability== :TERAVOLT)
				  	fieldscore+=25 if (i.ability== :GALVANIZE)
				  	fieldscore+=25 if Rejuv && (i.ability== :STEADFAST)
				  	fieldscore+=25 if Rejuv && (i.ability== :QUICKFEET)
				  	fieldscore+=25 if Rejuv && (i.ability== :LIGHTNINGROD)
				  	fieldscore+=25 if Rejuv && (i.ability== :BATTERY)
				  	fieldscore+=25 if (i.ability== :TRANSISTOR)
				  	fieldscore+=25 if i.hasType?(:ELECTRIC)
				  	fieldscore+=20 if Rejuv && (i.ability== :STATIC)
				  	fieldscore+=15 if Rejuv && (i.ability== :VOLTABSORB)
				when :GRASSY
				  	fieldscore+=30 if (i.ability== :GRASSPELT)
				  	fieldscore+=30 if (i.ability== :COTTONDOWN)
				  	fieldscore+=30 if Rejuv && (i.ability== :OVERGROW)
				  	fieldscore+=20 if Rejuv && (i.ability== :SAPSIPPER)
				  	fieldscore+=25 if Rejuv && (i.ability== :HARVEST)
				  	fieldscore+=25 if i.hasType?(:GRASS) || i.hasType?(:FIRE)
				when :MISTY
				  	fieldscore+=20 if i.hasType?(:FAIRY)
				  	fieldscore+=20 if (i.ability== :MARVELSCALE)
				  	fieldscore+=20 if (i.ability== :DRYSKIN)
				  	fieldscore+=20 if (i.ability== :WATERCOMPACTION)
				  	fieldscore+=25 if (i.ability== :PIXILATE)
				  	fieldscore+=25 if (i.ability== :SOULHEART)
					fieldscore+=20 if (i.ability== :PASTELVEIL)
				when :DARKCRYSTALCAVERN # LAWDS improved DCC
					fieldscore+=20 if i.hasType?(:DARK) || i.hasType?(:GHOST) || i.hasType?(:ROCK)
				  	fieldscore+=30 if (i.ability== :PRISMARMOR)
					fieldscore+=30 if (i.ability== :SHADOWSHIELD)
					fieldscore+=25 if (i.ability== :ILLUMINATE)
					fieldscore+=20 if ((i.ability== :PRESSURE) || (nonmegaform.ability== :PRESSURE))
					fieldscore+=20 if ((i.ability== :UNNERVE) || (nonmegaform.ability== :UNNERVE))
					fieldscore+=20 if ((i.ability== :RATTLED))
					fieldscore-=20 if i.ability==:MIRRORARMOR
				when :CHESS
				  	fieldscore+=10 if (i.ability== :ADAPTABILITY)
				  	fieldscore+=10 if (i.ability== :SYNCHRONIZE)
				  	fieldscore+=10 if (i.ability== :ANTICIPATION)
				  	fieldscore+=10 if (i.ability== :TELEPATHY)
				  	fieldscore+=30 if Rejuv && (i.ability== :STANCECHANGE)
				  	fieldscore+=25 if Rejuv && (i.ability== :STALL)
				when :BIGTOP
				  	fieldscore+=30 if (i.ability== :SHEERFORCE)
				  	fieldscore+=30 if (i.ability== :PUREPOWER)
				  	fieldscore+=30 if (i.ability== :HUGEPOWER)
				  	fieldscore+=30 if (i.ability== :GUTS)
				  	fieldscore+=10 if (i.ability== :DANCER)
				  	fieldscore+=20 if i.hasType?(:FIGHTING)
				  	fieldscore+=20 if (i.ability== :PUNKROCK)
					fieldscore+=30 if i.ability== :COSTAR
				when :BURNING
				  	fieldscore+=25 if i.hasType?(:FIRE)
				  	fieldscore+=15 if (i.ability== :WATERVEIL)
					fieldscore+=15 if (i.ability== :HEATPROOF)
				  	fieldscore+=15 if (i.ability== :WATERBUBBLE)
					fieldscore+=30 if (i.ability== :FLASHFIRE)
				  	fieldscore+=30 if (i.ability== :FLAREBOOST)
				  	fieldscore+=30 if (i.ability== :BLAZE)
				  	fieldscore-=30 if (i.ability== :ICEBODY)
				  	fieldscore-=30 if (i.ability== :LEAFGUARD)
				  	fieldscore-=30 if (i.ability== :GRASSPELT)
				  	fieldscore-=30 if (i.ability== :FLUFFY)
				when :VOLCANIC
					fieldscore+=25 if i.hasType?(:FIRE)
					fieldscore+=15 if (i.ability== :WATERVEIL)
					fieldscore+=15 if (i.ability== :HEATPROOF)
					fieldscore+=15 if (i.ability== :WATERBUBBLE)
					fieldscore+=20 if (i.ability== :MAGMAARMOR) || (nonmegaform.ability== :MAGMAARMOR)
					fieldscore+=20 if i.ability== :THERMALEXCHANGE # LAWDS - thermal exchange on volcanic/infernal
					fieldscore+=25 if (i.ability== :STEAMENGINE)
				  	fieldscore+=30 if (i.ability== :FLASHFIRE)
					fieldscore+=30 if (i.ability== :FLAREBOOST)
					fieldscore+=30 if (i.ability== :BLAZE)
					fieldscore-=30 if (i.ability== :ICEBODY)
					fieldscore-=30 if (i.ability== :LEAFGUARD)
					fieldscore-=30 if (i.ability== :GRASSPELT)
					fieldscore-=30 if (i.ability== :FLUFFY)
					fieldscore-=30 if (i.ability== :ICEFACE)
					#fieldscore+=30 if (@battle.doublebattle && i.pbHasMove?(:TAILWIND) && i.pbHasMove?(:DRAGONPULSE) && i.pbHasMove?(:AIRSLASH) && i.ability== :INFILTRATOR) # LAWDS - make Melia send Noivern early. disabled since it no longer has tailwind so it's got no point
				when :SWAMP
				  	fieldscore+=15 if (i.ability== :GOOEY)
				  	fieldscore+=20 if (i.ability== :WATERCOMPACTION)
					fieldscore+=15 if (i.ability== :PROPELLERTAIL)
					fieldscore+=15 if (i.ability== :STICKYHOLD) # lawds sticky hold prevents swamp drops  
				  	fieldscore+=20 if (i.ability== :DRYSKIN)
					fieldscore+=25 if (i.ability== :WATERBUBBLE) # Lawds Mod - Water Bubble boosts Defense
					fieldscore+=10 if ((i.ability== :RATTLED) || (nonmegaform.ability== :RATTLED))
					  
				when :RAINBOW
				  	fieldscore+=10 if (i.ability== :WONDERSKIN)
				  	fieldscore+=20 if (i.ability== :MARVELSCALE)
				  	fieldscore+=25 if (i.ability== :SOULHEART)
				  	#fieldscore+=30 if (i.ability== :CLOUDNINE)
				  	fieldscore+=30 if (i.ability== :PRISMARMOR)
					fieldscore+=20 if (i.ability== :PASTELVEIL)
					fieldscore-=20 if (i.ability== :NIGHTTERROR)
				when :CORROSIVE
				  	fieldscore+=20 if (i.ability== :POISONHEAL)
				  	fieldscore+=25 if (i.ability== :TOXICBOOST)
				  	fieldscore+=30 if (i.ability== :MERCILESS)
				  	fieldscore+=30 if (i.ability== :CORROSION)
				  	fieldscore+=15 if i.hasType?(:POISON)
				when :CORROSIVEMIST
				  	fieldscore+=10 if (i.ability== :WATERCOMPACTION)
				  	fieldscore+=20 if (i.ability== :POISONHEAL)
				  	fieldscore+=25 if (i.ability== :TOXICBOOST)
				  	fieldscore+=30 if (i.ability== :CORROSION)
				  	fieldscore+=15 if i.hasType?(:POISON)
				when :DESERT
					fieldscore+=20 if ((i.ability== :SANDSTREAM) || (nonmegaform.ability== :SANDSTREAM))
					fieldscore+=20 if ((i.ability== :SANDSPIT) || (nonmegaform.ability== :SANDSPIT))
				  	fieldscore+=25 if (i.ability== :SANDVEIL)
					fieldscore+=30 if (i.ability== :SANDFORCE)
					fieldscore+=20 if (i.ability== :EARTHEATER)
				  	fieldscore+=50 if (i.ability== :SANDRUSH || i.ability== :DUSTDEVIL)
				  	fieldscore+=20 if i.hasType?(:GROUND)
				  	fieldscore-=25 if i.hasType?(:ELECTRIC)
				when :ICY
				  	fieldscore+=25 if i.hasType?(:ICE)
				  	fieldscore+=25 if (i.ability== :ICEBODY)
				  	fieldscore+=25 if (i.ability== :SNOWCLOAK)
				  	fieldscore+=25 if (i.ability== :REFRIGERATE)
					fieldscore+=50 if (i.ability== :SLUSHRUSH) || (i.item == :EMPCREST && i.species == :EMPOLEON)
					fieldscore+=30 if (i.ability== :BADSEEDS)  #lawds bad seeds
				when :ROCKY
				  	fieldscore-=15 if (i.ability== :GORILLATACTICS)

					#Lawds mod 6/4/2024
					#fieldscore+=25 if (i.ability== :WEAKARMOR)
					#fieldscore+=15 if [:ROCKHEAD,:STURDY,:STAMINA,:STALWART].include?(i.ability)
					fieldscore+=25 if (i.ability== :SHARPNESS)
					fieldscore+=25 if (i.ability== :TOUGHCLAWS)
				when :FOREST
				  	fieldscore+=20 if (i.ability== :SAPSIPPER)
				  	fieldscore+=25 if i.hasType?(:GRASS) || i.hasType?(:BUG)
				  	fieldscore+=30 if (i.ability== :GRASSPELT)
				  	fieldscore+=30 if (i.ability== :OVERGROW)
				  	fieldscore+=30 if (i.ability== :SWARM)
					fieldscore+=20 if (i.ability== :EFFECTSPORE)
				when :SUPERHEATED
				  	fieldscore+=15 if i.hasType?(:FIRE)
				when :VOLCANICTOP
					fieldscore+=15 if i.hasType?(:FIRE)
					fieldscore+=25 if (i.ability== :STEAMENGINE)
					fieldscore-=30 if (i.ability== :ICEFACE)
					fieldscore+=25 if i.ability== :ROCKYPAYLOAD # LAWDS - Rocky Payload
					fieldscore+=20 if i.ability== :WINDPOWER && @battle.weather== :STRONGWINDS # LAWDS - Wind Power
				when :FACTORY
				  	fieldscore+=25 if i.hasType?(:ELECTRIC)
				  	fieldscore+=20 if (i.ability== :MOTORDRIVE)
				  	fieldscore+=20 if (i.ability== :STEELWORKER)
				  	fieldscore+=25 if (i.ability== :DOWNLOAD)
				  	fieldscore+=25 if (i.ability== :TECHNICIAN)
				  	fieldscore+=25 if (i.ability== :GALVANIZE)
				when :SHORTCIRCUIT
				  	fieldscore+=20 if (i.ability== :VOLTABSORB)
				  	fieldscore+=20 if (i.ability== :STATIC)
				  	fieldscore+=25 if (i.ability== :GALVANIZE)
				  	fieldscore+=50 if (i.ability== :SURGESURFER)
					fieldscore+=25 if (i.ability== :TECHNICIAN) # Lawds Mod - Technician Factory interaction is now on Short-Circuit as well
				  	fieldscore+=20 if (Rejuv && i.ability== :DOWNLOAD)
				  	fieldscore+=25 if i.hasType?(:ELECTRIC)
				when :WASTELAND
				  	fieldscore+=10 if i.hasType?(:POISON)
				  	fieldscore+=10 if (i.ability== :CORROSION)
				  	fieldscore+=20 if (i.ability== :POISONHEAL)
				  	fieldscore+=20 if (i.ability== :EFFECTSPORE)
				  	fieldscore+=20 if (i.ability== :POISONPOINT)
				  	fieldscore+=20 if (i.ability== :STENCH)
				  	fieldscore+=20 if (i.ability== :GOOEY)
				  	fieldscore+=25 if (i.ability== :TOXICBOOST)
				  	fieldscore+=30 if (i.ability== :MERCILESS)
				when :ASHENBEACH
				  	fieldscore+=10 if i.hasType?(:FIGHTING)
				  	fieldscore+=15 if (i.ability== :INNERFOCUS)
				  	fieldscore+=15 if (i.ability== :OWNTEMPO)
				  	fieldscore+=15 if (i.ability== :PUREPOWER)
				  	fieldscore+=15 if (i.ability== :STEADFAST)
				  	fieldscore+=20 if ((i.ability== :SANDSTREAM) || (nonmegaform.ability== :SANDSTREAM))
				  	fieldscore+=20 if (i.ability== :WATERCOMPACTION)
				  	fieldscore+=30 if (i.ability== :SANDFORCE)
				  	fieldscore+=35 if (i.ability== :SANDVEIL)
					# Lawds Mod - abilities on this here field see
				  	fieldscore+=50 if (i.ability== :SANDRUSH || i.ability== :DUSTDEVIL)
					fieldscore+=25 if (i.ability== :SHELLARMOR) || (nonmegaform.ability== :SHELLARMOR)
				when :WATERSURFACE
				  	fieldscore+=25 if i.hasType?(:WATER)
				  	fieldscore+=25 if i.hasType?(:ELECTRIC)
				  	fieldscore+=25 if (i.ability== :WATERVEIL)
				  	fieldscore+=25 if (i.ability== :HYDRATION)
				  	fieldscore+=25 if (i.ability== :TORRENT)
				  	fieldscore+=25 if (i.ability== :SCHOOLING)
				  	fieldscore+=25 if (i.ability== :WATERCOMPACTION)
				  	fieldscore+=50 if (i.ability== :SWIFTSWIM)
					fieldscore+=15 if (i.ability== :DAMP)
				  	fieldscore+=25 if (i.ability== :SURGESURFER)
				  	fieldscore+=25 if (i.ability== :STEAMENGINE)
				  	mod1=PBTypes.oneTypeEff(:WATER,i.type1)
				  	mod2=(i.type1==i.type2 || i.type2.nil?) ? 2 : PBTypes.oneTypeEff(:WATER,i.type2)
				  	fieldscore-=50 if mod1*mod2>4
				when :UNDERWATER
				  	fieldscore+=25 if i.hasType?(:WATER)
				  	fieldscore+=25 if i.hasType?(:ELECTRIC)
				  	fieldscore+=25 if (i.ability== :WATERVEIL)
				  	fieldscore+=25 if (i.ability== :HYDRATION)
				  	fieldscore+=25 if (i.ability== :TORRENT)
				  	fieldscore+=25 if (i.ability== :SCHOOLING)
				  	fieldscore+=25 if (i.ability== :WATERCOMPACTION)
				  	fieldscore+=50 if (i.ability== :SWIFTSWIM)
				  	fieldscore+=50 if (i.ability== :SURGESURFER)
					fieldscore+=15 if (i.ability== :DAMP)
					fieldscore+=25 if (i.ability== :STEAMENGINE)
					fieldscore+=25 if [:CLEARBODY,:FULLMETALBODY,:INDUSTRYSTANDARD,:STEELWORKER].include?(i.ability) && !(i.hasType?(:WATER))
				  	mod1=PBTypes.oneTypeEff(:WATER,i.type1)
				  	mod2=(i.type1==i.type2 || i.type2.nil?) ? 2 : PBTypes.oneTypeEff(:WATER,i.type2)
				  	fieldscore-=50 if mod1*mod2>4 && ![:SWIFTSWIM, :MAGICGUARD, :WATERABSORB, :STORMDRAIN].include?(i.ability)
				when :CAVE
				  	fieldscore+=15 if i.hasType?(:GROUND)
				when :GLITCH
				  	fieldscore+=20 if (Rejuv && i.ability== :DOWNLOAD)
				when :CRYSTALCAVERN
				  	fieldscore+=25 if i.hasType?(:DRAGON)
				  	fieldscore+=30 if (i.ability== :PRISMARMOR)
				when :MURKWATERSURFACE
				  	fieldscore+=25 if i.hasType?(:WATER)
				  	fieldscore+=25 if i.hasType?(:POISON)
				  	fieldscore+=25 if i.hasType?(:ELECTRIC)
				  	fieldscore+=25 if (i.ability== :SCHOOLING)
				  	fieldscore+=25 if (i.ability== :WATERCOMPACTION)
				  	fieldscore+=25 if (i.ability== :TOXICBOOST)
				  	fieldscore+=25 if (i.ability== :POISONHEAL)
				  	fieldscore+=25 if (i.ability== :MERCILESS)
				  	fieldscore+=50 if (i.ability== :SWIFTSWIM)
					fieldscore+=50 if (i.ability== :SURGESURFER)
					fieldscore+=20 if (i.ability== :FILTER) # LAWDS filter on murkwater surface
				  	fieldscore+=20 if (i.ability== :GOOEY)
					fieldscore+=20 if (i.ability== :STENCH)
				when :MOUNTAIN
				  	fieldscore+=25 if i.hasType?(:ROCK)
				  	fieldscore+=25 if i.hasType?(:FLYING)
				  	fieldscore+=20 if ((i.ability== :SNOWWARNING) || (nonmegaform.ability== :SNOWWARNING))
				  	fieldscore+=20 if ((i.ability== :DROUGHT) || (nonmegaform.ability== :DROUGHT))
				  	fieldscore+=25 if (i.ability== :LONGREACH) || i.ability== :ROCKYPAYLOAD # LAWDS - Rocky Payload
					fieldscore+=30 if (i.ability== :GALEWINGS) && @battle.weather== :STRONGWINDS
					fieldscore+=20 if i.ability== :WINDPOWER && @battle.weather== :STRONGWINDS # LAWDS - Wind Power
				when :SNOWYMOUNTAIN
				  	fieldscore+=25 if i.hasType?(:ROCK)
				  	fieldscore+=25 if i.hasType?(:FLYING)
				  	fieldscore+=25 if i.hasType?(:ICE)
				  	fieldscore+=20 if ((i.ability== :SNOWWARNING) || (nonmegaform.ability== :DROUGHT))
				  	fieldscore+=20 if ((i.ability== :DROUGHT) || (nonmegaform.ability== :DROUGHT))
				  	fieldscore+=20 if (i.ability== :ICEBODY)
				  	fieldscore+=20 if (i.ability== :SNOWCLOAK)
				  	fieldscore+=25 if (i.ability== :LONGREACH) || i.ability== :ROCKYPAYLOAD # LAWDS - Rocky Payload
				  	fieldscore+=25 if (i.ability== :REFRIGERATE)
				  	fieldscore+=30 if (i.ability== :GALEWINGS) && @battle.weather== :STRONGWINDS
					fieldscore+=50 if (i.ability== :SLUSHRUSH) || (i.item == :EMPCREST && i.species == :EMPOLEON)
					fieldscore+=20 if i.ability== :WINDPOWER && @battle.weather== :STRONGWINDS # LAWDS - Wind Power
				when :HOLY
				  	fieldscore+=20 if i.hasType?(:NORMAL)
				  	fieldscore+=20 if (i.ability== :JUSTIFIED)
					fieldscore+=25 if i.ability== :POWERSPOT
					fieldscore+=25 if i.pbHasMove?(:SALTCURE)
				when :MIRROR
					fieldscore+=25 if (i.ability== :SANDVEIL)
				  	fieldscore+=25 if (i.ability== :SNOWCLOAK)
				  	fieldscore+=25 if (i.ability== :ILLUSION)
				  	fieldscore+=25 if (i.ability== :TANGLEDFEET)
				  	fieldscore+=25 if (i.ability== :MAGICBOUNCE)
					fieldscore+=25 if (i.ability== :COLORCHANGE)
				when :DEEPEARTH # lawds added field scoring for deep earth
					fieldscore+=25 if i.hasType?(:GROUND)
					fieldscore+=20 if [:CONTRARY,:MAGNETPULL,:UNAWARE,:OBLIVIOUS].include?(i.ability)
					fieldscore+=30 if [:SPIRITEATER,:MINDSEYE].include?(i.ability)
					fieldscore-=20 if i.ability==:GALEWINGS
					fieldscore+=20 if (i.ability== :EARTHEATER)
				when :FAIRYTALE
				  	fieldscore+=25 if i.hasType?(:FAIRY)
				  	fieldscore+=25 if i.hasType?(:STEEL)
				  	fieldscore+=40 if i.hasType?(:DRAGON)
				  	fieldscore+=25 if (i.ability== :POWEROFALCHEMY)
				  	fieldscore+=25 if (i.ability== :MIRRORARMOR) || (nonmegaform.ability== :MIRRORARMOR)
				  	fieldscore+=25 if (i.ability== :PASTELVEIL)
				  	fieldscore+=25 if (i.ability== :MAGICGUARD) || (nonmegaform.ability== :MAGICGUARD)
				  	fieldscore+=25 if (i.ability== :MAGICBOUNCE)
				  	fieldscore+=25 if (i.ability== :FAIRYAURA)
				  	fieldscore+=25 if (i.ability== :BATTLEARMOR) || (nonmegaform.ability== :BATTLEARMOR)
				  	fieldscore+=25 if (i.ability== :SHELLARMOR) || (nonmegaform.ability== :SHELLARMOR)
				  	fieldscore+=25 if (i.ability== :MAGICIAN)
				  	fieldscore+=25 if (i.ability== :MARVELSCALE)
				  	fieldscore+=30 if (i.ability== :STANCECHANGE)
				  	fieldscore+=50 if (i.ability== :DAUNTLESSSHIELD)
				  	fieldscore+=50 if (i.ability== :INTREPIDSWORD)
				when :DRAGONSDEN
				  	fieldscore+=25 if i.hasType?(:FIRE)
				  	fieldscore+=50 if i.hasType?(:DRAGON)
				  	fieldscore+=20 if (i.ability== :MARVELSCALE)
				  	fieldscore+=20 if (i.ability== :MULTISCALE)
					fieldscore+=20 if ((i.ability== :MAGMAARMOR) || (nonmegaform.ability== :MAGMAARMOR))
				when :FLOWERGARDEN1,:FLOWERGARDEN2,:FLOWERGARDEN3,:FLOWERGARDEN4,:FLOWERGARDEN5
				  	fieldscore+=25 if i.hasType?(:GRASS)
				  	fieldscore+=25 if i.hasType?(:BUG)
				  	fieldscore+=20 if (i.ability== :FLOWERGIFT)
				  	fieldscore+=20 if (i.ability== :FLOWERVEIL)
				  	fieldscore+=20 if ((i.ability== :DROUGHT) || (nonmegaform.ability== :DROUGHT))
				  	fieldscore+=20 if ((i.ability== :DRIZZLE) || (nonmegaform.ability== :DRIZZLE))
				  	fieldscore+=20 if Rejuv && ((i.ability== :GRASSYSURGE) || (nonmegaform.ability== :GRASSYSURGE))
				  	fieldscore+=25 if (i.ability== :RIPEN)
				when :STARLIGHT
				  	fieldscore+=25 if i.hasType?(:PSYCHIC)
				  	fieldscore+=25 if i.hasType?(:FAIRY) && !@opponent.hasType?(:STEEL)
				  	fieldscore+=25 if i.hasType?(:DARK)
				  	fieldscore+=20 if (i.ability== :MARVELSCALE)
				  	fieldscore+=20 if (i.ability== :VICTORYSTAR)
				  	fieldscore+=25 if ((i.ability== :ILLUMINATE) || (nonmegaform.ability== :ILLUMINATE))
				  	fieldscore+=30 if (i.ability== :SHADOWSHIELD)
				when :NEWWORLD		# LAWDS - new ability bonuses on New World
				  	fieldscore+=25 if i.hasType?(:FLYING)
					fieldscore+=25 if i.hasType?(:DARK)
					fieldscore+=25 if i.hasType?(:SHADOW)
				  	fieldscore+=20 if (i.ability== :VICTORYSTAR)
					fieldscore+=25 if [:LEVITATE,:SOLARIDOL,:LUNARIDOL,:CLEARBODY,:FULLMETALBODY,:INDUSTRYSTANDARD,:PROTOSYNTHESIS,:QUARKDRIVE].include?(i.ability)
				  	fieldscore+=30 if (i.ability== :SHADOWSHIELD)
				when :INVERSE
					fieldscore+=10 if i.hasType?(:NORMAL)
					fieldscore-=10000 if i.species==:AERODACTYL && @battle.opponent!=nil && @battle.opponent.trainertype==:LEADER_ADAM # LAWDS - makes Adam more likely to send out Aerodactyl later
				  	fieldscore+=10 if i.hasType?(:ICE)
				  	fieldscore-=10 if i.hasType?(:FIRE)
				  	fieldscore-=30 if i.hasType?(:STEEL)
				when :PSYTERRAIN
					fieldscore+=25 if i.hasType?(:PSYCHIC)
					fieldscore+=25 if (i.ability== :INNERFOCUS)
				  	fieldscore+=20 if (i.ability== :PUREPOWER)
				  	fieldscore+=20 if ((i.ability== :ANTICIPATION) || (nonmegaform.ability== :ANTICIPATION))
					fieldscore+=20 if Rejuv && ((i.ability== :FOREWARN) || (nonmegaform.ability== :FOREWARN))
				  	fieldscore+=50 if (i.ability== :TELEPATHY)
					fieldscore+=25 if i.ability== :POWERSPOT
				when :DIMENSIONAL
					fieldscore+=25 if i.hasType?(:DARK)
					fieldscore+=30 if (i.ability== :SHADOWSHIELD)
					fieldscore+=30 if (i.ability== :BEASTBOOST)
					fieldscore+=30 if (i.ability== :PERSIHBODY)
					fieldscore+=20 if ((i.ability== :RATTLED) || (nonmegaform.ability== :RATTLED))
					fieldscore+=20 if ((i.ability== :BERSERK) || (nonmegaform.ability== :BERSERK))
					fieldscore+=20 if ((i.ability== :ANGERPOINT) || (nonmegaform.ability== :ANGERPOINT))
					fieldscore+=20 if ((i.ability== :JUSTIFIED) || (nonmegaform.ability== :JUSTIFIED))
					fieldscore+=20 if ((i.ability== :PRESSURE) || (nonmegaform.ability== :PRESSURE))
					fieldscore+=20 if ((i.ability== :UNNERVE) || (nonmegaform.ability== :UNNERVE))
					fieldscore+=50 if i.item == :MAGICALSEED && (i.pbSpeed < @opponent.pbSpeed) # LAWDS - AI accounts for powerful Trick Room effect
					fieldscore-=50 if i.item == :MAGICALSEED && (@opponent.pbSpeed < i.pbSpeed) # LAWDS - AI accounts for powerful Trick Room effect
				when :FROZENDIMENSION
					fieldscore+=25 if i.hasType?(:ICE)
					fieldscore+=25 if i.hasType?(:DARK)
					fieldscore+=25 if (i.ability== :ICEBODY)
				  	fieldscore+=25 if (i.ability== :SNOWCLOAK)
				  	fieldscore+=25 if (i.ability== :REFRIGERATE)
					fieldscore+=50 if (i.ability== :SLUSHRUSH) || (i.item == :EMPCREST && i.species == :EMPOLEON)
					fieldscore+=(25 + (25*@battle.field.counter)) if (i.ability== :BADSEEDS)  #lawds bad seeds
					fieldscore+=25 if (i.ability== :ICEFACE)
					fieldscore+=20 if ((i.ability== :RATTLED) || (nonmegaform.ability== :RATTLED))
					fieldscore+=20 if ((i.ability== :BERSERK) || (nonmegaform.ability== :BERSERK))
					fieldscore+=20 if ((i.ability== :ANGERPOINT) || (nonmegaform.ability== :ANGERPOINT))
					fieldscore+=20 if ((i.ability== :JUSTIFIED) || (nonmegaform.ability== :JUSTIFIED))
					fieldscore+=20 if ((i.ability== :PRESSURE) || (nonmegaform.ability== :PRESSURE))
					fieldscore+=20 if ((i.ability== :UNNERVE) || (nonmegaform.ability== :UNNERVE))
				when :HAUNTED
					fieldscore+=25 if i.hasType?(:GHOST)
					fieldscore+=25 if i.ability== :RATTLED
					if i.ability== :CURSEDBODY
						fieldscore+=15 
						fieldscore+=20 if i.hasType?(:GHOST)
					end
					fieldscore+=25 if i.ability== :PERISHBODY
					fieldscore+=25 if i.ability== :POWERSPOT
					if i.ability== :PURIFYINGSALT	&& @battle.canChangeFE?(:HOLY)	# LAWDS - Purifying Salt purifies Haunted
						to_holy_score = getFieldDisruptScore(i, @opponent, :HOLY)
						fieldscore+=100 if to_holy_score > 1
						fieldscore-=100 if to_holy_score < 1
					end
					fieldscore+=25 if [:SPIRITSENVOY,:SPIRITEATER].include?(i.ability)
				when :CORRUPTED
					fieldscore+=25 if i.hasType?(:POISON)
					fieldscore-=25 if [:GRASSPELT,:LEAFGUARD,:FLOWERVEIL].include?(i.ability)
					fieldscore+=25 if i.ability== :POISONHEAL
					fieldscore+=15 if [:WONDERSKIN,:IMMUNITY,:PASTELVEIL].include?(i.ability)
					fieldscore+=15 if [:POISONTOUCH,:POISONPOINT].include?(i.ability)
					fieldscore+=15 if i.ability== :LIQUIDOOZE
					fieldscore+=30 if [:TOXICBOOST,:CORROSION].include?(i.ability)
					if i.ability== :DRYSKIN
						fieldscore+=25 if i.hasType?(:POISON)
						fieldscore-=25 if !i.hasType?(:POISON)
					end
				when :BEWITCHED
					fieldscore+=20 if i.ability== :FLOWERVEIL
				  	fieldscore+=25 if i.hasType?(:GRASS) || i.hasType?(:FAIRY)
				  	fieldscore+=25 if i.ability== :NATURALCURE
				  	fieldscore+=25 if i.ability== :PASTELVEIL
					fieldscore+=25 if i.ability== :COTTONDOWN
				  	fieldscore+=25 if i.ability== :POWERSPOT
					fieldscore+=20 if i.ability== :EFFECTSPORE
				when :SKY
					fieldscore+=15 if i.ability== :EARLYBIRD
					fieldscore+=15 if i.ability== :CLOUDNINE
				  	fieldscore+=25 if i.hasType?(:FLYING)
				  	fieldscore+=25 if i.ability== :GALEWINGS
				  	fieldscore+=25 if i.ability== :BIGPECKS || nonmegaform.ability== :BIGPECKS
					fieldscore+=25 if i.ability== :LEVITATE || nonmegaform.ability== :LEVITATE
					fieldscore+=30 if (i.ability== :SOLARPOWER) && ![:RAINDANCE, :HAIL, :SANDSTORM].include?(@battle.pbWeather) # LAWDS - solar power on sky
					fieldscore+=25 if i.ability== :SOLARIDOL || nonmegaform.ability== :SOLARIDOL
					fieldscore+=25 if i.ability== :LUNARIDOL || nonmegaform.ability== :LUNARIDOL
				  	fieldscore+=30 if i.ability== :AERILATE
					fieldscore+=30 if i.ability== :LONGREACH
					fieldscore+=40 if i.ability== :ROCKYPAYLOAD  # LAWDS - Rocky Payload
					fieldscore+=30 if i.ability== :WINDPOWER && @battle.weather== :STRONGWINDS # LAWDS - Wind Power
					fieldscore+=50 if i.ability== :DANCER && i.pbOwnSide.effects[:Tailwind] != 0
					fieldscore+=25 if [:RECKLESS,:NOGUARD].include?(i.ability) && i.pbOwnSide.effects[:Tailwind] != 0 # lawds no guard/reckless on sky with tailwind
					fieldscore+=25 if i.ability==:TANGLEDFEET
					fieldscore+=25 if i.ability==:COSTAR && pbAIfaster?(nil,nil,i,@opponent)
				when :INFERNAL
					fieldscore+=25 if i.hasType?(:FIRE)
					fieldscore+=25 if i.hasType?(:DARK)
					# LAWDS infernal interactions
					fieldscore+=15 if i.hasType?(:GHOST)
					if (!i.isAirborne?(field_on_switch_in) || i.effects[:infernalPain]) && i.burningFieldPassiveDamage?
						fieldscore+=15 if i.ability== :DEFIANT
						fieldscore+=15 if i.ability== :COMPETITIVE
					end
					fieldscore+=25 if (i.ability== :PERSIHBODY)
					fieldscore+=20 if i.ability== :THERMALEXCHANGE
					fieldscore+=20 if i.ability== :STEADFAST
					fieldscore+=20 if i.ability== :AFTERMATH
					fieldscore+=20 if i.ability== :MERCILESS
					fieldscore+=30 if (i.ability== :MAGMAARMOR) || (nonmegaform.ability== :MAGMAARMOR)
					fieldscore+=20 if (i.ability== :FLAMEBODY) || (nonmegaform.ability== :FLAMEBODY)
					fieldscore+=20 if (i.ability== :DESOLATELAND) || (nonmegaform.ability== :DESOLATELAND)
					fieldscore+=20 if (i.pbHasMove?(:RAGEFIST))
					fieldscore+=25 if i.ability==:SUPREMEOVERLORD
					# LAWDS - dimensional interactions on infernal
					fieldscore+=10 if ((i.ability== :RATTLED) || (nonmegaform.ability== :RATTLED))
					fieldscore+=20 if ((i.ability== :BERSERK) || (nonmegaform.ability== :BERSERK))
					fieldscore+=20 if ((i.ability== :ANGERPOINT) || (nonmegaform.ability== :ANGERPOINT))
					fieldscore+=20 if ((i.ability== :JUSTIFIED) || (nonmegaform.ability== :JUSTIFIED))
					fieldscore+=25 if (i.ability==:WILDFIRE)
					fieldscore+=25 if (i.ability== :STEAMENGINE)
				  	fieldscore+=30 if (i.ability== :FLASHFIRE)
					fieldscore+=30 if (i.ability== :FLAREBOOST)
					fieldscore+=30 if (i.ability== :BLAZE)
					fieldscore-=20 if (i.ability== :PASTELVEIL)
					fieldscore-=30 if (i.ability== :ICEFACE)
				when :COLOSSEUM
					fieldscore+=15 if i.ability== :STALWART
					fieldscore-=30 if i.ability== :RATTLED || i.ability== :WIMPOUT
				  	fieldscore+=25 if i.ability== :WONDERGUARD
					fieldscore+=25 if i.ability== :QUICKDRAW
					fieldscore+=25 if i.ability== :EMERGENCYEXIT || i.ability== :HITANDRUN # LAWDS - Hit and Run
				  	fieldscore+=25 if (i.ability== :BATTLEARMOR) || (nonmegaform.ability== :BATTLEARMOR)
				  	fieldscore+=25 if (i.ability== :SHELLARMOR) || (nonmegaform.ability== :SHELLARMOR)
					fieldscore+=25 if (i.ability== :MIRRORARMOR) || (nonmegaform.ability== :MIRRORARMOR)
				  	fieldscore+=25 if (i.ability== :MAGICGUARD) || (nonmegaform.ability== :MAGICGUARD)
				  	fieldscore+=25 if i.ability== :SKILLLINK
					fieldscore+=30 if i.ability== :NOGUARD || (nonmegaform.ability== :NOGUARD)
					fieldscore+=50 if (i.ability== :DAUNTLESSSHIELD)
				  	fieldscore+=50 if (i.ability== :INTREPIDSWORD)
				when :CONCERT1,:CONCERT2,:CONCERT3,:CONCERT4
					fieldscore+=25 if (i.ability== :TECHNICIAN)
					fieldscore+=25 if ([:HEAVYMETAL,:SOLIDROCK,:ROCKHEAD,:PUNKROCK,:SOUNDPROOF].include?(i.ability))
					fieldscore+=15 if i.ability== :PUNKROCK && @battle.ProgressiveFieldCheck(PBFields::CONCERT,3,4)
					fieldscore+=40 if i.ability== :SURGESURFER && @battle.ProgressiveFieldCheck(PBFields::CONCERT,3,4)
					fieldscore+=15 if ([:HEAVYMETAL,:SOLIDROCK,:PUNKROCK,:GALVANIZE,:PLUS].include?(i.ability)) && @battle.ProgressiveFieldCheck(PBFields::CONCERT,1,3)
					fieldscore-=15 if ([:KLUTZ,:MINUS].include?(i.ability)) && @battle.ProgressiveFieldCheck(PBFields::CONCERT,2,4)
					fieldscore+=25 if ([:RUNAWAY,:EMERGENCYEXIT].include?(i.ability)) && @battle.ProgressiveFieldCheck(PBFields::CONCERT,2,4)
					fieldscore+=30 if (i.ability== :RATTLED) && @battle.ProgressiveFieldCheck(PBFields::CONCERT,3,4)
					fieldscore+=30 if i.ability== :COSTAR && @battle.ProgressiveFieldCheck(PBFields::CONCERT,4)
					fieldscore+=30 if i.ability== :INTIMIDATE && (@opponent.ability != :DEFIANT && @opponent.ability != :COMPETITIVE) && !@battle.doublebattle && i.pbHasMove?(:FLING) # LAWDS - hi amber incineroar hiiiii
					fieldscore+=30 if (i.ability== :RATTLED) && @battle.ProgressiveFieldCheck(PBFields::CONCERT,3,4) && !(@battle.doublebattle) && i.pbHasMove?(:BATONPASS) # LAWDS - Jenner baton pass chicanery
					fieldscore+=30 if i.ability== :OWNTEMPO
				when :BACKALLEY
					fieldscore+=25 if i.hasType?(:DARK)
					fieldscore+=20 if i.hasType?(:POISON)
					fieldscore+=20 if i.hasType?(:BUG)
					fieldscore+=20 if i.hasType?(:STEEL)
					fieldscore-=25 if i.hasType?(:FAIRY)
					fieldscore+=20 if (i.ability== :STENCH)
					fieldscore+=25 if (i.ability== :DOWNLOAD)
					fieldscore+=25 if ((i.ability== :PICKPOCKET) || (nonmegaform.ability== :PICKPOCKET))
					fieldscore+=25 if ((i.ability== :MERCILESS) || (nonmegaform.ability== :MERCILESS))
					fieldscore+=25 if ((i.ability== :MAGICIAN) || (nonmegaform.ability== :MAGICIAN))
					fieldscore+=25 if ((i.ability== :ANTICIPATION) || (nonmegaform.ability== :ANTICIPATION))
					fieldscore+=25 if ((i.ability== :FOREWARN) || (nonmegaform.ability== :FOREWARN))
					fieldscore+=25 if ((i.ability== :RATTLED) || (nonmegaform.ability== :RATTLED))
					fieldscore+=20 if i.ability== :DEFIANT
				when :CITY
					fieldscore+=25 if i.hasType?(:NORMAL)
					fieldscore+=20 if i.hasType?(:POISON)
					fieldscore+=20 if i.hasType?(:BUG)
					fieldscore+=20 if i.hasType?(:STEEL)
					fieldscore-=20 if i.hasType?(:FAIRY)
					fieldscore+=20 if (i.ability== :STENCH)
					fieldscore+=25 if (i.ability== :DOWNLOAD)
					fieldscore+=25 if ((i.ability== :BIGPECKS) || (nonmegaform.ability== :BIGPECKS))
					fieldscore+=25 if ((i.ability== :PICKUP) || (nonmegaform.ability== :PICKUP))
					fieldscore+=25 if ((i.ability== :EARLYBIRD) || (nonmegaform.ability== :EARLYBIRD))
					fieldscore+=25 if ((i.ability== :RATTLED) || (nonmegaform.ability== :RATTLED))
					fieldscore+=20 if (i.ability== :HUSTLE)
					fieldscore+=20 if ((i.ability== :FRISK) || (nonmegaform.ability== :FRISK))
					fieldscore+=20 if i.ability== :COMPETITIVE
				when :CLOUDS
					fieldscore+=25 if i.hasType?(:FLYING)
					fieldscore+=20 if (i.ability== :CLOUDNINE)
					fieldscore+=20 if (i.ability== :FLUFFY)
					fieldscore+=20 if (i.ability== :HYDRATION)
					fieldscore+=20 if (i.ability== :FORECAST)
					fieldscore+=20 if (i.ability== :OVERCOAT)
				when :DARKNESS1
					fieldscore+=10 if i.hasType?(:DARK)
					fieldscore+=10 if (i.ability== :DARKAURA)
					fieldscore-=10 if (i.ability== :FAIRYAURA)
					fieldscore+=20 if (i.ability== :RATTLED)
				when :DARKNESS2
					fieldscore+=20 if i.hasType?(:DARK)
					fieldscore+=20 if (i.ability== :DARKAURA)
					fieldscore-=20 if (i.ability== :FAIRYAURA)
					fieldscore+=20 if (i.ability== :RATTLED)
					fieldscore-=20 if (i.ability== :INSOMNIA)
					fieldscore+=20 if (i.ability== :BADDREAMS)
					fieldscore+=20 if (i.ability== :SHADOWSHIELD)
				when :DARKNESS3
					fieldscore+=40 if i.hasType?(:DARK)
					fieldscore+=40 if (i.ability== :DARKAURA)
					fieldscore-=40 if (i.ability== :FAITTLED)
					fieldscore-=20 if (i.ability== :INSOMNIA)
					fieldscore+=40 if (i.ability== :BADDREAMS)
					fieldscore+=20 if (i.ability== :SHADOWSHIELD)
				when :DANCEFLOOR
					fieldscore+=10 if i.hasType?(:GHOST)
					fieldscore+=10 if i.hasType?(:DARK)
					fieldscore+=20 if i.hasType?(:PSYCHIC)
					fieldscore+=20 if (i.ability== :INSOMNIA)
					fieldscore+=20 if (i.ability== :MAGICGUARD)
					fieldscore+=10 if (i.ability== :MAGICIAN)
					fieldscore+=40 if (i.ability== :DANCER)
					fieldscore+=20 if (i.ability== :ILLUMINATE)
				when :CROWD
					fieldscore+=20 if (i.ability== :GUTS)
					fieldscore+=10 if (i.ability== :INNERFOCUS)
					fieldscore+=30 if (i.ability== :INTIMIDATE)
					fieldscore+=20 if (i.ability== :IRONFIST)
			  end
			end
			monscore += fieldscore
			PBDebug.log(sprintf("Fields: %d",fieldscore)) if $INTERNAL
			#Other
			otherscore = 0
			otherscore -= 70 if hard_switch==true && @attacker.species == i.species
			#otherscore -= 50 if hard_switch && i.hasMega? # LAWDS - dont switch in megas so easily ok?
			otherscore -= 100 if @opponent.ability== :WONDERGUARD && roughdamagearray[0].max == 0
			if @attacker.effects[:FutureSight] >= 1
				move, moveuser = @attacker.pbFutureSightUserPlusMove
				damage = hard_switch==true ? pbRoughDamage(move,moveuser,nonmegaform) : pbRoughDamage(move,moveuser,i)
				otherscore += 50 if damage == 0
				otherscore += 50 if damage < i.hp
				otherscore += 50 if 2*damage < i.hp
				otherscore -= 100 if damage > i.hp
			end
			
			monscore += otherscore
			PBDebug.log(sprintf("Other Score: %d",otherscore)) if $INTERNAL

			if @attacker.pbOwnSide.effects[:StealthRock] || @attacker.pbOwnSide.effects[:Spikes]>0
			  monscore= (monscore*(i.hp.to_f/i.totalhp.to_f)).floor
			end
			hazpercent = totalHazardDamage(nonmegaform,field_on_switch_in)
			monscore=1 if hazpercent>(i.hp.to_f/i.totalhp)*100
			# more likely to send out ace the fewer party members are alive
			# Lawds Mod - relegated the Ace role to only affect certain pokemon on certain fights
			# Lawds make Silvally come later in GZ. buffer score so it will still send silv if there are no good mons (thus making tailwind good)
			zoroparty = i.index==2 ? @battle.pbPartySingleOwner(2) : party
			zorocheck=zoroparty.any? {|mon| mon && mon.hp>0 && (mon.ability==:ILLUSION || (mon.species==:ZOROARK))}
			silvcheck = i.species==:SILVALLY && i.ability==:GALEWINGS && @battle.opponent && @battle.opponent.is_a?(Array) && @battle.opponent[0].trainertype==:XENEXECUTIVE_1

			if (i.index==2 && @battle.opponent && !@battle.opponent.is_a?(Array) && @battle.opponent.trainertype==:MASTEROFNIGHTMARES) || 
			   (i.species==:REGIROCK && i.form==2) || # rift aelita
			   (i.species==:GENESECT && !@battle.doublebattle) ||
			   (i.item==:KINGSROCK) || # king's rock effect
			   (i.species==:GARBODOR && i.form==2) || # rift garbodor
			   (i.species==:REGICE && field_on_switch_in==:FROZENDIMENSION) ||
			   @opponent.species == :DARKRAI || (zorocheck && i.species!=:ZOROARK && theseRoles.include?(:ACE)) || silvcheck
				partyacedrop = 0.9 - 0.1 * party.count {|mon| mon && mon.hp > 0}
				partyacedrop*=0.8
				partyacedrop*=0.6 if (zorocheck && i.species!=:ZOROARK && theseRoles.include?(:ACE) && i.species==:GIRATINA)
				if silvcheck || i.species==:REGICE
					partyacedrop += 0.2
					partyacedrop += 0.1 if silvcheck
					partyacedrop = 1 if partyacedrop > 1
				end
				monscore*= partyacedrop if monscore > 0
			end

			monscore*=1.2 if i.crested == :ZOROARK && monscore > 0
			if monscore > 0 && @battle.opponent && !@battle.opponent.is_a?(Array) && @battle.opponent.trainertype==:RIFT_HIPPO
				monscore*=0.3 if i.pbPartner.hp > 0 && i.ability!=:STALL && i.pbPartner.ability!=:STALL && pbPartyHasAbility?(:STALL, i.index, false)
				monscore*=0.3 if i.pbPartner.hp > 0 && i.ability==:STALL && i.pbPartner.ability==:STALL
			end
			#Final score
			monscore=monscore.floor
			PBDebug.log(sprintf("Final Pokemon Score: %d \n",monscore)) if $INTERNAL
			$ai_log_data[@attacker.index].switch_scores.push(monscore)
			$ai_log_data[@attacker.index].switch_name.push(getMonName(i.pokemon.species))
			partyScores.push(monscore)
			@gonnaTerrains = []
			@gonnaWeather = 0
		end

		# NOT DOING BEFORE E19 PUBLIC RELEASE
		# If the whole party would just die, check specific things
		# LAWDS added stipulations to the doublebattle checks to catch nils in the event that the opponent has no partner
		if survivors.none? { |lives| lives }
      		opponent = pbCloneBattler(firstOpponent().index, illusionCheck(firstOpponent(), @battle.battlers[firstOpponent().index]))
			opponent2 = pbCloneBattler(firstOpponent().pbPartner.index, illusionCheck(firstOpponent().pbPartner, @battle.battlers[firstOpponent().pbPartner.index])) if @battle.doublebattle && !@opponent.isbossmon
			  
     		 # innards out
      		for mon in partycheck.find_all{ |mon| mon.ability== :INNARDSOUT}
        		partyScores[mon.pokemonIndex] += 500 if (@battle.doublebattle && opponent2 != nil && mon.hp >= opponent2.hp) || mon.hp >= opponent.hp
			end
			  

			# LAWDS red card/dust devil to phase
			if opponent.pbNonActivePokemonCount>0
				for mon in partycheck.find_all{ |mon| mon.item==:REDCARD || (mon.ability==:DUSTDEVIL && field_on_switch_in==:DESERT)}
			  		partyScores[mon.pokemonIndex] += 500 
		    	end
			end

      		if opponent.ability != :MAGICGUARD && opponent.item != :PROTECTIVEPADS && opponent.ability != :LONGREACH
        		# aftermath
        		aftermathdmg = [:CORROSIVEMIST,:MURKWATERSURFACE].include?(field_on_switch_in) ? 50 : 25
        		for mon in partycheck.find_all{ |mon| mon.ability== :AFTERMATH}
          		if aftermathdmg >= (opponent.hp.to_f / opponent.totalhp) * 100	# LAWDS aftermath on infernal
            		partyScores[mon.pokemonIndex] += 200 if checkAIbestMove(opponent, mon, nil,field_on_switch_in).contactMove? || field_on_switch_in==:INFERNAL
          		elsif @battle.doublebattle && opponent2 != nil && (aftermathdmg >= (opponent2.hp.to_f / opponent2.totalhp) * 100)
            		partyScores[mon.pokemonIndex] += 200 if checkAIbestMove(opponent2, mon).contactMove? || field_on_switch_in==:INFERNAL
         		end
			end
			

        	# Rocky Helmet
        	helmetdmg = (1/6 * 10)
        	for mon in partycheck.find_all{ |mon| mon.ability}
          		if helmetdmg >= (opponent.hp.to_f / opponent.totalhp) * 100
            		partyScores[mon.pokemonIndex] += 200 if checkAIbestMove(opponent, mon, nil,field_on_switch_in).contactMove?
          		elsif @battle.doublebattle && opponent2 != nil && (helmetdmg >= (opponent2.hp.to_f / opponent2.totalhp) * 100)
            		partyScores[mon.pokemonIndex] += 200 if checkAIbestMove(opponent2, mon, nil,field_on_switch_in).contactMove?
          		end
        	end

       		# Contact Abilities
        	contactdmg = 12.5
        	for mon in partycheck.find_all{ |mon| mon.ability== :IRONBARBS || mon.ability== :ROUGHSKIN}
          		if contactdmg >= (opponent.hp.to_f / opponent.totalhp) * 100
            		partyScores[mon.pokemonIndex] += 200 if checkAIbestMove(opponent, mon, nil,field_on_switch_in).contactMove?
          		elsif @battle.doublebattle && opponent2 != nil && (contactdmg >= (opponent2.hp.to_f / opponent2.totalhp) * 100)
            		partyScores[mon.pokemonIndex] += 200 if checkAIbestMove(opponent2, mon, nil,field_on_switch_in).contactMove?
          		end
        	end
      	end
      	# intimidate # lawds added fullmetalbody and clear amulet to the consideration
      	if opponent.attack > opponent.spatk && !([:DEFIANT, :CONTRARY, :CLEARBODY, :WHITESMOKE, :HYPERCUTTER, :FULLMETALBODY].include?(opponent.ability) || ([:SCRAPPY, :OBLIVIOUS, :OWNTEMPO, :INNERFOCUS].include?(opponent.ability))) && opponent.item!=:CLEARAMULET
        	for mon in partycheck.find_all{ |mon| mon.ability== :INTIMIDATE}
          		pbStatChangingSwitchOpponent(mon,opponent,field_on_switch_in)
          		pbStatChangingSwitchOpponent(mon,opponent2,field_on_switch_in) if @battle.doublebattle && opponent2 != nil
          		for mon2 in partycheck
            		next if mon2.pokemonIndex == mon.pokemonIndex
            		incomingdamage = checkAIdamage(mon2, opponent) if @battle.doublebattle && opponent2 != nil
            		incomingdamage2 = 0
            		incomingdamage2 += checkAIdamage(mon2, opponent2) if @battle.doublebattle && opponent2 != nil
            		incomingpercentage = (incomingdamage + incomingdamage2) / mon2.hp.to_f
            		maxsingulardamage = [incomingdamage2, incomingdamage].max / mon2.hp.to_f
            		if incomingpercentage > 1.0
              			next
            		else
              			partyScores[mon.pokemonIndex] += 200
            		end
          		end
        	end
		  end
		  
		
      	opponent = pbCloneBattler(firstOpponent().index, illusionCheck(firstOpponent(), @battle.battlers[firstOpponent().index]))
      	opponent2 = pbCloneBattler(firstOpponent().pbPartner.index, illusionCheck(firstOpponent().pbPartner, @battle.battlers[firstOpponent().pbPartner.index])) if @battle.doublebattle && !@opponent.isbossmon

      	# check any move that moves before opponent

      	# prankster
      	for mon in partycheck.find_all{ |mon| mon.ability== :PRANKSTER}	# LAWDS - good as gold. add targeting checks, tailwind, rage powder, encore, etc.
        	break if (opponent.hasType?(:DARK) && !field_on_switch_in == :BEWITCHED) || (field_on_switch_in == :PSYCHICTERRAIN && !opponent.isAirborne?(field_on_switch_in)) || opponent.ability== :GOODASGOLD && !moldBreakerCheck(mon)
        	check = false
        	check = true if mon.moves.any? { |moveloop| moveloop != nil && moveloop.basedamage == 0 && (PBStuff::SLEEPMOVE.include?(moveloop) && opponent.pbCanSleep?(false, false))}
        	check = true if mon.moves.any? { |moveloop| moveloop != nil && moveloop.basedamage == 0 && (PBStuff::PARAMOVE.include?(moveloop) && opponent.pbCanParalyze?(false, false))} && (pbRoughStat(@opponent, PBStats::SPEED) / 2.0) < @attacker.pbSpeed && @battle.trickroom == 0 && opponent.ability != :QUICKFEET
        	check = true if mon.moves.any? { |moveloop| moveloop != nil && moveloop.basedamage == 0 && (PBStuff::BURNMOVE.include?(moveloop) && opponent.pbCanBurn?(false, false))} && opponent.attack > opponent.spatk && opponent.ability != :GUTS
        	check = true if mon.pbHasMove?(:DISABLE) && opponent.lastMoveUsed == checkAIbestMove(mon, opponent)
        	partyScores[mon.pokemonIndex] += 300 if check
      	end

      	# damaging priority moves: do we have the needed priority moves to take the opponent out over time?
      	priosum = [0, []]
      	for mon in partycheck
        	priodam = 0
        	for move in mon.moves
          		next if !move.pbIsPriorityMoveAI(mon)
          		next if !moveSuccessful?(move, mon, opponent)
          		next if move.priority < checkAIbestMove(opponent, mon,nil,field_on_switch_in).priority || ((move.priority == checkAIbestMove(opponent, mon,nil,field_on_switch_in).priority) && !pbAIfaster?(nil, nil, mon, opponent))
          		tempdamage = pbRoughDamage(move, opponent, mon)
          		priodam = tempdamage if tempdamage >= priodam
        	end
        	priosum[0] += priodam if priodam > 0
        	priosum[1].push(mon.pokemonIndex) if priodam > 0
      	end
      	if priosum[0] > opponent.hp
        	for i in priosum[1]
          		partyScores[i] += 200
        	end
      	end
      	# and see if it does anything useful, even tho not kills
      	# then modify scores based on that
    end
		return partyScores
	end

	#should the current @attacker switch out?
	def shouldSwitch?
		return -1000 if !@battle.opponent && @battle.pbIsOpposing?(@attacker.index)
		return -1000 if @battle.pbPokemonCount(@mondata.party) == 1
		return -1000 if $game_switches[:NameOverwrite] && @battle.pbPokemonCount(@mondata.party) == 2
		return -1000 if @attacker.issossmon
		return -1000 if @attacker.species==:DARKRAI && @attacker.form != 0 # LAWDS MoN
		count = 0
		for i in 0..(@mondata.party.length-1)
			next if !@battle.pbCanSwitch?(@attacker.index,i,false)
			count+=1
		end
		return -1000 if count==0
		aimem = getAIMemory(@opponent)
		aimem2 = getAIMemory(@opponent.pbPartner)
		statusscore = 0
		statscore = 0
		healscore = 0
		forcedscore = 0
		typescore = 0
		specialscore = 0
		#Statuses
		statusscore+=80 if @attacker.effects[:Curse] && @attacker.ability!=:MAGICGUARD
		statusscore+=60 if @attacker.effects[:LeechSeed]>=0 && @attacker.ability!=:MAGICGUARD
		statusscore+=60 if @attacker.effects[:Attract]>=0
		statusscore+=80 if @attacker.effects[:Confusion]>0
		
		# Gen 9 Mod - Encourage switching if being salt cured.
		if @attacker.effects[:SaltCure] && @attacker.ability!=:MAGICGUARD
    		statusscore+=60 
			statusscore+=80 if (@attacker.hasType?(:WATER) || @attacker.hasType?(:STEEL))
		end
		if @attacker.effects[:PerishSong]==2
			statusscore+=40
		elsif @attacker.effects[:PerishSong]==1
			statusscore+=200
		end
		statusscore+= (@attacker.effects[:Toxic]*15) if @attacker.effects[:Toxic]>0 && @attacker.ability!=:MAGICGUARD
		statusscore+=50 if @battle.FE!=:BEWITCHED && @attacker.ability== :NATURALCURE && !@attacker.status.nil? && !(@attacker.status==:SLEEP && @attacker.statusCount==1 && @aimondata[@opponent.index].roughdamagearray[@attacker.index].max < @attacker.hp) # lawds let sleepers stay in if you'd wake up next turn and they cant hurt you
		statusscore+=60 if @mondata.partyroles.any? {|roles| roles.include?(:CLERIC)} && !@attacker.status.nil?
		if (@attacker.pbHasMove?(:FIRSTIMPRESSION) || @attacker.crested==:FERALIGATR) && @attacker.turncount > 0 && @battle.FE!=:PSYCHICTERRAIN  # lawds first impression AI
			player_temp_Party = @battle.pbParty(0)
			num_player_mons = 0
			can_doubles_block = false
			for partyindex in 0...player_temp_Party.length
				playermon = player_temp_Party[partyindex]
				playerbattler = pbMakeFakeBattler(playermon,partyindex,false,@opponent.index)
				prioblocked = prioBlocked?(playerbattler,@attacker)
				if prioblocked && @battle.doublebattle
					can_doubles_block = true
					break
				end
				num_player_mons+=1 if playermon!=nil && playermon.hp > 0 && !playermon.isEgg? && !prioblocked
			end
			num_player_mons = 1 if num_player_mons == 0
			fimpbuttonmu = 1.25 * 6/num_player_mons
			matchups = can_doubles_block ? [0] : getPokemonMatchupArray(@attacker)
			matchups = [matchups] if matchups.is_a?(Integer)
			matchups = [0] if matchups==nil || !matchups.is_a?(Array)
			impresskills = matchups.find_all {|matchup| matchup >= fimpbuttonmu}
			statusscore+= 30*impresskills.sum/fimpbuttonmu
		end
		if @attacker.status== :SLEEP
			statusscore+=170 if checkAImoves([:DREAMEATER,:NIGHTMARE],aimem)
		end
		if @attacker.effects[:Yawn]>0 && @attacker.status!=:SLEEP && !(@attacker.pbOwnSide.effects[:SleepPenalty]) # LAWDS - increased the weighing of yawn unless its a guaranteed one-turn
			statusscore+=95
			statusscore+=55 if @attacker.pbFaintedPokemonCount < 3
		end
		# LAWDS dont keep a physical attacker in on a mon with will-o-wisp if you can't kill them before getting burned. limited to only single battles for now.
		value = getPokemonMatchupTotal(@attacker)
		if (@opponent.pbHasMove?(:WILLOWISP) || (@opponent.pbHasMove?(:PSYCHOSHIFT) && @opponent.status==:BURN)) && @attacker.pbCanBurn?(false, false) &&
			![:GUTS,:QUICKFEET].include?(@attacker.ability) && @attacker.attack > @attacker.spatk*1.1 && @attacker.hp >= @attacker.hp/3 &&
			@opponent.effects[:Taunt] <= 0 && !([:LUMBERRY, :RAWSTBERRY].include?(@attacker.item) && 
			@opponent.ability!=:UNNERVE && @opponent.pbPartner.ability!=:UNNERVE) && 
			!(@opponent.ability==:PRANKSTER && ((@attacker.hasType?(:DARK) && @battle.FE!=:BEWITCHED) || prioBlocked?(@attacker,@opponent))) &&
			!(@battle.FE==:ROCKY && @attacker.stages[PBStats::DEFENSE]>0 && !(@opponent.pbHasMove?(:PSYCHOSHIFT) && @opponent.status==:BURN))
			maxdmg = @mondata.roughdamagearray[@opponent.index].max
			willomove = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(:WILLOWISP),@opponent)
			cantKillBeforeBurn = (maxdmg < 100 || !pbAIfaster?(nil,willomove,@attacker,@opponent))
			burnswitchscore=0
			burnswitchscore+=60 if cantKillBeforeBurn
			burnswitchscore+=25 if cantKillBeforeBurn && (maxdmg < 67 || (checkAIhealing))
			burnswitchscore*=0.3 if !(@mondata.roles.include?(:SWEEPER) || @mondata.roles.include?(:TANK))
			burnswitchscore*=value
			statusscore+=(burnswitchscore.round)
		end
		# LAWDS - don't save weakened, paralyzed pokemon if you cant cure them
		statusscore -= 100 if @attacker.status==:PARALYSIS && ![:GUTS,:QUICKFEET].include?(@attacker.ability) && (@attacker.hp <= @attacker.totalhp/2 || @mondata.roles.include?(:SWEEPER)) && 
							!(@mondata.partyroles.any? {|roles| roles.include?(:CLERIC)}) && @attacker.ability!=:NATURALCURE
							
		PBDebug.log(sprintf("Initial switchscore building: Statuses (%d)",statusscore)) if $INTERNAL
		#Stat changes
		specialmove = false
		physmove = false
		for i in @attacker.moves
			next if i.nil?
			specialmove = true if i.pbIsSpecial?()
			physmove = true if i.pbIsPhysical?()
		end
		# LAWDS see how much your stats have been lowered from how much you'd get by switching in again, and use that as the comparison instead of raw stats.
		fakemon = pbCloneBattler(@attacker.index)
		fakemon.stages = Array.new(8,0)
		pbStatChangingSwitch(fakemon)
		stagedifferences = [0,0,0,0,0,0,0]
		for i in [PBStats::ATTACK, PBStats::DEFENSE, PBStats::SPATK, PBStats::SPDEF, PBStats::SPEED, PBStats::ACCURACY, PBStats::EVASION]
			stagedifferences[i] = @attacker.stages[i] - fakemon.stages[i]
		end
		oppspeed = @opponent.pbSpeed
		if @mondata.roles.include?(:SWEEPER) || @mondata.roles.include?(:STALLBREAKER)
			statscore+= (-15)*stagedifferences[PBStats::ATTACK] if stagedifferences[PBStats::ATTACK]<0 && physmove  && (move.pbCritRate?(@attacker, @opponent) < 3)
			statscore+= (-15)*stagedifferences[PBStats::SPATK] if stagedifferences[PBStats::SPATK]<0 && specialmove && (move.pbCritRate?(@attacker, @opponent) < 3)
			statscore+= (-15)*stagedifferences[PBStats::SPEED] if stagedifferences[PBStats::SPEED]<0 && @battle.trickroom==0 && fakemon.pbSpeed > oppspeed && @attacker.pbSpeed < oppspeed # lawds only care abt speed stages if they cause you to underspeed
			statscore+= (-15)*stagedifferences[PBStats::ACCURACY] if stagedifferences[PBStats::ACCURACY]<0
			statscore+= (-5)*(@battle.getBattlerHit(@attacker)) if @attacker.pbHasMove?(:RAGEFIST) # LAWDS - prefer staying in slightly more the stronger Rage Fist is
		else
			statscore+= (-10)*stagedifferences[PBStats::ATTACK] if stagedifferences[PBStats::ATTACK]<0 && physmove && (move.pbCritRate?(@attacker, @opponent) < 3)
			statscore+= (-10)*stagedifferences[PBStats::SPATK] if stagedifferences[PBStats::SPATK]<0 && specialmove && (move.pbCritRate?(@attacker, @opponent) < 3)
			statscore+= (-10)*stagedifferences[PBStats::SPEED] if stagedifferences[PBStats::SPEED]<0 && @battle.trickroom==0 && fakemon.pbSpeed > oppspeed && @attacker.pbSpeed < oppspeed
			statscore+= (-15)*stagedifferences[PBStats::ACCURACY] if stagedifferences[PBStats::ACCURACY]<0
		end
		if @mondata.roles.include?(:PHYSICALWALL)
			statscore+= (-20)*stagedifferences[PBStats::DEFENSE] if stagedifferences[PBStats::DEFENSE]<0
		else
			statscore+= (-10)*stagedifferences[PBStats::DEFENSE] if stagedifferences[PBStats::DEFENSE]<0
		end
		if @mondata.roles.include?(:SPECIALWALL)
			statscore+= (-20)*stagedifferences[PBStats::SPDEF] if stagedifferences[PBStats::SPDEF]<0
		else
			statscore+= (-10)*stagedifferences[PBStats::SPDEF] if stagedifferences[PBStats::SPDEF]<0
		end
		PBDebug.log(sprintf("Initial switchscore building: Stat Stages (%d)",statscore)) if $INTERNAL
		#Healing potential
		healscore+=30 if (@attacker.hp.to_f)/@attacker.totalhp<(2/3) && @attacker.ability== :REGENERATOR
		healscore+=30 if (@attacker.pbPartner.hp.to_f)/@attacker.pbPartner.totalhp<(3/4) && @attacker.ability== :HOSPITALITY	# Gen 9 Mod - Hospitality
		if @attacker.effects[:Wish]>0
			for i in @mondata.party
				next if i.nil? || i.hp == 0 || @mondata.party.index(i) == @attacker.pokemonIndex
				if i.hp > 0.3*i.totalhp && i.hp < 0.6*i.totalhp
					healscore+=40
					break
				end
			end
		end
		PBDebug.log(sprintf("Initial switchscore building: Healing (%d)",healscore)) if $INTERNAL
		#Force-out conditions
		bothimmune = true
		bothimmune = false if @attacker.species==:COSMOEM && Reborn # for postgame only
		for i in @attacker.moves
			next if i.nil?
			tricktreat = true if i.move==:TRICKORTREAT
			forestcurse = true if i.move==:FORESTSCURSE
			dmark = true if i.move==:DESERTSMARK # lawds added desert's mark to this
			notnorm = true if i.type != (:NORMAL)
			notelec = true if i.type != :ELECTRIC
			bothimmune = false if i.move==:DESTINYBOND

			for oppmon in [@opponent, @opponent.pbPartner]
				next if oppmon.hp <= 0
				bothimmune = false if [0x05,0x06,0x017].include?(i.function) && i.basedamage==0 && (oppmon.pbCanPoison?(false,false,i.move==:TOXIC && @attacker.ability==:CORROSION) && !hydrationCheck(oppmon)) || oppmon.status == :POISON
				bothimmune = false if i.move==:PERISHSONG && !(oppmon.ability== :SOUNDPROOF && !moldBreakerCheck(@attacker,i))
				bothimmune = false if i.function == 0xdc && (!noLeechSeed(oppmon) || oppmon.effects[:LeechSeed] > -1)
				if i.basedamage > 0
					typemod = pbTypeModNoMessages(i.pbType(@attacker),@attacker,oppmon,i)
					typemod = 0 if oppmon.ability== :WONDERGUARD && typemod<=4
					bothimmune = false if typemod != 0
				end
			end
		end
		if bothimmune
			bothimmune = false if (tricktreat && notnorm) || forestcurse || (dmark && notelec)
			forcedscore+=140 if bothimmune
		end
		for i in 0...@attacker.moves.length
			next if @attacker.moves[i].nil? || !@battle.pbCanChooseMove?(@attacker.index,i,false)
			haspp = true if @attacker.moves[i].pp != 0
		end
		forcedscore+=200 if !haspp
		forcedscore+=30 if @attacker.effects[:Torment]
		# lawds playing around gastro acid
		if @attacker.effects[:GastroAcid] && !hasgreatmoves && @attacker.pokemon
			abil = @attacker.pokemon.ability
			if ![:TRUANT,:DEFEATIST,:GORILLATACTICS].include?(abil)
				forcedscore+=30
				forcedscore+=70 if [:HUGEPOWER,:PUREPOWER,:TOUGHCLAWS,:ADAPTABILITY,:EARLYBIRD,:SHEERFORCE,:MAGICGUARD,:UNAWARE,:POISONHEAL,:GUTS,:QUICKFEET,:PROTEAN,:LIBERO].include?(abil)
				forcedscore+=50 if abil==:POISONHEAL
			end
		end
		forcedscore-=200 if @attacker.item==:LIFEORB && ![:SHEERFORCE,:MAGICGUARD,:REGENERATOR].include?(@attacker.ability) && @attacker.hp <= @attacker.totalhp/10 # lawds
		if @attacker.effects[:Encore]>0
			if @opponent.hp>0
				encoreScore = @mondata.scorearray[@opponent.index][@attacker.effects[:EncoreIndex]]
			elsif @opponent.pbPartner.hp>0
				encoreScore = @mondata.scorearray[@opponent.pbPartner.index][@attacker.effects[:EncoreIndex]]
			else
				encoreScore = 100
			end
			forcedscore+=500 if encoreScore <= 30
			forcedscore+=110 if @attacker.effects[:Torment]
		end
		if (@attacker.item == :CHOICEBAND || @attacker.item == :CHOICESPECS || @attacker.item == :CHOICESCARF || @attacker.ability== :GORILLATACTICS) && @attacker.effects[:ChoiceBand] != nil
			for i in 0...@attacker.moves.length
				if @attacker.moves[i].move==@attacker.effects[:ChoiceBand]
					choiceindex = i
					break
				end
			end
			if choiceindex
				if @opponent.hp>0
					choiceScore = @mondata.scorearray[@opponent.index][choiceindex]
				elsif @opponent.pbPartner.hp>0
					choiceScore = @mondata.scorearray[@opponent.pbPartner.index][choiceindex]
				end
			else
				choiceScore = 0
			end
			forcedscore+=50 if choiceScore <= 50
			forcedscore+=130 if choiceScore <= 30
			forcedscore+=150 if choiceScore <= 10
		end

		# LAWDS 10/15/2024 - switch if you get outsped and killed. locked to awesome mode effects
		# to avoid serious lag, only run this code block if there are no more than 6 inactive pokemon in the party.
		hazdam = totalHazardDamage(@attacker)/100
		numMons = @battle.pbParty(@attacker.index).length - @attacker.pbFaintedPokemonCount()
		if !@battle.doublebattle && $game_variables[:DifficultyModes]==2 && @attacker.hp >= (@attacker.totalhp*0.5) && numMons <= 7 && !(@attacker.status!=nil && hydrationCheck(@attacker)) && # stay in to cure status with hydration
			((@attacker.status!=:SLEEP || @attacker.ability==:NATURALCURE)) && # dont switch out slept/frozen mons
			!(((@attacker.attack > @attacker.spatk*1.1 && @attacker.status==:BURN) || @attacker.status!=:PARALYSIS)  && ![:GUTS,:QUICKFEET,:NATURALCURE].include?(@attacker.ability)) && # don't save burned physical attackers who cant cure it or benefit from it
			((hazdam*@attacker.totalhp) <= (@attacker.hp/4).floor) # dont switch out if you're gonna take a shit load of hazard damage coming back in
			opp=@opponent
			killmoves = []
			diesOnSwitch = false
			pursuitdmg = 0
			healmove=false
			for i in 0...opp.moves.length
				move = opp.moves[i]
				next if [:COUNTER,:MIRRORCOAT,:METALBURST,:COMEUPPANCE].include?(move.move)
				next if !@battle.pbCanChooseMove?(opp.index,i,false)
				movedamage = @aimondata[opp.index].roughdamagearray[@attacker.index][i]
				killmoves.push(move) if movedamage >= 100
				if [:PURSUIT,:VILEASSAULT].include?(move.move)  # dont try to switch if ur pursuit trapped
					pursuitdmg = movedamage*2 if movedamage*2 > pursuitdmg
				end
				healmove=i if move.isHealingMove? && opp.effects[:HealBlock]==0 # dont let them trick you into giving them a free heal on the switch
			end
			pursuitdmg = (pursuitdmg.to_f/100.0 * @attacker.hp).floor
			atthp = @attacker.hp - pursuitdmg - (hazdam*@attacker.totalhp).round # check the HP this mon will have the next time it switches in
			atthp = [atthp + (@attacker.totalhp/3).round, @attacker.totalhp].min if @attacker.ability==:REGENERATOR
			if atthp <= 0
				diesOnSwitch=true
			end
			if killmoves.length > 0 && !diesOnSwitch && !(healmove && checkAIdamage(opp,@attacker)>=opp.hp) && @attacker.hp >= @attacker.totalhp*0.5
				can_move_before_dying = false
				can_kill_before_dying = false
				sash_broken = false
				for moveindex in 0... @attacker.moves.length
					move = @attacker.moves[moveindex]
					move_outspeeds_all = true
					for oppmove in killmoves
						if !pbAIfaster?(move,oppmove,@attacker,opp)
							move_outspeeds_all = false
							break
						end
					end
					if move_outspeeds_all
						can_move_before_dying = true
						movedamage = @mondata.roughdamagearray[opp.index][i]
						if (movedamage >= 100)
							can_kill_before_dying = true
							break
						elsif (movedamage>=99)
							sash_broken = true
						end
					end
				end
				if !can_kill_before_dying
					matchupscore = getPokemonMatchupTotal(@attacker)
					matchupscore *= ((@attacker.hp).to_f)/((@attacker.totalhp).to_f).to_f
					# try to preserve healthier mons
					healthscore=10
					healthscore+=10 if atthp>=@attacker.totalhp*0.7
					healthscore+=10 if atthp>=@attacker.totalhp*0.9
					healthscore-=10 if atthp<=@attacker.totalhp*0.5
					healthscore-=50 if atthp<@attacker.totalhp*0.1
					healthscore-=150 if atthp <= 0
					if atthp==@attacker.totalhp
						healthscore+=10 
						if hazdam==0
							healthscore+=5
							healthcore+=5 if [:MULTISCALE,:SHADOWSHIELD,:TERASHELL].include?(@attacker.ability)
						end
					end
					healthscore*=matchupscore if healthscore > 0
					forcedscore+=healthscore if !@battle.doublebattle
				else # if we're able to kill the opp this turn no matter what, then do not switch
					forcedscore-=350
				end
		 	# LAWDS even if we don't die this turn, think about matchups that it would be better if the AI switched out of. based on the switching AI from v13/MM. work in progress
			elsif true==false && $game_variables[:DifficultyModes]==2 && !@battle.doublebattle && !diesOnSwitch && !canKillBeforeOpponentKills(@attacker,opponent,false,field_on_switch_in)

			end
		end
		# end switching to avoid death
		PBDebug.log(sprintf("Initial switchscore building: fsteak (%d)",forcedscore)) if $INTERNAL
		#Type effectiveness
		# lawds since AI sees all your moves, it has all the calcs it needs, so no need to run estimates like these. leaving the structure in just in case
		effcheck = PBTypes.twoTypeEff(@opponent.type1,@attacker.type1,@attacker.type2)
		if effcheck > 4
			#typescore+=20
		elsif effcheck < 4
			#typescore-=20
		end
		effcheck2 = PBTypes.twoTypeEff(@opponent.type2,@attacker.type1,@attacker.type2)
		if effcheck2 > 4
			#typescore+=20
		elsif effcheck2 < 4
			#typescore-=20
		end
		if @opponent.pbPartner.totalhp !=0
			#typescore *= 0.5
			effcheck = PBTypes.twoTypeEff(@opponent.pbPartner.type1,@attacker.type1,@attacker.type2)
			if effcheck > 4
				#typescore+=10
			elsif effcheck < 4
				#typescore-=10
			end
			effcheck2 = PBTypes.twoTypeEff(@opponent.pbPartner.type2,@attacker.type1,@attacker.type2)
			if effcheck2 > 4
				#typescore+=10
			elsif effcheck2 < 4
				#typescore-=10
			end
		end
		PBDebug.log(sprintf("Initial switchscore building: Typing (%d)",typescore)) if $INTERNAL
		#Special cases
		# If the opponent just switched in to counter you
		if !@battle.doublebattle && @opponent.turncount == 0 && checkAIdamage() > @attacker.hp &&
			 @attacker.hp > (0.6 * @attacker.totalhp) && !notOHKO?(@attacker,@opponent,true)
			specialscore += 100
		# LAWDS dont switch out if you literally just switched in and you're not about to die. dont run this on leads
		elsif !@battle.doublebattle && @attacker.turncount < 2 && @battle.turncount > 1 && (checkAIdamage() < @attacker.hp) && @opponent.turncount > @attacker.turncount
			specialscore -= 200
		end
		specialscore-=150 if @attacker.crested == :BASTIODON # LAWDS this dude just kinda kills you by existing so dont switch it out
		# If future sight is about to trigger
		if @attacker.effects[:FutureSight] == 1
			move, moveuser = @attacker.pbFutureSightUserPlusMove
			damage = pbRoughDamage(move,moveuser,@attacker)
			specialscore += 50 if damage > @attacker.hp
			specialscore += 50 if 2*damage > @attacker.hp
		end
		#If opponent is in a two turn attack
		if !@battle.doublebattle && @opponent.effects[:TwoTurnAttack]!=0 #this section really doesn't work in doubles.
			twoturntype = $cache.moves[@opponent.effects[:TwoTurnAttack]].type
			for i in @mondata.party
				next if i.nil? || i.hp == 0 || @mondata.party.index(i) == @attacker.pokemonIndex
				if @attacker.moves[0].pbTypeModifierNonBattler(twoturntype,@opponent,i) < 4
					specialscore += 80
					break
				end
			end
		end
		# If trainer has unburden activated
		specialscore -= 60 if @attacker.unburdened  # LAWDS - increase the hit to switching score when unburdened from 30 to 60
		for oppmon in [@opponent,@opponent.pbPartner]
			next if oppmon.hp <= 0
			#Good Switch for two-turn attack
			if !pbAIfaster?(nil,nil,@attacker,oppmon) && oppmon.effects[:TwoTurnAttack]!=0
				twoturntype = $cache.moves[oppmon.effects[:TwoTurnAttack]].type
				bestmove = checkAIbestMove(oppmon)
				for i in @mondata.party
					next if i.nil? || i.hp == 0 || @mondata.party.index(i) == @attacker.pokemonIndex
					if bestmove.pbTypeModifierNonBattler(twoturntype,oppmon,i) < 4
						specialscore += 80 
						specialscore += 80 if bestmove.pbTypeModifierNonBattler(twoturntype,oppmon,i) < 4
						break
					end
				end
			end
			#Getting around fake out
			# lawds again dont try this prediction shit
			#if checkAImoves([:FAKEOUT],getAIMemory(oppmon)) && oppmon.turncount == 1
				#for i in @mondata.party
					#count+=1
					#next if i.nil? || i.hp == 0 || @mondata.party.index(i) == @attacker.pokemonIndex
					#if (i.ability== :STEADFAST)
						#specialscore+=90
						#break
					#end
				#end
			#end
			#punishing skill-link multi-hit contact moves
			# lawds omitted this, dont try to predict, only switch into good matchups
			#if oppmon.ability== :SKILLLINK || oppmon.item == :LOADEDDICE
				#if getAIMemory(oppmon).any? {|moveloop| moveloop!=nil && moveloop.function==0xC0 && moveloop.contactMove?}
					#for i in @mondata.party
						#next if i.nil? || i.hp == 0 || @mondata.party.index(i) == @attacker.pokemonIndex
						#if (i.item == :ROCKYHELMET) || (i.ability== :ROUGHSKIN) || (i.ability== :IRONBARBS)
							#specialscore+=70
							#break
						#end
					#end
				#end
			#end
			#Justified switch vs dark attack moves
			# LAWDS dont do this as its really just exploitable.
			#bestmove=checkAIbestMove()
			#if bestmove.pbType(@opponent) == :DARK && @attacker.ability != :JUSTIFIED
				#for i in @mondata.party
					#next if i.nil? || i.hp == 0 || @mondata.party.index(i) == @attacker.pokemonIndex
					#if i.ability==:JUSTIFIED
						#specialscore+=70
						#break
					#end
				#end
			#end
			#LAWDS Mod 7/10/2024 - Very experimental attempt to make the AI play around First Impression
			if checkAImoves([:FIRSTIMPRESSION],getAIMemory(oppmon)) && oppmon.turncount == 0 && pbTypeModNoMessages(:BUG) > 4 && !prioBlocked?()
				move = PokeBattle_Move.pbFromPBMove(@battle,PBMove.new(:FIRSTIMPRESSION),attacker)
				damage = pbRoughDamage(move,@opponent,@attacker)
				if damage > @attacker.hp/2
					specialscore+=20
					specialscore+=30 if @attacker.isMega? # Value Mega Pokemon more
					specialscore+=50 if @mondata.roles.include?(:SWEEPER) # Value Sweepers more
				end
			end
		end
		PBDebug.log(sprintf("Initial switchscore building: Specific Switches (%d)",specialscore)) if $INTERNAL
		switchscore = statusscore + statscore + healscore + forcedscore + typescore + specialscore
		PBDebug.log(sprintf("%s: initial switchscore: %d" ,getMonName(@attacker.species),switchscore)) if $INTERNAL
		statantiscore = 0
		specialmove = false
		physmove = false
		for i in @attacker.moves
			next if i.nil?
			specialmove = true if i.pbIsSpecial?()
			physmove = true if i.pbIsPhysical?()
		end
		if @mondata.roles.include?(:SWEEPER)
			statantiscore += (30)*stagedifferences[PBStats::ATTACK] if stagedifferences[PBStats::ATTACK]>0 && physmove
			statantiscore += (30)*stagedifferences[PBStats::SPATK] if stagedifferences[PBStats::SPATK]>0 && specialmove
			statantiscore += (30)*stagedifferences[PBStats::SPEED] if stagedifferences[PBStats::SPEED]>0 unless (@mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL) || @mondata.roles.include?(:TANK))
			statantiscore += (30)*@attacker.effects[:FocusEnergy]
		else
			statantiscore += (15)*stagedifferences[PBStats::ATTACK] if stagedifferences[PBStats::ATTACK]>0 && physmove
			statantiscore += (15)*stagedifferences[PBStats::SPATK] if stagedifferences[PBStats::SPATK]>0 && specialmove
			statantiscore += (15)*stagedifferences[PBStats::SPEED] if stagedifferences[PBStats::SPEED]>0 unless (@mondata.roles.include?(:PHYSICALWALL) || @mondata.roles.include?(:SPECIALWALL) || @mondata.roles.include?(:TANK))
			statantiscore += (30)*@attacker.effects[:FocusEnergy]
		end
		if @mondata.roles.include?(:PHYSICALWALL)
			statantiscore += (30)*stagedifferences[PBStats::DEFENSE] if stagedifferences[PBStats::DEFENSE]>0
		else
			statantiscore += (15)*stagedifferences[PBStats::DEFENSE] if stagedifferences[PBStats::DEFENSE]>0
		end
		if @mondata.roles.include?(:SPECIALWALL)
			statantiscore += (30)*stagedifferences[PBStats::SPDEF] if stagedifferences[PBStats::SPDEF]>0
		else
			statantiscore += (15)*stagedifferences[PBStats::SPDEF] if stagedifferences[PBStats::SPDEF]>0
		end
		statantiscore += (20)*stagedifferences[PBStats::EVASION] if stagedifferences[PBStats::EVASION]>0 && !(checkAIaccuracy(aimem) || checkAIaccuracy(aimem2))
		statantiscore += 100 if @attacker.effects[:Substitute] > 0
		PBDebug.log(sprintf("Initial noswitchscore building: Stat Stages (%d)",statantiscore)) if $INTERNAL
		hazardantiscore = 0
		hazardantiscore+= (15)*@attacker.pbOwnSide.effects[:Spikes]
		hazardantiscore+= (15)*@attacker.pbOwnSide.effects[:ToxicSpikes]
		hazardantiscore+= (15) if @attacker.pbOwnSide.effects[:StealthRock]
		hazardantiscore+= (15) if @attacker.pbOwnSide.effects[:StickyWeb]
		hazardantiscore+= (15) if (@attacker.pbOwnSide.effects[:StickyWeb] && @mondata.roles.include?(:SWEEPER))
		airmon = @attacker.isAirborne?
		hazarddam = totalHazardDamage(@attacker)
		if ((@attacker.hp.to_f)/@attacker.totalhp)*100 < hazarddam
		  	hazardantiscore+= 200
		end
		temppartyko = true
		for i in @mondata.party
			next if i.nil?
			next if @mondata.party.index(i) == @attacker.pokemonIndex
			#next if @mondata.partyroles[@mondata.party.find_index(i)].include?(:ACE) && hazardantiscore > 0	Lawds Mod - commenting this out since the Ace role is being made nonfunctional
			i = pbMakeFakeBattler(i,@mondata.party.index(i))
			temppartyko = false if ((i.hp.to_f)/i.totalhp)*100 > totalHazardDamage(i)
		end
		hazardantiscore+= 200 if temppartyko
		PBDebug.log(sprintf("Initial noswitchscore building: Entry Hazards (%d)",hazardantiscore)) if $INTERNAL
		# Better Switching Options
		betterswitchscore = 0
		if pbAIfaster?(nil,nil,@attacker,@opponent) && pbAIfaster?(nil,nil,@attacker,@opponent.pbPartner)
			betterswitchscore+=90 if @attacker.pbHasMove?(:VOLTSWITCH) || @attacker.pbHasMove?(:UTURN)
		end
		betterswitchscore+=100 if @attacker.turncount==0
		betterswitchscore+=190 if @attacker.effects[:PerishSong]==0 && @attacker.pbHasMove?(:BATONPASS)
		betterswitchscore+=60 if @attacker.ability== :WIMPOUT || @attacker.ability== :EMERGENCYEXIT
		PBDebug.log(sprintf("Initial noswitchscore building: Alternate Switching Options (%d)",betterswitchscore)) if $INTERNAL
		secondwindscore = 0
		#Can you kill them before they kill you?
		for oppmon in [@opponent,@opponent.pbPartner]
			next if oppmon.hp <=0
			if !checkAIpriority()
				if pbAIfaster?(nil,nil,@attacker,oppmon)
					secondwindscore +=130 if @mondata.roughdamagearray[oppmon.index].any? {|movescore| movescore > 100}
				end
			else
				for i in 0...@attacker.moves.length
					next if @attacker.moves[i].nil?
					next if !@attacker.moves[i].pbIsPriorityMoveAI(@attacker)
					secondwindscore +=130 if @mondata.roughdamagearray[oppmon.index][i] > 100 && pbAIfaster?(nil,nil,@attacker,oppmon)
				end
			end
		end
		monturn = (50 - (@attacker.turncount*25))
		monturn /= 1.5 if @mondata.roles.include?(:LEAD)
		secondwindscore += monturn if monturn > 0
		PBDebug.log(sprintf("Initial noswitchscore building: Second Wind Situations (%d)",secondwindscore)) if $INTERNAL
		noswitchscore = statantiscore + hazardantiscore + betterswitchscore + secondwindscore
		noswitchscore += 999 if Reborn && !@battle.doublebattle && @battle.opponent.name=="Priscilla"
		PBDebug.log(sprintf("%s: initial noswitchscore: %d",getMonName(@attacker.species),noswitchscore)) if $INTERNAL
		finalscore = switchscore - noswitchscore
		finalscore/=2.0 if @mondata.skill<HIGHSKILL
		finalscore-=100 if @mondata.skill<MEDIUMSKILL
		finalscore+=1000000 if (@attacker.ability== :ZEROTOHERO) && (@attacker.form == 0)
		return finalscore
	end

	def pbStatChangingSwitchOpponent(mon, opponent, field_on_switch_in=@battle.FE, mirrorswitch: false)
		if field_on_switch_in!=@battle.FE # lawds catch any stat changes you'd give your opponent when changing fields on switch-in
			pbStatChangingSwitch(opponent,field_on_switch_in)
		end
		return if opponent.item == :CLEARAMULET && opponent.itemWorks?
		return if [:CLEARBODY, :WHITESMOKE, :FULLMETALBODY, :INDUSTRYSTANDARD].include?(opponent.ability)
		if mon.ability==:INTIMIDATE
		  atkstage=-1
		  atkstage*=2 if opponent.ability==:SIMPLE
		  abil=[]
		  if opponent.ability.is_a?(PokeAbility)
			if opponent.ability.ability.is_a?(Array)
				for i in opponent.ability.ability
					abil.push(i)
				end
			else
				abil=[opponent.ability.ability]
			end
		  end
		  for i in abil
		  case i
		  when :DEFIANT, :CONTRARY, :GUARDDOG
			atkstage += 2
		  when :COMPETITIVE
			opponent.stages[PBStats::SPATK] += 2 if ![:SCRAPPY, :INNERFOCUS, :OBLIVIOUS, :OWNTEMPO, :HYPERCUTTER].include?(opponent.ability)
		  when :RATTLED
			opponent.stages[PBStats::SPEED] += 1 if ![:SCRAPPY, :INNERFOCUS, :OBLIVIOUS, :OWNTEMPO, :HYPERCUTTER].include?(opponent.ability)
		  end
		  end
		  atkstage=0 if [:SCRAPPY, :INNERFOCUS, :OBLIVIOUS, :OWNTEMPO, :HYPERCUTTER].include?(opponent.ability)
		  opponent.stages[PBStats::ATTACK] += atkstage
		end # LAWDS pressure and unnerve on dcc
		if mon.ability==:PRESSURE && [:DIMENSIONAL, :FROZENDIMENSION, :DARKCRYSTALCAVERN].include?(field_on_switch_in)
			abil=[]
			defstage = -1
			spdefstage = -1
		  	if opponent.ability.is_a?(PokeAbility)
				if opponent.ability.ability.is_a?(Array)
					for i in opponent.ability.ability
						abil.push(i)
					end
				else
					abil=[opponent.ability.ability]
				end
		  end
		  for i in abil
		  case i
		  when :CONTRARY
			defstage *= -1
			spdefstage *= -1
		  when :DEFIANT
			opponent.stages[PBStats::ATTACK] += 2
		  when :COMPETITIVE
			opponent.stages[PBStats::SPATK] += 2
		  when :BIGPECKS
			defstage=0
		  when :SIMPLE
			defstage*=2
			spdefstage*=2
		  end
		  end
		  if opponent.ability!=:MIRRORARMOR || field_on_switch_in==:DARKCRYSTALCAVERN
		    opponent.stages[PBStats::DEFENSE] += defstage
		    opponent.stages[PBStats::SPDEF] += spdefstage
                  else
                    mon.stages[PBStats::DEFENSE] += defstage
		    mon.stages[PBStats::SPDEF] += spdefstage
                  end
		end
		if mon.ability==:UNNERVE && [:DIMENSIONAL, :FROZENDIMENSION, :DARKCRYSTALCAVERN].include?(field_on_switch_in) && !opponent.ability==:OBLIVIOUS
			speedstage=-1
		  	abil=[]
		  	if opponent.ability.is_a?(PokeAbility)
				if opponent.ability.ability.is_a?(Array)
					for i in opponent.ability.ability
						abil.push(i)
					end
				else
					abil=[opponent.ability.ability]
				end
		  	end
		  for i in abil
		  case i
		  when :CONTRARY
			speedstage*=-1
		  when :DEFIANT
			opponent.stages[PBStats::ATTACK] += 2
		  when :COMPETITIVE
			opponent.stages[PBStats::SPATK] += 2
		  when :SIMPLE
			speedstage*=2
		  end
		  end
		  if opponent.ability!=:MIRRORARMOR || field_on_switch_in==:DARKCRYSTALCAVERN
		    opponent.stages[PBStats::SPEED] += speedstage
                  else
                    mon.stages[PBStats::SPEED] += speedstage
                  end
		end
		if mon.ability==:FRISK && [:CITY,:BACKALLEY].include?(field_on_switch_in)
			spdefstage=1
			spdefstage*=2 if opponent.ability==:SIMPLE
			abil=[]
		  	if opponent.ability.is_a?(PokeAbility)
				if opponent.ability.ability.is_a?(Array)
					for i in opponent.ability.ability
						abil.push(i)
					end
				else
					abil=[opponent.ability.ability]
				end
			end
			for i in abil
				case i
				when :CONTRARY
					spdefstage*=-1
				when :DEFIANT
					opponent.stages[PBStats::ATTACK] += 2
				when :COMPETITIVE
					opponent.stages[PBStats::SPATK] += 2
				end
			end
			if field_on_switch_in==:CITY
				if opponent.ability!=:MIRRORARMOR
		    			opponent.stages[PBStats::SPDEF] += spdefstage
                  		else
                    			mon.stages[PBStats::SPDEF] += spdefstage
                  		end
			else
				if opponent.ability!=:MIRRORARMOR
		    			opponent.stages[PBStats::DEFENSE] += spdefstage
                  		else
                    			mon.stages[PBStats::DEFENSE] += spdefstage
                  		end
			end
		end
		if opponent.hasWorkingItem(:WHITEHERB)
		  worked = false
		  for i in 1..7
			if opponent.stages[i] < 0
			  opponent.stages[i] = 0
			  worked = true
			end
		  end
		  opponent.unburdened = true if worked && opponent.ability==:UNBURDEN
		end
		if mirrorswitch && (opponent.hasWorkingItem(:MIRRORHERB) || opponent.ability==:OPPORTUNIST)
			worked=false
			for i in 1..7
				if mon.stages[i] > 0 && opponent.stages[i]<6
				  opponent.stages[i] += mon.stages[i]
				  opponent.stages[i] = 6 if opponent.stages[i] > 6
				  worked = true
				end
			end
			opponent.unburdened = true if worked && opponent.ability!=:OPPORTUNIST && opponent.ability==:UNBURDEN
		end
	  end

	def pbStatChangingSwitch(mon,field_on_switch_in=@battle.FE,mega: false, seedonly: false) # lawds added mega parameter to check ability switch-in effects when mega evolving
		trainer = @battle.pbGetOwner(mon.index)
		# lawds fake terrains for AI calcs
		# Seed Stat boosts		# LAWDS - generic seed
		if field_on_switch_in != @battle.FE
			field = PokeBattle_Field.new
			field.effect = field_on_switch_in
		else
			field = @battle.field
		end	# LAWDS seed used, including preseed
		if (mon.item == field.seeds[:seedtype] || mon.item == :SEED || mon.pokemon.seeded) && !mega
			mon.unburdened = true if mon.ability== :UNBURDEN && (mon.item == field.seeds[:seedtype] || mon.item == :SEED)
			mon.item=nil if (mon.item == field.seeds[:seedtype] || mon.item == :SEED)
			field.seeds[:stats].each_pair {|stat,statval| mon.stages[stat]+=statval}
			mon.effects[field.seeds[:effect]] = field.seeds[:duration]
			fieldabil=nil
			case field_on_switch_in # field abilities
			when :SWAMP then fieldabil=:CLEARBODY
			when :SKY then fieldabil=:WINDRIDER
			when :INFERNAL
				mon.effects[:MeanLook]=mon.index
				mon.effects[:FlashFire]=true
				mon.effects[:infernalPain]=true
			when :HAUNTED
				mon.status=:BURN if mon.pbCanBurn?(false)
			when :UNDERWATER
				mon.type1=:WATER
				mon.type2=nil
			end
			if fieldabil!=nil && mon.ability!=fieldabil
				abilarray=[]
				if mon.ability.is_a?(PokeAbility)
					if mon.PULSE3
						abilarray=mon.ability.ability
					else
						abilarray=[mon.ability.ability]
					end
				else
					abilarray=[mon.ability]
				end
				abilarray.push(fieldabil)
			end
		end
		return mon if seedonly
		if mon.ability==:GRASSYSURGE && @battle.state.effects[:GRASSY]==0 && !@battle.state.effects[:OVERLAYLOCK] && ![:NEWWORLD,:DRAGONSDEN,:FROZENDIMENSION].include?(@battle.FE)
			@gonnaTerrains.push(:GRASSY) if !@gonnaTerrains.include?(:GRASSY)
		end
		if mon.ability==:PSYCHICSURGE && @battle.state.effects[:PSYTERRAIN]==0 && !@battle.state.effects[:OVERLAYLOCK] && ![:NEWWORLD,:DRAGONSDEN,:FROZENDIMENSION].include?(@battle.FE)
			@gonnaTerrains.push(:PSYTERRAIN) if !@gonnaTerrains.include?(:PSYTERRAIN)
		end
		if mon.ability==:ELECTRICSURGE && @battle.state.effects[:ELECTERRAIN]==0 && !@battle.state.effects[:OVERLAYLOCK] && ![:NEWWORLD,:DRAGONSDEN,:FROZENDIMENSION].include?(@battle.FE)
			@gonnaTerrains.push(:ELECTERRAIN) if !@gonnaTerrains.include?(:ELECTERRAIN)
		end
		if mon.ability==:MISTYSURGE && @battle.state.effects[:MISTY]==0 && !@battle.state.effects[:OVERLAYLOCK] && ![:NEWWORLD,:DRAGONSDEN,:FROZENDIMENSION].include?(@battle.FE)
			@gonnaTerrains.push(:MISTY) if !@gonnaTerrains.include?(:MISTY)
		end
		if mon.ability==:BADSEEDS && @battle.state.effects[:FROZENDIMENSION]==0 && !@battle.state.effects[:OVERLAYLOCK] && ![:NEWWORLD,:DRAGONSDEN,:FROZENDIMENSION].include?(@battle.FE)
			@gonnaTerrains.push(:FROZENDIMENSION) if !@gonnaTerrains.include?(:GRASSY)
		end
		if ([:DROUGHT].include?(mon.ability) || (mon.crested==:CASTFORM && mon.moves[0].move==:SUNNYDAY) || (field_on_switch_in==:PSYTERRAIN && !mon.hasType?(:GRASS) && mon.item==:ROSEINCENSE)) && !@battle.state.effects[:WEATHERLOCK] && @gonnaWeather != :PRIMORDIALSEA
			@gonnaWeather = :SUNNYDAY
		end
		if [:DESOLATELAND].include?(mon.ability) && !@battle.state.effects[:WEATHERLOCK]
			@gonnaWeather = :DESOLATELAND
		end
		if ([:DRIZZLE].include?(mon.ability) || (mon.crested==:CASTFORM && mon.moves[0].move==:RAINDANCE) || (field_on_switch_in==:PSYTERRAIN && !mon.hasType?(:WATER) && mon.item==:SEAINCENSE)) && !@battle.state.effects[:WEATHERLOCK] && @gonnaWeather != :DESOLATELAND
			@gonnaWeather = :RAINDANCE
		end
		if [:PRIMORDIALSEA].include?(mon.ability) && !@battle.state.effects[:WEATHERLOCK]
			@gonnaWeather = :PRIMORDIALSEA
		end
		if (mon.ability==:SANDSTREAM || (field_on_switch_in==:PSYTERRAIN && !mon.hasType?(:ROCK) && mon.item==:ROCKINCENSE)) && !@battle.state.effects[:WEATHERLOCK] && ![:DESOLATELAND,:PRIMORDIALSEA].include?(@gonnaWeather)
			@gonnaWeather = :SANDSTORM
		end
		if (mon.ability==:SNOWWARNING || (mon.crested==:CASTFORM && mon.moves[0].move==:HAIL)) && !@battle.state.effects[:WEATHERLOCK] && ![:DESOLATELAND,:PRIMORDIALSEA].include?(@gonnaWeather)
			@gonnaWeather = :HAIL
		end
		if mon.species==:GRENINJA && mon.form==0 && mon.ability==:BATTLEBOND && !@battle.pbOwnedByPlayer?(mon.index) # lawds enemy bb
			mon.form=1
			mon.pbUpdate(true)
		end
		if mon.species==:TERAPAGOS && mon.form==0 && mon.ability==:TERASHIFT # lawds tera shell AI
			mon.form=1
			mon.pbUpdate(true)
		end
		# Sticky Web
		if mon.pbOwnSide.effects[:StickyWeb] && !(mon.isAirborne?(field_on_switch_in) && field_on_switch_in != :FOREST)
			drop = (field_on_switch_in == :FOREST && !mon.isAirborne?(field_on_switch_in)) ? 2 : 1	
			drop *=2 if mon.ability== :SIMPLE														# Gen 9 Mod - Clear Amulet		 # Lawds Mod 6/19/2024 - Industry Standard
			if !(mon.item == :WHITEHERB || mon.ability== :WHITESMOKE || mon.ability== :CLEARBODY || mon.hasWorkingItem(:CLEARAMULET) || mon.ability== :INDUSTRYSTANDARD || mon.item == :HEAVYDUTYBOOTS)
				mon.stages[PBStats::SPEED]-= drop
				mon.stages[PBStats::ATTACK]+=2 if mon.ability==:DEFIANT
				mon.stages[PBStats::SPATK]+=2 if mon.ability==:COMPETITIVE
			end
			mon.unburdened = true 			  if mon.ability== :UNBURDEN && mon.item == :WHITEHERB
		end
		# LAWDS toxic spikes
		if mon.pbOwnSide.effects[:ToxicSpikes] > 0 && !mon.isAirborne?(field_on_switch_in) && mon.pbCanPoisonSpikes?(false) && !mon.hasWorkingItem(:HEAVYDUTYBOOTS) && !mega
			if mon.pbOwnSide.effects[:ToxicSpikes]==2
				mon.status=:POISON
				mon.statusCount=1
      			mon.effects[:Toxic]=0
			else
				mon.status=:POISON
				mon.statusCount=0
			end
		end
		# Iron Ball Deep Earth
		if mon.item == :IRONBALL && field_on_switch_in == :DEEPEARTH && mon.ability != :INDUSTRYSTANDARD && !mega
			mon.stages[PBStats::SPEED] -=2 if !(mon.ability==:CONTRARY)
			mon.stages[PBStats::SPEED] +=2 if (mon.ability==:CONTRARY)
		end
		# Magnet Deep Earth
		if mon.item == :MAGNET && field_on_switch_in == :DEEPEARTH && mon.ability != :INDUSTRYSTANDARD && !mega
			if !(mon.ability==:CONTRARY)
				mon.stages[PBStats::SPEED] -=1
				mon.stages[PBStats::SPATK] +=1
				mon.stages[PBStats::SPATK] +=2 if mon.ability== :COMPETITIVE # LAWDS - the speed drop triggers competitive and defiant, so take that into account
				mon.stages[PBStats::ATTACK] +=2 if mon.ability== :DEFIANT
			else
				mon.stages[PBStats::SPEED] +=1
				mon.stages[PBStats::SPATK] -=1 
			end
		end
		if field_on_switch_in == :DESERT && !mega# LAWDS desert absorb bulb
			if mon.item == :ABSORBBULB 
				mon.stages[PBStats::SPDEF]+=1
				mon.effects[:AquaRing]=true
				mon.unburdened = true if mon.ability== :UNBURDEN
			end
			mon.effects[:DesertSpit] = mon.ability==:SANDSPIT
		end
		# Industry Standard
		if mon.ability== :INDUSTRYSTANDARD && field_on_switch_in==:SHORTCIRCUIT
			field_on_switch_in = :FACTORY
		end
				# Lawds Mod - Eidolon
		if mon.ability==:EIDOLON && mon.item != :ABILITYSHIELD && @battle.last_switched_abilities[mon.index].is_a?(PokeAbility)
      			if mon.ability.ability.is_a?(Array)
				abillist = mon.ability.ability - [:EIDOLON]
				if @battle.last_switched_abilities[mon.index].ability.is_a?(Array)
					abillist = @battle.last_switched_abilities[mon.index].ability + abillist
				else
					abillist = [@battle.last_switched_abilities[mon.index].ability] + abillist
				end
			   mon.ability= abillist
      			else
			   mon.ability= @battle.last_switched_abilities[mon.index]
			end
      			
    		end
		# LAWDS Mod - AI considers what protosynthesis/quark drive boosts it will get after coming in, if any.
		if mon.ability== :PROTOSYNTHESIS || mon.ability== :QUARKDRIVE
				boosted = false
			if field_on_switch_in == :NEWWORLD || field_on_switch_in == :DEEPEARTH
				boosted = true
			elsif mon.ability== :PROTOSYNTHESIS && ((@battle.pbWeather == :SUNNYDAY || mon.pbPartner.crested == :CHERRIM) || ([:RAINBOW,:DRAGONSDEN,:FAIRYTALE].include?(field_on_switch_in)))
				boosted = true
			elsif mon.ability== :QUARKDRIVE && ((@battle.state.effects[:ELECTERRAIN] > 0) || @gonnaTerrains.include?(:ELECTERRAIN) || ([:ELECTERRAIN, :FACTORY, :CONCERT4].include?(field_on_switch_in)))
				boosted = true
			elsif mon.item == :BOOSTERENERGY
				boosted = true
			end
			boostabil = mon.ability==:PROTOSYNTHESIS ? :Protosynthesis : :Quarkdrive
			if boosted
				aBoost = mon.attack * 1.0+(0.5*mon.stages[PBStats::ATTACK])
				dBoost = mon.defense * 1.0+(0.5*mon.stages[PBStats::DEFENSE])
				saBoost = mon.spatk * 1.0+(0.5*mon.stages[PBStats::SPATK])
				sdBoost = mon.spdef * 1.0+(0.5*mon.stages[PBStats::SPDEF])
				spdBoost = mon.speed * 1.0+(0.5*mon.stages[PBStats::SPEED])
				stats = [aBoost,dBoost,saBoost,sdBoost,spdBoost]
				boostStat = stats.index(stats.max)+1
				case boostStat
				when 1
					mon.effects[boostabil][0] = PBStats::ATTACK
				when 2
					mon.effects[boostabil][0] = PBStats::DEFENSE
				when 3
					mon.effects[boostabil][0] = PBStats::SPATK
				when 4
					mon.effects[boostabil][0] = PBStats::SPDEF
				when 5
					mon.effects[boostabil][0] = PBStats::SPEED
				end
				mon.effects[boostabil][1]=true
			else
				mon.effects[boostabil]=[0,false]
			end
		end
		# Electric Terrain instant Cellbattery
		# Lawds Mod - Electric Terrain Overlay now activates Cell Battery as well
		if Rejuv && (field_on_switch_in == :ELECTERRAIN || @battle.state.effects[:ELECTERRAIN] > 0 || @gonnaTerrains.include?(:ELECTERRAIN)) && mon.item == :CELLBATTERY && !mega
			mon.unburdened = true if mon.ability== :UNBURDEN
			mon.stages[PBStats::ATTACK]+=1
		end
		# Abilities on Entry
		if [:MAGICBOUNCE,:REFLECTOR].include?(mon.ability) && !mega # LAWDS magic bounce buffer
			mon.effects[:mbouncebuffer] = true
		end
		# Lawds new Anticipation, if both enemy mons have a super effective move then count it as not being on.
		if mon.ability== :ANTICIPATION
			found = false
			ignored = false
			for foe in [mon.pbOppositeOpposing,mon.pbOppositeOpposing.pbPartner]
				next if foe.isFainted?
				for j in foe.moves
				  next if moldBreakerCheck(foe,j)
				  movedata=$cache.moves[j.move]
				  eff=PBTypes.twoTypeEff(movedata.type,mon.type1,mon.type2)
				  eff*=4 if j.move==:FREEZEDRY && mon.hasType?(:WATER) # lawds freeze dry
          		  eff*=4 if movedata.type==:STEEL && foe.crested==:TINKATON && mon.hasType?(:STEEL) # lawds tink crest
          		  eff*=4 if j.move==:BARBEDWEB && mon.hasType?(:FLYING) # lawds barbed web
				  if (movedata.basedamage>0 && eff>4 &&
					 movedata.function!=0x71 && # Counter
					 movedata.function!=0x72 && # Mirror Coat
					 movedata.function!=0x73) || # Metal Burst
					 (movedata.function==0x70 && eff>0) # OHKO
					 if j.pbIsMultiHit || found==true
						ignored = true
						break
					 end
					found=true
					break
				  end
				end
				break if ignored
			end
			mon.effects[:Anticipation] = true if found && !ignored
		end

		# Lawds Mod - Industry Standard on City
		if mon.ability== :INDUSTRYSTANDARD && field_on_switch_in == :CITY
			mon.stages[PBStats::SPDEF] +=1
		end
		# LAWDS download boosts
		if mon.ability== :DOWNLOAD || (([:PORYGON,:PORYGON2,:PORYGONZ,:GENESECT].include?(mon.species) || (mon.crested==:SILVALLY && mon.type1==:ELECTRIC) || 
			(mon.crested==:ZOROARK && mon.effects[:Illusion]!=nil && ([:PORYGON,:PORYGON2,:PORYGONZ,:GENESECT].include?(mon.effects[:Illusion].species) || (mon.effects[:Illusion].crested==:SILVALLY && mon.effects[:Illusion].type1==:ELECTRIC)))) && 
			mon.PULSE3 && !@battle.pbOwnedByPlayer?(mon.index))
			if [:GLITCH,:SHORTCIRCUIT].include?(field_on_switch_in)
				mon.stages[PBStats::ATTACK]+=1
				mon.stages[PBStats::SPATK]+=1
			elsif !@battle.doublebattle && mon.pbOppositeOpposing.hp > 0 # just do singles for now bro.
				increment = [:FACTORY,:CITY,:BACKALLEY].include?(field_on_switch_in) ? 2 : 1
				download_target = mon.pbOppositeOpposing
				stagemult=[2,2,2,2,2,2,2,3,4,5,6,7,8]
				stagediv=[8,7,6,5,4,3,2,2,2,2,2,2,2]
				odef=ospdef=0
				odef+=(download_target.defense*stagemult[download_target.stages[PBStats::DEFENSE]+6]/stagediv[download_target.stages[PBStats::DEFENSE]+6])
				ospdef+=(download_target.spdef*stagemult[download_target.stages[PBStats::SPDEF]+6]/stagediv[download_target.stages[PBStats::SPDEF]+6])
				stat = ospdef <= odef ? PBStats::SPATK : PBStats::ATTACK
				mon.stages[stat]+=increment
			end
		end
		# Intrepid Sword
		if mon.ability==:INTREPIDSWORD
			boost = (field_on_switch_in == :FAIRYTALE || field_on_switch_in == :COLOSSEUM) ? 2 : 1
			mon.stages[PBStats::ATTACK]+=boost 
			mon.stages[PBStats::SPATK]+=1 if (field_on_switch_in == :FAIRYTALE || field_on_switch_in == :COLOSSEUM)
		end
		# Dauntless Shield
		if mon.ability==:DAUNTLESSSHIELD
			boost = (field_on_switch_in == :FAIRYTALE || field_on_switch_in == :COLOSSEUM) ? 2 : 1
			mon.stages[PBStats::DEFENSE]+=boost 
			mon.stages[PBStats::SPDEF]+=1 if (field_on_switch_in == :FAIRYTALE || field_on_switch_in == :COLOSSEUM)
		end
		# Steadfast
		if ((Rejuv && field_on_switch_in == :ELECTERRAIN) || @battle.state.effects[:ELECTERRAIN] > 0 || @gonnaTerrains.include?(:ELECTERRAIN)) && mon.ability==:STEADFAST
			mon.stages[PBStats::SPEED]+=1
		end
		# Light Metal
		if mon.ability==:LIGHTMETAL && ([:DEEPEARTH,:FACTORY].include?(field_on_switch_in))
			mon.stages[PBStats::SPEED]+=1
		end
		# LAWDS - Spirit's Envoy
		if mon.ability==:SPIRITSENVOY && ([:HAUNTED, :DEEPEARTH].include?(field_on_switch_in))
			mon.stages[PBStats::SPATK]+=1
		end
		# LAWDS Spirit Eater
		if mon.ability==:SPIRITEATER && ([:HAUNTED, :DEEPEARTH].include?(field_on_switch_in))
			mon.stages[PBStats::ATTACK]+=1
		end
		# LAWDS Mind's Eye on Deep Earth
		if mon.ability==:MINDSEYE && field_on_switch_in==:DEEPEARTH
			mon.effects[:LaserFocus]=1
		end
		#Costar		# LAWDS shown fields disable costar
		if mon.ability==:COSTAR && ![:DIMENSIONAL,:FROZENDIMENSION,:BACKALLEY,:NEWWORLD,:INFERNAL].include?(field_on_switch_in) && mon.pbPartner.hp > 0
			mon.stages[PBStats::ATTACK]+=mon.pbPartner.stages[PBStats::ATTACK]
			mon.stages[PBStats::DEFENSE]+=mon.pbPartner.stages[PBStats::DEFENSE]
			mon.stages[PBStats::SPATK]+=mon.pbPartner.stages[PBStats::SPATK]
			mon.stages[PBStats::SPDEF]+=mon.pbPartner.stages[PBStats::SPDEF]
			mon.stages[PBStats::SPEED]+=mon.pbPartner.stages[PBStats::SPEED]
			mon.stages[PBStats::ACCURACY]+=mon.pbPartner.stages[PBStats::ACCURACY]
			mon.stages[PBStats::EVASION]+=mon.pbPartner.stages[PBStats::EVASION]
		end
		# LAWDS new screen cleaner
		if mon.ability==:SCREENCLEANER
			screenscleaned = [false,false,false,false]
			if mon.pbOwnSide.effects[:Reflect] > 0
				mon.stages[PBStats::ATTACK] +=1 
				screenscleaned[0]=true
			end
			if mon.pbOwnSide.effects[:LightScreen] > 0
				mon.stages[PBStats::SPATK] +=1 
				screenscleaned[1]=true
			end
			if mon.pbOwnSide.effects[:AuroraVeil] > 0
				mon.stages[PBStats::SPDEF] +=1 
				screenscleaned[2]=true
			end
			if mon.pbOwnSide.effects[:AreniteWall] > 0
				mon.stages[PBStats::DEFENSE] +=1 
				screenscleaned[3]=true
			end
			if mon.crested==:MRRIME && mon.moves[0]!=nil
				rimescreen = mon.moves[0].move
				if rimescreen==:REFLECT && !screenscleaned[0]
					mon.stages[PBStats::ATTACK] +=1 
				elsif rimescreen==:LIGHTSCREEN && !screenscleaned[1]
					mon.stages[PBStats::SPATK] +=1 
				elsif rimescreen==:AURORAVEIL && !screenscleaned[2]
					mon.stages[PBStats::SPDEF] +=1 
				elsif rimescreen==:ARENITEWALL && !screenscleaned[3]
					mon.stages[PBStats::DEFENSE] +=1 
				end
			end
		end
		# LAWDS - Rocky Payload interactions
		if mon.ability== :ROCKYPAYLOAD
			mon.stages[PBStats::ATTACK]+=1 if [:MOUNTAIN, :VOLCANICTOP, :SNOWYMOUNTAIN, :ROCKY].include?(field_on_switch_in)
		end
		# LAWDS - Wind Power on Sky with Strong Winds up
		if mon.ability== :WINDPOWER && [:SKY,:MOUNTAIN,:VOLCANICTOP,:SNOWYMOUNTAIN].include?(field_on_switch_in) && @battle.pbWeather == :STRONGWINDS
			mon.stages[PBStats::SPDEF]+=1
		end
		# LAWDS Wind Rider
		if mon.ability==:WINDRIDER && (mon.pbOwnSide.effects[:Tailwind] != 0)
			mon.stages[PBStats::ATTACK]+=1
			mon.stages[PBStats::SPATK]+=1 if field_on_switch_in==:SKY
		end
		# LAWDS - Rocky Field ability interactions
		if field_on_switch_in == :ROCKY
			mon.stages[PBStats::DEFENSE]+=1 if [:SOLIDROCK,:ROCKHEAD,:STURDY,:STALWART].include?(mon.ability)
			mon.stages[PBStats::SPDEF]+=1 if mon.ability== :SANDSTREAM
			if mon.ability== :WEAKARMOR
				mon.stages[PBStats::DEFENSE]-=1 if ![:CLEARBODY,:WHITESMOKE,:FULLMETALBODY,:INDUSTRYSTANDARD,:BATTLEARMOR,:SHELLARMOR,:BIGPECKS].include?(mon.ability) && mon.item!=:CLEARAMULET
				mon.stages[PBStats::SPEED]+=2
			end
		end
		# LAWDS Mod - Purifying Salt on Holy (or Haunted, since it triggers a switch to Holy)
		if mon.ability== :PURIFYINGSALT && (field_on_switch_in == :HOLY || (field_on_switch_in == :HAUNTED && @battle.canChangeFE?(:HOLY)))
			mon.stages[PBStats::DEFENSE]+=1
		end
		# Lawds Mod - Spidops Crest
		if mon.crested == :SPIDOPS && !mon.pokemon.crestUsed && !mega
			for droppedOpp in [mon.pbOppositeOpposing, mon.pbOppositeOpposing.pbPartner]
				next if !droppedOpp
				if droppedOpp.hp > 0
				  for i in 1...droppedOpp.stages.length # skips HP
					if droppedOpp.stages[i] < 0
					  mon.stages[i] = 1 if mon.stages[i] < 1
					end
				  end
				end
			end
		end
		# Heavy Metal
		if mon.ability==:HEAVYMETAL && (field_on_switch_in == :DEEPEARTH)
			mon.stages[PBStats::DEFENSE]+=1
			mon.stages[PBStats::SPEED]-=1
		end
		# Lightning Rod
		if (mon.ability==:LIGHTNINGROD) && (Rejuv && (field_on_switch_in == :ELECTERRAIN))
			mon.stages[PBStats::SPATK]+=1
		end
		# Magma Armor
		if mon.ability==:MAGMAARMOR && (field_on_switch_in == :DRAGONSDEN || field_on_switch_in == :VOLCANIC)
			boost = 1
			mon.stages[PBStats::DEFENSE]+=boost 
			mon.stages[PBStats::SPDEF]+=boost if field_on_switch_in == :DRAGONSDEN
		end
		# Shell Armor				# Lawds Mod - Shell Armor on Ashen Beach
		if Rejuv && mon.ability==:SHELLARMOR && [:DRAGONSDEN, :ASHENBEACH].include?(field_on_switch_in)
			mon.stages[PBStats::DEFENSE]+=1 
		end
		# Stance Change
		if mon.ability==:STANCECHANGE || mon.ability==:STALL
			if ((field_on_switch_in == :FAIRYTALE || (Rejuv && field_on_switch_in == :CHESS)) && mon.ability==:STANCECHANGE) || (Rejuv && field_on_switch_in == :CHESS && mon.ability==:STALL) 
			  mon.stages[PBStats::DEFENSE]+=1 
			end
		end
		# Crests
		case mon.crested
			when :VESPIQUEN 
				mon.effects[:VespiCrest]=false if !mega
			when :THIEVUL then mon.stages[PBStats::SPATK]+=1 if !mega
		end
		# Fairy Tale Abilities
		if field_on_switch_in == :FAIRYTALE
			if [:MAGICGUARD, :MAGICBOUNCE, :POWEROFALCHEMY, :MIRRORARMOR, :PASTELVEIL].include?(mon.ability)
				mon.stages[PBStats::SPDEF]+=1 
			end
			if [:BATTLEARMOR, :SHELLARMOR, :POWEROFALCHEMY].include?(mon.ability)
				mon.stages[PBStats::DEFENSE]+=1 
			end
			if mon.ability== :MAGICIAN
				mon.stages[PBStats::SPATK]+=1
			end 
		end
		# Starlight Illuminate		# LAWDS - mirror armor, magic bounce
		if field_on_switch_in == :STARLIGHT
			mon.stages[PBStats::SPATK]+=2 if mon.ability== :ILLUMINATE
			mon.stages[PBStats::SPDEF]+=1 if [:MAGICBOUNCE, :MIRRORARMOR, :MAGICGUARD, :REFLECTOR].include?(mon.ability)
		end
		# LAWDS - switch-in boosts on DCC
		if field_on_switch_in == :DARKCRYSTALCAVERN
			mon.stages[PBStats::SPATK]+=1 if mon.ability== :ILLUMINATE
			mon.stages[PBStats::SPEED]+=1 if mon.ability==:RATTLED
		end
		# LAWDS - switch-in boosts on New World
		if field_on_switch_in == :NEWWORLD
			mon.stages[PBStats::SPATK]+=1 if mon.ability== :ILLUMINATE
		end
		# Water Compaction
		if field_on_switch_in == :MISTY || field_on_switch_in == :CORROSIVEMIST || @battle.state.effects[:MISTY] > 0
			mon.stages[PBStats::DEFENSE]+=2 if mon.ability== :WATERCOMPACTION
		end
		# LAWDS corrosive mist
		if field_on_switch_in == :CORROSIVEMIST && mon.ability==:AROMAVEIL && !mon.hasType?(:POISON)
			mon.type2= :POISON
		end
		# Mirror Field Evasion & Accuracy
		if field_on_switch_in == :MIRROR
			mon.stages[PBStats::EVASION]+=1 if [:SANDVEIL,:SNOWCLOAK,:TANGLEDFEET,:MAGICBOUNCE,:COLORCHANGE].include?(mon.ability)
			mon.stages[PBStats::EVASION]+=2 if mon.ability== :ILLUSION
			mon.stages[PBStats::ACCURACY]+=1 if [:KEENEYE,:COMPOUNDEYES].include?(mon.ability)
		end
		# Rattled 
		if mon.ability== :RATTLED
			mon.stages[PBStats::SPEED]+=1 if field_on_switch_in == :DIMENSIONAL || field_on_switch_in == :FROZENDIMENSION || field_on_switch_in == :HAUNTED || field_on_switch_in == :INFERNAL
		end
		# Psychic Terrain	LAWDS - incense stuff on psy terrain. currently no handlers for non-stat boost effects
		if field_on_switch_in == :PSYTERRAIN || @battle.state.effects[:PSYTERRAIN] > 0 || @gonnaTerrains.include?(:PSYTERRAIN)
			mon.stages[PBStats::SPATK]+=2 if mon.ability== :FOREWARN || (mon.ability== :ANTICIPATION && field_on_switch_in == :PSYTERRAIN)
			mon.stages[PBStats::SPDEF]+=1 if mon.ability== :INNERFOCUS
			if (mon.item == :ROSEINCENSE && mon.hasType?(:GRASS)) && !mega
				mon.stages[PBStats::ACCURACY]+=1 
				mon.stages[PBStats::DEFENSE]+=1 
			end
			if (mon.item == :ROCKINCENSE && mon.hasType?(:ROCK)) && !mega
				mon.stages[PBStats::DEFENSE]+=1
				mon.stages[PBStats::SPDEF]+=1
			end
			if mon.item == :SEAINCENSE && !mega && mon.hasType?(:WATER)
				mon.stages[PBStats::DEFENSE]+=1
			end
			if mon.item == :FULLINCENSE && !mega
				mon.stages[PBStats::DEFENSE]+=1
				mon.stages[PBStats::SPDEF]+=1
			end
			if mon.item == :WAVEINCENSE && !mega
				mon.stages[PBStats::ATTACK]+=1
				mon.stages[PBStats::SPATK]+=1
				mon.unburdened = true if mon.ability==:UNBURDEN
				mon.item=nil
			end
		end
		# Dimensionals													
		if [:INFERNAL,:DIMENSIONAL,:FROZENDIMENSION].include?(field_on_switch_in)
			mon.stages[PBStats::SPATK]+=1 if mon.ability== :BERSERK
			mon.stages[PBStats::ATTACK]+=1 if mon.ability== :JUSTIFIED || mon.ability== :ANGERPOINT
		end
		
		# Sky
		if field_on_switch_in == :SKY # lawds mod - new seed effect and interactions
			if [:BIGPECKS, :ROCKYPAYLOAD].include?(mon.ability)
				increment = 1
				mon.stages[PBStats::DEFENSE]+=increment
			end
			mon.stages[PBStats::SPEED]+=1 if mon.ability== :LEVITATE || mon.ability== :SOLARIDOL || mon.ability== :LUNARIDOL || ([:RECKLESS, :NOGUARD].include?(mon.ability) && mon.pbOwnSide.effects[:Tailwind] != 0)
			mon.effects[:LaserFocus] = 1 if mon.ability==:KEENEYE
		end 
		# Infernal
		if field_on_switch_in == :INFERNAL
			mon.stages[PBStats::DEFENSE]+=1 if mon.ability== :MAGMAARMOR || mon.ability== :FLAMEBODY || mon.ability== :DESOLATELAND
			mon.stages[PBStats::SPDEF]+=1 if mon.ability== :MAGMAARMOR || mon.ability== :FLAMEBODY || mon.ability== :DESOLATELAND
		end
		# Colosseum
		if field_on_switch_in == :COLOSSEUM
			mon.stages[PBStats::DEFENSE]+=1 if  (mon.ability== :BATTLEARMOR || mon.ability== :SHELLARMOR)
			mon.stages[PBStats::SPDEF]+=1 if  (mon.ability== :MIRRORARMOR || mon.ability== :MAGICGUARD)
			mon.stages[PBStats::ATTACK]+=1 if mon.ability== :JUSTIFIED || mon.ability== :NOGUARD
			mon.stages[PBStats::SPATK]+=1 if mon.ability== :JUSTIFIED || mon.ability== :NOGUARD
		end
		# Concert
		if @battle.ProgressiveFieldCheck(PBFields::CONCERT)
			mon.stages[PBStats::DEFENSE]+=1 if [:HEAVYMETAL,:SOLIDROCK,:PUNKROCK,:SOUNDPROOF,:ROCKHEAD].include?(mon.ability)
			mon.stages[PBStats::SPDEF]+=1 if mon.ability== :SOUNDPROOF
			mon.stages[PBStats::ATTACK]+=1 if [:COSTAR, :PLUS].include?(mon.ability)
			mon.stages[PBStats::SPATK]+=1 if mon.ability== :COSTAR

			if  @battle.ProgressiveFieldCheck(PBFields::CONCERT,2,4)
				mon.stages[PBStats::SPEED]+=1 if mon.ability== :EMERGENCYEXIT || mon.ability== :RUNAWAY
				if  @battle.ProgressiveFieldCheck(PBFields::CONCERT,3,4)
					mon.stages[PBStats::SPEED]+=2 if mon.ability== :RATTLED
				end
			end
		end
		if field_on_switch_in == :BACKALLEY
			mon.stages[PBStats::DEFENSE]+=1 if  mon.ability== :ANTICIPATION || mon.ability== :FOREWARN
			mon.stages[PBStats::SPDEF]+=1 if  mon.ability== :ANTICIPATION || mon.ability== :FOREWARN
			mon.stages[PBStats::ATTACK]+=1 if mon.ability== :PICKPOCKET || mon.ability== :MERCILESS || mon.ability== :OPPORTUNIST || mon.ability== :GUARDDOG
			mon.stages[PBStats::SPATK]+=1 if mon.ability== :MAGICIAN || mon.ability== :OPPORTUNIST
			mon.stages[PBStats::SPEED]+=1 if mon.ability== :RATTLED
			if mon.ability== :ZEROTOHERO && mon.form== 0
				mon.form=1
				mon.pbUpdate(true)
				mon.stages[PBStats::ATTACK]+=1
			end
		end
		if field_on_switch_in == :CITY
			mon.stages[PBStats::DEFENSE]+=1 if  mon.ability== :BIGPECKS
			mon.stages[PBStats::ATTACK]+=1 if [:EARLYBIRD,:OPPORTUNIST,:GUARDDOG].include?(mon.ability)
			mon.stages[PBStats::SPATK]+=1 if mon.ability== :OPPORTUNIST
			mon.stages[PBStats::SPEED]+=1 if mon.ability== :PICKUP
			mon.stages[PBStats::SPEED]+=1 if mon.ability== :RATTLED
			if mon.ability== :ZEROTOHERO && mon.form== 0
				mon.form=1
				mon.pbUpdate(true)
				mon.stages[PBStats::ATTACK]+=1
			end
		end
		#Contrary	
		if mon.ability==:CONTRARY
			for stage in 0...mon.stages.length
				next if mon.stages[stage].nil?
				mon.stages[stage] = -1*mon.stages[stage]
			end
		end
		return mon
	end

	def shouldHardSwitch?(attacker,switch_in_index)
		return false if switch_in_index==nil
		return true if (attacker.effects[:Encore] > 0 || attacker.effects[:ChoiceBand] != nil) # LAWDS AI changes - adding this here i guess. idk why this doesnt get accounted for in pbCanChooseMove but whateverrrrr
		for i in 0...attacker.moves.length
			return true if !@battle.pbCanChooseMove?(attacker.index,i,false) 
		end
		return true if attacker.effects[:PerishSong]>0
		return true if attacker.ability== :ZEROTOHERO && attacker.form == 0 # LAWDS - switch the dolphin out idiot.
		switch_in = pbMakeFakeBattler(@battle.pbParty(attacker.index)[switch_in_index],switch_in_index)
		switch_in = pbStatChangingSwitch(switch_in)
		# LAWDS take the switch-in's value into account
		switch_in_value = getPokemonMatchupTotal(switch_in)
		attacker_value = getPokemonMatchupTotal(attacker)
		opponent = firstOpponent(attacker)
		#check if the switch_in would just straight up die from assumed move used
		# LAWDS we go off the maximum damage the switch-in can take
		assumed_damage = 0
		assumed_damage += totalHazardDamage(switch_in)*switch_in.totalhp.to_f / 100
		assumed_move = checkAIbestMove(opponent,switch_in)
		assumed_damage += pbRoughDamage(assumed_move,opponent,switch_in)
		assumed_damage += hpGainPerTurn(switch_in,true)*switch_in.totalhp
		return false if assumed_damage >= switch_in.hp/2 && (switch_in_value > 1 || !pbAIfaster?(nil,nil,switch_in,opponent))
		return false if assumed_damage >= switch_in.hp
		switch_in.hp -= assumed_damage
		return false if !canKillBeforeOpponentKills?(switch_in,opponent)

		return true
	end

	def canKillBeforeOpponentKills?(attacker,opponent,actual_kos = false,field=@battle.FE) # lawds added a parameter that repurposes the function when set true
		#first check what move is fastest for attacker and opponent
		attmovearray, attdamagearray = checkAIMovePlusDamage(attacker,opponent,nil,field,wholearray: true)
		oppmovearray, oppdamagearray = checkAIMovePlusDamage(opponent,attacker,nil,field,wholearray: true)
		attdamagearray.map! {|score| score > 0 && notOHKO?(attacker,opponent,true) ? score-1 : score }
		oppdamagearray.map! {|score| score > 0 && notOHKO?(opponent,attacker,true) ? score-1 : score }
		
		#filter out all moves that actually kill
		attmovearray.filter!.with_index {|move, index| attdamagearray[index] >= opponent.hp }
		oppmovearray.filter!.with_index {|move, index| oppdamagearray[index] >= attacker.hp }
		attdamagearray.filter! {|score| score >= opponent.hp }
		oppdamagearray.filter! {|score| score >= attacker.hp }
		return true if oppmovearray.length==0 && !actual_kos
		return false if attmovearray.length==0

		#check if there are any moves the attacker has that would move before all moves of opponent
		return attmovearray.any? {|attmove| oppmovearray.all? {|oppmove| pbAIfaster?(attmove,oppmove,attacker,opponent,field) } }
	end


################################################################################
# AI Memory utility functions
################################################################################

	def addMoveToMemory(battler,move)
		return if move.nil?
		trainer = @battle.pbGetOwner(battler.index)
		return if !trainer #wild battle
		return if !battler.pokemon
		#check if pokemon is added to trainer array, add if isn't the case
		@aiMoveMemory[trainer][battler.pokemon.personalID] = [] if !@aiMoveMemory[trainer].key?(battler.pokemon.personalID)
		knownmoves = @aiMoveMemory[trainer][battler.pokemon.personalID]
		return if knownmoves.any? {|moveloop| moveloop!=nil && moveloop.move == move.move} #move is already added to memory
		#update the move memory by taking current known move array and add new move in array form to it
		@aiMoveMemory[trainer][battler.pokemon.personalID] = knownmoves.push(move)
	end

	def addMonToMemory(pkmn,index)
		trainer = @battle.pbGetOwner(index)
		return if !trainer #wild battle
		@aiMoveMemory[trainer][pkmn.personalID] = [] if !@aiMoveMemory[trainer].key?(pkmn.personalID)
	end

	def getAIMemory(battler=@opponent,inspecting=false)
		return [] if battler.hp == 0
		trainer = @battle.pbGetOwner(battler.index)
		return [] if !trainer
		if (@mondata.index==battler.index || @mondata.index==battler.pbPartner.index) && battler.is_a?(PokeBattle_Battler) && inspecting!=true
			#we're checking out own moves stupid
			ret= @mondata.index==battler.index ? battler.moves : battler.pbPartner.moves
			return ret.find_all {|moveloop| moveloop.move}
		elsif battler.is_a?(PokeBattle_Battler) || inspecting == true
			#we're dealing with enemy battler
			if @aiMoveMemory[trainer][battler.pokemon.personalID]
				return @aiMoveMemory[trainer][battler.pokemon.personalID]
			else
				return []
			end
		elsif battler.is_a?(PokeBattle_Pokemon)
			#we're dealing with mon not on field
			for key in @aiMoveMemory.keys
				return @aiMoveMemory[key][battler.personalID] if @aiMoveMemory[key].key?(battler.personalID)
			end
			return []
		end
	end

	def getAIKnownParty(battler)
		trainer = @battle.pbGetOwner(battler.index)
		return [] if !trainer
		party = @battle.pbPartySingleOwner(battler.index)
		knownparty = party.find_all {|mon| mon.hp > 0 && @aiMoveMemory[trainer].keys.include?(mon.personalID) }
		return knownparty
	end

	def checkAImoves(moveID,memory=nil)
		if memory==nil
			for i in moveID
				for j in @opponent.moves
					return true if j.move==i && j.pp > 0
				end
			end
			return false
		end
		memory=getAIMemory(@opponent) if memory.nil?
		#basic "does the other mon have x"
		for i in moveID
			for j in memory
				move = pbChangeMove(j,@opponent)
				return true if i == move.move && move.pp > 0 #i should already be an ID here		LAWDS - this now takes PP into account
			end
		end
		return false
	end

	def checkAIhealing(memory=nil)
		memory=getAIMemory(@opponent) if memory.nil?
		#less basic "can the other mon heal"
		for j in memory
			return true if j.isHealingMove?
		end
		return false
	end

	def checkAIpriority(memory=nil, opp=nil, attacks=false) # lawds, can check battler moves directly. also can specify only prio attacks
		if opp==nil
			opp = memory.nil? ? @opponent : nil
			memory=getAIMemory(@opponent) if memory.nil?
		else
			memory=opp.moves if memory.nil?
		end
		#"does the other mon have priority"
		for j in memory
			if opp
				return true if j.pbIsPriorityMoveAI(opp,attacks)
			else
				return true if j.priority > 0
			end
		end
		return false
	end

	def checkAIaccuracy(memory=nil)
		memory=getAIMemory(@opponent) if memory.nil?
		#"does the other mon have moves that don't miss"
		for j in memory
			move = pbChangeMove(j,@opponent)
			return true if move.accuracy==0
		end
		return false
	end

	def checkAIMovePlusDamage(opponent=@opponent, attacker=@attacker, memory=nil, field=@battle.FE, wholearray: false)
		# Opponent is the one attacking, bit confusing i know
		return [[],[]] if wholearray && (!opponent || opponent.hp == 0)
		return [PokeBattle_Struggle.new(@battle,nil,nil),0] if !opponent || opponent.hp == 0
		memory=opponent.moves #if memory.nil?
		damagearray = []
		movearray = []

		for j in memory
			damagearray.push(pbRoughDamage(j,opponent,attacker,true,nil,field))
			movearray.push(j)
		end
		return [movearray, damagearray] if wholearray
		return [PokeBattle_Struggle.new(@battle,nil,nil),0] if damagearray.empty?
		return [movearray[damagearray.index(damagearray.max)],damagearray.max]
	end

	def checkAIdamage(attacker=@attacker,opponent=@opponent,memory=nil,field=@battle.FE) # gets the amt of damage the attacker can take from the opponent
		bestmove, damage = checkAIMovePlusDamage(opponent, attacker, memory, field)
		return damage
	end 

	def checkAIbestMove(opponent=@opponent, attacker=@attacker, memory=nil,field=@battle.FE)
		bestmove, damage = checkAIMovePlusDamage(opponent, attacker, memory,field)
		return bestmove
	end

	

######################################################
# AI Damage Calc
######################################################
# LAWDS - added checkOHKOs flag to avoid recursion. added opponentmove flag to play around counter moves. also added fields parameter to check move damage if the mon will change the field
	def pbRoughDamage(move=@move,attacker=@attacker,opponent=@opponent,checkOHKOs=true,opponentmove=nil,field=@battle.FE)
		if field != @battle.FE
			btlfield = PokeBattle_Field.new
			btlfield.effect = field
		else
			btlfield=@battle.field
		end
		return 0 if opponent==nil || attacker==nil
		return 0 if opponent.species==0 || attacker.species==0
		return 0 if opponent.hp==0 || attacker.hp==0
		return 0 if move.pp==0 && !move.zmove && !(move.type == :SHADOW)
		oldmove = move
		move = pbChangeMove(move,attacker,field)
		
		basedamage = move.basedamage
		return 0 if !move.basedamage || move.basedamage == 0
		# LAWDS return 0 for sucker punch and its clones if effect lasts
		return 0 if [:SUCKERPUNCH,:ELECTROCLAP,:THUNDERCLAP].include?(move.move) && attacker.effects[:SuckerPunch]
		#typemod=pbTypeModNoMessages(move.type,attacker,opponent,move,field) # LAWDS - commenting these out for redundancy, just saving processing time
		typemod=pbTypeModNoMessages(move.pbType(attacker),attacker,opponent,move, field: field) #if @mondata.skill >= HIGHSKILL
		return typemod if typemod<=0
		# LAWDS - knowing your move is going to get redirected by Dachsbun Crest or Ring Target on Big Top
		if @battle.doublebattle
			redirected = false
			redirected = true if opponent.pbPartner.effects[:FollowMe] && !opponent.effects[:FollowMe]
			if !redirected && opponent.pbPartner.species==:CORVIKNIGHT && field==:STARLIGHT # lawds see when partner corviknight is going to mega evolve
				dummypartner = pbCloneBattler(opponent.pbPartner.index)
				willMega = checkMega(dummypartner)
				redirected = true if willMega
			end
			if redirected && (attacker.pbTarget(move)==:SingleNonUser || attacker.pbTarget(move)==:RandomOpposing) && ![:STALWART,:PROPELLERTAIL].include?(attacker.ability) && move.function != 0x179 && move.move != :THUNDERRAID # Snipe Shot, Thunder Raid
			  return 0 # we return 0 for the damage against the opponent since we can't target them
			end
		end
		return 0 if !moveSuccessful?(oldmove,attacker,opponent)
		return 0 if opponent.totalhp == 1 && (opponent.ability== :STURDY || (opponent.ability== :STALWART && field == :COLOSSEUM)) && move.pbNumHits(attacker)==1 && !attacker.effects[:ParentalBond] && !attacker.effects[:TyphBond] && !attacker.effects[:DreadBond] && !move.pbIsMultiHit && !moldBreakerCheck(attacker,move)
		if @mondata.skill>=MEDIUMSKILL
		  basedamage = pbBetterBaseDamage(move,attacker,opponent,field)
		  return 0 if basedamage==0 # lawds
		end
		return 0 if move.zmove && ((opponent.effects[:Disguise] || (opponent.effects[:IceFace] && (move.pbIsPhysical? || field == :FROZENDIMENSION))) && !moldBreakerCheck(opponent))
		return basedamage if (0x6A..0x73).include?(move.function) || [0xD4,0xE1].include?(move.function) #fixed damage function codes (sonicboom, etc)
		basedamage*=1.25 if (attacker.effects[:ParentalBond]) && move.pbNumHits(attacker)==1
		basedamage*=1.5 if (attacker.effects[:DreadBond]) && move.pbNumHits(attacker)==1
		# LAWDS - tweak to typhlosion crest	
		basedamage*=1.15 if (attacker.effects[:TyphBond]) && move.pbNumHits(attacker) == 1
		basedamage*=1.15 if (attacker.crested == :TYPHLOSION && attacker.hp == attacker.totalhp && move.pbIsSpecial?)
		# LAWDS - Dancer on Sky Field with Tailwind up
		basedamage*=2.0 if attacker.ability== :DANCER && (PBStuff::DANCEMOVE).include?(move.move) && field == :SKY && attacker.pbOwnSide.effects[:Tailwind] != 0
		# Lawds Mod - Delphox Crest
		basedamage*=1.2 if attacker.crested == :DELPHOX && !move.pbTargetsAll?(attacker) && opponent.item && !@battle.pbIsUnlosableItem(opponent,opponent.item)
		# Lawds Mod - Pachirisu Crest
		basedamage*=0.5 if opponent.crested == :PACHIRISU && attacker.hp/attacker.totalhp < 1/2
		# Lawds Mod - Oinkologne Crest
		basedamage*=2.0 if attacker.crested == :OINKOLOGNE && opponent.ability== :LINGERINGAROMA
		# Lawds Mod - Little King damage increase
		if (opponent.effects[:LittleKingTarget]) || (attacker.ability== :LITTLEKING && !(move.pbTargetsAll?(attacker)) && attacker.pbIsOpposing?(opponent.index))
			if attacker.ability== :LITTLEKING
				basedamage*=1.3 
			else
				basedamage*=1.5
			end
		end
		
		basedamage*=4 if attacker.crested == :LEDIAN && move.punchMove? && move.move!=:COMETPUNCH # lawds the 12 hit comet punch is handled elsewhere
		if attacker.crested == :CINCCINO && !move.pbIsMultiHit
			# lawds multihit move change
			basedamage*=0.3
			if attacker.ability== :SKILLLINK || attacker.hasWorkingItem(:LOADEDDICE)
				basedamage*=5	
			else
				basedamage=(basedamage*3)
			end
		end
		# lawds tough claws on rocky
		if field==:ROCKY && attacker.ability==:TOUGHCLAWS && move.contactMove? && move.pbIsMultiHit && !move.pbHitsSpecialStat?(move.pbType(attacker))
			stagemul=[2,2,2,2,2,2,2,3,4,5,6,7,8]
			stagediv=[8,7,6,5,4,3,2,2,2,2,2,2,2]

			if opponent.pbCanReduceStatStage?(PBStats::DEFENSE,false,false) && 
				opponent.ability!=:STAMINA && !(move.function==0xA9 || attacker.ability==:UNAWARE)
				defstage=opponent.stages[PBStats::DEFENSE]+6
				defmult1=(1.0*stagemul[defstage]/stagediv[defstage])
				defstage-=1
				defmult2=(1.0*stagemul[defstage]/stagediv[defstage])
				avgdefmult = ((defmult1+defmult2)/2).to_f
				basedamage = basedamage*1.0
				basedamage = (basedamage/avgdefmult).floor
			end
		end
		fielddata = btlfield.moveData(move.move)
		type=move.type

		# Determine if an AI mon is attacking a player mon
		ai_mon_attacking = false
		if attacker.index == 2 && !@battle.pbOwnedByPlayer?(attacker.index)
			ai_mon_attacking = true if opponent.index==1 || opponent.index==3
		elsif opponent.index==0 || opponent.index==2
			ai_mon_attacking = true
		end

		# More accurate move type (includes Normalize, most type-changing moves, etc.)
		if @mondata.skill>=MINIMUMSKILL
			type=move.pbType(attacker,type)
		end
		stagemul=[2,2,2,2,2,2,2,3,4,5,6,7,8]
		stagediv=[8,7,6,5,4,3,2,2,2,2,2,2,2]
		oppitemworks = opponent.itemWorks?
		attitemworks = attacker.itemWorks?

		# ATTACKING/BASE DAMAGE SECTION
		atk=attacker.attack
		atk=attacker.spatk if attacker.crested == :REUNICLUS && attacker.type1 == :PSYCHIC && move.pbIsPhysical?(type)
		atkstage=attacker.stages[PBStats::ATTACK]+6
		if attacker.species==:AEGISLASH
			originalform = attacker.form
			dummymon = pbAegislashStats(attacker)
			dummymon.pbUpdate
			atk=dummymon.attack
			atkstage=dummymon.stages[PBStats::ATTACK]+6
			dummymon.form = originalform
			dummymon.pbUpdate
		end

		# LAWDS p3 aegislash and crest zoroark as aegislash. should technically check if the illusion object is p3'd but the case where one is p3'd but not the other will never arise (and if it does ur a goddamn little cheater)
		# we check for mirror armor since that's the p3 ability for shield form, saves me having to check for form and then illusion form
		if attacker.ability==:STANCECHANGE && attacker.pokemon.PULSE3 && attacker.ability==:MIRRORARMOR
			attacker.ability= [:STANCECHANGE,:JUSTIFIED,:SHARPNESS]
		end
		if move.function==0x16e && opponent.stages[PBStats::ATTACK] > 0 # lawds spec thief
			atkstage = [12, (atkstage + opponent.stages[PBStats::ATTACK])].min
		end
		if move.function==0x309 || move.function ==0x20D || move.function == 0x80A || move.function == 0x80B #Shell Side Arm / Super Ultra Mega Death Move / Unleashed Power / Blinding Speed
			move.smartDamageCategory(attacker,opponent,field)
		end
		if move.function==0x184 # lawds body press
			atk=attacker.defense
			atkstage=attacker.stages[PBStats::DEFENSE]+6
		end
		if move.function==0x216 # lawds UMD2
			atk=attacker.spdef
			atkstage=attacker.stages[PBStats::SPDEF]+6
		end
		if move.function==0x121 # Foul Play
			atk=opponent.attack
			atkstage=opponent.stages[PBStats::ATTACK]+6
		end
		if move.pbIsSpecial?(type) && !((field==:PSYTERRAIN || @battle.state.effects[:PSYTERRAIN]>0 || @gonnaTerrains.include?(:PSYTERRAIN)) && attacker.ability==:PUREPOWER)
			atk=attacker.spatk
			atk=attacker.attack if attacker.crested == :REUNICLUS && attacker.type1 == :FIGHTING
			atkstage=attacker.stages[PBStats::SPATK]+6
			if move.move==:ELECTROSHOT || move.move==:METEORBEAM # LAWDS take into account electro shot/meteorbeam boosting SpA before damage
				atkstage+=1 if atkstage<12 && attacker.ability!=:INDUSTRYSTANDARD
			end
			if attacker.species==:AEGISLASH
				originalform = attacker.form
				dummymon = pbAegislashStats(attacker)
				dummymon.pbUpdate
				atk=dummymon.spatk
				atkstage=dummymon.stages[PBStats::SPATK]+6
				dummymon.form = originalform
				dummymon.pbUpdate
			end
			if move.function==0x121 # Foul Play
				atk=opponent.spatk
				atkstage=opponent.stages[PBStats::SPATK]+6
			end
			if field == :GLITCH
				atk = attacker.getSpecialStat(opponent.ability== :UNAWARE, electroshot: move.move==:ELECTROSHOT) # lawds added parameter for electro shot on glitch, making it see the +1
				atkstage = 6 #getspecialstat handles unaware
			end
		end
		case attacker.crested
			when :CLAYDOL then atkstage=attacker.stages[PBStats::DEFENSE]+6 if move.pbIsSpecial?(type)
			when :DEDENNE then atkstage=attacker.stages[PBStats::SPEED]+6 if !move.pbIsSpecial?(type)
		end
		atkstage = 12 if atkstage > 12
		atkstage = 0 if atkstage < 0
		if opponent.ability != :UNAWARE || moldBreakerCheck(attacker,move) 
			atk_after_stat_changes=(atk*1.0*stagemul[atkstage]/stagediv[atkstage]).floor
			#LAWDS 6/4/2024: AI only considers stat changes that would result in lower damage if its crit rate is less than 100%, since a guaranteed crit would ignore that damage drop.
			if (atk_after_stat_changes > atk) || (move.pbCritRate?(attacker,opponent) < 3)
				atk = atk_after_stat_changes
			end
		end

		if @mondata.skill>=BESTSKILL && field != :INDOOR
			# lawds - account for wind rider on sky with tailwind
			if field == :SKY && opponent.ability== :WINDRIDER && opponent.pbOwnSide.effects[:Tailwind] != 0 && ((type == :FLYING && move.pbIsSpecial?(type)) || move.windMove?) && !moldBreakerCheck(attacker,move)
				field_boost = 1
			else
				field_boost = move.moveFieldBoost
			end
			basedamage=(basedamage*field_boost)#.round	# LAWDS - minimize rounding
			# lawds eterrain overlay teravolt
			if Rejuv && (field==:ELECTERRAIN || @battle.state.effects[:ELECTERRAIN]!=0 || @gonnaTerrains.include?(:ELECTERRAIN)) && type == :ELECTRIC && attacker.ability== :TERAVOLT
					basedamage = (basedamage*1.5)#.round
			end
			case field
			when :ELECTERRAIN
				if type == :GROUND && opponent.ability== :TRANSISTOR
					basedamage = (basedamage*0.5)#.round
				end
			when :CHESS
				# Chess Move boost
				if (CHESSMOVES).include?(move.move)
					if (opponent.ability== :ADAPTABILITY) || (opponent.ability== :ANTICIPATION) || (opponent.ability== :SYNCHRONIZE) || (opponent.ability== :TELEPATHY)
						basedamage=(basedamage*0.5)#.round
					end
					if (opponent.ability== :OBLIVIOUS) || (opponent.ability== :KLUTZ) || (opponent.ability== :UNAWARE) || (opponent.ability== :SIMPLE) || (Rejuv && opponent.ability== :DEFEATIST) || opponent.effects[:Confusion]>0
						basedamage=(basedamage*2)#.round
					end
					if Rejuv && (attacker.ability== :KLUTZ)
						basedamage=0
					end
				end
				if Rejuv && attacker.ability== :RECKLESS || attacker.ability== :GORILLATACTICS
					basedamage = (basedamage*1.2)#.round
				end
				# Illusion damage boost TODO?: make sure the AI doesn't see this for opposing Zoroark?
				if Rejuv && attacker.effects[:Illusion]
					basedamage = (basedamage*1.2)#.round
				end
				if Rejuv && attacker.ability== :COMPETITIVE
					frac = (1.0*attacker.hp)/(1.0*attacker.totalhp)
					multiplier = 1.0  
					multiplier += ((1.0-frac)/0.8)  
					if frac < 0.2  
						multiplier = 2.0  
					end  
					basedamage=(basedamage*multiplier)#.round
				end
				# Queen piece boost																
				if (attacker.pokemon.piece==:QUEEN && attacker.ability != :QUEENLYMAJESTY)
					basedamage=(basedamage*1.5)#.round
				end
			
				#Knight piece boost
				if attacker.pokemon.piece==:KNIGHT && opponent.pokemon.piece==:QUEEN
					basedamage=(basedamage*3.0)#.round
				end
			when :DARKCRYSTALCAVERN
				if Rejuv && attacker.effects[:Illusion]
					basedamage = (basedamage*1.2) if pbAIfaster?(@move)
				end
			when :BIGTOP
				if ((type == :FIGHTING && move.pbIsPhysical?(type)) || (STRIKERMOVES).include?(move.move))
					if attacker.ability== :HUGEPOWER || attacker.ability== :GUTS ||		# Lawds Mod - Gale Strike and Gigaton Hammer have better Striker odds. Helping Hand also guarantees high striker odds
						attacker.ability== :PUREPOWER || attacker.ability== :SHEERFORCE || move.move == :GALESTRIKE || move.move == :GIGATONHAMMER || attacker.effects[:HelpingHand]
						provimult=2.2
          				provimult=1.6 if $game_variables[:DifficultyModes]==1
						provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
						basedamage=(basedamage*provimult)#.round
					else
						provimult=1.2
          				provimult=1.1 if $game_variables[:DifficultyModes]==1
						provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
						basedamage=(basedamage*provimult)#.round
					end
				end
				if move.isSoundBased?
					provimult=1.5
          			provimult=1.25 if $game_variables[:DifficultyModes]==1
					provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
					basedamage=(basedamage*provimult)#.round
				end
			when :SHORTCIRCUIT
				if type == :ELECTRIC
					damageroll = btlfield.getRoll(update_roll: false, maximize_roll: (@battle.state.effects[:ELECTERRAIN] > 0 || @gonnaTerrains.include?(:ELECTERRAIN)))
					damageroll = 4 if attacker.effects[:Charge] # LAWDS - charge effect makes it always apply the max roll
					damageroll = ((damageroll-1.0)/2.0)+1.0 if $game_variables[:DifficultyModes]==1 && !$game_switches[:FieldFrenzy]
          			damageroll = ((damageroll-1.0)*2.0)+1.0 if $game_variables[:DifficultyModes]!=1 && $game_switches[:FieldFrenzy] && damageroll > 1
          			damageroll = damageroll/2.0 if $game_variables[:DifficultyModes]!=1 && $game_switches[:FieldFrenzy] && damageroll < 1
					basedamage=(basedamage*damageroll)#.round
				end
			when :WATERSURFACE, :UNDERWATER
				if attacker.ability== :PROPELLERTAIL
					basedamage=(basedamage*1.5)#.round if move.priority > 0
				end
			when :CAVE
				if move.isSoundBased?
					provimult=1.5
          			provimult=1.25 if $game_variables[:DifficultyModes]==1
					provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
					basedamage=(basedamage*provimult)#.round
				end
			when :MOUNTAIN
				if move.windMove? && @battle.pbWeather== :STRONGWINDS
					provimult=1.5
          			provimult=1.25 if $game_variables[:DifficultyModes]==1
					provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
					basedamage=(basedamage*provimult)#.round
				end
			when :SNOWYMOUNTAIN
				if move.windMove? && @battle.pbWeather== :STRONGWINDS
					provimult=1.5
          			provimult=1.25 if $game_variables[:DifficultyModes]==1
					provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
					basedamage=(basedamage*provimult)#.round
				end
			when :MIRROR
				if (PBFields::MIRRORMOVES).include?(move.move) && opponent.stages[PBStats::EVASION]>0
					provimult=2.0
          			provimult=1.5 if $game_variables[:DifficultyModes]==1
					provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
					basedamage=(basedamage*provimult)#.round
				end
			when :CORRUPTED
				if attacker.ability== :CORROSION
					basedamage=(basedamage*1.5)#.round
				end
			when :SKY # lawds early bird
				basedamage=(basedamage*1.2) if attacker.ability==:EARLYBIRD && ([0x213, 0x0C5, 0x0C6, 0x0C7, 0x0C8, 0x0C9, 0x0CA, 0x0CB, 0x0CC, 0x0CD, 0x308].include?(move.function) || (move.function==0x0C4 && @battle.pbWeather!=:SUNNYDAY)) && !attacker.hasWorkingItem(:POWERHERB)
			when :CONCERT1,:CONCERT2,:CONCERT3,:CONCERT4
				if move.isSoundBased?
					provimult=1.5
          			provimult=1.25 if $game_variables[:DifficultyModes]==1
					provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
					basedamage=(basedamage*provimult)#.round
				end
			when :DEEPEARTH
				if type == :GROUND && opponent.hasType?(:GROUND)
				  	provimult=0.5
				  	provimult=0.75 if $game_variables[:DifficultyModes]==1 && !$game_switches[:FieldFrenzy]
				  	provimult=0.25 if $game_variables[:DifficultyModes]!=1 && $game_switches[:FieldFrenzy]
				  	basedamage=(basedamage*provimult)#.round
				end
				if move.pbIsPriorityMoveAI(attacker) && move.basedamage > 0
					provimult=0.7
					provimult=0.85 if $game_variables[:DifficultyModes]==1
					provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
					basedamage=(basedamage*provimult)#.round
				end
				# lawds fixed this to accurately check for negative prio instead of positive i wish i was joking
				if move.priorityCheck(attacker) < 0 && move.basedamage > 0
					provimult=1.3
					provimult=1.15 if $game_variables[:DifficultyModes]==1
					provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
					basedamage=(basedamage*provimult)#.round
				end
			when :DRAGONSDEN # LAWDS dragon's den thermal exchange
				if type == :ICE && attacker.ability==:THERMALEXCHANGE
					provimult=1.5
          			provimult=1.25 if $game_variables[:DifficultyModes]==1
          			basedamage=(basedamage*provimult)#.round
				end
			end
		end
		if type == :POISON && (opponent.ability== :PASTELVEIL || opponent.pbPartner.ability== :PASTELVEIL) && ([:MISTY,:RAINBOW].include?(field) || @battle.state.effects[:MISTY] > 0 || @gonnaTerrains.include?(:MISTY))
			basedamage = (basedamage*0.5)#.round
		end
		for terrain in [:ELECTERRAIN,:GRASSY,:MISTY,:PSYTERRAIN,:FROZENDIMENSION] # LAWDS - frozen dimensional overlay
			if @battle.state.effects[terrain] > 0 || @gonnaTerrains.include?(terrain)
				overlaymult = move.moveOverlayBoost(terrain)
				basedamage*=overlaymult
			end
		end

		if @mondata.skill>=MEDIUMSKILL
		  ############ ATTACKER ABILITY CHECKS ############
		  # lawds pulse3
		  abil=[]
		  if attacker.ability.is_a?(PokeAbility)
			if attacker.ability.ability.is_a?(Array)
				for i in attacker.ability.ability
					abil.push(i)
				end
			else
				abil = [attacker.ability.ability]
			end
		  end
		  for i in abil
		    case i
			#Technician
		  	when :TECHNICIAN								# Lawds Mod - Technician Factory interaction is now on Short-Circuit as well
				basedamage=(basedamage*1.5) if (basedamage<=60) || ([:FACTORY,:SHORTCIRCUIT,:CONCERT1,:CONCERT2,:CONCERT3,:CONCERT4].include?(field) && basedamage<=80)
			# Iron Fist
		 	when :IRONFIST
				basedamage=(basedamage*1.3) if move.punchMove? # lawds iron fist buff
			# Strong Jaw
		  	when :STRONGJAW
				basedamage=(basedamage*1.5) if (PBStuff::BITEMOVE).include?(move.move)
			# Sharpness
		  	when :SHARPNESS
				if move.sharpMove?
					basedamage=(basedamage*1.5)
				end
			# True Shot
			when :TRUESHOT
				basedamage=(basedamage*1.3) if (PBStuff::BULLETMOVE).include?(move.move)
			#Tough Claws
			when :TOUGHCLAWS
				basedamage=(basedamage*1.3) if move.contactMove?
			# lawds quick draw
			when :QUICKDRAW
				if attacker.turncount==0
					qdmult = field==:COLOSSEUM ? 1.6 : 1.3
					basedamage=(basedamage*qdmult)
				end
			# Lawds Mod 6/19/2024 - Rampant Growth boosts Grass-type attacks by 1.5x
			when :RAMPANTGROWTH
				if move.type == :GRASS
					basedamage=(basedamage*1.5)#.round
				end
			# Reckless
			when :RECKLESS
				if move.function==0xFA ||  # Take Down, etc.
					move.function==0xFD ||  # Volt Tackle
					move.function==0xFE ||  # Flare Blitz
					move.function==0x10B || # Jump Kick, Hi Jump Kick
					move.function==0x130    # Shadow End
					basedamage=(basedamage*1.2)#.round
				end
			# Flare Boost
			when :FLAREBOOST
				if field != :FROZENDIMENSION && (attacker.status== :BURN || [:BURNING,:VOLCANIC,:INFERNAL].include?(field)) && move.pbIsSpecial?(type)
					basedamage=(basedamage*1.5)#.round
				end
			# Toxic Boost
			when :TOXICBOOST
				if (attacker.status== :POISON || field == :CORROSIVE || field == :CORROSIVEMIST || field == :WASTELAND || field == :MURKWATERSURFACE) && move.pbIsPhysical?(type)
					basedamage= field == :CORRUPTED ? (basedamage*2.0) : (basedamage*1.5)
				end
			# LAWDS Rivalry rework
			when :RIVALRY
				mult = 1.0
				for stat in opponent.stages
					mult+=0.1 if stat > 0
				end
				basedamage=(basedamage*mult)#.round
			# Mega Launcher
			when :MEGALAUNCHER
				if move.move == :AURASPHERE || move.move == :DRAGONPULSE || move.move == :DARKPULSE || move.move == :WATERPULSE || move.move == :ORIGINPULSE
					basedamage=(basedamage*1.5)#.round
				end
			# Sand Force
			when :SANDFORCE
				if @battle.pbWeather== :SANDSTORM && (type == :ROCK || type == :GROUND || type == :STEEL)
					basedamage=(basedamage*1.3)#.round
				elsif @mondata.skill>=BESTSKILL && (field == :DESERT || field == :ASHENBEACH) &&
					(type == :ROCK || type == :GROUND || type == :STEEL)
					basedamage=(basedamage*1.3)#.round
				end
			# Analytic
			when :ANALYTIC
				if !pbAIfaster?(move,nil,attacker,opponent) # lawds correcting this conditional by inverting it
					basedamage = (basedamage*1.3)#.round
				end
			# Sheer Force
			when :SHEERFORCE
				basedamage=(basedamage*1.3) if move.effect>0
			# Normalize
			when :NORMALIZE
				basedamage=(basedamage*1.2)
			# Hustle
			when :HUSTLE
				atk= [:BACKALLEY,:CITY].include?(field) ? (atk*1.75) : (atk*1.5) if move.pbIsPhysical?(type)
			# Guts
			when :GUTS
				atk=(atk*1.5) if !attacker.status.nil? && move.pbIsPhysical?(type)
			#Plus/Minus
			when :PLUS, :MINUS
				if move.pbIsSpecial?(type)
					partner=attacker.pbPartner
					if partner.ability== :PLUS || partner.ability== :MINUS
						atk=(atk*1.5)
					elsif (field == :SHORTCIRCUIT || (Rejuv && field == :ELECTERRAIN) || @battle.state.effects[:ELECTERRAIN] > 0 || @gonnaTerrains.include?(:ELECTERRAIN)) && @mondata.skill>=BESTSKILL
						atk=(atk*1.5)
					end
				end
			#Defeatist
			when :DEFEATIST
				atk=(atk*0.5) if attacker.hp<=(attacker.totalhp/2.0).floor
			#Pure/Huge Power
			when :PUREPOWER, :HUGEPOWER
				if @mondata.skill>=BESTSKILL
					# lawds pure power
					atk=(atk*2.0) if move.pbIsPhysical?(type) || ((field == :PSYTERRAIN || @battle.state.effects[:PSYTERRAIN] > 0 || @gonnaTerrains.include?(:PSYTERRAIN)) && i==:PUREPOWER)
				elsif move.pbIsPhysical?(type)
					atk=(atk*2.0)
				end
			#Solar Power			# Lawds Mod 6/19/2024 - Wildfire
			when :SOLARPOWER, :WILDFIRE
				if (@battle.pbWeather== :SUNNYDAY || attacker.pbPartner.crested == :CHERRIM || (field == :SKY && ![:RAINDANCE, :HAIL, :SANDSTORM].include?(field) && i==:SOLARPOWER) || (i==:WILDFIRE && field==:INFERNAL)) && move.pbIsSpecial?(type)
					atk=(atk*1.5)
				end
			#Slow Start
			when :SLOWSTART
				if attacker.turncount<5 && move.pbIsPhysical?(type) && field != :DEEPEARTH # lawds
					atk=(atk*0.5)
				end
			#Punk Rock (offensive)
			when :PUNKROCK
				if (field == :BIGTOP || field == :CAVE) && move.isSoundBased?
					basedamage=(basedamage*1.5)
				elsif move.isSoundBased?
					basedamage=(basedamage*1.3)
				end
			# LAWDS Liquid Voice buff
			when :LIQUIDVOICE
				if move.isSoundBased?
					if field==:ICY
						basedamage=(basedamage*1.5)
					else
						basedamage=(basedamage*1.2)
					end
				end
			end
		  end
		    # Gen 9 Mod - Beads of Ruin, Sword of Ruin
			if (attacker.pbOpposing1.ability== :VESSELOFRUIN || attacker.pbOpposing2.ability== :VESSELOFRUIN || attacker.pbPartner.ability== :VESSELOFRUIN) && attacker.ability != :VESSELOFRUIN && move.pbIsSpecial?(type) 
				basedamage=(basedamage*0.75).round
			elsif (attacker.pbOpposing1.ability== :TABLETSOFRUIN || attacker.pbOpposing2.ability== :TABLETSOFRUIN || attacker.pbPartner.ability== :TABLETSOFRUIN) && attacker.ability != :TABLETSOFRUIN && move.pbIsPhysical?(type)
				basedamage=(basedamage*0.75).round
			end
			# LAWDS handle vespiquen crest differently
			basedamage=(basedamage*1.5) if attacker.crested==:VESPIQUEN  # dont check the effect since it will always be active while vesp is attacking
			#Power Spot
			if attacker.pbPartner.ability== :POWERSPOT
				if [:HOLY,:PSYTERRAIN,:HAUNTED,:BEWITCHED].include?(field)
					basedamage=(basedamage*1.5)
				else
					basedamage=(basedamage*1.3)
				end
			end
			#Steely Spirit			LAWDS - code blocks which check partner's ability shouldn't be if-else with blocks that only check attacker's ability
			if type == :STEEL && (attacker.ability== :STEELYSPIRIT || attacker.pbPartner.ability== :STEELYSPIRIT)
				if field == :FAIRYTALE
					basedamage=(basedamage*2.0)
				else
					basedamage=(basedamage*1.5)
				end
			end
			#Flash Fire
			if attacker.effects[:FlashFire]
				if type == :FIRE
					atk=(atk*1.5)
				end
			end
			# Gen 9 Mod - Supreme Overlord
			if attacker.ability== :SUPREMEOVERLORD
				allyfainted = attacker.effects[:SupremeOverlord]
				modifier = (allyfainted * 0.1) + 1.0
				basedamage = (basedamage*modifier)
			end
			if type == :ELECTRIC && attacker.ability== :TRANSISTOR
				basedamage=(basedamage*1.5)
			end
			if type == :DRAGON && attacker.ability== :DRAGONSMAW
				basedamage=(basedamage*1.5)
			end
			if type == :DRAGON && attacker.ability== :INEXORABLE
				if pbAIfaster?(move,nil,attacker,opponent)
					basedamage = (basedamage*1.5)
				end
			end
			if  attacker.ability== :GORILLATACTICS && move.pbIsPhysical?(type)
				atk=(atk*1.5)
			end
			# Type Changing Abilities
			if move.type == :NORMAL && attacker.ability != :NORMALIZE
				# Aerilate
				if attacker.ability== :AERILATE
					if [:MOUNTAIN,:SNOWYMOUNTAIN,:SKY,:VOLCANICTOP].include?(field) # lawds aerilate on vtop
						basedamage=(basedamage*1.5)
					else
						basedamage=(basedamage*1.2)
					end
				# Galvanize
				elsif attacker.ability== :GALVANIZE
					if @mondata.skill>=BESTSKILL
						if field == :ELECTERRAIN || field == :FACTORY || @battle.state.effects[:ELECTERRAIN] > 0 || @gonnaTerrains.include?(:ELECTERRAIN) # Electric or Factory Fields
							basedamage=(basedamage*1.5)
						elsif field == :SHORTCIRCUIT # Short-Circuit Field
							basedamage=(basedamage*2)
						else
							basedamage=(basedamage*1.2)
						end
					else
						basedamage=(basedamage*1.2)
					end
				# Pixilate
				elsif attacker.ability== :PIXILATE
					if @mondata.skill>=BESTSKILL
						if field == :MISTY || @battle.state.effects[:MISTY] > 0 || @gonnaTerrains.include?(:MISTY)
							basedamage= (basedamage*1.5) # Misty Field
						else
							basedamage= (basedamage*1.2)
						end
					else
						basedamage=(basedamage*1.2)
					end
				# Refrigerate
				elsif attacker.ability== :REFRIGERATE
					if @mondata.skill>=BESTSKILL
						if field == :ICY || field == :SNOWYMOUNTAIN || field == :FROZENDIMENSION # Icy Fields
							basedamage=(basedamage*1.5)
						else
							basedamage=(basedamage*1.2)
						end
					else
						basedamage=(basedamage*1.2)
					end
				end
			end
				# Quark Drive (offense boost)
			if attacker.ability== :QUARKDRIVE
				basedamage=(basedamage*1.3) if (attacker.effects[:Quarkdrive][0] == PBStats::ATTACK && move.pbIsPhysical?(type)) || (attacker.effects[:Quarkdrive][0] == PBStats::SPATK && move.pbIsSpecial?(type))
			end
			# LAWDS - protosynthesis, might be identical to the gen 9 mod's idk
			if attacker.ability== :PROTOSYNTHESIS
				basedamage=(basedamage*1.3) if (attacker.effects[:Protosynthesis][0] == PBStats::ATTACK && move.pbIsPhysical?(type)) || (attacker.effects[:Protosynthesis][0] == PBStats::SPATK && move.pbIsSpecial?(type))
			end

				# Execution
			if attacker.ability== :EXECUTION
				basedamage=(basedamage*2.0) if opponent.hp<=(opponent.totalhp/2.0).floor
			end
			#Solar Idol
			if attacker.ability== :SOLARIDOL
				if @battle.pbWeather== :SUNNYDAY && move.pbIsPhysical?(type)
					atk=(atk*1.5)
				end
			end
			#Solar Idol
			if attacker.ability== :LUNARIDOL
				if @battle.pbWeather== :HAIL && move.pbIsSpecial?(type)
					atk=(atk*1.5)
				end
			end

		  ############ OPPONENT ABILITY CHECKS ############
			if !moldBreakerCheck(attacker,move) && !opponent.hasWorkingItem(:ABILITYSHIELD) && !(move.isSoundBased? && attacker.ability==:LIQUIDVOICE) # lawds just put this here manually ig
				# Heatproof
				if opponent.ability== :HEATPROOF
					if type == :FIRE
						basedamage=(basedamage*0.5)
					end
				end
				# Dry Skin
				if opponent.ability== :DRYSKIN
					if type == :FIRE
						basedamage=(basedamage*1.25)
					end
				end
				if opponent.ability== :THICKFAT
					if type == :ICE || type == :FIRE
						atk=(atk*0.5)
					end
				end
				# Punk Rock (defensive)
				if opponent.ability== :PUNKROCK
					if move.isSoundBased?
						basedamage=(basedamage*0.5)
					end
				end
				if opponent.ability== :PURIFYINGSALT			# LAWDS - Purifying Salt
					if type == :GHOST
						atk=(atk*0.5)
					end
				end
			end

			############ ATTACKER ITEM CHECKS ############
			if attitemworks #don't bother with this if it doesn't work
				#Type-boosting items
				if field == :CRYSTALCAVERN && $cache.items[attacker.item].checkFlag?(:gem) # LAWDS - gems on crystal cavern provide a tera boost rather than being consumed
					if $cache.items[attacker.item].checkFlag?(:typeboost) == type
						if attacker.hasType?(type)
							basedamage=(basedamage*1.33333333333)
						else
							basedamage=(basedamage*1.5) 
						end
					end
				else
					case type
						when :NORMAL
							case attacker.item
								when :SILKSCARF then basedamage=(basedamage*1.2)
								when :NORMALGEM then basedamage=(basedamage*1.3)
								when :PUREINCENSE then basedamage= field==:PSYTERRAIN ? (basedamage*1.5) : basedamage
							end
						when :FIGHTING
							case attacker.item
								when :BLACKBELT,:FISTPLATE then basedamage=(basedamage*1.2)
								when :FIGHTINGGEM then basedamage=(basedamage*1.3)
							end
						when :FLYING
							case attacker.item
								when :SHARPBEAK,:SKYPLATE then basedamage=(basedamage*1.2)
								when :FLYINGGEM then basedamage=(basedamage*1.3)
							end
						when :POISON
							case attacker.item
								when :POISONBARB,:TOXICPLATE then basedamage=(basedamage*1.2)
								when :FLYINGGEM then basedamage=(basedamage*1.3)
							end
						when :GROUND
							case attacker.item
								when :SOFTSAND,:EARTHPLATE then basedamage=(basedamage*1.2)
								when :GROUNDGEM then basedamage=(basedamage*1.3)
							end
						when :ROCK
							case attacker.item
								when :HARDSTONE,:STONEPLATE then basedamage=(basedamage*1.2)
								when :ROCKGEM then basedamage=(basedamage*1.3)
								when :ROCKINCENSE then basedamage= field==:PSYTERRAIN && !attacker.hasType?(:ROCK) ? (basedamage*1.5) : (basedamage*1.2)
							end
						when :BUG
							case attacker.item
								when :SILVERPOWDER,:INSECTPLATE then basedamage=(basedamage*1.2)
								when :BUGGEM then basedamage=(basedamage*1.3)
							end
						when :GHOST
							case attacker.item
								when :SPELLTAG,:SPOOKYPLATE then basedamage=(basedamage*1.2)
								when :GHOSTGEM then basedamage=(basedamage*1.3)
							end
						when :STEEL
							case attacker.item
								when :METALCOAT,:IRONPLATE then basedamage=(basedamage*1.2)
								when :STEELGEM then basedamage=(basedamage*1.3)
							end
						when :FIRE
							case attacker.item
								when :CHARCOAL,:FLAMEPLATE then basedamage=(basedamage*1.2)
								when :FIREGEM then basedamage=(basedamage*1.3)
							end
						when :WATER
							case attacker.item
								when :MYSTICWATER,:SPLASHPLATE,:WAVEINCENSE then basedamage=(basedamage*1.2)
								when :WATERGEM then basedamage=(basedamage*1.3)
								when :SEAINCENSE then basedamage= field==:PSYTERRAIN && !attacker.hasType?(:WATER) ? (basedamage*1.5) : (basedamage*1.2)
							end
						when :GRASS
							case attacker.item
								when :MIRACLESEED,:MEADOWPLATE then basedamage=(basedamage*1.2)
								when :FLYINGGEM then basedamage=(basedamage*1.3)
								when :ROSEINCENSE then basedamage= field==:PSYTERRAIN && !attacker.hasType?(:GRASS) ? (basedamage*1.5) : (basedamage*1.2)
							end
						when :ELECTRIC
							case attacker.item
								when :MAGNET,:ZAPPLATE then basedamage=(basedamage*1.2)
								when :ELECTRICGEM then basedamage=(basedamage*1.3)
							end
						when :PSYCHIC
							case attacker.item
								when :TWISTEDSPOON,:MINDPLATE,:ODDINCENSE then basedamage=(basedamage*1.2)
								when :PSYCHICGEM then basedamage=(basedamage*1.3)
							end
						when :ICE
							case attacker.item
								when :NEVERMELTICE,:ICICLEPLATE then basedamage=(basedamage*1.2)
								when :ICEGEM then basedamage=(basedamage*1.3)
							end
						when :DRAGON
							case attacker.item
								when :DRAGONFANG,:DRACOPLATE then basedamage=(basedamage*1.2)
								when :DRAGONGEM then basedamage=(basedamage*1.3)
							end
						when :DARK
							case attacker.item
								when :BLACKGLASSES,:DREADPLATE then basedamage=(basedamage*1.2)
								when :DARKGEM then basedamage=(basedamage*1.3)
							end
						when :FAIRY
							case attacker.item
								when :PIXIEPLATE then basedamage=(basedamage*1.2)
								when :FAIRYGEM then basedamage=(basedamage*1.3)
							end
					end
				end
				# Muscle Band
				if attacker.item == :MUSCLEBAND && move.pbIsPhysical?(type)
					basedamage=(basedamage*1.1)
				# Wise Glasses
				elsif attacker.item == :WISEGLASSES && move.pbIsSpecial?(type)
					basedamage=(basedamage*1.1)
				# LAWDS quick claw
				elsif attacker.item == :QUICKCLAW && move.priorityCheck(attacker) > 0
					basedamage=(basedamage*1.2)
				# LAWDS razor fang
				elsif attacker.item == :RAZORFANG && (PBStuff::BITEMOVE).include?(move.move)
					basedamage=(basedamage*1.2)	
				# LAWDS razor claw
				elsif attacker.item == :RAZORCLAW && move.sharpMove?
					basedamage=(basedamage*1.2)
				# LAWDS punching glove
				elsif attacker.item == :PUNCHINGGLOVE && move.punchMove?
					basedamage=(basedamage*1.2)
				# Legendary Orbs
				elsif attacker.item == :LUSTROUSORB
					if (attacker.pokemon.species == :PALKIA) && (type == :DRAGON || type == :WATER)
						basedamage=(basedamage*1.2)
					end
				elsif attacker.item == :ADAMANTORB
					if (attacker.pokemon.species == :DIALGA) && (type == :DRAGON || type == :STEEL)
						basedamage=(basedamage*1.2)
					end
				elsif attacker.item == :GRISEOUSORB
					if (attacker.pokemon.species == :GIRATINA) && (type == :DRAGON || type == :GHOST)
						basedamage=(basedamage*1.2)
					end
				elsif attacker.item == :SOULDEW
					if (attacker.pokemon.species == :LATIAS || attacker.pokemon.species == :LATIOS) &&
						(type == :DRAGON || type == :PSYCHIC)
						basedamage=(basedamage*1.2)
					end
				# Gen 9 Mod - Ogerpon's Masks give it a 1.2x boost to all damaging moves it uses.
				elsif [:WELLSPRINGMASK, :HEARTHFLAMEMASK, :CORNERSTONEMASK].include?(attacker.item) 
					basedamage=(basedamage*1.2) if attacker.species==:OGERPON
				end
				# lawds separated these due to precrest
				if attacker.crested
					if attacker.crested == :FERALIGATR
						basedamage=(basedamage*1.5) if (PBStuff::BITEMOVE).include?(move.move)
					elsif attacker.crested == :CHERRIM || attacker.pbPartner.crested == :CHERRIM
						basedamage=(basedamage*1.5) if (type == :FIRE && @battle.pbWeather!=:SUNNYDAY) # LAWDS - apply sun boost to fire moves if sun is not up, ignore if it is since the sun AI already accounts for that boost
					elsif attacker.crested == :BOLTUND
						basedamage=(basedamage*1.5) if (PBStuff::BITEMOVE).include?(move.move) && pbAIfaster?(move,nil,attacker,opponent)
					elsif attacker.crested == :CLAYDOL
						basedamage=(basedamage*1.5) if move.isBeamMove?
					elsif attacker.crested == :DRUDDIGON # LAWDS druddigon crest buff
						if type == :DRAGON
							basedamage=(basedamage*1.3)
						elsif type == :FIRE
							basedamage=(basedamage*1.5)
						end
					elsif attacker.crested == :FEAROW
						basedamage=(basedamage*1.5) if (PBStuff::STABBINGMOVE).include?(move.move)
					# Lawds Mod - Braviary Crest
					elsif attacker.crested == :BRAVIARY
						basedamage=(basedamage*(1.0 + (1.0*(attacker.totalhp-attacker.hp)/attacker.totalhp))) if move.pbIsPhysical?
					elsif attacker.crested == :DUSKNOIR # LAWDS - rework to Dusknoir crest.
						basedamage=(basedamage*1.5) if (move.basedamage<=60 || ((field == :FACTORY || @battle.ProgressiveFieldCheck(PBFields::CONCERT))&& move.basedamage<=80))
						basedamage=(basedamage*1.2) if move.punchMove?
					elsif attacker.crested == :CRABOMINABLE
						basedamage=(basedamage*1.5) if !pbAIfaster?(move,nil)
					# lawds mod - electivire, pz crests
					elsif attacker.crested == :ELECTIVIRE
						basedamage=(basedamage*1.3) if move.contactMove?
					elsif attacker.crested == :PORYGONZ
						basedamage=(basedamage*1.2)
					elsif attacker.crested == :AMPHAROS
						basedamage= attacker.hasType?(type) ? (basedamage*1.2) : (basedamage*1.5) if attacker.moves[0] == move
					elsif attacker.crested == :CASTFORM && attacker.form == 1
						basedamage=(basedamage*1.5) if @battle.pbWeather== :SUNNYDAY && move.pbIsSpecial?(type)
					elsif attacker.crested == :LUXRAY
						basedamage=(basedamage*1.2) if move.type == :NORMAL && type == :ELECTRIC
					elsif attacker.crested == :SAWSBUCK  
					  case attacker.form
					  when 0 then basedamage*=1.2 if move.type == :NORMAL && type == :WATER
					  when 1 then basedamage*=1.2 if move.type == :NORMAL && type == :FIRE
					  when 2 then basedamage*=1.2 if move.type == :NORMAL && type == :GROUND
					  when 3 then basedamage*=1.2 if move.type == :NORMAL && type == :ICE
					  end
					end
				end
			end
			#pbBaseDamageMultiplier

			############ MISC CHECKS ############
			# Charge
			if attacker.effects[:Charge] && type == :ELECTRIC
				basedamage=(basedamage*2.0)
			end
			# LAWDS desert sand spit
			# Helping Hand
			if attacker.effects[:HelpingHand]
				basedamage=(basedamage*1.5)
			end
			# Water/Mud Sport
			if type == :FIRE
				if @battle.state.effects[:WaterSport]>0
					basedamage=(basedamage*0.33)
				end
			elsif type == :ELECTRIC
				if @battle.state.effects[:MudSport]>0
					basedamage=(basedamage*0.33)
				end
			# Dark Aura/Aurabreak
			elsif type == :DARK
				if @battle.battlers.any? {|battler| battler.ability== :DARKAURA}
					if field== :DARKNESS1
						basedamage*= @battle.battlers.any? {|battler| battler.ability== :AURABREAK} ? (0.6) : (1.4)
					elsif field == :DARKNESS2
						basedamage*= @battle.battlers.any? {|battler| battler.ability== :AURABREAK} ? (0.5) : (1.5)
					elsif field == :DARKNESS3
						basedamage*= @battle.battlers.any? {|battler| battler.ability== :AURABREAK} ? (0.33) : (1.66)
					else
						basedamage*= @battle.battlers.any? {|battler| battler.ability== :AURABREAK} ? (2.0/3) : (4.0/3)
					end
				end
			# Fairy Aura/Aurabreak
			elsif type == :FAIRY
				if @battle.battlers.any? {|battler| battler.ability== :FAIRYAURA}
					if field== :DARKNESS1
						basedamage*= @battle.battlers.any? {|battler| battler.ability== :AURABREAK} ? (0.7) : (1.3)
					elsif field == :DARKNESS2
						basedamage*= @battle.battlers.any? {|battler| battler.ability== :AURABREAK} ? (0.8) : (1.2)
					elsif field == :DARKNESS3
						basedamage*= @battle.battlers.any? {|battler| battler.ability== :AURABREAK} ? (0.9) : (1.1)
					else
						basedamage*= @battle.battlers.any? {|battler| battler.ability== :AURABREAK} ? (2.0/3) : (4.0/3)
					end
				end
			end
			#Battery
			if attacker.pbPartner.ability== :BATTERY && move.pbIsSpecial?(type)
				atk= (Rejuv && field == :ELECTERRAIN) ? (atk*1.5) : (atk*1.3)
			end
			# Spiritomb Crest
			if attacker.crested == :SPIRITOMB
				atk=(atk*(1.0+(attacker.pbFaintedPokemonCount*0.2)))
			end
			#Flower Gift
			if (@battle.pbWeather== :SUNNYDAY || field == :BEWITCHED || @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN) || attacker.crested == :CHERRIM || attacker.pbPartner.crested == :CHERRIM) && move.pbIsPhysical?(type)
				if attacker.ability== :FLOWERGIFT && attacker.species == :CHERRIM
					atk=(atk*1.5)
				end
				if attacker.pbPartner.ability== :FLOWERGIFT && attacker.pbPartner.species == :CHERRIM
					atk=(atk*1.5)
				end
			end
		end

		# Pinch Abilities
		if @mondata.skill>=BESTSKILL
			if ([:BURNING,:VOLCANIC,:INFERNAL].include?(field) || attacker.effects[:Blazed]) && attacker.ability== :BLAZE && type == :FIRE
				atk=(atk*1.5)
			elsif field == :FOREST && attacker.ability== :OVERGROW && type == :GRASS
				atk=(atk*1.5)
			elsif Rejuv && field == :GRASSY && attacker.ability== :OVERGROW && type == :GRASS
				atk=(atk*1.5)
			elsif field == :FOREST && attacker.ability== :SWARM && type == :BUG
				atk=(atk*1.5)
			elsif (field == :WATERSURFACE || field == :UNDERWATER) && attacker.ability== :TORRENT && type == :WATER
				atk=(atk*1.5)
			elsif @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN) && attacker.ability== :SWARM && type == :BUG
				atk=(atk*1.5) if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,1,2)
				atk=(atk*1.8) if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,3,4)
				atk=(atk*2) if field == :FLOWERGARDEN5
			elsif @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN) && attacker.ability== :OVERGROW && type == :GRASS
				atk=(atk*1.5) if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,1,2)
				atk=(atk*1.8) if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,3,4)
				atk=(atk*2) if field == :FLOWERGARDEN5
			elsif attacker.hp<=(attacker.totalhp/3.0).floor
				if (attacker.ability== :OVERGROW && type == :GRASS) || (attacker.ability== :BLAZE && type == :FIRE && field != :FROZENDIMENSION) ||
					(attacker.ability== :TORRENT && type == :WATER) || (attacker.ability== :SWARM && type == :BUG)
					atk=(atk*1.5)
				end
			end
		elsif @mondata.skill>=MEDIUMSKILL && attacker.hp<=(attacker.totalhp/3.0).floor
			if (attacker.ability== :OVERGROW && type == :GRASS) || (attacker.ability== :BLAZE && type == :FIRE) ||
				(attacker.ability== :TORRENT && type == :WATER) || (attacker.ability== :SWARM && type == :BUG)
				atk=(atk*1.5)
			end
		end

		# Attack-boosting items
		if @mondata.skill>=HIGHSKILL
			if (attitemworks && attacker.item == :THICKCLUB)
				if ((attacker.pokemon.species == :CUBONE) || (attacker.pokemon.species == :MAROWAK)) && move.pbIsPhysical?(type)
					atk=(atk*2.0)
				end
			elsif (attitemworks && attacker.item == :DEEPSEATOOTH)
				if (attacker.pokemon.species == :CLAMPERL) && move.pbIsSpecial?(type)
					atk=(atk*2.0)
				end
			elsif (attitemworks && [:LIGHTBALL,:PIKACHUNITE].include?(attacker.item)) # lawds pikachunite
				if (attacker.pokemon.species == :PIKACHU)
					atk=(atk*2.0)
				end
			elsif (attitemworks && attacker.item == :CHOICEBAND) && move.pbIsPhysical?(type)
				atk=(atk*1.5)
			elsif (attitemworks && attacker.item == :CHOICESPECS) && move.pbIsSpecial?(type)
				atk=(atk*1.5)
			end
		end

		#Specific ability field boosts
		if @mondata.skill>=BESTSKILL
			if field == :STARLIGHT || field == :NEWWORLD
				atk=(atk*1.5) if attacker.ability== :VICTORYSTAR
				partner=attacker.pbPartner
				atk=(atk*1.5) if partner && partner.ability== :VICTORYSTAR
			end
			atk=(atk*1.5) if attacker.ability== :QUEENLYMAJESTY && (field == :CHESS || field == :FAIRYTALE)
			atk=(atk*1.5) if attacker.ability== :COMMANDER && (field == :CHESS)# LAWDS - Commander boost on Chess Field
			atk=(atk*1.5) if attacker.ability== :LONGREACH && [:MOUNTAIN,:SNOWYMOUNTAIN,:SKY].include?(field)
			atk=(atk*1.5) if attacker.ability== :CORROSION && (field == :CORROSIVE || field == :CORROSIVEMIST)
			atk=(atk*0.5) if field == :UNDERWATER && move.pbIsPhysical?(type) && type != :WATER && ![:SWIFTSWIM,:STEELWORKER,:CLEARBODY,:FULLMETALBODY,:INDUSTRYSTANDARD].include?(attacker.ability)
			atk=(atk*1.2) if field == :COLOSSEUM && (move.function == 0xC0 || move.function == 0x307 || (attacker.crested == :CINCCINO && !move.pbIsMultiHit))
		end

		# Get base defense stat
		defense=opponent.defense
		defstage=opponent.stages[PBStats::DEFENSE]+6
		applysandstorm=false
		if move.pbHitsSpecialStat?(type)
			defense=opponent.spdef
			defstage=opponent.stages[PBStats::SPDEF]+6
			applysandstorm=true
			if field == :GLITCH
				defense = opponent.getSpecialStat(attacker.ability== :UNAWARE)
				defstage = 6 #getspecialstat handles unaware
				applysandstorm=false #getSpecialStat handles sand
			end
		end
		if move.function==0x142 && field==:DEEPEARTH # lawds topsy-turvy inverts stat changes before dealing damage on deep earth, so invert defense stage
			defstage=6-opponent.stages[PBStats::DEFENSE]
		end
		if move.function==0x16e && opponent.stages[PBStats::DEFENSE] > 0 # lawds spec thief
			defstage = 6
		end
		defstage=6 if move.function==0xA9 # Chip Away (ignore stat stages)
		defstage=6 if attacker.ability== :UNAWARE
		defense=(defense*1.0*stagemul[defstage]/stagediv[defstage]).floor
		defense = 1 if (defense == 0 || !defense)

		#Glitch Item and Ability Checks
		if @mondata.skill>=HIGHSKILL && field == :GLITCH
			if move.function==0xE0 #Explosion
				defense=(defense*0.5)
			end
		end
		defense=(defense*0.5) if attacker.crested == :ELECTRODE && move.pbHitsPhysicalStat?(type)
		defense=(defense*1.5) if opponent.crested == :VESPIQUEN && opponent.effects[:VespiCrest]==false # LAWDS handle vespiquen crest differently
		if @mondata.skill>=MEDIUMSKILL
			# Sandstorm weather
			if (@battle.pbWeather== :SANDSTORM || field == :ROCKY || field == :DARKCRYSTALCAVERN) 	# LAWDS - rocky, DCC field spdef boost for rock types
				defense=(defense*1.5) if opponent.hasType?(:ROCK) && applysandstorm
			end
			# Defensive Abilities
			if opponent.ability== :MARVELSCALE
				if move.pbIsPhysical?(type)
					if !opponent.status.nil?
						defense=(defense*1.5)
					elsif ([:MISTY,:RAINBOW,:FAIRYTALE,:DRAGONSDEN,:STARLIGHT].include?(field) || @battle.state.effects[:MISTY] > 0 || @gonnaTerrains.include?(:MISTY)) && @mondata.skill>=BESTSKILL
						defense=(defense*1.5)
					end
				end
			end
			if opponent.ability== :GRASSPELT
				defense=(defense*1.5) if move.pbIsPhysical?(type) && (field == :GRASSY || field == :FOREST || @battle.state.effects[:GRASSY] > 0 || @gonnaTerrains.include?(:GRASSY)) # Grassy Field
			end
			if opponent.ability== :FLUFFY && !moldBreakerCheck(attacker,move)
				defense=(defense*2) if !move.zmove && move.contactMove? && attacker.ability!= :LONGREACH
				defense=(defense*0.5) if type == :FIRE
			end
			if opponent.ability== :FURCOAT
				defense=(defense*2) if move.pbIsPhysical?(type) && !moldBreakerCheck(attacker,move)
			end
			if opponent.ability== :ICESCALES
				defense=(defense*2) if move.pbIsSpecial?(type) && !moldBreakerCheck(attacker,move)
			end
			if opponent.ability== :QUARKDRIVE
				defense=(defense*1.3) if (opponent.effects[:Quarkdrive][0] == PBStats::DEFENSE && move.pbIsPhysical?(type)) || (opponent.effects[:Quarkdrive][0] == PBStats::SPDEF && move.pbIsSpecial?(type))
			end
			# LAWDS - protosynthesis, might be identical to the gen 9 mod's idk
			if opponent.ability== :PROTOSYNTHESIS
				defense=(defense*1.3) if (opponent.effects[:Protosynthesis][0] == PBStats::DEFENSE && move.pbIsPhysical?(type)) || (opponent.effects[:Protosynthesis][0] == PBStats::SPDEF && move.pbIsSpecial?(type))
			end
			# LAWDS - rework to sand veil and snow cloak. crestform also gets snow cloak over slush rush
			if opponent.ability== :SANDVEIL && (@battle.pbWeather== :SANDSTORM || field == :DESERT || field == :ASHENBEACH)
				defense=(defense*1.2)
			end
			if (opponent.ability== :SNOWCLOAK || (opponent.crested==:CASTFORM && opponent.form==3)) && (@battle.pbWeather== :HAIL || field == :ICY || field == :SNOWYMOUNTAIN || field == :FROZENDIMENSION)
				defense=(defense*1.2)
			end
			if (@battle.pbWeather== :SUNNYDAY || @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN) || field == :BEWITCHED || attacker.crested == :CHERRIM || attacker.pbPartner.crested == :CHERRIM) && move.pbIsSpecial?(type) && field != :GLITCH
				defense=(defense*1.5) if opponent.ability== :FLOWERGIFT && (opponent.species == :CHERRIM)
				defense=(defense*1.5) if opponent.pbPartner.ability== :FLOWERGIFT && opponent.pbPartner.species == :CHERRIM
			end
			# Gen 9 Mod - Beads of Ruin, Sword of Ruin
			if ((opponent.pbOpposing1.ability== :SWORDOFRUIN || opponent.pbOpposing2.ability== :SWORDOFRUIN || opponent.pbPartner.ability== :SWORDOFRUIN) && opponent.ability != :SWORDOFRUIN)
				if @battle.state.effects[:WonderRoom] != 0 && move.pbIsSpecial?(type)
				  defense = (defense * 0.75).round
				elsif @battle.state.effects[:WonderRoom] == 0 && move.pbIsPhysical?(type)
				  defense = (defense * 0.75).round
				end
			end
			if ((opponent.pbOpposing1.ability== :BEADSOFRUIN || opponent.pbOpposing2.ability== :BEADSOFRUIN || opponent.pbPartner.ability== :BEADSOFRUIN) && opponent.ability != :BEADSOFRUIN) 
				if @battle.state.effects[:WonderRoom] != 0 && move.pbIsPhysical?(type)
				  defense = (defense * 0.75).round
				elsif @battle.state.effects[:WonderRoom] == 0 && move.pbIsSpecial?(type)
				  defense = (defense * 0.75).round
				end
			end
		end

		# Field Effect defense boost
		if @mondata.skill>=BESTSKILL
			defense= (defense*move.fieldDefenseBoost(type,opponent))
		end

		# Defense-boosting items
		if @mondata.skill>=HIGHSKILL && oppitemworks
			case opponent.item
			when :EVIOLITE
				evos=pbGetEvolvedFormData(opponent.pokemon.species,opponent.pokemon)
				# lawds ensures eviolite works on these megas
     	 		evos=[true] if [:EEVEE,:MEOWTH,:PIKACHU,:DURALUDON].include?(opponent.species)
				defense=(defense*1.5) if evos && evos.length>0
			when :ASSAULTVEST
				defense=(defense*1.5) if move.pbIsSpecial?(type)
			when :DEEPSEASCALE
				defense=(defense*2.0) if (opponent.pokemon.species == :CLAMPERL) && move.pbIsSpecial?(type)
			when :METALPOWDER
				defense=(defense*2.0) if (opponent.pokemon.species == :DITTO) && !opponent.effects[:Transform] && move.pbIsPhysical?(type)
			when :BRIGHTPOWDER # lawds bright powder
				defense=(defense*1.25) if move.priorityCheck(attacker) > 0 && !(@battle.FE==:CHESS && attacker.pokemon.piece==:KING && move.priority<1)
			# lawds - no stop
			#when :EEVIUMZ
				#defense=(defense*1.5) if opponent.pokemon.species == :EEVEE
			#when :PIKANIUMZ
				#defense=(defense*1.5) if opponent.pokemon.species == :PIKACHU
			#when :LIGHTBALL
				#defense=(defense*1.5) if opponent.pokemon.species == :PIKACHU
			end
		end		

		# Main damage calculation
		damage=(((2.0*attacker.level/5+2).floor*basedamage*atk/defense).floor/50).floor+2 if basedamage >= 0
		
		# Multi-targeting attacks
		if @mondata.skill>=MEDIUMSKILL
			if move.pbTargetsAll?(attacker)
				damage=(damage*0.75)
			end
		end
		# Field Boosts
		if @mondata.skill>=BESTSKILL
			#Type-based field boosts
			fieldBoost = move.typeFieldBoost(type,attacker,opponent)
    		overlayBoost, overlay = move.typeOverlayBoost(type,attacker,opponent,@gonnaTerrains)
    		if fieldBoost != 1 || overlayBoost != 1
      			if fieldBoost > 1 && overlayBoost > 1
        			boost = [fieldBoost,overlayBoost].max
        			if $game_variables[:DifficultyModes]==1 && !$game_switches[:FieldFrenzy]
          				boost = 1.25 if boost < 1.25
					elsif $game_variables[:DifficultyModes]!=1 && $game_switches[:FieldFrenzy]
						boost = 2.0 if boost < 2.0
        			else
          				boost = 1.5 if boost < 1.5
        			end
      			else
        			boost = fieldBoost*overlayBoost
      			end
				damage=(damage*boost).floor
    		end
			case field
			when :MOUNTAIN # Mountain
				if type == :FLYING && !move.pbIsPhysical?(type) && @battle.pbWeather== :STRONGWINDS
					provimult=1.5
          			provimult=1.25 if $game_variables[:DifficultyModes]==1
					provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
					damage=(damage*provimult)
				end
			when :SNOWYMOUNTAIN # Snowy Mountain
				if type == :FLYING && !move.pbIsPhysical?(type) && @battle.pbWeather== :STRONGWINDS
					provimult=1.5
          			provimult=1.25 if $game_variables[:DifficultyModes]==1
					provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
					damage=(damage*provimult)
				end
			end
			#Boosts caused by transformations
			fieldmove = btlfield.moveData(move.move)
			# LAWDS ignore field changes if field is locked
			if !(@battle.state.effects[:FIELDLOCK] || ($game_variables[:DifficultyModes]==2 && !(@battle.ProgressiveFieldCheck(PBFields::CONCERT)) && !(@battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN)) && ![:FACTORY,:SHORTCIRCUIT].include?(field))) && fieldmove && fieldmove[:fieldchange]
				handled = fieldmove[:condition] ? eval(fieldmove[:condition]): true
				if handled  #don't continue if conditions to change are not met
					provimult=1.3
          			provimult=1.15 if $game_variables[:DifficultyModes]==1
					provimult = ((provimult-1.0)*2.0)+1.0 if $game_switches[:FieldFrenzy]
					damage=(damage*provimult).floor if damage >= 0
				end
			end
		end
		# Weather
		if @mondata.skill>=MEDIUMSKILL
			case @battle.pbWeather
				when :SUNNYDAY
					if @battle.state.effects[:HarshSunlight] && type == :WATER
						damage=0
					end
					if type == :FIRE
						damage=(damage*1.5)
					  elsif type == :WATER
						# Gen 9 Mod - Hydro Steam damage gets boosted in Sun instead of reduced.
						if move.move == :HYDROSTEAM
						  damage=(damage*1.5)
						else
						  damage=(damage*0.5)
						end
					  end
				when :RAINDANCE # LAWDS - cherrim crest allows fire moves to ignore rain cuts
					if @battle.state.effects[:HeavyRain] && type == :FIRE && attacker.crested != :CHERRIM && attacker.pbPartner.crested != :CHERRIM
						damage=0
					end
					if type == :FIRE && attacker.crested != :CHERRIM && attacker.pbPartner.crested != :CHERRIM
						damage=(damage*0.5)
					elsif type == :WATER
						damage=(damage*1.5)
					end
			end
		end
		if ai_mon_attacking || $game_switches[:No_Damage_Rolls] || $game_variables[:DifficultyModes]==2
			random=100
			random=85 #This is something that could be tweaked based on skill
			random=93 if $game_switches[:No_Damage_Rolls] || $game_variables[:DifficultyModes]==2 #damage rolls
			random=85 if @mondata.skill >=BESTSKILL && field == :CONCERT1 && opponent.ability!=:OWNTEMPO
			random=100 if @mondata.skill >=BESTSKILL && field == :CONCERT4 && opponent.ability!=:OWNTEMPO
			damage=(damage*random/100.0).floor
		end
		# STAB
		typecrest = false
      	case attacker.crested
      		when :EMPOLEON then typecrest = true if type == :ICE
      		when :LUXRAY then typecrest = true if type == :DARK
      		when :SAMUROTT, :BRAVIARY then typecrest = true if type == :FIGHTING # Lawds - braviary crest
      		when :SIMISEAR then typecrest = true if type == :WATER
      		when :SIMIPOUR then typecrest = true if type == :GRASS
      		when :SIMISAGE then typecrest = true if type == :FIRE
			when :GOTHITELLE then typecrest = true if type == :PSYCHIC || type == :DARK
			when :REUNICLUS then typecrest = true if type == :PSYCHIC || type == :FIGHTING
			when :ZOROARK
				if attacker.effects[:Illusion] != nil
					typecrest = true if attacker.effects[:Illusion].hasType?(type)
				else
					party = @battle.pbPartySingleOwner(attacker.index)
        			if !@battle.pbOwnedByPlayer?(attacker.index) && $game_variables[:DifficultyModes]==2
          				party = (attacker.pokemonIndex < @battle.party2.length/2) ? @battle.pbParty(1) : @battle.pbParty(3)
        			end
        			party=party.find_all {|item| item && !item.egg? && item.hp>0 }
        			if party[party.length-1] != attacker.pokemon
          				typecrest = true if party[party.length-1].hasType?(type)
					end
				end
      	end
		if @mondata.skill>=MEDIUMSKILL
			# Water Bubble
			if attacker.ability== :WATERBUBBLE && type == :WATER
				damage=(damage*=2)
			end	# LAWDS - inverse field seed normalize effect
			if (attacker.hasType?(type) && (!attacker.effects[:DesertsMark])) || attacker.ability== :PROTEAN || attacker.ability== :LIBERO || (attacker.effects[:seed_normalize]==true && type == :NORMAL) || typecrest==true
				if attacker.ability== :ADAPTABILITY || (attacker.ability== :SPIRITSENVOY && type == :GHOST && field == :HAUNTED) # LAWDS spirits envoy on haunted with stab
					damage=(damage*2)
				else
					damage=(damage*1.5)
				end
				if attacker.crested == :SILVALLY
					damage=(damage*1.2)
				end
			elsif attacker.ability== :STEELWORKER && type == :STEEL
				if field == :FACTORY # Factory Field
					damage=(damage*2)
				else
					damage=(damage*1.5)
				end									# LAWDS - spirit's envoy boosts ghost 50%
			elsif (attacker.ability== :SOLARIDOL && type == :FIRE) || (attacker.ability== :LUNARIDOL && type == :ICE) || (attacker.ability== :SPIRITSENVOY && type == :GHOST)
				damage=(damage*1.5)
				damage=(damage*1.3333) if (attacker.ability== :SPIRITSENVOY && type == :GHOST && field == :HAUNTED) # boost is 2x on haunted
			elsif attacker.ability== :ROCKYPAYLOAD # LAWDS - rocky payload and field interaction
				payload_type = :ROCK
				payload_boost = 1.5
				if field == :SNOWYMOUNTAIN
					payload_type = :ICE
				elsif field == :VOLCANICTOP
					payload_type = :FIRE
				elsif field == :SKY
					payload_boost = 2
				end
				damage=(damage*payload_boost) if type == payload_type
			end
		end
		# Type effectiveness
		# typemod calc has been moved to the beginning
		if @mondata.skill>=MINIMUMSKILL
		  	damage=(damage*typemod/4.0)
		end
		# Water Bubble
		if @mondata.skill>=MEDIUMSKILL
			if opponent.ability== :WATERBUBBLE && type == :FIRE
				damage=(damage*=0.5)
			end
			# Burn
			if attacker.status== :BURN && move.pbIsPhysical?(type) &&
				attacker.ability != :GUTS && move.move != :FACADE && attacker.ability != :QUICKFEET
				damage=(damage*0.5)
			end
		end
		# Gen 9 Mod - Added Well-Baked Body
		if @mondata.skill>=MEDIUMSKILL
			if opponent.ability== :WELLBAKEDBODY && type == :FIRE
			  return 0 # lawds just hard return 0 here
			end
		  end
		  # Gen 9 Mod - Added Wind Rider
		  if @mondata.skill>=MEDIUMSKILL
			if opponent.ability== :WINDRIDER && move.windMove? && field != :SKY # LAWDS - wind rider does not block wind moves on sky (you still get boosted)
			  damage*=0
			end
		  end
		# Shelter
		if @mondata.skill>=MEDIUMSKILL
			addedtypes=move.getSecondaryType(attacker)
			if opponent.effects[:Shelter] && field != :INDOOR && (type == btlfield.mimicry || (!addedtypes.nil? && addedtypes.include?(btlfield.mimicry)))
				damage=(damage*0.5)
			end
		end
		# Screens
		if @mondata.skill>=HIGHSKILL
			if move.pbIsPhysical?(type)
				if opponent.pbOwnSide.screenActive?(:physical)
					if !opponent.pbPartner.isFainted?
						damage=(damage*0.66)
					else
						damage=(damage*0.5)
					end
				end
			elsif move.pbIsSpecial?(type)
				if opponent.pbOwnSide.screenActive?(:special)
					if !opponent.pbPartner.isFainted?
						damage=(damage*0.66)
					else
						damage=(damage*0.5)
					end
				end
			end
		end
		# lawds deep earth klutz
		if damage > 0 && attacker.ability==:KLUTZ && field==:DEEPEARTH && !attacker.pokemon.klutzUsed && attacker.ability!=:LONGREACH && 
			!(attacker.hasWorkingItem(:PROTECTIVEPADS) || opponent.hasWorkingItem(:PROTECTIVEPADS)) && move.contactMove?
			weightratio = (opponent.weight/4000)
			weightratio = 0.3 if weightratio > 0.3
			weightratio = 0.1 if weightratio < 0.1
			klutzdamage = weightratio * opponent.totalhp
			damage=(damage+klutzdamage)
		end
		if @mondata.skill>=MEDIUMSKILL
			# LAWDS improved playing around multiscale
			# also added disguise stuff to this + new anticipation and tera shell
			if (((opponent.ability== :MULTISCALE || opponent.ability== :SHADOWSHIELD || opponent.ability==:TERASHELL) && opponent.hp==opponent.totalhp) || 
			      opponent.effects[:Disguise] || opponent.effects[:Anticipation] || (opponent.effects[:IceFace] && move.pbIsPhysical?())) && 
				  (!moldBreakerCheck(attacker,move))
				if (opponent.hp==opponent.totalhp) || opponent.effects[:Disguise]
					num_hits = move.pbNumHits(attacker)
					num_hits = 4 if move.punchMove? && attacker.crested==:LEDIAN
					if [0x0C0, 0x307].include?(move.function) || (num_hits==1 && attacker.crested==:CINCCINO)
						# lawds random multihit change
						num_hits = 3
						num_hits = 5 if attacker.ability==:SKILLLINK || (attacker.crested==:FEAROW && move.move==:FURYATTACK) || attacker.hasWorkingItem(:LOADEDDICE)
						num_hits = 3 if move.move==:WATERSHURIKEN && attacker.species==:GRENINJA && attacker.form==1 # lawds bbond
						num_hits = 12 if move.move==:COMETPUNCH && attacker.crested==:LEDIAN
					end
					if move.function==0x0BF # triple kick, triple axel, thunder raid
						if opponent.effects[:Disguise]
							damage = damage*(5/6)
						else
							damage = damage*(5.5/6)
						end
					elsif attacker.ability==:DREADNOUGHT && num_hits==1 && move.pbIsSpecial?
						if opponent.effects[:Disguise]
							damage = damage*(1/3).floor
						else
							damage = damage*(2/3).floor
						end
					elsif attacker.ability==:PARENTALBOND && num_hits==1
						if opponent.effects[:Disguise]
							damage = damage*(1/5).floor
						else
							damage = damage*(3/5).floor
						end
					else
						num_hits = num_hits.to_f
						if opponent.effects[:Disguise] && num_hits > 0
							damage = damage*(num_hits-1)/num_hits
						elsif num_hits > 0
							damage = damage*(num_hits-0.5)/num_hits
						end
					end
					damage = damage + ((opponent.totalhp/8).floor) if opponent.effects[:Disguise]
				end
			end
			if (opponent.ability== :SOLIDROCK || opponent.ability== :FILTER || opponent.ability== :PRISMARMOR) && !moldBreakerCheck(attacker,move)
				damage=(damage*0.75) if typemod>4
			end
			if opponent.ability== :FILTER && !moldBreakerCheck(attacker,move) && field == :CORROSIVEMIST && move.pbIsSpecial?() # LAWDS
				damage=damage*0.75 
			end
			if opponent.crested==:AMPHAROS # LAWDS ampharos crest actually sees the filter effect
				damage=(damage*0.7) if typemod>4
			elsif opponent.crested==:VESPIQUEN
				damage=(damage*0.5) if typemod>4 
			end
			if opponent.ability== :SHADOWSHIELD && [:STARLIGHT, :DIMENSIONAL, :NEWWORLD, :DARKCRYSTALCAVERN].include?(field)
				damage=(damage*0.75)
			end
			if opponent.ability== :SHADOWSHIELD && @battle.ProgressiveFieldCheck(PBFields::DARKNESS,2,3)
				damage=(damage*0.33) if opponent.hp==opponent.totalhp
			end
			if field==:CORROSIVEMIST
				damage=(damage*0.5) if @battle.FE==:CORROSIVEMIST && [:POISON,:FAIRY].include?(type) && [:WATERCOMPACTION,:WATERVEIL,:DRYSKIN,:WINDRIDER].include?(opponent.ability) # LAWDS
			end
			damage=(damage*0.75) if opponent.pbPartner.ability== :FRIENDGUARD
			damage=(damage*2.0) if attacker.ability== :STAKEOUT && @battle.switchedOut[opponent.index]
			# Tinted Lens				
			damage=(damage*2.0) if (attacker.ability== :TINTEDLENS) && typemod<4
			# Neuroforce
			damage=(damage*1.25) if attacker.ability== :NEUROFORCE && typemod>4
			# Meganium Crest
			damage=(damage*0.8) if (opponent.crested == :MEGANIUM || opponent.pbPartner.crested == :MEGANIUM)
			# Beheeyem Crest
			damage=(damage*0.67) if (opponent.crested == :BEHEEYEM) && (!opponent.hasMovedThisRound? || @battle.switchedOut[opponent.index])
			# Seviper Crest
			if attacker.crested == :SEVIPER
				multiplier = 0.5*(opponent.pokemon.hp*1.0)/(opponent.pokemon.totalhp*1.0)
				multiplier += 1.0
				damage=(damage*multiplier)
			end
			# LAWDS - Klinklang Crest
			damage=(damage*2.0) if (attacker.crested == :KLINKLANG) && opponent.effects[:LockOn] > 0 && opponent.effects[:LockOnPos] == attacker.index
		end

		# Flower Veil + Flower Garden Shenanigans
		if @mondata.skill>=BESTSKILL
			if @battle.ProgressiveFieldCheck(PBFields::FLOWERGARDEN,3,5)
				if (opponent.pbPartner.ability== :FLOWERVEIL &&
				opponent.hasType?(:GRASS)) || opponent.ability== :FLOWERVEIL
					damage=(damage*0.5)
				end
				case field
					when :FLOWERGARDEN3 then damage=(damage*0.75) if opponent.hasType?(:GRASS)
					when :FLOWERGARDEN4 then damage=(damage*0.67) if opponent.hasType?(:GRASS)
					when :FLOWERGARDEN5 then damage=(damage*0.5) if opponent.hasType?(:GRASS)
				end
			end
		end
		# Final damage-altering items
		if @mondata.skill>=HIGHSKILL
			if (attitemworks && (attacker.item == :METRONOME || field == :CONCERT4))
				if attacker.effects[:Metronome]>4
					damage=(damage*2.0)
				else
					met=1.0+attacker.effects[:Metronome]*0.2
					damage=(damage*met)
				end
			elsif (attitemworks && attacker.item == :EXPERTBELT) && typemod>4
				damage=(damage*1.2)
			elsif (attitemworks && attacker.item == :LIFEORB)
				damage=(damage*1.3)
			elsif (attitemworks && attacker.item == :KINGSROCK) # lawds king's rock
				faintedmod = 0.06*(attacker.pbFaintedPokemonCount(true)).to_f
				faintedmult = 1 + faintedmod
				damage=(damage*faintedmult)
			end
			# LAWDS - Improved this. Made AI see the damage reduction for enemies, then made it favor using moves that will expend the berry if there are no killing moves. for now also just added a multihit check.
			if typemod>4 && oppitemworks && !move.pbIsMultiHit && !([:UNNERVE,:ASONE].include?(attacker.ability) || [:UNNERVE,:ASONE].include?(attacker.pbPartner.ability))  #&& !ai_mon_attacking 
				berrymod = opponent.ability== :RIPEN ? 0.25 : 0.5
				case opponent.item
					when :CHOPLEBERRY	then damage=(damage*berrymod) if type == :FIGHTING
					when :COBABERRY		then damage=(damage*berrymod) if type == :FLYING
					when :KEBIABERRY	then damage=(damage*berrymod) if type == :POISON
					when :SHUCABERRY	then damage=(damage*berrymod) if type == :GROUND
					when :CHARTIBERRY   then damage=(damage*berrymod) if type == :ROCK
					when :TANGABERRY	then damage=(damage*berrymod) if type == :BUG
					when :KASIBBERRY	then damage=(damage*berrymod) if type == :GHOST
					when :BABIRIBERRY 	then damage=(damage*berrymod) if type == :STEEL
					when :OCCABERRY 	then damage=(damage*berrymod) if type == :FIRE
					when :PASSHOBERRY 	then damage=(damage*berrymod) if type == :WATER
					when :RINDOBERRY 	then damage=(damage*berrymod) if type == :GRASS
					when :WACANBERRY 	then damage=(damage*berrymod) if type == :ELECTRIC
					when :PAYAPABERRY 	then damage=(damage*berrymod) if type == :PSYCHIC
					when :YACHEBERRY 	then damage=(damage*berrymod) if type == :ICE
					when :HABANBERRY 	then damage=(damage*berrymod) if type == :DRAGON
					when :COLBURBERRY 	then damage=(damage*berrymod) if type == :DARK
					when :ROSELIBERRY 	then damage=(damage*berrymod) if type == :FAIRY
				end
			end
		end
		# pbModifyDamage - TODO
		if opponent.effects[:Minimize] && (move.move == :BODYSLAM || move.function==0x10 ||
			move.function==0x9B || move.function==0x137 || move.function == 0x806)
			damage=(damage*2.0)
		end
		# "AI-specific calculations below"
		# Increased critical hit rates
		if @mondata.skill>=MEDIUMSKILL
			#Lawds Mod 6/23/2024 - AI takes stronger crits into account when calculating average damage
			critrate = move.pbCritRate?(attacker,opponent)
			if critrate==2
				if attacker.ability== :SNIPER || attacker.crested == :DECIDUEYE
					damage=(damage*1.5)
				else
					damage=(damage*1.25)
				end

			elsif critrate>2
				if attacker.ability== :SNIPER || attacker.crested == :DECIDUEYE
					damage=(damage*2.0) 
				else
					damage=(damage*1.5)
				end
			end
			
		end
		#Substitute damage
		if opponent.effects[:Substitute] > 0 && attacker.ability != :INFILTRATOR && !move.isSoundBased? && 
			move.move!=:SPECTRALTHIEF && move.move!=:HYPERSPACEHOLE && move.move!=:HYPERSPACEFURY && damage > opponent.hp/2
			damage=(opponent.hp/2.0)
		end
		# lawds focus band causes you to take 10% less damage from attacks that do not KO you (and wouldn't trigger sash/sturdy/etc)
		if oppitemworks && opponent.item==:FOCUSBAND && (![:SHADOWSHIELD,:MULTISCALE].include?(opponent.ability) || moldBreakerCheck(attacker,move))
			numHits = move.pbNumHits(attacker)
			numHits = numHits*4 if (attacker.crested==:LEDIAN && move.punchMove?)
			if numHits==1 && ![:PARENTALBOND,:DREADNOUGHT].include?(attacker.ability)
				damage=damage*0.9 if damage < opponent.hp
			elsif move.function==0x0BF # triple kick, triple axel, thunder raid
				totalReducedDamage = 0
				if damage/6 < opponent.hp # if first hit doesnt kill
					totalReducedDamage += (damage/6)*0.1
					if (damage/6)*0.9 + damage/3 < opponent.hp # if second hit doesnt kill
						totalReducedDamage += (damage/3)*0.1
						if (damage/2 * 0.9) + damage/2 < opponent.hp # if the third hit doesnt kill
							totalReducedDamage += (damage/2)*0.1
						end
					end
				end
				damage -= totalReducedDamage
			elsif attacker.ability==:PARENTALBOND && numHits==1
				firstHitDamage = damage*0.8
				firstHitDamage *= 0.9 if firstHitDamage < opponent.hp
				secondHitDamage = damage*0.2
				secondHitDamage = secondHitDamage*0.9 if firstHitDamage*secondHitDamage < opponent.hp
				damage = firstHitDamage + secondHitDamage
			elsif attacker.ability==:DREADNOUGHT && move.pbIsSpecial? && numHits==1
				firstHitDamage = damage*2/3
				firstHitDamage *= 0.9 if firstHitDamage < opponent.hp
				secondHitDamage = damage/6
				secondHitDamage *= 0.9 if firstHitDamage + secondHitDamage < opponent.hp
				thirdHitDamage = damage/6
				thirdHitDamage *= 0.9 if firstHitDamage + secondHitDamage + thirdHitDamage < opponent.hp
				damage = firstHitDamage + secondHitDamage + thirdHitDamage
			else
				totalReducedDamage=0
				for i in 0..numHits
					hitDamage = damage/numHits
					hitDamage*=0.9 if totalReducedDamage + hitDamage < opponent.hp
					totalReducedDamage+=numHits
				end
				damage = totalReducedDamage
			end
		end
		# LAWDS - reduce damage to non-killing if it can't OHKO
		damage = opponent.hp-1 if damage>=opponent.hp && notOHKO?(opponent,attacker,false,move,damage) && checkOHKOs
		damage=damage.floor # LAWDS - dont round until the very end of calculation. this is to be more accurate to actual damage calculation.
		# Make sure damage is at least 1
		damage=1 if damage<1
		return damage
	end

	def pbBetterBaseDamage(move=@move,attacker=@attacker,opponent=@opponent, field=@battle.FE)
		# Covers all function codes which have their own def pbBaseDamage
		aimem = getAIMemory(opponent)
		basedamage = move.basedamage
		basedamage = [attacker.happiness,250].min if attacker.crested == :LUVDISC
		case move.function
			when 0x12 # Fake Out
				return basedamage if attacker.turncount==0 # lawds shouldnt this be <0 not <=
				return 0
			when 0x6A # SonicBoom
				return 140 if field == :RAINBOW
				return 20
			when 0x6B # Dragon Rage
				return 140 if field == :DIMENSIONAL || field == :FROZENDIMENSION
				return 40
			when 0x6C # Super Fang
				if (move.move == :NATURESMADNESS) && (field == :GRASSY || field == :FOREST || field == :NEWWORLD)
					return (opponent.hp*0.75).floor
				elsif (move.move == :NATURESMADNESS) && field == :HOLY
					return (opponent.hp*0.66).floor
				end
				return (opponent.hp/2.0).floor
			when 0x6D # Night Shade
				return attacker.level*1.5 if (field == :HAUNTED &&  move.move == :NIGHTSHADE || field == :DEEPEARTH &&  move.move == :SEISMICTOSS) 
				return attacker.level
			when 0x6E # Endeavor
				return 0 if pbAIfaster?() && attacker.hp >= opponent.hp
				return opponent.hp-attacker.hp if pbAIfaster?()
				if !aimem.any? {|moveloop| moveloop!=nil && [:ENDEAVOR,:METALBURST,:COUNTER,:MIRRORCOAT,:BIDE].include?(moveloop.move)}
					return opponent.hp - [attacker.hp-checkAIdamage(attacker,opponent,aimem), 1].max
				end
				return 20
			when 0x6F # Psywave
				return ((attacker.level + attacker.level*1.5)/2).floor
				return attacker.level
			when 0x70 # OHKO
				return 0 if move.move == :FISSURE && field == :NEWWORLD
				return opponent.totalhp
			when 0x71 # Counter
					return 0 if @battle.pbOwnedByPlayer?(attacker.index) # lawds playing around these is handled elsewhere
					maxdam=60
					for j in aimem
						next if j.pbIsSpecial?() || j.basedamage<=1 || [:ENDEAVOR,:METALBURST,:COUNTER,:MIRRORCOAT,:BIDE].include?(j.move)
						tempdam = pbRoughDamage(j,opponent,attacker)*2
						# LAWDS - you only reflect the last move of a multi hit move
						tempdam=(tempdam/j.pbNumHits(opponent)).floor if j.pbIsMultiHit
						maxdam=tempdam if tempdam>maxdam
					end
					return maxdam
			when 0x72 # Mirror Coat
					return 0 if @battle.pbOwnedByPlayer?(attacker.index) # lawds playing around these is handled elsewhere
					maxdam=60
					for j in aimem
						next if j.pbIsPhysical?() || j.basedamage<=1 || [:ENDEAVOR,:METALBURST,:COUNTER,:MIRRORCOAT,:BIDE].include?(j.move)
						tempdam = pbRoughDamage(j,opponent,attacker)*2
						# LAWDS - you only reflect the last move of a multi hit move
						tempdam=(tempdam/j.pbNumHits(opponent)).floor if j.pbIsMultiHit
						maxdam=tempdam if tempdam>maxdam
					end
					return maxdam
			when 0x73 # Metal Burst
				return 0 if @battle.pbOwnedByPlayer?(attacker.index) # lawds playing around these is handled elsewhere
				return (1.5 * checkAIdamage(attacker,opponent,aimem)).floor unless aimem.any? {|moveloop| moveloop!=nil && [:ENDEAVOR,:METALBURST,:COUNTER,:MIRRORCOAT,:BIDE].include?(moveloop.move)}
			when 0x75, 0x12D # Surf, Shadow Storm
				return basedamage*2 if !$cache.moves[opponent.effects[:TwoTurnAttack]].nil? &&
				$cache.moves[opponent.effects[:TwoTurnAttack]].function == 0xCB # Dive
			when 0x76 # Earthquake
				return basedamage*2 if !$cache.moves[opponent.effects[:TwoTurnAttack]].nil? &&
				$cache.moves[opponent.effects[:TwoTurnAttack]].function == 0xCA # Dig
			when 0x77, 0x78 # Gust, Twister
				return basedamage*2 if !$cache.moves[opponent.effects[:TwoTurnAttack]].nil? &&
				($cache.moves[opponent.effects[:TwoTurnAttack]].function == 0xC9 ||# Fly
				$cache.moves[opponent.effects[:TwoTurnAttack]].function == 0xCC ||# Bounce
				$cache.moves[opponent.effects[:TwoTurnAttack]].function == 0xCE )# Sky Drop
			when 0x93 # LAWDS added rage AI
				return 60 if [:DIMENSIONAL,:FROZENDIMENSION].include?(field)
				return 40
			when 0x79 # Fusion Bolt
				return basedamage*2 if @battle.previousMove == :FUSIONFLARE
			when 0x7A # Fusion Flare
				return basedamage*2 if @battle.previousMove == :FUSIONBOLT
			when 0x7B # Venoshock, Barb Barrage, (Lawds Mod) Nerve Pinch
				if opponent.status== :POISON
					return basedamage*1.75 if @move == :NERVEPINCH
					return basedamage*2
				elsif @mondata.skill>=BESTSKILL
					if field == :CORROSIVE || field == :WASTELAND || field == :MURKWATERSURFACE # Corrosive/Wasteland/Murkwater
						return basedamage*1.75 if @move == :NERVEPINCH
						return basedamage*2
					end
				end
			when 0x7C # SmellingSalt
				return basedamage*2 if opponent.status== :PARALYSIS  && opponent.effects[:Substitute]<=0
			when 0x7D # Wake-Up Slap
				return basedamage*2 if opponent.status== :SLEEP && opponent.effects[:Substitute]<=0
			when 0x7E # Facade
				return basedamage*2 if attacker.status== :POISON || attacker.status== :BURN || attacker.status== :PARALYSIS
			when 0x7F # Hex
				if !opponent.status.nil?
					return basedamage*2
				elsif @mondata.skill>=BESTSKILL
					if field == :INFERNAL
						return basedamage*2
					end
				end
			when 0x80 # Brine
				return basedamage*2 if opponent.hp<=(opponent.totalhp/2.0).floor
			when 0x85 # Retaliate
				return basedamage*2 if attacker.pbOwnSide.effects[:Retaliate]
			when 0x86 # Acrobatics				# LAWDS - gems aren't consumed on crystal cavern
				return basedamage*2 if attacker.item.nil? || (attacker.hasWorkingItem(:FLYINGGEM) && field != :CRYSTALCAVERN) || field == :BIGTOP
			when 0x87 # Weather Ball
				return basedamage*2 if (@battle.pbWeather!=0 || field == :RAINBOW || attacker.crested == :CHERRIM || attacker.pbPartner.crested == :CHERRIM)
			when 0x89 # Return
				return [attacker.happiness,250].min if attacker.crested == :LUVDISC
				return 102 if field == :CONCERT4 && opponent.ability!=:OWNTEMPO
				return [(attacker.happiness*2/5).floor,1].max
			when 0x8A # Frustration
				return 102 if field == :CONCERT4 && opponent.ability!=:OWNTEMPO
				return [((255-attacker.happiness)*2/5).floor,1].max
			when 0x8B # Eruption / Water Spout
				return [attacker.happiness,250].min if attacker.crested == :LUVDISC
				return 150 if field == :CONCERT4 && opponent.ability!=:OWNTEMPO
				return [(150*(attacker.hp.to_f)/attacker.totalhp).floor,1].max
			when 0x8C # Crush Grip / Wring Out
				return [attacker.happiness,250].min if attacker.crested == :LUVDISC
				return 120 if ((field == :CONCERT4 && opponent.ability!=:OWNTEMPO) || field == :DEEPEARTH)
				return [(120*(opponent.hp.to_f)/opponent.totalhp).floor,1].max
			when 0x8D # Gyro Ball
				return [attacker.happiness,250].min if attacker.crested == :LUVDISC
				return 150 if ((field == :CONCERT4 && opponent.ability!=:OWNTEMPO) || field == :DEEPEARTH)
				ospeed=pbRoughStat(opponent,PBStats::SPEED)
				aspeed=pbRoughStat(attacker,PBStats::SPEED)
				return [[(25*ospeed/aspeed).floor,150].min,1].max
			when 0x8E # Stored Power
				mult=0
				for i in [PBStats::ATTACK,PBStats::DEFENSE,PBStats::SPEED,
						PBStats::SPATK,PBStats::SPDEF,PBStats::ACCURACY,PBStats::EVASION]
				mult+=attacker.stages[i] if attacker.stages[i]>0
				end
				bp = 20
				bp = 40 if move.move ==:POWERTRIP && field == :FROZENDIMENSION
				return ([attacker.happiness,250].min)+(bp*mult) if attacker.crested == :LUVDISC
				return bp*(mult+1)
			when 0x8F # Punishment
				mult=0
				for i in [PBStats::ATTACK,PBStats::DEFENSE,PBStats::SPEED,
						PBStats::SPATK,PBStats::SPDEF,PBStats::ACCURACY,PBStats::EVASION]
				mult+=opponent.stages[i] if opponent.stages[i]>0
				end
				return [([attacker.happiness,250].min)+(20*mult),500].min if attacker.crested == :LUVDISC
				# LAWDS infernal
				if field==:INFERNAL
					return [60 + 30*(mult),200].min
				else
					return [20*(mult+3),200].min
				end
			when 0x91 # Fury Cutter
				# LAWDS AI sees how much crested cinccino does w/ stacking shot
				if attacker.crested==:CINCCINO && attacker.effects[:FuryCutter]==0
					if attacker.ability==:SKILLLINK || attacker.hasWorkingItem(:LOADEDDICE)
						totalbasedmg = (basedamage + basedamage*2 + basedamage*4 + basedamage*4 + basedamage*4)*0.3
						return totalbasedmg
					else
						totalbasedmg = (basedamage + basedamage*2 + basedamage*4 + basedamage*4)*0.3
						return totalbasedmg
					end
				end
				return basedamage * 2**(attacker.effects[:FuryCutter])
			when 0x92 # Echoed Voice
				return basedamage*(attacker.effects[:EchoedVoice]+1)
			when 0x94 # Present
				return [attacker.happiness,250].min if attacker.crested == :LUVDISC
				return 50
			when 0x95 # Magnitude
				damage = 71
				damage = 10 if field == :CONCERT1
				damage = 150 if field == :CONCERT4 && opponent.ability!=:OWNTEMPO
				damage = [attacker.happiness,250].min if attacker.crested == :LUVDISC
				damage *= 2 if !$cache.moves[opponent.effects[:TwoTurnAttack]].nil? && $cache.moves[opponent.effects[:TwoTurnAttack]].function==0xCA # Dig
				return damage
			when 0x96 # Natural Gift
				return [attacker.happiness,250].min if attacker.crested == :LUVDISC
				return 100 if field == :CONCERT4 && opponent.ability!=:OWNTEMPO
				return !PBStuff::NATURALGIFTDAMAGE[attacker.item].nil? ? PBStuff::NATURALGIFTDAMAGE[attacker.item] : 1
			when 0x97 # Trump Card
				return [attacker.happiness,250].min if attacker.crested == :LUVDISC
				return 200 if field == :CONCERT4 && opponent.ability!=:OWNTEMPO
				dmgs=[200,80,60,50,40]
				ppleft=[move.pp-1,4].min   # PP is reduced before the move is used
				return dmgs[ppleft]
			when 0x98 # Flail / Reversal
				return [attacker.happiness,250].min if attacker.crested == :LUVDISC
				return 200 if field == :CONCERT4 && opponent.ability!=:OWNTEMPO
				n=(48*(attacker.hp.to_f)/attacker.totalhp).floor
				return 200 if n<2
				return 150 if n<5
				return 100 if n<10
				return 80 if n<17
				return 40 if n<33
				return 20			
			when 0x99 # Electro Ball
				return [attacker.happiness,250].min if attacker.crested == :LUVDISC
				return 150 if field == :CONCERT4 && opponent.ability!=:OWNTEMPO
				n=(attacker.pbSpeed/opponent.pbSpeed).floor
				return 150 if n>=4
				return 120 if n>=3
				return 80 if n>=2
				return 60 if n>=1
				return 40				
			when 0x9A # Low Kick / Grass Knot
				return [attacker.happiness,250].min if attacker.crested == :LUVDISC
				return 120 if (field == :CONCERT4 && opponent.ability!=:OWNTEMPO)
				weight=opponent.weight
				weight*=2 if field == :DEEPEARTH	# LAWDS - fixed the AI thinking low kick/grass knot BP is always 120 on deep earth
				return 120 if weight>2000
				return 100 if weight>1000
				return 80 if weight>500
				return 60 if weight>250
				return 40 if weight>100
				return 20
			when 0x9B # Heavy Slam / Heat Crash
				return [attacker.happiness,250].min if attacker.crested == :LUVDISC
				return 120 if (field == :CONCERT4 && opponent.ability!=:OWNTEMPO)
				n=(attacker.weight/opponent.weight).floor
				n*=2 if field == :DEEPEARTH # LAWDS - fixed the AI thinking heavy slam/heat crash BP is always 120 on deep earth
				return 120 if n>=5
				return 100 if n>=4
				return 80 if n>=3
				return 60 if n>=2
				return 40
			when 0xA0 # Frost Breath
				return basedamage*1.5
			when 0xBD, 0xBE # Double Kick, Twineedle
				return basedamage*2
			when 0xBF # Triple Kick
				return basedamage*6
			when 0xC0 # Fury Attack
				if move.move==:COMETPUNCH && attacker.crested==:LEDIAN # lawds
					return basedamage*12
				elsif attacker.ability== :SKILLLINK || (attacker.crested==:FEAROW && move.move==:FURYATTACK) || attacker.hasWorkingItem(:LOADEDDICE)
					return basedamage*5
				elsif move.move==:WATERSHURIKEN && attacker.species==:GRENINJA && attacker.form==1 # lawds bbond
					return 60
				else
					# lawds multihit change
					return (basedamage*3).floor
				end
			when 0x20F # Lawds Mod - Boss's Orders rough approximation
				basedamage = 40 + 20*(@battle.pbPokemonCount(@battle.pbPartySingleOwner(attacker.index)) - 1)
				basedamage = 40 if basedamage < 40
			when 0xC1 # Beat Up
				party=@battle.pbPartySingleOwner(attacker.index)
				party=party.filter {|mon| !mon.nil? && !mon.isEgg? && mon.hp>0 && mon.status.nil?}
				basedamage=0
				party.each {|mon| basedamage+= 5+(mon.baseStats[1]/10)}
				return basedamage
			when 0xC4 # SolarBeam
				# lawds solar beam is no longer cut in other weathers
				#return (basedamage*0.5).floor if (@battle.pbWeather!=0 && @battle.pbWeather!=:SUNNYDAY && attacker.crested != :CLAYDOL && attacker.crested != :CHERRIM && attacker.pbPartner.crested != :CHERRIM && ![:STARLIGHT, :RAINBOW].include?(field))
			when 0xD0 # Whirlpool
				if @mondata.skill>=MEDIUMSKILL
					return basedamage*2 if !$cache.moves[opponent.effects[:TwoTurnAttack]].nil? && 
					$cache.moves[opponent.effects[:TwoTurnAttack]].function==0xCB # Dive
				end
			when 0xD3 # Rollout
				if @mondata.skill>=MEDIUMSKILL
					return basedamage*2 if attacker.effects[:DefenseCurl]
				end
			when 0xD4 # Bide
				return checkAIdamage(attacker,opponent,aimem) unless aimem.any? {|moveloop| moveloop!=nil && [:ENDEAVOR,:METALBURST,:COUNTER,:MIRRORCOAT,:BIDE].include?(moveloop.move)}
			when 0xE1 # Final Gambit
				return attacker.hp
			when 0xF0 # Knock Off
				return basedamage*1.5 if opponent.item && !@battle.pbIsUnlosableItem(opponent,opponent.item)
			when 0xF1 # Covet / Thief
				return basedamage*2 if field == :BACKALLEY && opponent.item && !@battle.pbIsUnlosableItem(opponent,opponent.item) 
			when 0xF7 # Fling
				if attacker.item.nil?
					return 0
				else
					return [attacker.happiness,250].min if attacker.crested == :LUVDISC
					return 130 if [:CONCERT4].include?(field) && opponent.ability!=:OWNTEMPO # Wingdings Mod - Fling is 130 on Concert
					return 10 if !attacker.item.nil? && pbIsBerry?(attacker.item)
					return PBStuff::FLINGDAMAGE[attacker.item] if PBStuff::FLINGDAMAGE[attacker.item]
					return 1
				end
			when 0x113 # Spit Up
				return [attacker.happiness,250].min if attacker.crested == :LUVDISC
				return 300 if field == :CONCERT4 && opponent.ability!=:OWNTEMPO
				return 100*attacker.effects[:Stockpile]
			when 0x118 # Gravity
				return (opponent.hp/2.0).floor if field == :DEEPEARTH
			when 0x142 # Topsy Turvy
				if field == :DEEPEARTH
					return [attacker.happiness,250].min if attacker.crested == :LUVDISC
					weight=opponent.weight*2
					return 120 if weight>2000
					return 100 if weight>1000
					return 80 if weight>500
					return 60 if weight>250
					return 40 if weight>100
					return 20
				end
			when 0x161 # First Impression
				return basedamage if attacker.turncount==0 # lawds shouldnt this be <1 not <=
				return 0
			when 0x171 # Stomping Tantrum
				return basedamage*2 if attacker.effects[:Tantrum]
			when 0x178 # Dynamax Cannon, Behemoth Blade, Behemoth Bash
				return basedamage*2 if opponent.isMega? || opponent.isUltra? || opponent.isPrimal?
			when 0x17E # Dragon Darts	# Lawds Mod 6/23/2024 - commented out the dragon darts targeting code since ddarts is just single target here
				return basedamage*2 #if !@battle.doublebattle || move.pbDragonDartTargetting(attacker).length < 2
			when 0x181 # Fishious Rend/Bolt beak
				return basedamage*2 if pbAIfaster?(move,nil,attacker,opponent)
			when 0x211 # Rage Fist - Lawds Mod
				basedmg = 75 + 25*(@battle.getBattlerHit(attacker)) 
				if field == :CITY && basedmg < 100 #set base power to 100 on city field if it's below 100
					return 100
				end
				return basedmg
			when 0x217 # LAWDS - Scented Geyser
				basedmg = 80
				case attacker.item
				when :PUREINCENSE, :ROCKINCENSE, :ROSEINCENSE, :SEAINCENSE, :WAVEINCENSE, :ODDINCENSE
				  basedmg = 100
				when :FULLINCENSE
				  basedmg = 160
				when :WAVEINCENSE
				  basedmg = 130
				when :LUCKINCENSE
				  basedmg = 104 if field == :CONCERT1 && opponent.ability!=:OWNTEMPO # average damage, given a 30% chance of doubled power
				  basedmg = 160 if field == :CONCERT4 && opponent.ability!=:OWNTEMPO
				end
			when 0x909 # Fickle Beam
				return basedamage*2 if field == :CONCERT4 && opponent.ability!=:OWNTEMPO # Lawds Mod - Fickle Beam is always maxed on Concert 4, min on Concert 1
				return basedamage if field == :CONCERT1 && opponent.ability!=:OWNTEMPO
				return basedamage*1.5 if field == :DRAGONSDEN # LAWDS Mod - Fickle Beam has a higher proc chance here
				return basedamage*1.3 # Takes into account 30% chance to double in base power.
															# Is it smarter for the AI to do this or to always assume 80 base power?
															# Who knows for sure, this seems to work well enough though so I'm leaving it like this.
			when 0x910 # Last Respects
        		faintedCounter=@battle.pbPartySingleOwner(attacker.index).find_all {|mon| mon && !mon.isEgg? && mon.hp<=0}
				return 50 + (50*faintedCounter.length) if attacker.crested == :HOUNDSTONE # lawds - houndstone crest lol
				return 60 + (12*faintedCounter.length)
			when 0x914 # Population Bomb
				if pbRoughAccuracy(move,attacker,opponent)>=99 # LAWDS - accounts for the accuracy boost
				  return (basedamage*10)
				elsif attacker.item == :LOADEDDICE
				  return (basedamage*7).floor         # Assumes we hit the single 90% accuracy check to not make maths egregious
				else
				  return (basedamage*586/100).floor   # Average number of hits with no modifiers ~= 5.86
				end
			when 0x307 # Scale Shot
				# lawds multihit moves change
				if attacker.ability== :SKILLLINK || attacker.hasWorkingItem(:LOADEDDICE)
					return basedamage*5
				else
					return (basedamage*3)
				end
			when 0x30A # Misty explosion
				return basedamage*1.5 if (field == :MISTY || @battle.state.effects[:MISTY] > 0 || @gonnaTerrains.include?(:MISTY))
			when 0x311 # Rising Voltage
				return basedamage*2 if (field == :ELECTERRAIN || @battle.state.effects[:ELECTERRAIN] > 0) && !opponent.isAirborne?(field)
			when 0x312 # LAWDS this shit was not coded in vanilla. terrain pulse
				return basedamage*2 if field != :INDOOR
			when 0x314 # Lash Out
				# I GENUINELY do not know when this moves condition is ever gonna be fulfilled while the AI choses a move but just in case - Fal
				return basedamage*2 if attacker.effects[:LashOut]
			when 0x319 # Surging Strikes
				return basedamage*3 # lawds reducing this to *3 since the crit modifier is already handled
			when 0x321 # Expanding Force
				return basedamage*1.5 if (field == :PSYTERRAIN || @battle.state.effects[:PSYTERRAIN] > 0 || @gonnaTerrains.include?(:PSYTERRAIN)) && !attacker.isAirborne?(field)
			when 0x322
				return basedamage*3
			when 0x502 # Barb Barrage
				if opponent.status== :POISON
					return basedamage*2
				elsif @mondata.skill>=BESTSKILL
					if field == :CORROSIVE || field == :WASTELAND || field == :MURKWATERSURFACE # Corrosive/Corromist/Wasteland/Murkwater
						return basedamage*2
					end
				end
			when 0x504 # Infernal Parade
				if !opponent.status.nil?
					return basedamage*2
				elsif @mondata.skill>=BESTSKILL
					if field == :HAUNTED
						return basedamage*2
					end
				end
			# Rejuv Customs
			when 0x202 # Fever Pitch
				return [attacker.happiness,250].min if attacker.crested == :LUVDISC
				return 40 if field == :CONCERT1 && opponent.ability!=:OWNTEMPO
				return 130 if field == :CONCERT4 && opponent.ability!=:OWNTEMPO
				return 74
			when 0x209 # Bunraku Beatdown
				return basedamage+(30*opponent.pbFaintedPokemonCount) if attacker.ability== :WORLDOFNIGHTMARES
				return [basedamage+(15*attacker.pbFaintedPokemonCount),165].min
			when 0x20C # Gilded Helix
				return basedamage*2 if move.move == :GILDEDHELIX
			# Z-moves
			when 0x809 # Guardian of Alola
				return (opponent.hp*0.75).floor
		end

		return basedamage
	end

	def pbStatusDamage(move)
		return PBStuff::STATUSDAMAGE[move.move] if PBStuff::STATUSDAMAGE[move.move]
		return 0
	end

	def pbRoughDamageAfterBoosts(move=@move,attacker=@attacker,opponent=@opponent,oppboosts: {},attboosts:{})
		# Set the Default value of the hashes, not really necessary
		oppboosts.default = 0
		attboosts.default = 0

		# Clone the stages arrays
		oppstages = opponent.stages.clone
		attstages = attacker.stages.clone

		# Apply stat changes to pokemons
		for stat in oppboosts.keys
			opponent.stages[stat] += oppboosts[stat]
			opponent.stages[stat].clamp(-6,6)
		end
		for stat in attboosts.keys
			attacker.stages[stat] += attboosts[stat]
			attacker.stages[stat].clamp(-6,6)
		end

		# Recalculate the damge
		damage = pbRoughDamage(move,attacker,opponent)

		# Revert the stat changes
		opponent.stages = oppstages
		attacker.stages = attstages

		return damage
	end


	def mirrorShatter
    	return true
	end

	def caveCollapse
		return false
	end

	def mirrorNeverMiss
		return (@attacker.stages[PBStats::ACCURACY] < 0 || @opponent.stages[PBStats::EVASION] > 0 || @opponent.item == :BRIGHTPOWDER || 
			@opponent.item == :LAXINCENSE || accuracyWeatherAbilityActive?(@opponent) || @opponent.vanished) &&
			 @opponent.ability != :NOGUARD && @attacker.ability != :NOGUARD && !(@attacker.ability== :FAIRYAURA && @battle.FE == :FAIRYTALE)
	end

	def mistExplosion
		return !@battle.pbCheckGlobalAbility(:DAMP)
	end

	def ignitecheck
		return @battle.state.effects[:WaterSport] <= 0 && @battle.pbWeather != :RAINDANCE
	end

	def suncheck;	end

	def pbAegislashStats(aegi)
		if aegi.form==1
		  	return aegi
		else
			bladecheck = aegi.clone
			bladecheck.stages = aegi.stages.map(&:clone)
			bladecheck.form = 1
			bladecheck.stages[PBStats::ATTACK] += 1 if @battle.FE == :FAIRYTALE && bladecheck.stages[PBStats::ATTACK]<6
			# lawds aegi sees sharpness on the stance change
			if aegi.PULSE3
				bladecheck.ability= [:STANCECHANGE,:JUSTIFIED,:SHARPNESS]
			end
			return bladecheck
		end
	end

	def moveSuccessful?(move,attacker,opponent)
		if move.pbIsPriorityMoveAI(attacker)
			# lawds new sucker punch
			return false if move.function==0x116 && (attacker.effects[:SuckerPunch] || opponent.ability==:FOREWARN)
			return false if @battle.FE==:DARKCRYSTALCAVERN && opponent.ability==:KEENEYE
			# lawds - none of this applies if the move's targets are as follows
			can_be_prio_blocked = [:SingleNonUser, :AllOpposing, :AllNonUsers].include?(attacker.pbTarget(move)) && ![:FLOWERSHIELD, :PERISHSONG, :ROTOTILLER].include?(move) 
			return true if !can_be_prio_blocked
			return false if @battle.FE == :PSYTERRAIN && !opponent.isAirborne?
			# lawds added mold breaker checks to these
			return false if (opponent.ability== :DAZZLING || opponent.ability== :QUEENLYMAJESTY || (opponent.ability== :MIRRORARMOR && @battle.FE == :STARLIGHT) || opponent.ability== :ARMORTAIL) && !moldBreakerCheck(attacker,move) # Gen 9 Mod - Armor Tail
			return false if (opponent.pbPartner.ability== :DAZZLING || opponent.pbPartner.ability== :QUEENLYMAJESTY || (opponent.pbPartner.ability== :MIRRORARMOR && @battle.FE == :STARLIGHT) || opponent.pbPartner.ability== :ARMORTAIL) && !moldBreakerCheck(attacker,move) # Gen 9 Mod - Armor Tail
			return false if @battle.FE != :BEWITCHED && attacker.ability== :PRANKSTER && opponent.hasType?(:DARK) && move.pbIsStatus?
		end
		return true
	end

#####################################################
## Utility functions							    #
#####################################################

	def moldBreakerCheck(battler, move = @move)
		move = nil if move != nil && !battler.pbHasMove?(move.move)
		return false if @opponent!=nil && @opponent.item==:ABILITYSHIELD
		move = nil if move==@move && @attacker!=nil && !(battler.ability== @attacker.ability) # lawds set move to nil if the battler in question isn't the one using it
		# LAWDS 7/30/2024 - checking for nil here stops errors but idk if it makes the AI handle mycelium might correctly
		return true if battler.ability==:MYCELIUMMIGHT && move != nil && move.category == :status  # LAWDS Mod - is myceliumMightCheck necessary? doesn't this just work instead???
		return true if battler.ability==:LIQUIDVOICE && move != nil && move.isSoundBased?
		return true if battler.ability==:DAMP && [:WATERSURFACE,:UNDERWATER].include?(@battle.FE) && move != nil && move.pbType(battler)==:WATER # lawds damp
		return true if move != nil && (move.function==0x166 || move.function==0x176 || move.function==0x200) # lawds solgalunacrozma signature moves ignore abilities
		return (battler.ability==:MOLDBREAKER || battler.ability==:TERAVOLT || battler.ability==:TURBOBLAZE)
	end

	def myceliumMightCheck(battler, move = @move)	# LAWDS - keeping this here in case i'm missing something but i'm like 95% sure that this is redundant given the redefinition of moldBreakerCheck above.
        return battler.ability==:MYCELIUMMIGHT && move.category == :status && @opponent.item != :ABILITYSHIELD # Gen 9 Mod - Added Mycelium Might & Ability Shield Check	
	end
	
	def unseenFistCheck(battler, move = @move)
		return battler.ability== :UNSEENFIST
	end

	def hydrationCheck(battler)
		return true if battler.ability== :HYDRATION && (@battle.pbWeather== :RAINDANCE || @battle.FE == :WATERSURFACE || @battle.FE == :UNDERWATER)
		return true if battler.ability== :WATERVEIL && (@battle.FE == :WATERSURFACE || @battle.FE == :UNDERWATER) # LAWDS - added check to water veil on those fields
		return true if battler.ability== :NATURALCURE && @battle.FE == :BEWITCHED # may not be hydration but it acts the same
	end
	# LAWDS - added a move and damage flags to check specific moves with this. also reordered some stuff
	def notOHKO?(attacker,opponent, immediate = false, move=-1, damage=-1)
		return true if attacker.isbossmon && attacker.shieldCount > 0 
		return true  if attacker.ability== :RESUSCITATION && attacker.form == 1
		return false if @battle.pbWeather == :HAIL && !(attacker.hasType?(:ICE) || [:ICEBODY,:SNOWCLOAK,:SLUSHRUSH,:LUNARIDOL,:MAGICGUARD,:OVERCOAT,:TEMPEST].include?(attacker.ability)) && !immediate
		return false if @battle.pbWeather == :SANDSTORM && !(attacker.hasType?(:ROCK) || attacker.hasType?(:GROUND) || attacker.hasType?(:STEEL) || [:SANDFORCE,:SANDRUSH,:DUSTDEVIL,:SANDVEIL,:MAGICGUARD,:OVERCOAT,:TEMPEST].include?(attacker.ability)) && !immediate
		return false if @battle.pbWeather == :SHADOWSKY && !(attacker.hasType?(:SHADOW) || [:MAGICGUARD,:OVERCOAT,:TEMPEST].include?(attacker.ability)) && !immediate
		return false if opponent.ability== :PARENTALBOND || opponent.ability== :SKILLLINK || opponent.ability== :DREADNOUGHT || opponent.crested == :TYPHLOSION || (opponent.crested == :FEAROW && move!=-1 && move.move==:SKILLLINK)# LAWDS corrected to opponent
		return false if (attacker.crested == :MAGMORTAR || attacker.pbPartner.crested == :MAGMORTAR || opponent.pbPartner.crested == :MAGMORTAR || opponent.crested == :MAGMORTAR) && !(attacker.hasType?(:FIRE) || [:FLASHFIRE, :STURDY, :MAGMAARMOR, :MAGICGUARD, :WELLBAKEDBODY, :BLAZE].include?(attacker.ability)) # LAWDS - magmortar crest
		if move == -1 # if no move is specified, it checks ALL moves. done when this function is being called for defensive purposes (i.e. 'am i guaranteed to live?') as opposed to finding whether a move can OHKO
			for thismove in opponent.moves
				# LAWDS - whoooole lot of checks here
				moveHitsMultiTimes = thismove.pbIsMultiHit || (opponent.crested == :TYPHLOSION && thismove.contactMove?) || (opponent.ability== :PARENTALBOND) ||
				(opponent.ability== :DREADNOUGHT && thismove.pbIsSpecial?) || (opponent.crested == :CINCCINO) || (opponent.crested == :LEDIAN && thismove.punchMove?) || 
				(opponent.ability== :DANCER && (@battle.FE == :SKY && opponent.pbOwnSide.effects[:Tailwind]!=0 && (PBStuff::DANCEMOVE).include?(thismove.move)))

				return false if moveHitsMultiTimes
				next if attacker.crested == :RAMPARDOS && (attacker.pokemon.rampCrestUsed == false)
				return false if attacker.hp != attacker.totalhp
				next if attacker.hasWorkingItem(:FOCUSSASH)
				next if @battle.FE == :CHESS && attacker.pokemon.piece==:PAWN && !attacker.damagestate.pawnsturdyused && @mondata.skill >= HIGHSKILL
				next if attacker.ability== :STURDY && !moldBreakerCheck(opponent,thismove)
				next if @battle.FE == :COLOSSEUM && attacker.ability== :STALWART && !moldBreakerCheck(opponent,thismove)
			end
			return false
		else
			moveHitsMultiTimes = move.pbIsMultiHit || (opponent.crested == :TYPHLOSION && move.contactMove?) || (opponent.ability== :PARENTALBOND) ||
			(opponent.ability== :DREADNOUGHT && move.pbIsSpecial?) || (opponent.crested == :CINCCINO) || (opponent.crested == :LEDIAN && move.punchMove?) || 
			(opponent.ability== :DANCER && (@battle.FE == :SKY && opponent.pbOwnSide.effects[:Tailwind]!=0 && (PBStuff::DANCEMOVE).include?(move.move)))
			return false if moveHitsMultiTimes # note - not actually a perfect check for rampardos
			return true  if attacker.crested == :RAMPARDOS && (attacker.pokemon.rampCrestUsed == false)
			return false if attacker.hp != attacker.totalhp
			return true  if attacker.hasWorkingItem(:FOCUSSASH)
			return true  if @battle.FE == :CHESS && attacker.pokemon.piece==:PAWN && !attacker.damagestate.pawnsturdyused && @mondata.skill >= HIGHSKILL
			return true	 if attacker.ability== :STURDY && !moldBreakerCheck(opponent,move)
			return true  if @battle.FE == :COLOSSEUM && attacker.ability== :STALWART && !moldBreakerCheck(opponent,move)
			return false
		end
	end

	def canGroundMoveHit?(battler,field=@battle.FE)
		return true if battler.item == :IRONBALL && field != :DEEPEARTH
		return true if battler.effects[:Ingrain]
		return true if battler.effects[:SmackDown]
		return false if [:MAGNETPULL,:CONTRARY,:UNAWARE,:OBLIVIOUS].include?(battler.ability) && field == :DEEPEARTH
		return true if @battle.state.effects[:Gravity]!=0
		return true if field == :CAVE
		return false if battler.hasType?(:FLYING) && battler.effects[:Roost]==false && field != :INVERSE
		return false if [:LEVITATE,:SOLARDIOL,:LUNARIDOL].include?(battler.ability)
		return false if [:SURGESURFER,:PUNKROCK].include?(battler.ability) && @battle.ProgressiveFieldCheck(PBFields::CONCERT,3,4)
		return false if battler.item == :AIRBALLOON && battler.itemWorks? && !battler.effects[:DesertsMark]
		return false if battler.effects[:MagnetRise]>0
		return false if battler.effects[:Telekinesis]>0
		return true
	  end

	  def secondaryEffectNegated?(move = @move, attacker = @attacker, opponent = @opponent)
		# lawds covert cloak protects partner
		return move.basedamage > 0 && (((opponent.ability== :SHIELDDUST || opponent.hasWorkingItem(:COVERTCLOAK) || (opponent.pbPartner.hp > 0 && opponent.pbPartner.hasWorkingItem(:COVERTCLOAK))) && !([0x1C,0x1D,0x1E,0x1F,0x20,0x2D,0x2F,0x147,0x186,0x307,0x103,0x105].include?(move.function))) || attacker.ability== :SHEERFORCE) # Gen 9 Mod - Added Covert Cloak and exception for Ceaseless Edge and Stone Axe functions
	  end

	  def seedProtection?(battler = @attacker)
		return battler.effects[:Protect] == :KingsShield || battler.effects[:Protect] == :BanefulBunker || battler.effects[:Protect] == :SpikyShield || battler.effects[:Protect] == :SilkTrap || battler.effects[:Protect] == :BurningBulwark
	  end

	def accuracyWeatherAbilityActive?(battler)
		return false # LAWDS - bypassing this method as it no longer applies
		return (battler.ability== :SANDVEIL && (@battle.pbWeather== :SANDSTORM || @mondata.skill >=BESTSKILL && (@battle.FE == :DESERT || @battle.FE == :ASHENBEACH))) ||
		(battler.ability== :SNOWCLOAK && (@battle.pbWeather== :HAIL || @mondata.skill >=BESTSKILL && (@battle.FE == :ICY || @battle.FE == :SNOWYMOUNTAIN)))
	end

	def firstOpponent(attacker=@attacker)
		return	@battle.doublebattle ? (attacker.pbOppositeOpposing.hp > 0 ? attacker.pbOppositeOpposing : attacker.pbCrossOpposing) : attacker.pbOppositeOpposing
	end

	# LAWDS - checks for any conditions that might block priority. some overlap with moveSuccessful? but this is already implemented so leave it for now. messy as hell but blargh
	def prioBlocked?(attacker=@attacker, opponent=@opponent)
		# again, attacker is the one being attacked and opponent is the one using the hypothetical priority move
		no_bright_block = !attacker.brightPowderPrioBlocks? # LAWDS - bright powder on bewitched
		no_prio_block_self = !([:DAZZLING,:ARMORTAIL,:QUEENLYMAJESTY].include?(attacker.ability) && !moldBreakerCheck(opponent))
		no_mirror_armor_block = !((attacker.ability== :MIRRORARMOR || attacker.pbPartner.ability== :MIRRORARMOR) && @battle.FE == :STARLIGHT && !moldBreakerCheck(opponent))
		no_prio_block_partner = !([:DAZZLING,:ARMORTAIL,:QUEENLYMAJESTY].include?(attacker.pbPartner.ability) && !moldBreakerCheck(opponent))
		no_prio_block_field = !((@battle.FE == :PSYTERRAIN) && !(attacker.isAirborne?))
		no_dcc_keeneye_block = !(@battle.FE==:DARKCRYSTALCAVERN && attacker.ability==:KEENEYE)
		return !(no_prio_block_self && no_prio_block_partner && no_prio_block_field && no_bright_block && no_mirror_armor_block && no_dcc_keeneye_block) 
	end
end

#####################################################
## Other Classes
#####################################################

class PokeBattle_Move_FFF < PokeBattle_Move	#Fake move used by AI to determine damage if no damaging AI memory move
	def initialize(battle,user,type)
		type = :QMARKS if !type
		@move = :FAKEMOVE
		@battle = battle
		hash = {
		:name 		 => "Fake Move",
		:function    => 0xFFF,
		:basedamage  => (user.level >= 40 ? 80 : [2*user.level,40].max),
		:type        => type,
		:effect		 => 0,
		:moreeffect  => 0,
		:category    => (user.attack>user.spatk ? 0 : 1),
		:accuracy    => 100,
		:target      => :SingleNonUser,
		:maxpp       => 15}
		@priority    = 0
		@zmove       = false
		@user        = user
		@data				 = MoveData.new(@move,hash)
		# these attributes do need to be assigned but we also need the data seperately for reasons (idk do we?)
		if @data
			@function   = @data.function
      		@type       = @data.type
      		@category   = @data.category
      		@basedamage = @data.basedamage
      		@accuracy   = @data.accuracy
      		@maxpp      = @data.maxpp
      		@target     = @data.target
			@effect     = @data.checkFlag?(:effect,0)
			@moreeffect = @data.checkFlag?(:moreeffect,0)
		end
		# LAWDS initialize a default matchup array
		basicmatchuparray = Array.new(@battle.party1.length,0.25)
		@AI_Matchup_Spread = Array.new(@battle.party2.length,basicmatchuparray)
	end
end

class PokeBattle_AI_Info #info per battler for debuglogging
	attr_accessor :battler_name
	attr_accessor :battler_item
	attr_accessor :battler_ability
	attr_accessor :field_effect
	attr_accessor :items
	attr_accessor :items_scores
	attr_accessor :switch_scores
	attr_accessor :switch_name
	attr_accessor :should_switch_score
	attr_accessor :move_names
	attr_accessor :init_score_moves
	attr_accessor :final_score_moves
	attr_accessor :chosen_action
	attr_accessor :opponent_name
	attr_accessor :expected_damage
	attr_accessor :expected_damage_name
	attr_accessor :battler_hp_percentage

	def initialize
		@battler_name								= ""
		@battler_item								= ""
		@battler_ability							= ""
		@battler_hp_percentage						= 0
		@field_effect								= 0
		@items 										= []
		@items_scores 								= []
		@switch_scores 								= []
		@switch_name 								= []
		@should_switch_score						= 0
		@move_names									= []
		@opponent_name								= []
		@init_score_moves							= []
		@final_score_moves							= []
		@chosen_action								= ""
		@expected_damage							= []
		@expected_damage_name						= []
	end

	def reset(battler)
		@battler_name								= battler.nil? ? "" : battler.name
		@battler_item								= battler.nil? || battler.item.nil? ? "" : getItemName(battler.item)
		@battler_ability							= battler.nil? || battler.ability.nil? ? "" : getAbilityName(battler.ability)
		@battler_hp_percentage						= (battler.hp*100.0 / battler.totalhp).round(1)
		@field_effect								= battler.battle.FE
		@items 										= []
		@items_scores 								= []
		@switch_scores 								= []
		@switch_name 								= []
		@should_switch_score						= 0
		@move_names 								= []
		@opponent_name								= []
		@init_score_moves							= []
		@final_score_moves							= []
		@chosen_action								= ""
		@expected_damage							= []
		@expected_damage_name						= []
	end

	def logAIScorings()
		return if !$INTERNAL
		to_be_printed = "\n ______________________________________________________________________________ \n"
		to_be_printed += "Scoring for battler: " + @battler_name + " , HP percentage: #{@battler_hp_percentage} %\n"
		to_be_printed += "Held Item: " + @battler_item + " , Ability: " + @battler_ability + " , Field: " + PokeBattle_Field.getFieldName(@field_effect).to_s + "\n"
		to_be_printed += " "*60 +  +"|AI Scores\n"
	
		#Add scores for current hp and the expected damage it will take
		@expected_damage.each_with_index {|_,i|
		to_be_printed += "Expected Damage taken from #{@expected_damage_name[i]}".ljust(60) + "|#{@expected_damage[i]} % \n"
		}
		to_be_printed += "\n"
	
		#Add scores for items and switching to string
		to_be_printed += "Scoring for Switching to other mon".ljust(60) + "|"  + "#{@should_switch_score} \n \n"
		to_be_printed += "Scoring for items".ljust(60) + "|".ljust(21) + "| \n"	if @items.length != 0
		@items.each_with_index {|item_name, index|
		to_be_printed += item_name.ljust(60) + "|" + @items_scores[index].to_s.ljust(20) + "\n"
		}
		
		# Sort the move order so moves are grouped together
		@opponent_name.sort_by!.with_index{|_,i|@move_names[i]}
		@init_score_moves.sort_by!.with_index{|_,i|@move_names[i]}
		@final_score_moves.sort_by!.with_index{|_,i|@move_names[i]}
		@move_names.sort!

		# Now add these badboys to the string
		@move_names.each_with_index {|movename,index|
		to_be_printed += "#{movename} vs #{@opponent_name[index]}, Init scoring move: ".ljust(60) + "|#{@init_score_moves[index]} \n"
		to_be_printed += "#{movename} vs #{@opponent_name[index]}, Final scoring move: ".ljust(60) +"|#{@final_score_moves[index]} \n"
		to_be_printed += "\n"
		}
		to_be_printed += "Final action chosen:".ljust(60) + "|#{@chosen_action}".ljust(20)
		to_be_printed += "\n ______________________________________________________________________________ \n"
	
		#put to console
		#$stdout.print(to_be_printed)
		PBDebug.log(to_be_printed)
	end
	
	def logAISwitching()
		return if !$DEBUG
		to_be_printed = "Scoring for switching from: " + @battler_name + "\n"
		to_be_printed += " "*60 +"|New AI\n"
		@switch_name.each_with_index {|name, index|
			to_be_printed += "Score for switching to #{name}".ljust(60) + "|#{@switch_scores[index]} \n"
		}
		to_be_printed += "Switch chosen = ".ljust(60) + "|#{@switch_name[@switch_scores.index(@switch_scores.max)]} \n"
		to_be_printed += "\n ______________________________________________________________________________ \n"
		#$stdout.print(to_be_printed)
		PBDebug.log(to_be_printed)
	end
end



